package spc.webos.cache;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class MapCache extends AbstractCache
{
	Map cache = new ConcurrentHashMap();

	public Collection getKeys()
	{
		return cache.keySet();
	}

	public int size()
	{
		return cache.size();
	}

	public Object poll(Object key)
	{
		Object v = get(key);
		remove(key);
		return v;
	}

	public void removeAll()
	{
		cache.clear();
	}

	public Object get(Object key)
	{
		return cache.get(key);
	}

	public Object put(Object key, Object o)
	{
		return cache.put(key, o);
	}

	public Object remove(Object o)
	{
		return cache.remove(o);
	}

	public void put(String key, Object obj, long expireSeconds) throws Exception
	{
	}

	public Object get(String key, boolean browse)
	{
		return null;
	}
}
