package spc.webos.persistence.stat;

/**
 * sql��ִ��ʱ��
 * 
 * @author spc
 * 
 */
public class SqlCostTime
{
	String model; // ģ��
	String id; // ģ���е�id
	String fastSql; // ��ǰsqlִ������sql���
	String slowSql; // ������sql���
	int fastCost = 100000; // ���ʱ��
	int slowCost = -1; // ����ʱ��
	int times; // ��sqlִ�еĴ���
	long totalCost; // ��ʱ��
	int failTimes;

	public SqlCostTime()
	{
	}

	public SqlCostTime(String sqlId, String sql, int cost, boolean success)
	{
		String voprefix = "class";
		int index = sqlId.startsWith(voprefix) ? sqlId.lastIndexOf('_') : sqlId.indexOf('_');
		if (index < 0) index = sqlId.startsWith(voprefix) ? sqlId.lastIndexOf('.') : sqlId
				.indexOf('.');
		model = sqlId.substring(0, index);
		id = sqlId.substring(index + 1);
		add(sql, cost, success);
	}

	public void add(String sql, int cost, boolean success)
	{
		times++;
		if (!success) failTimes++;
		totalCost += cost;
		if (cost > slowCost)
		{
			slowCost = cost;
			slowSql = sql;
		}
		if (cost < fastCost)
		{
			fastCost = cost;
			fastSql = sql;
		}
	}

	public String toString()
	{
		return toJson().toString();
	}

	public StringBuffer toJson()
	{
		StringBuffer buf = new StringBuffer();
		buf.append("{model:'");
		buf.append(model);
		buf.append("',id:'");
		buf.append(id);
		buf.append("',fastSql:\"");
		if (fastSql != null) buf.append(fastSql.replace('"', '\''));
		buf.append("\",slowSql:\"");
		if (slowSql != null) buf.append(slowSql.replace('"', '\''));
		buf.append("\",slowCost:'");
		buf.append(slowCost);
		buf.append("',fastCost:'");
		buf.append(fastCost);
		buf.append("',times:'");
		buf.append(times);
		buf.append("',failTimes:'");
		buf.append(failTimes);
		buf.append("',totalCost:'");
		buf.append(totalCost);
		buf.append("'}");
		return buf;
	}

	public String getModel()
	{
		return model;
	}

	public void setModel(String model)
	{
		this.model = model;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getFastSql()
	{
		return fastSql;
	}

	public void setFastSql(String fastSql)
	{
		this.fastSql = fastSql;
	}

	public String getSlowSql()
	{
		return slowSql;
	}

	public void setSlowSql(String slowSql)
	{
		this.slowSql = slowSql;
	}

	public int getFastCost()
	{
		return fastCost;
	}

	public void setFastCost(int fastCost)
	{
		this.fastCost = fastCost;
	}

	public int getSlowCost()
	{
		return slowCost;
	}

	public void setSlowCost(int slowCost)
	{
		this.slowCost = slowCost;
	}

	public int getTimes()
	{
		return times;
	}

	public void setTimes(int times)
	{
		this.times = times;
	}

	public long getTotalCost()
	{
		return totalCost;
	}

	public void setTotalCost(long totalCost)
	{
		this.totalCost = totalCost;
	}
}
