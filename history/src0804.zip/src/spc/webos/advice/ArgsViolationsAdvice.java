package spc.webos.advice;

import java.lang.reflect.Method;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validation;
import javax.validation.Validator;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * aop��֤spring������service�ӿڵ���ʱ�����Ϸ���
 * 
 * @author chenjs
 *
 */
public class ArgsViolationsAdvice
{
	protected Logger log = LoggerFactory.getLogger(getClass());
	protected Validator validator = Validation.buildDefaultValidatorFactory().getValidator();

	public Object validate(ProceedingJoinPoint jp) throws Throwable
	{
		MethodSignature sig = (MethodSignature) jp.getSignature();
		Method m = sig.getMethod();
		log.debug("validate args of method:{}", m);
		Set<ConstraintViolation<Object>> violations = validator.forExecutables()
				.validateParameters(jp.getTarget(), m, jp.getArgs());
		for (Object arg : jp.getArgs())
			if (arg != null) violations.addAll(validator.validate(arg));
		if (!violations.isEmpty()) throw new ConstraintViolationException(
				"Failed to validate: " + m + ", cause: " + violations, violations);
		return jp.proceed();
	}
}
