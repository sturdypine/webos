package spc.webos.util.tree;

public interface ITreeNodeValue
{
	Object getId();

	Object getParentId();

	String getNodeText();

	boolean isRoot();
}
