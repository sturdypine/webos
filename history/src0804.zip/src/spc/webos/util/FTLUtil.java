package spc.webos.util;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

import freemarker.cache.ClassTemplateLoader;
import freemarker.cache.FileTemplateLoader;
import freemarker.cache.MultiTemplateLoader;
import freemarker.cache.TemplateLoader;
import freemarker.ext.beans.BeansWrapper;
import freemarker.template.Configuration;
import freemarker.template.DefaultObjectWrapper;
import freemarker.template.Template;
import spc.webos.config.AppConfig;
import spc.webos.constant.Common;
import spc.webos.message.AppMessageSource;
import spc.webos.message.DictMessageSource;
import spc.webos.model.FTLPO;
import spc.webos.persistence.IPersistence;
import spc.webos.service.IService;
import spc.webos.web.common.ISessionUserInfo;

public class FTLUtil
{
	final static Logger log = LoggerFactory.getLogger(FTLUtil.class);
	SpringUtil springUtil = SpringUtil.getInstance();
	String[] templateLocations; // ģ��·��
	Configuration ftlCfg; // ����ϵͳ��ftl��������
	Map ftlCache = new HashMap(); // 800, ��DB�ȵط���ȡ��ftl
	static FTLUtil util = new FTLUtil();

	public static FTLUtil getInstance()
	{
		return util;
	}

	public void setSpringUtil(SpringUtil springUtil)
	{
		this.springUtil = springUtil;
	}

	public void setFtlCache(Map cache)
	{
		ftlCache = (cache == null ? new HashMap() : cache);
	}

	public Map getFtlCache()
	{
		return ftlCache;
	}

	public void addFtl(String id, Template t)
	{
		ftlCache.put(id, t);
	}

	public Configuration getFtlCfg()
	{
		return ftlCfg;
	}

	public void setFtlCfg(Configuration ftlCfg)
	{
		this.ftlCfg = ftlCfg;
	}

	public Map loadFTLInDB(IPersistence persistence) throws IOException
	{
		Map cache = new HashMap();
		List ftls = null;
		try
		{
			ftls = persistence.get(new FTLPO());
		}
		catch (Exception e)
		{
			log.info("fail to load FTL in DB:" + e);
		}
		if (ftls == null) return cache;
		Configuration cfg = new Configuration();
		cfg.setNumberFormat("0");
		for (int i = 0; i < ftls.size(); i++)
		{
			FTLPO vo = (FTLPO) ftls.get(i);
			cache.put(vo.getId(), new Template(vo.getId(), new StringReader(vo.getFtl()), cfg));
		}
		if (log.isInfoEnabled()) log.info("FTL in DB: " + cache.keySet());
		setFtlCache(cache);
		return cache;
	}

	public static String freemarker(String t, Map root) throws Exception
	{
		StringWriter sw = new StringWriter();
		Configuration cfg = new Configuration();
		cfg.setNumberFormat("0");
		freemarker(new Template("ftlutil", new StringReader(t), cfg), root, sw);
		return sw.toString();
	}

	public static String freemarker(Template t, Map root) throws Exception
	{
		StringWriter sw = new StringWriter();
		freemarker(t, root, sw);
		return sw.toString();
	}


	public static Map<String, Object> freemarker(Map<String, Object> root)
	{
		if (root == null) root = new HashMap<>();
		// root.put(Common.MODEL_SERVICE_KEY,
		// SystemUtil.getInstance().getServices());
		root.put(Common.MODEL_SERVICE_KEY, IService.SERVICES_PROXY);
		root.put(Common.MODEL_ROOT_KEY, root);
		root.put(Common.MODEL_STATICS_KEY, BeansWrapper.getDefaultInstance().getStaticModels());
		root.put(Common.MODEL_ENUMS_KEY, BeansWrapper.getDefaultInstance().getEnumModels());
		if (ISessionUserInfo.SUI.get() != null)
			root.put(Common.MODEL_SUI_KEY, ISessionUserInfo.SUI.get());
		root.put(Common.MODEL_APP_CFG_KEY, AppConfig.getInstance().getConfig());
		root.put(Common.MODEL_SYS_UTIL_KEY, SpringUtil.getInstance());
		// root.put(Common.MODEL_FILE_UTIL_KEY, FileUtil.getInstance()); //
		// 2015-11-18 ȡ���ļ�����
		root.put(Common.MODEL_JSON_UTIL_KEY, JsonUtil.getInstance());
		// root.put(Common.MODEL_REPORT_UTIL_OLD_KEY, ReportUtil.getInstance());
		root.put(Common.MODEL_REPORT_UTIL_KEY, ReportUtil.getInstance());
		root.put(Common.MODEL_STRINGX_KEY, StringX.STRINGX);
		root.put(Common.MODEL_DICT_KEY, DictMessageSource.getInstance().getDict());
		root.put(Common.MODEL_APPMS, AppMessageSource.getInstance().getDict());
		root.put(Common.MODEL_CALENDAR, Calendar.getInstance());
		return root;
	}

	public static Writer freemarker(Template t, Map root, Writer writer) throws Exception
	{
		t.process(freemarker(root), writer);
		return writer;
	}

	public static String ftl(String id, Map root) throws Exception
	{
		StringWriter sw = new StringWriter();
		freemarker(id, root, sw);
		return sw.toString();
	}

	public static Writer freemarker(String templateId, Map root, Writer writer) throws Exception
	{
		// 1. from db cache
		Template t = (Template) getInstance().ftlCache.get(templateId);
		// 2. from local disk
		if (t == null) t = getInstance().getFtlCfg().getTemplate(templateId + ".ftl");
		return freemarker(t, root, writer);
	}

	// 2012-09-01 for FTL �ж�һ�������Ƿ�ΪMap����
	public static boolean isMap(Object o)
	{
		return o instanceof Map;
	}

	public static boolean isList(Object o)
	{
		return o instanceof List;
	}

	@PostConstruct
	public void init() throws Exception
	{
		if (templateLocations == null) return;
		if (ftlCfg == null)
		{
			ftlCfg = new Configuration();
			ftlCfg.setDefaultEncoding(Common.CHARSET_UTF8);
		}
		ftlCfg.setNumberFormat("0"); // 2012-09-01 ��������������ֵ${age}����1000�����������
		List loaders = new ArrayList();
		try
		{ // ��Щ��web�����, ����Ҫspring��������Ϣ
			loaders.add(new ClassTemplateLoader(FreeMarkerConfigurer.class, StringX.EMPTY_STRING));
		}
		catch (Throwable t)
		{
		}
		loaders.add(new ClassTemplateLoader(SpringUtil.class, "/"));

		// class path �µ�ģ��
		for (String location : templateLocations)
		{
			Resource path = springUtil.getResourceLoader().getResource(location);
			File file = path.getFile();
			log.info("ftl path:{}", file.getAbsolutePath());
			loaders.add(new FileTemplateLoader(file));
		}

		MultiTemplateLoader mtl = new MultiTemplateLoader(
				(TemplateLoader[]) loaders.toArray(new TemplateLoader[loaders.size()]));
		ftlCfg.setTemplateLoader(mtl);
		ftlCfg.setObjectWrapper(new DefaultObjectWrapper());

		// ���ʱ��ģ�������µ�ʱ����, ����Ϊ��λ ����������,��ʱ��������ô�����6*60*60(S), ����ʱ���������С�����2(S),
		// default is 5 s
		log.info("product: {}  for set ftl update_daly...", AppConfig.isProductMode());
		ftlCfg.setSetting(Configuration.TEMPLATE_UPDATE_DELAY_KEY,
				AppConfig.isProductMode() ? "999999999" : "0");
	}

	public void setTemplateLocations(String[] templateLocations)
	{
		this.templateLocations = templateLocations;
	}
}
