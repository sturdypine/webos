package spc.webos.web.filter.security;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringEscapeUtils;

import spc.webos.constant.AppRetCode;
import spc.webos.constant.Common;
import spc.webos.constant.Web;
import spc.webos.exception.AppException;
import spc.webos.service.seq.UUID;
import spc.webos.service.seq.impl.TimeMillisUUID;
import spc.webos.util.LogUtil;
import spc.webos.util.StringX;
import spc.webos.web.common.ISessionUserInfo;
import spc.webos.web.controller.VerifyImageCtrller;
import spc.webos.web.filter.AbstractURLFilter;
import spc.webos.web.view.ExceptionView;

public class URLSecurityFilter extends AbstractURLFilter
{
	protected int maxInactiveInterval = 72000; // ���sessionʱ��Ϊ20��Сʱ
	protected AntPathBasedFilterDefinitionMap source = new AntPathBasedFilterDefinitionMap();
	protected AntPathBasedFilterDefinitionMap errPageSource = new AntPathBasedFilterDefinitionMap();
	protected String suiClazz = "spc.webos.web.common.SessionUserInfo";
	protected String[] loginUriPrefix = { "/js/login/login" };
	// ��־׷����Ϣ��ʽ��0: userCode+":"+counts, mvc
	// 1��session id+counts,mvc:+userCode,
	protected int logMode;
	protected UUID uuid;
	public final static String AUTH_ANONYMOUS = "public"; // ����Ȩ��
	public final static String MUST_LOGIN = "login";

	public void filter(ServletRequest request, ServletResponse response, FilterChain chain,
			String patternURL) throws IOException, ServletException
	{
		HttpServletRequest req = new XssHttpServletRequestWrapper((HttpServletRequest) request); // ��ֹxss����
		HttpServletResponse res = (HttpServletResponse) response;
		String uri = getUri(req);
		// ������־׷����Ϣ
		boolean set = false;
		if (uuid != null) set = LogUtil.setTraceNo(String.valueOf(uuid.uuid()), uri, false);
		ISessionUserInfo sui = createSUI(req, res, uri); // ��õ�ǰ�߳��û�������Ϣ

		if (set) set = true; // ����Ѿ�ʹ��uuid���óɹ�
		else if (logMode == 0)
			set = LogUtil.setTraceNo(sui.getUserCode() + ":" + sui.requestCount(), uri, false);
		else set = LogUtil.setTraceNo(sui.session().getId() + ":" + sui.requestCount(),
				sui.getUserCode(), false);
		try
		{ // ��ȫ��鵱ǰ�û��Ƿ���Է���uri
			security(req, response, chain, uri, sui);
		}
		catch (Exception e)
		{
			errorPage(req, res, uri, e);
		}
		finally
		{
			if (set) LogUtil.removeTraceNo();
			ISessionUserInfo.SUI.set(null); // ��յ�ǰ�̵߳ĵĵ�¼��������ֹ�̻߳����Ĳ���
		}
	}

	protected void security(ServletRequest request, ServletResponse response, FilterChain chain,
			String uri, ISessionUserInfo sui) throws IOException, ServletException
	{
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;

		String remoteHost = req.getRemoteHost();
		if (sui != null && !remoteHost.equals(sui.getLoginIP()))
		{ // ��ǰ�����IP���ǵ�¼IP
			log.info("{} is not login IP {}", remoteHost, sui.getLoginIP());
			errorPage(req, res, uri, new AppException(AppRetCode.UN_LOGIN_IP));
			return;
		}

		List<String> validRoles = source.lookupAttributes(uri); // ����ܺϷ������URI�Ľ�ɫ,����
		log.debug("validRoles:{}, by:{}", validRoles, (sui == null ? "" : sui.getUserCode()));
		String method = req.getMethod().toLowerCase(); // ��ǰ��Դ�Ƿ����˺Ϸ�����ʽget/post
		if (!validRoles.contains(method))
		{
			log.info("method:{} unvalid for uri:{}", method, uri);
			errorPage(req, res, uri,
					new AppException(AppRetCode.URL_SECURIY, new Object[] { method }));
			return;
		}
		if (validRoles.contains(AUTH_ANONYMOUS))
		{ // ���õ�½���ܷ��ʵ���Դ
			chain.doFilter(request, response);
			return;
		}
		if (sui == null || sui.getUserCode() == null)
		{
			log.info("sui is null or usercode is null:{}", uri);
			errorPage(req, res, uri,
					new AppException(AppRetCode.URL_SECURIY, new Object[] { MUST_LOGIN }));
			return;
		}
		if (validRoles.contains(MUST_LOGIN))
		{ // ֻ��Ҫ��½���ܷ��ʵ���Դ
			chain.doFilter(request, response);
			return;
		}
		// �ж�Ȩ��, �Ƿ����������URL
		// 1. ���ǰ�õķǷ����ʵ���Դ�Ľ�ɫ
		List<String> unValidRoles = source.lookupAttributes('-' + uri); // ��ò��ܺϷ������URI�Ľ�ɫ,����
		if (unValidRoles.size() > 0)
		{
			int unValidTimes = 0;
			for (int i = 0; i < unValidRoles.size(); i++)
			{// ˵������Դ�ǵ�ǰ��ɫ���ܷ��ʵ�, ����һ���˿���ӵ�ж����ɫ, ֻ������ӵ�еĽ�ɫ�����ܷ��ʲ���˵�����ܷ���
				if (sui.containRole(unValidRoles.get(i))) unValidTimes++;
			}
			if (unValidTimes > 0)
			{ // ������ӵ�е����н�ɫ�����ܷ��ʴ�ģ��
				request.setAttribute(Web.RESP_ATTR_ERROR_KEY, Boolean.TRUE);
				log.info("no right to visit some resource:{}", uri);
				errorPage(req, res, uri, new AppException(AppRetCode.URL_SECURIY));
				return;
			}
		}

		// 2. ��úϷ���ԴȨ��
		for (int i = 0; i < validRoles.size(); i++)
		{
			if (sui.containRole(validRoles.get(i)))
			{ // ����Դ��Ȩ�ޱ�����ӵ��, ��Ϸ�ͨ��
				chain.doFilter(request, response);
				return;
			}
		}
		// û��ͨ���� 2 ������Դ����Ϸ����. �ض�λ����½ҳ��
		log.info("no right to visit {}", uri);
		request.setAttribute(Web.RESP_ATTR_ERROR_KEY, Boolean.TRUE);
		errorPage(req, res, uri, new AppException(AppRetCode.URL_SECURIY));
	}

	protected ISessionUserInfo createSUI(HttpServletRequest req, HttpServletResponse res,
			String uri)
	{
		ISessionUserInfo.SUI.set(null); // ��յ�ǰ�̵߳ĵĵ�¼��������ֹ�ϴ��̻߳����Ĳ���

		boolean loginUri = StringX.contain(loginUriPrefix, uri, true);
		HttpSession session = req.getSession(loginUri); // ֻ�е�¼url���ܴ���session
		if (loginUri) log.info("create session:{}, maxInactiveInterval:{}, uri:{}", session.getId(),
				maxInactiveInterval, uri);
		ISessionUserInfo sui = null;
		if (session != null)
			sui = (ISessionUserInfo) session.getAttribute(ISessionUserInfo.USER_SESSION_INFO_KEY);

		String method = req.getMethod();
		String remoteHost = req.getRemoteHost();
		String user = sui == null ? "" : StringX.null2emptystr(sui.getUserCode());
		if ("GET".equalsIgnoreCase(method)) log.info("{} {} session:{}, {} {}?{}", user, remoteHost,
				(session != null), method, uri, StringX.null2emptystr(req.getQueryString()));
		else log.info("{} {} session:{}, {} {}, len:{}", user, remoteHost, (session != null),
				method, uri, req.getContentLength());

		try
		{
			if (sui == null && loginUri)
			{ // �״ε�½����Ҫ����session��Ϣ
				log.info("user login, sui clazz:{}", suiClazz);
				sui = (ISessionUserInfo) (Class.forName(suiClazz, false,
						Thread.currentThread().getContextClassLoader())).newInstance();
				sui.setLoginDt(new Date()); // ��¼ʱ��
				sui.setLoginIP(remoteHost); // ��¼�ͻ���IP
				sui.setUrlKey(String.valueOf(Math.random()).substring(2));
				session.setMaxInactiveInterval(maxInactiveInterval); // session�Ự���ʱ��
				session.setAttribute(ISessionUserInfo.USER_SESSION_INFO_KEY, sui);
				setVerifyCode(req, res, session, sui);
			}
			if (sui != null)
			{ // ���״ε�½���޸ĵ�ǰsession��Ϣ
				sui.request(session, uri); // �Ǽ�һ�ε�¼��Ϣ
				sui.setLastVisitDt(new Date());
				sui.removeExpiredTransient();
				ISessionUserInfo.SUI.set(sui); // ���SessionUserInfo����ThreadLocal����ȥ
			}
		}
		catch (Exception e)
		{
			log.error("create user session fail:: uri: " + uri + ", remote: " + req.getRemoteAddr(),
					e);
		}
		return sui;
	}

	protected void setVerifyCode(HttpServletRequest req, HttpServletResponse res,
			HttpSession session, ISessionUserInfo sui)
	{
		String verifyCode = (String) session
				.getAttribute(VerifyImageCtrller.VERIFY_IMG_SESSION_KEY);
		if (verifyCode != null)
		{ // ��½ʱ�������֤�룬������֤����Ϣ
			sui.setVerifyCode(verifyCode);
			session.removeAttribute(VerifyImageCtrller.VERIFY_IMG_SESSION_KEY);
		}
	}

	protected void errorPage(HttpServletRequest req, HttpServletResponse res, String uri,
			Exception ex) throws IOException
	{
		String redirect = req.getContextPath();
		List<String> handler = errPageSource.lookupAttributes(uri);
		log.info("err page:{}, uri:{}, ex:{}", handler, uri, ex.toString());
		if (handler == null || handler.size() == 0) redirect = req.getContextPath();
		else if ("json".equalsIgnoreCase(handler.get(0)))
		{ // json Ӧ��
			Map model = new HashMap();
			model.put(Common.MODEL_EXCEPTION, ex);
			new ExceptionView(handler.get(1), Common.FILE_JSON_CONTENTTYPE).render(model, req, res);
			return;
		}
		else if ("redirect".equalsIgnoreCase(handler.get(0))) redirect = handler.get(1);
		log.info("redirect to {}, uri:{}", redirect, uri);
		res.sendRedirect(redirect);
	}

	/**
	 * ������õ�Url��Դ��Ӧ��Ȩ�� or ��ɫ or ����ģ����Ϣ
	 * 
	 * @param s
	 */
	public void setDefinitionSource(String s)
	{
		setDefinitionMap(source, s);
	}

	public void setSuiClazz(String suiClazz)
	{
		this.suiClazz = suiClazz;
	}

	public void setMaxInactiveInterval(int maxInactiveInterval)
	{
		this.maxInactiveInterval = maxInactiveInterval;
	}

	public void setLoginUriPrefix(String[] loginUriPrefix)
	{
		this.loginUriPrefix = loginUriPrefix;
	}

	public void setLogMode(int logMode)
	{
		this.logMode = logMode;
	}

	public void setUuid(UUID uuid)
	{
		this.uuid = uuid;
	}

	public void setUuidWorkId(int workId)
	{
		this.uuid = new TimeMillisUUID(workId);
	}

	public void setErrPageSource(String s)
	{
		setDefinitionMap(errPageSource, s);
	}
}

class XssHttpServletRequestWrapper extends HttpServletRequestWrapper
{
	public XssHttpServletRequestWrapper(HttpServletRequest servletRequest)
	{
		super(servletRequest);
	}

	public String[] getParameterValues(String parameter)
	{
		String[] values = super.getParameterValues(parameter);
		if (values == null) return null;
		int count = values.length;
		String[] encodedValues = new String[count];
		for (int i = 0; i < count; i++)
			encodedValues[i] = StringEscapeUtils.escapeHtml4(values[i]);
		return encodedValues;
	}

	public String getParameter(String parameter)
	{
		String value = super.getParameter(parameter);
		if (value == null) return null;
		return StringEscapeUtils.escapeHtml4(value);
	}

	public String getHeader(String name)
	{
		String value = super.getHeader(name);
		if (value == null) return null;
		return StringEscapeUtils.escapeHtml4(value);
	}
}
