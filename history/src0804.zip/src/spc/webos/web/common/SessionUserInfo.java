package spc.webos.web.common;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.http.HttpSession;

import spc.webos.model.UserPO;

public class SessionUserInfo implements ISessionUserInfo, Serializable, Cloneable
{
	private static final long serialVersionUID = 1L;
	// ����Ա������Ϣ
	protected List<String> roles; // ��ɫID
	// ����Ա��½�Ŀͻ�����Ϣ
	protected String loginIP; // ��½��IP
	protected Date loginDt; // ��½ʱ��
	protected Date lastVisitDt; // ��һ�η��ʷ�����ʱ��
	protected String verifyCode;

	protected UserPO user;
	protected transient Map<String, TransientInSession> transientParams = new HashMap<String, TransientInSession>();
	protected Map<String, Serializable> permanence = new HashMap<String, Serializable>();
	protected String urlKey; // ����ǩ��GET��ʽ��url����ֹ�ͻ����Լ�����
	protected String uri;

	protected transient HttpSession session; // ��ǰ�û���session
	protected AtomicInteger requestCount = new AtomicInteger(0);

	// ����һ��request���������ڲ������� Ҳ����ͳ�Ƶ�ǰ�û����������
	public void request(HttpSession session, String uri)
	{
		this.session = session;
		requestCount.incrementAndGet();
		this.uri = uri;
	}

	// �ͻ��˶��߳�����ʱ�����ܵ�ǰ�̶߳�ζ�ȡ�����в�һ��
	public int requestCount()
	{
		return requestCount.get();
	}

	public void setInPermanence(String key, Serializable value)
	{
		permanence.put(key, value);
	}

	public Object getInPermanence(String key)
	{
		return permanence.get(key);
	}

	public void setTransientInSession(String key, TransientInSession tis)
	{
		transientParams.put(key, tis);
	}

	public void setTransientInSession(String key, Serializable value)
	{
		transientParams.put(key, new TransientInSession(value));
	}

	public Object getTransient(String key)
	{
		TransientInSession tis = transientParams.get(key);
		return tis == null ? null : tis.value();
	}

	public TransientInSession getTransientInSession(String key)
	{
		return transientParams.get(key);
	}

	public void setVerifyCode(String verifyCode)
	{
		this.verifyCode = verifyCode;
	}

	public String getVerifyCode()
	{
		return this.verifyCode;
	}

	public String getLoginIP()
	{
		return loginIP;
	}

	public void setLoginIP(String loginIP)
	{
		this.loginIP = loginIP;
	}

	public String getUserCode()
	{
		return user == null ? null : user.getCode();
	}

	public List<String> getRoles()
	{
		return roles;
	}

	public boolean containRole(String role)
	{
		for (String r : roles)
			if (r.startsWith(role)) return true;
		return false;
	}
	
	public boolean containSqlId(String sqlId, Map param)
	{
		return true;
	}

	public void removeExpiredTransient()
	{
		if (transientParams == null) transientParams = new HashMap<String, TransientInSession>();
		if (this.transientParams.size() == 0) return;
		long currentTimeMillis = System.currentTimeMillis();
		for (String key : transientParams.keySet())
		{
			TransientInSession tis = getTransientInSession(key);
			if (tis.isExpired(currentTimeMillis)) transientParams.remove(key);
		}
	}

	public String getUrlKey()
	{
		return urlKey;
	}

	public void setRoles(List<String> roles)
	{
		this.roles = roles;
	}

	public HttpSession session()
	{
		return session;
	}

	public Date getLoginDt()
	{
		return this.loginDt;
	}

	public void setLoginDt(Date loginDate)
	{
		this.loginDt = loginDate;
	}

	public UserPO getUser()
	{
		return user;
	}

	public void setUser(UserPO user)
	{
		this.user = user;
	}

	public Map<String, TransientInSession> getTransientParams()
	{
		return transientParams;
	}

	public Date getLastVisitDt()
	{
		return lastVisitDt;
	}

	public void setLastVisitDt(Date lastVisitDt)
	{
		this.lastVisitDt = lastVisitDt;
	}

	public Map<String, Serializable> getPermanence()
	{
		return permanence;
	}

	public void setUrlKey(String urlKey)
	{
		this.urlKey = urlKey;
	}

	public AtomicInteger getRequestCount()
	{
		return requestCount;
	}

	public void setRequestCount(AtomicInteger requestCount)
	{
		this.requestCount = requestCount;
	}

	public String getUri()
	{
		return uri;
	}

	public void setUri(String uri)
	{
		this.uri = uri;
	}
}
