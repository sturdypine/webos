package spc.webos.web.view;

import java.io.ByteArrayOutputStream;
import java.io.OutputStreamWriter;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.View;

import spc.webos.constant.Common;
import spc.webos.constant.Web;
import spc.webos.util.FTLUtil;
import spc.webos.util.PDFUtil;
import spc.webos.util.StringX;

public class PDFView implements View
{
	protected Logger log = LoggerFactory.getLogger(getClass());
	@Resource
	protected ExceptionView exView;

	public String getContentType()
	{
		return Common.FILE_PDF_CONTENTTYPE;
	}

	public void render(Map model, HttpServletRequest request, HttpServletResponse response)
			throws Exception
	{
		response.setContentType(getContentType());
		String template = (String) model.get(Web.REQ_KEY_TEMPLATE_ID); // ���õ�ģ��ID
		if (StringX.nullity(template)) template = (String) model.get(Web.REQ_KEY_VIEW_NAME_SKEY); // ���õ�page

		log.info("pdf template:{}", template);
		try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
				OutputStreamWriter osw = new OutputStreamWriter(baos))
		{
			FTLUtil.freemarker(template, model, osw);
			PDFUtil.createPdf(response.getOutputStream(), baos.toByteArray());
		}
		catch (Exception e)
		{ // ����ڴ���html, pdf���쳣��������쳣����view
			model.put(Common.MODEL_EXCEPTION, e);
			exView.render(model, request, response);
		}
	}

	public void setExView(ExceptionView exView)
	{
		this.exView = exView;
	}
}
