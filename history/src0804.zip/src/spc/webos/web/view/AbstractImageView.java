package spc.webos.web.view;

import Acme.JPM.Encoders.GifEncoder;
import com.bigfoot.bugar.image.PNGEncoder;
import com.sun.image.codec.jpeg.JPEGImageEncoder;
import java.awt.image.BufferedImage;
import java.util.Map;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.View;
import sun.awt.image.codec.JPEGImageEncoderImpl;

public abstract class AbstractImageView implements View
{
	public void render(Map model, HttpServletRequest request, HttpServletResponse response)
			throws Exception
	{
		Integer intWidth = (Integer) model.get(IMAGE_WIDTH);
		Integer intHeight = (Integer) model.get(IMAGE_HEIGHT);
		int width = (intWidth == null) ? defaultImageWidth : intWidth.intValue();
		int height = (intHeight == null) ? defaultImageHeight : intHeight.intValue();
		BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		buildImage(model, image, request, response);
		ServletOutputStream out = response.getOutputStream();
		int imageType = ((Integer) model.get(IMAGE_TYPE)).intValue();
		if (imageType == PNG)
		{
			response.setContentType("image/png");
			PNGEncoder encoder = new PNGEncoder(image, out);
			encoder.encodeImage();
		}
		else if (imageType == GIF)
		{
			response.setContentType("image/gif");
			GifEncoder encoder = new GifEncoder(image, out);
			encoder.encode();
		}
		else
		{ // default is JPEG
			response.setContentType("image/jpeg");
			JPEGImageEncoder encoder = new JPEGImageEncoderImpl(out);
			encoder.encode(image);
		}
		out.flush();
		out.close();
	}

	protected abstract void buildImage(Map model, BufferedImage image, HttpServletRequest request,
			HttpServletResponse response) throws Exception;

	public void setDefaultImageWidth(int defaultImageWidth)
	{
		this.defaultImageWidth = defaultImageWidth;
	}

	public void setDefaultImageHeight(int defaultImageHeight)
	{
		this.defaultImageHeight = defaultImageHeight;
	}

	private int defaultImageWidth = 100;
	private int defaultImageHeight = 100;

	public final static int JPEG = 0;
	public final static int GIF = 1;
	public final static int PNG = 2;
	public final static String IMAGE_TYPE = "IMAGE_TYPE";
	public final static String IMAGE_WIDTH = "IMAGE_WIDTH";
	public final static String IMAGE_HEIGHT = "IMAGE_HEIGHT";
}
