package spc.webos.endpoint;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import spc.webos.util.SpringUtil;

public class SpringServiceEndpoint implements Endpoint
{
	public SpringServiceEndpoint()
	{
	}

	public SpringServiceEndpoint(String location)
	{
		setLocation(location);
	}

	public void setLocation(String location)
	{
		this.location = location;
		int start = location.indexOf("//") + 2;
		this.service = location.substring(start);
		int idx = service.indexOf('.');
		this.method = service.substring(idx + 1);
		this.service = service.substring(0, idx);
		log.info("m:{}.{}", service, method);
	}

	public void init() throws Exception
	{
	}

	public void execute(Executable exe) throws Exception
	{
		exe.repExt = SpringUtil.call(service, method, (Object[]) exe.reqmsg);
	}

	public void destroy()
	{
	}

	public Endpoint clone() throws CloneNotSupportedException
	{
		return null;
	}

	// format is:
	// spring://serviceName:method?argName=..XXXVO&argName=int&argName=list&argName=map
	protected String location;
	protected String service;
	protected String method;
	protected Logger log = LoggerFactory.getLogger(getClass());

	public String getLocation()
	{
		return location;
	}
}
