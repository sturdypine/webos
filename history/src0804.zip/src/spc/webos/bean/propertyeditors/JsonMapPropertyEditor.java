package spc.webos.bean.propertyeditors;

import java.beans.PropertyEditorSupport;
import java.util.Map;

import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;

public class JsonMapPropertyEditor extends PropertyEditorSupport
{
	public void setAsText(String text)
	{
		setValue(StringX.nullity(text) ? null : (Map) JsonUtil.json2obj(text));
	}

	public String getAsText()
	{
		Object v = getValue();
		return v == null ? null : JsonUtil.obj2json(v);
	}
}
