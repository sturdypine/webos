package spc.webos.tcc;

import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;

import spc.webos.util.FileUtil;
import spc.webos.util.SpringUtil;
import spc.webos.util.StringX;

public class Terminator
{
	protected String xid; // ���������
	protected int seq; // ÿ������������������е�˳��ţ�0��ʼ
	protected String tid; // �ӷ�����ˮ��
	protected Object target;
	protected String clazz;
	protected String method;
	protected Class[] parameterTypes;
	protected Object[] args;
	protected transient Logger log = LoggerFactory.getLogger(getClass());
	public static String PREFIX_CONFIRM = "confirm"; // confirmXXX
	public static String PREFIX_CANCEL = "cancel"; // cancelXXX
	public static int PREFIX_TRY_LENGTH = 3; // "tryXXX"

	public Terminator(String xid, int seq, String tid, Object target, String clazz, String m,
			Class[] parameterTypes, Object[] args) throws Exception
	{
		this.xid = xid;
		this.seq = seq;
		this.tid = tid;
		this.target = target;
		this.clazz = clazz;
		method = m.substring(PREFIX_TRY_LENGTH);
		this.parameterTypes = parameterTypes;
		this.args = args;
	}

	public Terminator(Map<String, String> map) throws Exception
	{
		this.clazz = map.get("clazz");
		this.method = map.get("method");
		this.xid = map.get("xid");
		this.tid = map.get("tid");
		this.seq = Integer.parseInt(map.get("seq"));
		String[] types = StringX.split(map.get("types"), ",");
		parameterTypes = new Class[types.length];
		for (int i = 0; i < types.length; i++)
			parameterTypes[i] = Class.forName(types[i]);
		args = (Object[]) FileUtil.deserialize(StringX.decodeBase64(map.get("args")), false);
		Class c = Class.forName(clazz);
		String[] beanNames = SpringUtil.APPCXT.getBeanNamesForType(c);
		target = SpringUtil.APPCXT.getBean(beanNames[0], c);
	}

	public void commit() throws Exception
	{
		String m = PREFIX_CONFIRM + method;
		log.info("TX commit:{}/{} {}, {}.{}", xid, seq, tid, target.getClass().getSimpleName(), m);
		try
		{
			target.getClass().getMethod(m, parameterTypes).invoke(target, args);
		}
		catch (InvocationTargetException e)
		{
			log.warn("TX commit:{}/{} {}, {}.{}, ex:{}", xid, seq, tid,
					target.getClass().getSimpleName(), m, e.getTargetException().toString());
			throw (Exception) e.getTargetException();
		}
	}

	public void rollback() throws Exception
	{
		String m = PREFIX_CANCEL + method;
		log.info("TX cancel:{}/{} {}, {}.{}", xid, seq, tid, target.getClass().getSimpleName(), m);
		try
		{
			target.getClass().getMethod(m, parameterTypes).invoke(target, args);
		}
		catch (InvocationTargetException e)
		{
			log.warn("TX cancel:{}/{} {}, {}.{}, ex:{}", xid, seq, tid,
					target.getClass().getSimpleName(), m, e.getTargetException().toString());
			throw (Exception) e.getTargetException();
		}
	}

	public int getSeq()
	{
		return seq;
	}

	public void setXid(String xid)
	{
		this.xid = xid;
	}

	public String toJson()
	{
		Map<String, String> map = new HashMap<String, String>();
		map.put("clazz", clazz);
		map.put("method", method);
		map.put("xid", xid);
		map.put("tid", tid);
		map.put("seq", String.valueOf(seq));
		StringBuffer buf = new StringBuffer();
		for (Class<?> c : parameterTypes)
			buf.append((buf.length() == 0 ? "" : ",") + c.getName());
		map.put("types", buf.toString());
		try
		{
			map.put("args", StringX.base64(FileUtil.serialize((java.io.Serializable) args, false)));
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
		return new Gson().toJson(map);
	}

	public String toString()
	{
		return "\nTerm:" + clazz + "." + method + ":" + Arrays.toString(args);
	}
}
