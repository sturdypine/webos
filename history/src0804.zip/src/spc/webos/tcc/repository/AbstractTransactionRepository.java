package spc.webos.tcc.repository;

import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import spc.webos.tcc.ITransactionRepository;
import spc.webos.tcc.Terminator;
import spc.webos.tcc.Transaction;

public abstract class AbstractTransactionRepository implements ITransactionRepository, Runnable
{
	protected Logger log = LoggerFactory.getLogger(getClass());
	protected int sucTccExpireSeconds = 0; // 24 * 3600; // �������ﱣ��ʱ��
	protected int sleepSeconds = 30;
	protected boolean repositoryOnlyErr = true;
	protected boolean runDoFailTx = false;
	protected Thread daemon;

	public void init() throws Exception
	{
		if (runDoFailTx)
		{
			daemon = new Thread(this);
			daemon.setDaemon(true);
			daemon.start();
		}
	}

	public void addTerminator(Transaction transaction, String tid, int seq, Object target,
			String clazz, String m, Class[] parameterTypes, Object[] args) throws Exception
	{
		transaction.getTerminatorsList().add(
				new Terminator(transaction.xid, seq, tid, target, clazz, m, parameterTypes, args));
		updateStatus(transaction); // ���ӷ�����Ϣ���б���
	}

	public void destroy()
	{
		runDoFailTx = false;
		try
		{
			if (daemon != null) daemon.interrupt();
		}
		catch (Exception e)
		{
		}
		try
		{
			if (daemon != null) daemon.stop();
		}
		catch (Exception e)
		{
		}
	}

	public void run()
	{
		log.info("start daemon to doFailTx...");
		while (runDoFailTx)
		{
			try
			{
				Thread.sleep(sleepSeconds * 1000);
			}
			catch (Exception e)
			{
			}
			try
			{
				doFailTx();
			}
			catch (Exception e)
			{
			}
		}
	}

	public void doFailTx() throws Exception
	{
		Collection<String> errXids = findAllErr();
		if (errXids == null || errXids.size() == 0) return;
		log.info("err Tcc xids: " + errXids);
		for (String xid : errXids)
		{
			String status = "";
			try
			{
				Transaction t = find(xid);
				if (t.status == Transaction.STATUS_CANCEL_FAIL)
				{
					status = " Cancel " + t.proxy;
					t.rollback();
				}
				else if (t.status == Transaction.STATUS_CONFIRM_FAIL)
				{
					status = " Confirm " + t.proxy;
					t.commit();
				}
				delete(t, true);
			}
			catch (Exception e)
			{
				log.info("fail to doFailTx:" + status + ":" + xid, e);
			}
		}
	}

	public void setSleepSeconds(int sleepSeconds)
	{
		this.sleepSeconds = sleepSeconds;
	}

	public void setRunDoFailTx(boolean runDoFailTx)
	{
		this.runDoFailTx = runDoFailTx;
	}

	public void setSucTccExpireSeconds(int sucTccExpireSeconds)
	{
		this.sucTccExpireSeconds = sucTccExpireSeconds;
	}

	public boolean isRepositoryOnlyErr()
	{
		return repositoryOnlyErr;
	}

	public void setRepositoryOnlyErr(boolean repositoryOnlyErr)
	{
		this.repositoryOnlyErr = repositoryOnlyErr;
	}
}
