package spc.webos.tcc.service;

public interface ITcc
{
	String getTccXid();

	int getTccStatus();

	void setTccStatus(Integer status);
}
