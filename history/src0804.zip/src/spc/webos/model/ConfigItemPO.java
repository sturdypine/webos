package spc.webos.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * genarated by sturdypine.chen Email: sturdypine@gmail.com description:
 */
public class ConfigItemPO implements Serializable
{
	public static final long serialVersionUID = 20080121L;
	// ����������Ӧ�ֶε�����
	String module; // ����
	String name; // ����
	String value; //
	String type; //
	String status; //
	String model; //
	String remark; //
	Long seq; //

	// ver
	String userCd;// �����û�
	String lastUpdTm;// ������ʱ��
	String verDt; // ���ݰ汾����
	String verStatus;// ���ݰ汾״̬
	String actionNm;// ��������

	// �ʹ�VO�����������VO����

	// �ʹ�VO�������������Sql����
	// Note: ���������Sql����ΪString, Inegter...��Java final classʱ�� ֻ��ʹ��Object����
	// ����ʱ��ֻ��ͨ��
	// Object��toString()������ʹ�á�
	public static final String TABLE = "sys_config";
	public static final String[] BLOB_FIELD = null;
	public static final String SEQ_NAME = "seq";

	public final static String TP_INT = "int";
	public final static String TP_LONG = "long";
	public final static String TP_BOOL = "bool";
	public final static String TP_BOOLEAN = "boolean";
	// public final static String TP_FLOAT = "float";
	public final static String TP_DOUBLE = "double";
	public final static String TP_STRING = "string";

	public final static String MD_ARRAY = "array";
	public final static String MD_SIMPLE = "simple";
	public final static String MD_JSON = "json";

	public ConfigItemPO()
	{
	}

	public ConfigItemPO(String module, String name)
	{
		this.module = module;
		this.name = name;
	}

	public void setPrimary(String module, String name)
	{
		this.module = module;
		this.name = name;
	}

	public String primary(String delim)
	{
		StringBuffer buf = new StringBuffer();
		buf.append(this.module);
		buf.append(delim + this.name);
		return buf.toString();
	}

	public Map primary()
	{
		Map m = new HashMap();
		m.put("module", module);
		m.put("name", name);
		return m;
	}

	public String table()
	{
		return TABLE;
	}

	public String[] blobFields()
	{
		return BLOB_FIELD;
	}

	// public String getKeyName()
	// {
	// return SEQ_NAME;
	// }
	//
	// public Serializable getKey()
	// {
	// return seq;
	// }

	public String getUserCd()
	{
		return userCd;
	}

	public void setUserCd(String userCd)
	{
		this.userCd = userCd;
	}

	public String getLastUpdTm()
	{
		return lastUpdTm;
	}

	public void setLastUpdTm(String lastUpdTm)
	{
		this.lastUpdTm = lastUpdTm;
	}

	public String getVerDt()
	{
		return verDt;
	}

	public void setVerDt(String verDt)
	{
		this.verDt = verDt;
	}

	public String getVerStatus()
	{
		return verStatus;
	}

	public void setVerStatus(String verStatus)
	{
		this.verStatus = verStatus;
	}

	public String getActionNm()
	{
		return actionNm;
	}

	public void setActionNm(String actionNm)
	{
		this.actionNm = actionNm;
	}

	// set all properties to NULL
	public void setNULL()
	{
		this.module = null;
		this.name = null;
		this.value = null;
		this.type = null;
		this.status = null;
		this.model = null;
		this.remark = null;
		this.seq = null;
	}

	public boolean equals(Object o)
	{
		if (this == o) return true;
		if (!(o instanceof ConfigItemPO)) return false;
		ConfigItemPO obj = (ConfigItemPO) o;
		if (!module.equals(obj.module)) return false;
		if (!name.equals(obj.name)) return false;
		if (!value.equals(obj.value)) return false;
		if (!type.equals(obj.type)) return false;
		if (!status.equals(obj.status)) return false;
		if (!model.equals(obj.model)) return false;
		if (!remark.equals(obj.remark)) return false;
		if (!seq.equals(obj.seq)) return false;
		return true;
	}

	// ֻ����������ɢ��
	public int hashCode()
	{
		long hashCode = getClass().hashCode();
		if (module != null) hashCode += module.hashCode();
		if (name != null) hashCode += name.hashCode();
		return (int) hashCode;
	}

	public int compareTo(Object o)
	{
		return -1;
	}

	// set all properties to default value...
	public void init()
	{
	}

	public String getModule()
	{
		return module;
	}

	public void setModule(String module)
	{
		this.module = module;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getValue()
	{
		return value;
	}

	public void setValue(String value)
	{
		this.value = value;
	}

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public String getStatus()
	{
		return status;
	}

	public void setStatus(String status)
	{
		this.status = status;
	}

	public String getModel()
	{
		return model;
	}

	public void setModel(String model)
	{
		this.model = model;
	}

	public String getRemark()
	{
		return remark;
	}

	public void setRemark(String remark)
	{
		this.remark = remark;
	}

	public Long getSeq()
	{
		return seq;
	}

	public void setSeq(Long seq)
	{
		this.seq = seq;
	}

	public void set(ConfigItemPO vo)
	{
		this.module = vo.module;
		this.name = vo.name;
		this.value = vo.value;
		this.type = vo.type;
		this.status = vo.status;
		this.model = vo.model;
		this.remark = vo.remark;
		this.seq = vo.seq;
	}

	public StringBuffer toJson()
	{
		StringBuffer buf = new StringBuffer();
		buf.append('{');
		if (module != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("module:'");
			buf.append(module);
			buf.append('\'');
		}
		if (name != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("name:'");
			buf.append(name);
			buf.append('\'');
		}
		if (value != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("value:'");
			buf.append(value);
			buf.append('\'');
		}
		if (type != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("type:'");
			buf.append(type);
			buf.append('\'');
		}
		if (status != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("status:'");
			buf.append(status);
			buf.append('\'');
		}
		if (model != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("model:'");
			buf.append(model);
			buf.append('\'');
		}
		if (remark != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("remark:'");
			buf.append(remark);
			buf.append('\'');
		}
		if (seq != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("seq:'");
			buf.append(seq);
			buf.append('\'');
		}
		buf.append('}');
		return buf;
	}

	public void destory()
	{

	}

	public String toString()
	{
		StringBuffer buf = new StringBuffer(128);
		buf.append(getClass().getName() + "(serialVersionUID=" + serialVersionUID + "):");
		buf.append(toJson());
		return buf.toString();
	}

	public void afterLoad()
	{
		// TODO Auto-generated method stub

	}

	public void beforeLoad()
	{
		// TODO Auto-generated method stub

	}

	// public void setManualSeq(Long seq)
	// {
	// this.seq = seq;
	// }
}
