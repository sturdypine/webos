package spc.webos.model;

import java.io.Serializable;

/**
* genarated by sturdypine.chen
* Email: sturdypine@gmail.com
* description: 
*/
public class SeqNoPO implements Serializable
{
	public static final long serialVersionUID = 20151205L;
	// 和物理表对应字段的属�?
	String name; //  主键
	public Long seqNo; // 
	public Long maxSeqNo; //
	public Long recycleNo;
	public Integer batchSize; // 
	Integer ver; // 
	String remark; // 

	// 和此VO相关联的其他VO属�??
	
	// 和此VO相关联的其他�?单Sql属�??
	// Note: 如果关联的Sql对象为String, Inegter...等Java final class时， 只能使用Object对象�? 访问时�?�只能�?�过
	// Object的toString()方法来使用�??
	public static final String TABLE = "d_seqno";

	
	public SeqNoPO()
	{
	}
	
	public SeqNoPO(String name)
	{
		this.name = name;
	}
	
	// set all properties to NULL
	public void setNULL()
	{
    	this.name = null;
    	this.seqNo = null;
    	this.batchSize = null;
    	this.ver = null;
    	this.remark = null;
	}
	
	public boolean equals(Object o)
	{
		if (this == o) return true;
		if (!(o instanceof SeqNoPO)) return false;
		SeqNoPO obj = (SeqNoPO) o;
		if (!name.equals(obj.name)) return false;
		if (!seqNo.equals(obj.seqNo)) return false;
		if (!batchSize.equals(obj.batchSize)) return false;
		if (!ver.equals(obj.ver)) return false;
		if (!remark.equals(obj.remark)) return false;
		return true;
	}
	
	public int compareTo(Object o)
	{
		return -1;
	}

	// set all properties to default value...
	public void init()
	{
	}
	
    public String getName()
    {
        return name;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public Long getSeqNo()
    {
        return seqNo;
    }
    
    public void setSeqNo(Long seqNo)
    {
        this.seqNo = seqNo;
    }
    
    public Integer getBatchSize()
    {
        return batchSize;
    }
    
    public void setBatchSize(Integer batchSize)
    {
        this.batchSize = batchSize;
    }
    
    public Integer getVer()
    {
        return ver;
    }
    
    public void setVer(Integer ver)
    {
        this.ver = ver;
    }
    
    public Long getRecycleNo()
	{
		return recycleNo;
	}

	public void setRecycleNo(Long recycleNo)
	{
		this.recycleNo = recycleNo;
	}

	public Long getMaxSeqNo() {
		return maxSeqNo;
	}

	public void setMaxSeqNo(Long maxSeqNo) {
		this.maxSeqNo = maxSeqNo;
	}

	public String getRemark()
    {
        return remark;
    }
    
    public void setRemark(String remark)
    {
        this.remark = remark;
    }
    
	
	public void set(SeqNoPO vo)
	{
    	this.name = vo.name;
    	this.seqNo = vo.seqNo;
    	this.batchSize = vo.batchSize;
    	this.ver = vo.ver;
    	this.remark = vo.remark;
	}
	
	public StringBuffer toJson()
	{
		StringBuffer buf = new StringBuffer();
		try {
			buf.append(spc.webos.util.JsonUtil.obj2json(this));
		} catch (Exception e) {
		}
		return buf;
	}


	public String toString()
	{
		StringBuffer buf = new StringBuffer(128);
		buf.append(getClass().getName() + "(serialVersionUID=" + serialVersionUID + "):");
		buf.append(toJson());
		return buf.toString();
	}
	
	public Object clone()
	{
		SeqNoPO obj = new SeqNoPO();
		obj.set(this);
		return obj;
	}
}
