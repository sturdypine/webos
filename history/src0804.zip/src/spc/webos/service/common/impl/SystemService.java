package spc.webos.service.common.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import spc.webos.config.AppConfig;
import spc.webos.message.DictMessageSource;
import spc.webos.message.SqlMessageSource;
import spc.webos.message.SysMessageSource;
import spc.webos.service.Service;
import spc.webos.service.common.ISystemtService;

@org.springframework.stereotype.Service("systemService")
public class SystemService extends Service implements ISystemtService
{
	public String getCurrentDate(String format)
	{
		return new SimpleDateFormat(format).format(getCurrentDate());
	}

	public Date getCurrentDate()
	{
		return new Date();
	}

	public void refreshConfig() throws Exception
	{
		AppConfig.getInstance().refresh();
	}

	// ˢ��ϵͳ���ݿ��ֵ����ݵ��ڴ�
	public void refreshDict() throws Exception
	{
		DictMessageSource.getInstance().refresh();
	}

	// ˢ��ϵͳ�Ĺ��ʻ�ת����Ϣ���ڴ�
	public void refreshSysMsg() throws Exception
	{
		SysMessageSource.getInstance().refresh();
	}

	public void refreshSqlMsg(List sqls) throws Exception
	{
		Iterator keys = null;
		if (sqls != null && sqls.size() > 0) keys = sqls.iterator();
		else keys = SqlMessageSource.SQL_MSG.keySet().iterator();
		while (keys.hasNext())
		{
			SqlMessageSource ms = (SqlMessageSource) SqlMessageSource.SQL_MSG.get(keys.next());
			if (ms != null) ms.refresh();
		}
	}
}
