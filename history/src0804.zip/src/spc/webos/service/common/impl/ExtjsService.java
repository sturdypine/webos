package spc.webos.service.common.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import spc.webos.service.Service;
import spc.webos.service.common.IExtjsService;
import spc.webos.util.SpringUtil;
import spc.webos.util.tree.ExtTreeNode;
import spc.webos.util.tree.TreeNode;

@org.springframework.stereotype.Service("extjsService")
public class ExtjsService extends Service implements IExtjsService
{
	public TreeNode getSysFns()
	{
		// ���ǵ�ϵͳ���ܷǹ���������,ֻ��ϵͳ����Աʹ��,���Բ����浽�ڴ���
		// String treeId = "sysfns";
		// ExtTreeNode node = (ExtTreeNode) extTreeCache.get(treeId);
		// if (node != null) return node;
		ExtTreeNode node = new ExtTreeNode();
		List res = (List) persistence.execute("common.sysfns", null);
		node.createTree(res);
		List leafs = new ArrayList();
		ExtTreeNode.leafs(node, leafs);
		for (int i = 0; i < leafs.size(); i++)
		{
			ExtTreeNode n = (ExtTreeNode) leafs.get(i);
			Map attr = n.getAttributes();
			String opers = (String) attr.get("operation");
			if (opers == null || opers.length() == 0) opers = "S";
			for (int j = 0; j < opers.length(); j++)
			{
				String oper = String.valueOf(opers.charAt(j));
				n.insertChild(new ExtTreeNode(n.getId() + "/" + oper,
						SpringUtil.APPCXT.getMessage("DICT/operations/" + oper, null, null),
						Boolean.FALSE));
			}
		}
		// System.out.println(333);
		// extTreeCache.put(treeId, node);
		// System.out.println(node.toJson());
		return node;
	}

	public TreeNode getExtTree(String sqlId, Map param)
	{
		ExtTreeNode node = new ExtTreeNode();
		node.createTree((List) persistence.execute(sqlId, param));
		return node;
	}

	public void removeTrees(List treesId)
	{
		if (treesId == null || treesId.size() == 0) return;
		for (int i = 0; i < treesId.size(); i++)
			extTreeCache.remove((String) treesId.get(i));
	}

	public Map getTrees()
	{
		return extTreeCache;
		// Map trees = new HashMap();
		// if (extTreeCache == null) return trees;
		// Iterator keys = extTreeSql.keySet().iterator();
		// while (keys.hasNext())
		// {
		// String key = keys.next().toString();
		// trees.put(key, extTreeCache.get(key));
		// }
		// return trees;
	}

	Map<String, TreeNode> extTreeCache = new ConcurrentHashMap<String, TreeNode>();

	public void setExtTreeCache(Map<String, String> extTreeCache) throws Exception
	{
		this.extTreeCache = new ConcurrentHashMap<String, TreeNode>();
		for (String key : extTreeCache.keySet())
			this.extTreeCache.put(key, new ExtTreeNode()
					.createTree((List) persistence.execute(extTreeCache.get(key), null)));
	}
}
