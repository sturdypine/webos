package spc.webos.service;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import spc.webos.config.AppConfig;
import spc.webos.persistence.IPersistence;
import spc.webos.util.StringX;

public class Service implements IService
{
	@Autowired(required = false)
	protected IPersistence persistence;
	protected String name;
	protected IService self = this;
	// protected boolean jsrmi = true;
	protected final Logger log = LoggerFactory.getLogger(getClass());

	protected String lastDBVerDt = StringX.EMPTY_STRING;
	protected String dbVerDtKey; //

	public Service()
	{
		name = getClass().getSimpleName();
		// ����ĵ�һ������Сд��ȥ��Service��Ϊservice��Ĭ���ڲ���
		name = name.substring(0, 1).toLowerCase() + name.substring(1);
		if (name.endsWith("Service")) name = name.substring(0, name.length() - 7);
	}

	/**
	 * �ṩinit��������, ��spring2.0���� default-init-method
	 * 
	 */
	@PostConstruct
	public void init() throws Exception
	{
		if (StringX.nullity(name)) return;
		if (SERVICES.containsKey(name)) log.warn(name + " Service existed in SERVICES!!!");
		SERVICES.put(name, this);
		// if (jsrmi) SERVICES_JSRMI.put(name, this);
		SERVICES_PROXY.put(name, this);
	}

	// added by chenjs 2011-09-19 �޸�destory���ʷ���
	@PreDestroy
	public void destroy()
	{
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public IPersistence getPersistence()
	{
		return persistence;
	}

	public void setPersistence(IPersistence persistence)
	{
		this.persistence = persistence;
	}

	public boolean changeStatus(Map param)
	{
		return false;
	}

	public Map checkStatus(Map param)
	{
		return new HashMap();
	}

	public void refresh() throws Exception
	{
	}

	// ����ˢ��ʱ�жϷ����Ƿ���Ҫˢ�����ݿ�
	public boolean isDBRefreshed()
	{
		if (StringX.nullity(dbVerDtKey))
		{
			log.info("dbVerDtKey is null!!!");
			return true;
		}
		String curDBVerDt = AppConfig.getInstance().getProperty(dbVerDtKey, StringX.EMPTY_STRING)
				.toString();
		log.debug("curDBVerDt: " + curDBVerDt);
		if (!StringX.nullity(curDBVerDt) && !StringX.nullity(lastDBVerDt)
				&& lastDBVerDt.equalsIgnoreCase(curDBVerDt))
		{
			log.info("curDBVerDt == lastDBVerDt(" + lastDBVerDt + ")!!!");
			return false;
		}
		if (StringX.nullity(curDBVerDt)) log.info("curDBVerDt is null by:" + dbVerDtKey);
		if (log.isInfoEnabled())
			log.info("lastDBVerDt:" + lastDBVerDt + ", curDBVerDt:" + curDBVerDt);
		lastDBVerDt = curDBVerDt;
		return true;
	}

	public void self(Object proxyBean)
	{
		self = (IService) proxyBean;
		if (StringX.nullity(name) || self == null) return;
		SERVICES_PROXY.put(name, self);
		// if (jsrmi) SERVICES_JSRMI.put(name, proxyBean);
		if (!SERVICES.containsKey(name)) SERVICES.put(name, this);
	}

	public Object self()
	{
		return self;
	}

	// public boolean isJsrmi()
	// {
	// return jsrmi;
	// }
	//
	// public void setJsrmi(boolean jsrmi)
	// {
	// this.jsrmi = jsrmi;
	// }

	public String getLastDBVerDt()
	{
		return lastDBVerDt;
	}

	public void setLastDBVerDt(String lastDBVerDt)
	{
		this.lastDBVerDt = lastDBVerDt;
	}

	public String getDbVerDtKey()
	{
		return dbVerDtKey;
	}

	public void setDbVerDtKey(String dbVerDtKey)
	{
		this.dbVerDtKey = dbVerDtKey;
	}
}
