package spc.webos.service.seq;

public interface UUID
{
	long uuid();
}
