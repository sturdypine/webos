package spc.webos.service.seq;

public interface IDbSeqNoService extends ISeqNo
{
	void forceSynDB();
}
