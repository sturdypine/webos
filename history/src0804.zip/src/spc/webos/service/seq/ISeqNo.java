package spc.webos.service.seq;

public interface ISeqNo extends UUID
{
	long nextId(String name);
}
