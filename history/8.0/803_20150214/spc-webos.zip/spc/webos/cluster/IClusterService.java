package spc.webos.cluster;

import spc.webos.service.IStatus;

/**
 * �ɾ������ӿ�
 * 
 * @author spc
 */
public interface IClusterService extends IStatus
{
	void init() throws Exception;

	Object execute(Object req) throws Exception;

	boolean available();

	String getName();
}
