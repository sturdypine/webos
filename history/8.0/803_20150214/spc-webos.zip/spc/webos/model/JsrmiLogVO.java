package spc.webos.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * genarated by sturdypine.chen Email: sturdypine@gmail.com description:
 */
public class JsrmiLogVO implements ValueObject
{
	public static final long serialVersionUID = 20080121L;
	// ����������Ӧ�ֶε�����
	Integer dt; // 
	Integer time; // 
	String ip; // 
	String req; // 
	String res; // 
	String userCode; // 
	String uri; // 
	Long startTime; // 
	Long endTime; // 

	// �ʹ�VO�����������VO����

	// �ʹ�VO�������������Sql����
	// Note: ���������Sql����ΪString, Inegter...��Java final classʱ�� ֻ��ʹ��Object����
	// ����ʱ��ֻ��ͨ��
	// Object��toString()������ʹ�á�
	public static final String TABLE = "sys_jsrmilog";
	public static final String[] BLOB_FIELD = null;
	public static final String SEQ_NAME = null;

	public JsrmiLogVO()
	{
	}

	public void setPrimary()
	{
	}

	public String getPrimary(String delim)
	{
		StringBuffer buf = new StringBuffer();
		return buf.toString();
	}

	public Map getPrimary()
	{
		Map m = new HashMap();
		return m;
	}

	public String getTable()
	{
		return TABLE;
	}

	public String[] getBlobField()
	{
		return BLOB_FIELD;
	}

	public String getKeyName()
	{
		return SEQ_NAME;
	}

	public Serializable getKey()
	{
		return null;
	}

	// set all properties to NULL
	public void setNULL()
	{
		this.dt = null;
		this.time = null;
		this.ip = null;
		this.req = null;
		this.res = null;
		this.userCode = null;
		this.uri = null;
		this.startTime = null;
		this.endTime = null;
	}

	public boolean equals(Object o)
	{
		if (this == o) return true;
		if (!(o instanceof JsrmiLogVO)) return false;
		JsrmiLogVO obj = (JsrmiLogVO) o;
		if (!dt.equals(obj.dt)) return false;
		if (!time.equals(obj.time)) return false;
		if (!ip.equals(obj.ip)) return false;
		if (!req.equals(obj.req)) return false;
		if (!res.equals(obj.res)) return false;
		if (!userCode.equals(obj.userCode)) return false;
		if (!uri.equals(obj.uri)) return false;
		if (!startTime.equals(obj.startTime)) return false;
		if (!endTime.equals(obj.endTime)) return false;
		return true;
	}

	// ֻ����������ɢ��
	public int hashCode()
	{
		long hashCode = getClass().hashCode();
		return (int) hashCode;
	}

	public int compareTo(Object o)
	{
		return -1;
	}

	// set all properties to default value...
	public void init()
	{
	}

	public Integer getDt()
	{
		return dt;
	}

	public void setDt(Integer dt)
	{
		this.dt = dt;
	}

	public Integer getTime()
	{
		return time;
	}

	public void setTime(Integer time)
	{
		this.time = time;
	}

	public String getIp()
	{
		return ip;
	}

	public void setIp(String ip)
	{
		this.ip = ip;
	}

	public String getReq()
	{
		return req;
	}

	public void setReq(String req)
	{
		this.req = req;
	}

	public String getRes()
	{
		return res;
	}

	public void setRes(String res)
	{
		this.res = res;
	}

	public String getUserCode()
	{
		return userCode;
	}

	public void setUserCode(String userCode)
	{
		this.userCode = userCode;
	}

	public String getUri()
	{
		return uri;
	}

	public void setUri(String uri)
	{
		this.uri = uri;
	}

	public Long getStartTime()
	{
		return startTime;
	}

	public void setStartTime(Long startTime)
	{
		this.startTime = startTime;
	}

	public Long getEndTime()
	{
		return endTime;
	}

	public void setEndTime(Long endTime)
	{
		this.endTime = endTime;
	}

	public void set(JsrmiLogVO vo)
	{
		this.dt = vo.dt;
		this.time = vo.time;
		this.ip = vo.ip;
		this.req = vo.req;
		this.res = vo.res;
		this.userCode = vo.userCode;
		this.uri = vo.uri;
		this.startTime = vo.startTime;
		this.endTime = vo.endTime;
	}

	public static long getSerialVersionUID()
	{
		return serialVersionUID;
	}

	public StringBuffer toJson()
	{
		StringBuffer buf = new StringBuffer();
		buf.append('{');
		if (dt != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("dt:'");
			buf.append(dt);
			buf.append('\'');
		}
		if (time != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("time:'");
			buf.append(time);
			buf.append('\'');
		}
		if (ip != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("ip:'");
			buf.append(ip);
			buf.append('\'');
		}
		if (req != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("req:'");
			buf.append(req);
			buf.append('\'');
		}
		if (res != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("res:'");
			buf.append(res);
			buf.append('\'');
		}
		if (userCode != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("userCode:'");
			buf.append(userCode);
			buf.append('\'');
		}
		if (uri != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("uri:'");
			buf.append(uri);
			buf.append('\'');
		}
		if (startTime != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("startTime:'");
			buf.append(startTime);
			buf.append('\'');
		}
		if (endTime != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("endTime:'");
			buf.append(endTime);
			buf.append('\'');
		}
		buf.append('}');
		return buf;
	}

	public void destory()
	{
	}

	public String toString()
	{
		StringBuffer buf = new StringBuffer(128);
		buf.append(getClass().getName() + "(serialVersionUID="
				+ serialVersionUID + "):");
		buf.append(toJson());
		return buf.toString();
	}

	public void afterLoad()
	{
		// TODO Auto-generated method stub

	}

	public void beforeLoad()
	{
		// TODO Auto-generated method stub

	}

	public void setManualSeq(Long seq)
	{
		// TODO Auto-generated method stub
		
	}
}
