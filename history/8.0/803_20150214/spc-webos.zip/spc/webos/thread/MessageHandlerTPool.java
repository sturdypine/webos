package spc.webos.thread;

import java.util.Map;

import spc.webos.flownode.MessageFlow;

public class MessageHandlerTPool extends BizHandlerTPool
{
	MessageFlow messageFlow; // ��Ϣ������
	IMessageReceiver messageReceiver;

	public DaemonThread borrow()
	{
		MessageHandlerThread mht = new MessageHandlerThread(this);
//		mht.setDynamicLog(dynamicLog);
		return mht;
	}

	public Map checkStatus(Map param)
	{
		Map status = super.checkStatus(param);
		// if (outBuf != null) status.put("outBuf", outBuf.getName());
		if (messageFlow != null) status.put("messageFlow", messageFlow.getName());
		return status;
	}

	public MessageFlow getMessageFlow()
	{
		return messageFlow;
	}

	public void setMessageFlow(MessageFlow messageFlow)
	{
		this.messageFlow = messageFlow;
	}

	public void setMsgFlow(MessageFlow msgFlow)
	{
		this.messageFlow = msgFlow;
	}

	public IMessageReceiver getMessageReceiver()
	{
		return messageReceiver;
	}

	public void setMessageReceiver(IMessageReceiver messageReceiver)
	{
		this.messageReceiver = messageReceiver;
	}
}
