package spc.webos.jsrmi.protocal.converters.map;

import java.util.HashMap;

import spc.webos.data.ICompositeNode;
import spc.webos.jsrmi.protocal.ProtocalTag;
import spc.webos.jsrmi.protocal.converters.AbstractReferencableConverter;
import spc.webos.jsrmi.protocal.converters.Converter;
import spc.webos.jsrmi.protocal.io.MarshallingContext;
import spc.webos.jsrmi.protocal.io.StreamWriter;

public abstract class AbstractMapConverter extends
		AbstractReferencableConverter implements Converter
{
	protected final void marshalObject(Object value,
			MarshallingContext context, StreamWriter streamWriter)
	{
		streamWriter.startNode(ProtocalTag.TAG_MAP);
		// ����Ҫָ������
		streamWriter.startNode(ProtocalTag.TAG_TYPE);
		if (value instanceof ICompositeNode) streamWriter
				.setValue(HashMap.class.getName());
		else streamWriter.setValue(value.getClass().getName());
		streamWriter.endNode();
		marshalMapObject(value, context, streamWriter);
		streamWriter.endNode();
	}

	protected abstract void marshalMapObject(Object value,
			MarshallingContext context, StreamWriter streamWriter);

}
