package spc.webos.jsrmi.protocal.converters.basic;

import spc.webos.jsrmi.protocal.ProtocalTag;
import spc.webos.jsrmi.protocal.converters.Converter;
import spc.webos.jsrmi.protocal.io.MarshallingContext;
import spc.webos.jsrmi.protocal.io.StreamReader;
import spc.webos.jsrmi.protocal.io.StreamWriter;
import spc.webos.jsrmi.protocal.io.UnmarshallingContext;

public class NullConverter implements Converter{

	public boolean canConvert(Class type) {
		return type == null;
	}

	public void marshal(Object object, MarshallingContext context, StreamWriter streamWriter) {
		streamWriter.startNode(ProtocalTag.TAG_NULL);
		streamWriter.endNode();
	}

	public Object unmarshal(StreamReader reader, UnmarshallingContext unmarshallingContext) {
		return null;
	}

}
