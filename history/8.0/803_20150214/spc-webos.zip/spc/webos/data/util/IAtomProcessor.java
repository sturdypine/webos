package spc.webos.data.util;

import spc.webos.data.IAtomNode;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.model.MsgSchemaVO;

/**
 * ����ԭ�������ǩ�� �� ת���ܽӿ�
 */
public interface IAtomProcessor
{
	IAtomNode process(IMessage srcmsg, IAtomNode src, MsgSchemaVO schema, boolean esb2rcv,
			ICompositeNode pnode, String path, ICompositeNode tpnode) throws Exception;
}
