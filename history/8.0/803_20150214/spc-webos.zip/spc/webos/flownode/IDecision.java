package spc.webos.flownode;

import java.util.HashMap;
import java.util.Map;

import spc.webos.data.IMessage;

public interface IDecision
{
	String decide(IMessage msg, IFlowContext cxt) throws Exception;

	public static Map DECISIONS = new HashMap();
}
