package spc.webos.advice;

import java.util.Map;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

import spc.webos.data.IMessage;
import spc.webos.flownode.IFlowContext;
import spc.webos.flownode.IFlowNode;
import spc.webos.log.Log;
import spc.webos.service.IStatus;
import spc.webos.util.StringX;

/**
 * ���ڻ�������ĳһЩfnode, ����֧��һЩ����ı��ı��
 * 
 * @author chenjs
 * 
 */
public class FlowNodeAdvice implements MethodInterceptor, IStatus
{
	protected IFlowNode before; // ��ĳһfnodeִ��ǰִ�е�fnode
	protected IFlowNode after; // ��ĳһfnodeִ�к�ִ�е�fnode
	protected IFlowNode throwable; // ��ĳһ�ڵ�ִ��throw����
	protected String[] adviceMsgCds;
	protected String name;
	protected Log log = Log.getLogger(getClass());

	public Object invoke(MethodInvocation mi) throws Throwable
	{
		if (log.isDebugEnabled()) log.debug("start advice:" + mi.getThis().getClass() + ":"
				+ mi.getMethod());
		Object[] args = mi.getArguments();
		IMessage msg = ((IMessage) args[0]);
		IFlowContext cxt = (IFlowContext) args[1];
		if (!support(msg, cxt))
		{ // ��ǰ���Ĳ�֧��advice
			log.debug("unsupport advice!!!");
			return mi.proceed();
		}
		if (before != null)
		{
			log.debug("start before advice...");
			before.execute(msg, cxt);
		}
		Object ret = null;
		try
		{
			ret = mi.proceed();
		}
		catch (Throwable t)
		{
			if (throwable == null) throw t;
			((IMessage) args[0]).setEx(t);
			log.debug("start throwable advice...");
			throwable.execute(msg, cxt);
		}
		if (after != null)
		{
			log.debug("start after advice...");
			after.execute(msg, cxt);
		}
		log.debug("end advice...");
		return ret;
	}

	public boolean support(IMessage msg, IFlowContext cxt)
	{
		if (adviceMsgCds == null) return true;
		String msgCd = msg.getMsgCd();
		return StringX.contain(adviceMsgCds, msgCd, true);
	}

	public void init() throws Exception
	{
	}

	public void close()
	{
	}

	public void destory()
	{
	}

	public String getName()
	{
		return name;
	}

	public void setBefore(IFlowNode before)
	{
		this.before = before;
	}

	public void setAfter(IFlowNode after)
	{
		this.after = after;
	}

	public void setThrowable(IFlowNode throwable)
	{
		this.throwable = throwable;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String[] getAdviceMsgCds()
	{
		return adviceMsgCds;
	}

	public void setAdviceMsgCds(String[] adviceMsgCds)
	{
		this.adviceMsgCds = adviceMsgCds;
	}

	public boolean changeStatus(Map param)
	{
		// TODO Auto-generated method stub
		return false;
	}

	public Map checkStatus(Map param)
	{
		return null;
	}

	public void refresh() throws Exception
	{
	}
}
