package spc.webos.endpoint;

import spc.webos.log.Log;
import spc.webos.queue.QueueMessage;
import spc.webos.queue.ibmmq.QueueAccess;

/**
 * MQ ������endpoint
 * 
 * @author spc
 * 
 */
public class MQEndpoint implements Endpoint
{
	public void execute(Executable exe) throws Exception
	{
		QueueMessage qmsg = access.execute(reqQName, repQName, new QueueMessage(exe.request, exe
				.getCorrelationID().getBytes(), null, exe.timeout), exe.getTimeout());
		exe.setResponse(qmsg == null ? null : qmsg.buf);
	}

	public void setLocation(String location) throws Exception
	{
		throw new RuntimeException("No method!!!");
	}

	protected QueueAccess access;
	protected String reqQName;
	protected String repQName;
	protected Log log = Log.getLogger(MQEndpoint.class);

	public void setAccess(QueueAccess access)
	{
		this.access = access;
	}

	public void setReqQName(String reqQName)
	{
		this.reqQName = reqQName;
	}

	public void setRepQName(String repQName)
	{
		this.repQName = repQName;
	}

	public void init() throws Exception
	{
	}

	public void destory()
	{
	}

	public Endpoint clone() throws CloneNotSupportedException
	{
		throw new CloneNotSupportedException();
	}
}
