package spc.webos.cache;

import spc.webos.buffer.IBuffer;
import spc.webos.buffer.TimeoutException;
import spc.webos.log.Log;

/*
 * �Զ����wait��������timeout�ж�
 */
public abstract class WaitWithTime
{
	protected Object target;
	protected long timeout = 1000;
	static Log log = Log.getLogger(WaitWithTime.class);

	public WaitWithTime()
	{
	}

	public void setTarget(Object target)
	{
		this.target = target;
	}

	public WaitWithTime(long timeout)
	{
		this.timeout = timeout;
	}

	public WaitWithTime(Object target)
	{
		this.target = target;
	}

	public abstract boolean condition();

	public final void timeWait()
	{
		if (!condition()) return;
		long start = System.currentTimeMillis();
		long waitTime = timeout;
		while (true)
		{
			try
			{
				target.wait(timeout);
			}
			catch (InterruptedException e)
			{
				log.error("WaitWithTime.timeWait", e);
			}
			if (!condition()) return;
			long timeSoFar = System.currentTimeMillis() - start;
			if (timeSoFar >= waitTime)
			{
				if (log.isInfoEnabled()) log.info("Thread(" + Thread.currentThread().getName()
						+ ") wait timeout:" + timeout + ", target:" + target.getClass());
				TimeoutException te = new TimeoutException(timeout);
				if (target != null && target instanceof IBuffer) te.setDetail("name:"
						+ ((IBuffer) target).getName() + ",size:" + ((IBuffer) target).size()
						+ ",cap:" + ((IBuffer) target).cap());
				throw te;
			}
			else waitTime = timeout - timeSoFar;
		}
	}

	public void announce()
	{
		target.notifyAll();
	}

	public void setTimeout(long timeout)
	{
		this.timeout = timeout;
	}
}
