package spc.webos.queue.ibmmq;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.Map;

import spc.webos.buffer.IBuffer;
import spc.webos.cache.ICache;
import spc.webos.constant.AppRetCode;
import spc.webos.constant.Common;
import spc.webos.data.Status;
import spc.webos.queue.AbstractSenderThread;
import spc.webos.queue.AccessTPool;
import spc.webos.queue.MessageID;
import spc.webos.queue.QueueMessage;
import spc.webos.thread.ThreadPool;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;

public class SenderThread extends AbstractSenderThread
{
	protected int retryTimes = -1; // �������ʧ�ܵĳ��Դ���, -1��ʾ������
	protected int retryInterval = 500; // ���Է��͵ļ��, 0 ��ʾ�����
	protected MQPutMessageOptions pmo = new MQPutMessageOptions();
	protected Hashtable props;
	protected MQManager mqm;
	protected ICache msgIdCache;

	public SenderThread()
	{
		super();
	}

	public SenderThread(ThreadPool pool, Hashtable props, IBuffer buf, String qname,
			ICache msgIdCache)
	{
		super();
		this.pool = pool;
		this.props = props;
		this.buf = buf;
		this.msgIdCache = msgIdCache;
		this.qname = qname;
		Object ccsid = props.get(MQC.CCSID_PROPERTY);
		if (ccsid instanceof String) props.put(MQC.CCSID_PROPERTY, new Integer((String) ccsid));
		Object port = props.get(MQC.PORT_PROPERTY);
		if (port instanceof String) props.put(MQC.PORT_PROPERTY, new Integer((String) port));

		String retryTimes = (String) props.get("retryTimes");
		if (retryTimes != null && retryTimes.length() > 0) this.retryTimes = Integer
				.parseInt(retryTimes);
		String retryInterval = (String) props.get("retryInterval");
		if (retryInterval != null && retryTimes.length() > 0) this.retryInterval = Integer
				.parseInt(retryInterval);
	}

	public void init() throws Exception
	{
		mqm = new MQManager(props, -1);
		mqm.reconnect(-1);
		super.init();
	}

	public void asynStop()
	{
		log.warn("SenderThread(" + getName() + ") will stop: " + props);
		super.asynStop();
		release();
		log.warn("SenderThread(" + getName() + ") stopped...");
	}

	public void release()
	{
		mqm.disconnect();
		super.release();
	}

	public boolean send(String queueName, QueueMessage msg)
	{
		MQMessage mqMsg = new MQMessage();
		// mqMsg.characterSet = ccsid; // added by chenjs 2011-06-04
		long s = 0;
		if (msg.correlationId != null)
		{ // ���ͷ����������1. ǰ������û�й�����Ϣ�� 2. ������������Ӧ��������Ϣ������
			// mqMsg.messageId = msg.getCorrelationID();
			mqMsg.correlationId = msg.correlationId;
			if (log.isInfoEnabled()) log.info("send correlationId:"
					+ StringX.bytes2str(msg.correlationId, 16));
		}
		try
		{
			// byte[] buf = ((MQAccessTPool)
			// pool).getConverter().serialize(msg);
			byte[] buf = msg.buf;
			if (log.isInfoEnabled()) s = System.currentTimeMillis();
			if (log.isDebugEnabled()) log.debug("send content(utf-8) is:\n"
					+ new String(buf, Common.CHARSET_UTF8));
			mqMsg.write(buf);
		}
		catch (Exception e)
		{
			log.fatal("Fail to serialize msg in send this msg to queue", e);
			return false;
		}
		// �Ƿ����Ϣ���Ͳ��ó�ʱ����
		if (msg.expirySeconds > 0) mqMsg.expiry = msg.expirySeconds * 10;
		else if (((AccessTPool) pool).isExpiry()) mqMsg.expiry = AccessTPool.DEFAULT_EXPIRY * 10;
		try
		{
			Accessor.send(mqm, queueName, pmo, mqMsg, retryTimes, retryInterval);

			// �����������ʾ���ͳɹ������򲻳ɹ�
			if (log.isInfoEnabled()) log.info("success to send:" + queueName + ", sn:" + msg.sn
					+ ",cost:" + (System.currentTimeMillis() - s) + ",tm:"
					+ new SimpleDateFormat(SystemUtil.DF_SALL17).format(new Date()));
			// ����ͺ����¼�
			if (((AccessTPool) pool).getAsynSenderListener() != null) ((AccessTPool) pool)
					.getAsynSenderListener().success(msg, new Status(AppRetCode.SUCCESS()));
			// System.out.println(queueName+" send over buf:"+buf.length);
			// ���ǰ�˷���������������¼���͵���Ϣ����Ϣ�룬����ȡ��Ϣ���߳�ƥ��ʹ��
			if (msgIdCache != null)
			{
				msgIdCache.put(msg.sn, new MessageID(msg.sn, mqMsg.messageId));
				if (log.isDebugEnabled()) log.debug("put sn:" + msg.sn + " to msgIdCache");
			}
		}
		catch (Exception e)
		{ // ����һ�������쳣��رն��й�����������
			log.error("error send:", e);
			if (e instanceof MQException)
			{ // ����쳣��MQ�����쳣
				int ret = Accessor.handleMQException((MQException) e);
				if (ret == Accessor.MQ_CONNECTION_BROKER)
				{
					log.error("mqe.ret==-1...wait to reconnect...");
					mqm.disconnect();
				}
			}

			// �����ʧ�ܺ����¼�
			Status status = new Status();
			status.setDesc(retryTimes + "," + retryInterval + "," + queueName + ":" + props);
			status.setRetCd(AppRetCode.NET_COMMON());
			status.setAppCd(SystemUtil.APP);
			status.setIp(SystemUtil.LOCAL_HOST_IP);
			if (((AccessTPool) pool).getAsynSenderListener() != null) ((AccessTPool) pool)
					.getAsynSenderListener().fail(msg, status);
		}
		return mqm.qm != null;
	}

	public Hashtable getProps()
	{
		return props;
	}

	public void setProps(Hashtable props)
	{
		this.props = props;
	}

	public Map checkStatus(Map param)
	{
		Map status = super.checkStatus(param);
		status.put("props", props);
		return status;
	}

	public void setMsgIdCache(ICache msgIdCache)
	{
		this.msgIdCache = msgIdCache;
	}
}
