package spc.webos.data;

import java.io.Serializable;

import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;

public class Status implements Serializable
{
	private static final long serialVersionUID = 1L;
	public final static String STATUS_UNDERWAY = "U";
	public final static String STATUS_SUCCESS = "S";
	public final static String STATUS_FAIL = "F";

	public static String RETCD = "retCd";
	public static String DESC = "desc";
	public static String LOC = "location";
	public static String NODE = "mbrCd";
	public static String APPCD = "appCd";
	public static String IP = "ip";

	// added by chenjs 2011-10-13 ��ȷ����������ĸ��Χ
	/**
	 * @deprecated AppRetCode.SUCCESS()
	 */
	public static String SUCCESS = "000000"; // added by chenjs �Ѿ�ֹͣʹ��,
												// ��ΪAppRetCode.SUCCESS();
	public static String SUCCESS_PREFIX = "0";
	public static int SUCCESS_PREFIX_LEN = 1;
	public static int SUCCESS_PREFIX_START = 0;

	private String retCd;
	private String desc;
	private String location;
	private String mbrCd; // ��Ա���
	private String appCd; // Ӧ�ñ��
	private String ip;

	public Status()
	{
	}

	public Status(String retCd)
	{
		this.retCd = retCd;
	}

	public Status(String retCd, String desc, String loc, String mbrCd, String appCd, String ip)
	{
		this.retCd = retCd;
		this.desc = desc;
		this.location = loc;
		this.mbrCd = mbrCd;
		this.appCd = appCd;
		this.ip = ip;
	}

	public void set(ICompositeNode cn)
	{
		if (cn == null) return;
		IAtomNode an = (IAtomNode) cn.find(RETCD());
		if (an != null) retCd = an.stringValue();
		an = (IAtomNode) cn.find(DESC());
		if (an != null) desc = an.stringValue();
		an = (IAtomNode) cn.find(LOC());
		if (an != null) location = an.stringValue();
		an = (IAtomNode) cn.find(APPCD());
		if (an != null) appCd = an.stringValue();

		an = (IAtomNode) cn.find(NODE());
		if (an != null) mbrCd = an.stringValue();
		an = (IAtomNode) cn.find(IP());
		if (an != null) ip = an.stringValue();
	}

	public boolean isSuccess()
	{
		// modified by chenjs 2011-09-28 ������֧����дI(info), ������Ϣ�ɹ���
		return !StringX.nullity(retCd) && SUCCESS_PREFIX().indexOf(RETCD_STATUS(retCd)) >= 0;
	}

	public boolean isFail()
	{
		return !StringX.nullity(retCd) && SUCCESS_PREFIX().indexOf(RETCD_STATUS(retCd)) < 0;
	}

	public static String RETCD_STATUS(String retCd)
	{
		if (SUCCESS_PREFIX_START() >= 0) return retCd.substring(SUCCESS_PREFIX_START(),
				SUCCESS_PREFIX_LEN() < retCd.length() ? SUCCESS_PREFIX_LEN() : retCd.length());
		// ����Ǹ������ʾ��ĩβ����Ϊ��ʼ
		return retCd.substring(retCd.length() + SUCCESS_PREFIX_START(), SUCCESS_PREFIX_LEN());
	}

	public boolean isUnderWay()
	{
		return StringX.nullity(retCd);
	}

	public String getRetCd()
	{
		return retCd;
	}

	public void setRetCd(String code)
	{
		this.retCd = code;
	}

	public String getDesc()
	{
		return desc;
	}

	public void setDesc(String desc)
	{
		this.desc = desc;
	}

	public String getLocation()
	{
		return location;
	}

	public void setLocation(String location)
	{
		this.location = location;
	}

	public String getNodeAppCd()
	{
		return StringX.null2emptystr(mbrCd) + appCd;
	}

	public String getAppCd()
	{
		return appCd;
	}

	public void setAppCd(String appCd)
	{
		this.appCd = appCd;
	}

	public String getMbrCd()
	{
		return mbrCd;
	}

	public void setMbrCd(String mbrCd)
	{
		this.mbrCd = mbrCd;
	}

	public String getIp()
	{
		return ip;
	}

	public void setIp(String ip)
	{
		this.ip = ip;
	}

	public Status(ICompositeNode cn)
	{
		set(cn);
	}

	public StringBuffer toJson()
	{
		return new StringBuffer(JsonUtil.obj2json(this));
	}

	public String toString()
	{
		return "retCd:" + retCd + ",desc:" + desc + ",loc:" + location + ",mbr:" + mbrCd + ",app:"
				+ appCd + ",ip:" + ip;
	}

	public ICompositeNode toCNode()
	{
		ICompositeNode cnode = new CompositeNode();
		cnode.set(this);
		return cnode;
	}

	public static String RETCD()
	{
		return RETCD;
	}

	public static String DESC()
	{
		return DESC;
	}

	public static String LOC()
	{
		return LOC;
	}

	public static String NODE()
	{
		return NODE;
	}

	public static String APPCD()
	{
		return APPCD;
	}

	public static String IP()
	{
		return IP;
	}

	public static String SUCCESS_PREFIX()
	{
		return SUCCESS_PREFIX;
	}

	public static int SUCCESS_PREFIX_LEN()
	{
		return SUCCESS_PREFIX_LEN;
	}

	public static int SUCCESS_PREFIX_START()
	{
		return SUCCESS_PREFIX_START;
	}
}
