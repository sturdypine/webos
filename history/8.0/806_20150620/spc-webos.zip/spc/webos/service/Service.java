package spc.webos.service;

import java.util.HashMap;
import java.util.Map;

import spc.webos.config.AppConfig;
import spc.webos.log.Log;
import spc.webos.persistence.IPersistence;
import spc.webos.persistence.Persistence;
import spc.webos.util.StringX;

public class Service implements IService
{
	protected IPersistence persistence = Persistence.getInstance();
	protected String name;
	protected Object self = this;
	protected boolean jsrmi = true;
	protected final Log log = Log.getLogger(getClass());

	protected String lastDBVerDt = StringX.EMPTY_STRING;
	protected String dbVerDtKey; //

	/**
	 * �ṩinit��������, ��spring2.0���� default-init-method
	 * 
	 */
	public void init() throws Exception
	{
		if (!StringX.nullity(name))
		{
			if (SERVICES.containsKey(name)) log.warn(name + " Service existed in SERVICES!!!");
			SERVICES.put(name, this);
			if (jsrmi) SERVICES_JSRMI.put(name, this);
			SERVICES_PROXY.put(name, this);
		}
	}

	// ͬ��
	public void close()
	{
	}

	/**
	 * @deprecated
	 */
	public void destory()
	{
	}

	// added by chenjs 2011-09-19 �޸�destory���ʷ���
	public void destroy()
	{
		destory();
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public IPersistence getPersistence()
	{
		return persistence;
	}

	public void setPersistence(IPersistence persistence)
	{
		this.persistence = persistence;
	}

	public boolean changeStatus(Map param)
	{
		return false;
	}

	public Map checkStatus(Map param)
	{
		return new HashMap();
	}

	public void refresh() throws Exception
	{
	}

	// ����ˢ��ʱ�жϷ����Ƿ���Ҫˢ�����ݿ�
	public boolean isDBRefreshed()
	{
		if (StringX.nullity(dbVerDtKey))
		{
			log.info("dbVerDtKey is null!!!");
			return true;
		}
		String curDBVerDt = AppConfig.getInstance().getProperty(dbVerDtKey, StringX.EMPTY_STRING)
				.toString();
		log.debug("curDBVerDt: " + curDBVerDt);
		if (!StringX.nullity(curDBVerDt) && !StringX.nullity(lastDBVerDt)
				&& lastDBVerDt.equalsIgnoreCase(curDBVerDt))
		{
			log.info("curDBVerDt == lastDBVerDt(" + lastDBVerDt + ")!!!");
			return false;
		}
		if (StringX.nullity(curDBVerDt)) log.info("curDBVerDt is null by:" + dbVerDtKey);
		if (log.isInfoEnabled()) log.info("lastDBVerDt:" + lastDBVerDt + ", curDBVerDt:"
				+ curDBVerDt);
		lastDBVerDt = curDBVerDt;
		return true;
	}

	public void setSelf(Object proxyBean)
	{
		self = proxyBean;
		if (!StringX.nullity(name) && self != null)
		{
			SERVICES_PROXY.put(name, proxyBean);
			if (jsrmi) SERVICES_JSRMI.put(name, proxyBean);
			if (!SERVICES.containsKey(name)) SERVICES.put(name, this);
		}
	}

	public Object getSelf()
	{
		return self;
	}

	public boolean isJsrmi()
	{
		return jsrmi;
	}

	public void setJsrmi(boolean jsrmi)
	{
		this.jsrmi = jsrmi;
	}

	public String getLastDBVerDt()
	{
		return lastDBVerDt;
	}

	public void setLastDBVerDt(String lastDBVerDt)
	{
		this.lastDBVerDt = lastDBVerDt;
	}

	public String getDbVerDtKey()
	{
		return dbVerDtKey;
	}

	public void setDbVerDtKey(String dbVerDtKey)
	{
		this.dbVerDtKey = dbVerDtKey;
	}
}
