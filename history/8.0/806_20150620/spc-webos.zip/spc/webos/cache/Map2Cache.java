package spc.webos.cache;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class Map2Cache extends AbstractCache
{
	protected HashMap<Object, Object[]> map = new HashMap<Object, Object[]>();
	protected long expireSeconds = 60;
	protected int threshold = 200; // 713_20140924 Ĭ��ֵ��100��ߵ�200Ӧ��ǰ����200���������

	public Map2Cache()
	{
	}

	public Map2Cache(long expireSeconds)
	{
		this.expireSeconds = expireSeconds;
	}

	public Map2Cache(long expireSeconds, int threshold)
	{
		this.expireSeconds = expireSeconds;
		this.threshold = threshold;
	}

	public Map checkStatus(Map param)
	{
		return null;
	}

	public boolean changeStatus(Map param)
	{
		return false;
	}

	public void refresh() throws Exception
	{

	}

	public Collection getKeys()
	{
		return map.keySet();
	}

	public int size()
	{
		return map.size();
	}

	public Object get(Object key)
	{
		Object[] o = map.get(key);
		if (o == null) return null;
		return o[0];
	}

	public synchronized Object put(Object key, Object o) throws Exception
	{
		evictExpiredElements();
		map.put(key, new Object[] { o, System.currentTimeMillis(), expireSeconds });
		notifyAll();
		return o;
	}

	public synchronized void removeAll()
	{
		map.clear();
	}

	public synchronized Object remove(Object o)
	{
		map.remove(o);
		return o;
	}

	public synchronized void put(String key, Object o, long expireSeconds) throws Exception
	{
		evictExpiredElements();
		map.put(key, new Object[] { o, System.currentTimeMillis(), expireSeconds });
		notifyAll();
	}

	public Object get(String key, boolean browse)
	{
		return get(key);
	}

	public synchronized void evictExpiredElements()
	{
		if (map.size() <= threshold) return;
		log.info("evict expired elements...");
		long cur = System.currentTimeMillis();
		Object[] keys = new Object[map.size()];
		map.keySet().toArray(keys);
		for (int i = 0; i < keys.length; i++)
		{
			Object[] o = map.get(keys[i]);
			if (cur - ((Long) o[1]) > ((Long) o[2]) * 1000)
			{
				log.info("expired element: " + keys[i] + "," + o[1] + "," + o[2]);
				map.remove(keys[i]);
			}
		}
	}

	public long getExpireSeconds()
	{
		return expireSeconds;
	}

	public void setExpireSeconds(long expireSeconds)
	{
		this.expireSeconds = expireSeconds;
	}

	public int getThreshold()
	{
		return threshold;
	}

	public void setThreshold(int threshold)
	{
		this.threshold = threshold;
	}
}
