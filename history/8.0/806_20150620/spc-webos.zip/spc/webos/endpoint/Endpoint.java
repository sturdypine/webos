package spc.webos.endpoint;

public interface Endpoint
{
	void setLocation(String location) throws Exception;

	void init() throws Exception;

	void execute(Executable exe) throws Exception;

	void destory();

	Endpoint clone() throws CloneNotSupportedException;
}
