package spc.webos.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import spc.webos.jdbc.blob.ByteArrayBlob;
import spc.webos.timeout.service.Timeout;
import spc.webos.util.JsonUtil;

/**
 * genarated by sturdypine.chen Email: sturdypine@gmail.com description:
 */
public class BPELInstanceVO implements ValueObject, Timeout
{
	public static final long serialVersionUID = 20110131L;
	// ����������Ӧ�ֶε�����
	String msgSn; // ����
	String msgCd; //
	String lang;
	String callTyp; //
	String sndNode; //
	String sndAppCd; //
	String sndDt; //
	String sndTm; //
	String seqNb; //
	String proccessName; //
	String ver; //
	String instanceId; //
	String status; //
	String variables; //
	ByteArrayBlob parentXml; //
	String tmStamp; //
	Integer timeout;

	// �ʹ�VO�����������VO����

	// �ʹ�VO�������������Sql����
	// Note: ���������Sql����ΪString, Inegter...��Java final classʱ�� ֻ��ʹ��Object����
	// ����ʱ��ֻ��ͨ��
	// Object��toString()������ʹ�á�
	public static final String TABLE = "bpl_instance";
	public static final String[] BLOB_FIELD = null;
	public static final String SEQ_NAME = "msgSn";

	public BPELInstanceVO()
	{
	}

	public String getInTime() // ���볬ʱ�۲��ʱ��: "20110909010101001"
	{
		return tmStamp;
	}

	public String getSn() // ��ʱ��ϢΨһ��ˮ��
	{
		return msgSn;
	}

	public Integer getTimeout()
	{
		return timeout;
	}

	public void setTimeout(Integer timeout)
	{
		this.timeout = timeout;
	}

	public void setPrimary(String msgSn)
	{
		this.msgSn = msgSn;
	}

	public String getPrimary(String delim)
	{
		StringBuffer buf = new StringBuffer();
		buf.append(this.msgSn);
		return buf.toString();
	}

	public Map getPrimary()
	{
		Map m = new HashMap();
		m.put("msgSn", msgSn);
		return m;
	}

	public String getTable()
	{
		return TABLE;
	}

	public String[] getBlobField()
	{
		return BLOB_FIELD;
	}

	public String getKeyName()
	{
		return SEQ_NAME;
	}

	public Serializable getKey()
	{
		return msgSn;
	}

	// set all properties to NULL
	public void setNULL()
	{
		this.msgSn = null;
		this.msgCd = null;
		this.callTyp = null;
		this.sndNode = null;
		this.sndAppCd = null;
		this.sndDt = null;
		this.sndTm = null;
		this.seqNb = null;
		this.proccessName = null;
		this.ver = null;
		this.instanceId = null;
		this.status = null;
		this.variables = null;
		this.parentXml = null;
		this.tmStamp = null;
	}

	public boolean equals(Object o)
	{
		if (this == o) return true;
		if (!(o instanceof BPELInstanceVO)) return false;
		BPELInstanceVO obj = (BPELInstanceVO) o;
		if (!msgSn.equals(obj.msgSn)) return false;
		if (!msgCd.equals(obj.msgCd)) return false;
		if (!callTyp.equals(obj.callTyp)) return false;
		if (!sndNode.equals(obj.sndNode)) return false;
		if (!sndAppCd.equals(obj.sndAppCd)) return false;
		if (!sndDt.equals(obj.sndDt)) return false;
		if (!sndTm.equals(obj.sndTm)) return false;
		if (!seqNb.equals(obj.seqNb)) return false;
		if (!proccessName.equals(obj.proccessName)) return false;
		if (!ver.equals(obj.ver)) return false;
		if (!instanceId.equals(obj.instanceId)) return false;
		if (!status.equals(obj.status)) return false;
		if (!variables.equals(obj.variables)) return false;
		if (!parentXml.equals(obj.parentXml)) return false;
		if (!tmStamp.equals(obj.tmStamp)) return false;
		return true;
	}

	// ֻ����������ɢ��
	public int hashCode()
	{
		long hashCode = getClass().hashCode();
		if (msgSn != null) hashCode += msgSn.hashCode();
		return (int) hashCode;
	}

	public int compareTo(Object o)
	{
		return -1;
	}

	// set all properties to default value...
	public void init()
	{
	}

	public String getMsgSn()
	{
		return msgSn;
	}

	public void setMsgSn(String msgSn)
	{
		this.msgSn = msgSn;
	}

	public String getLang()
	{
		return lang;
	}

	public void setLang(String lang)
	{
		this.lang = lang;
	}

	public String getMsgCd()
	{
		return msgCd;
	}

	public void setMsgCd(String msgCd)
	{
		this.msgCd = msgCd;
	}

	public String getCallTyp()
	{
		return callTyp;
	}

	public void setCallTyp(String callTyp)
	{
		this.callTyp = callTyp;
	}

	public String getSndNode()
	{
		return sndNode;
	}

	public void setSndNode(String sndNode)
	{
		this.sndNode = sndNode;
	}

	public String getSndAppCd()
	{
		return sndAppCd;
	}

	public void setSndAppCd(String sndAppCd)
	{
		this.sndAppCd = sndAppCd;
	}

	public String getSndDt()
	{
		return sndDt;
	}

	public void setSndDt(String sndDt)
	{
		this.sndDt = sndDt;
	}

	public String getSndTm()
	{
		return sndTm;
	}

	public void setSndTm(String sndTm)
	{
		this.sndTm = sndTm;
	}

	public String getSeqNb()
	{
		return seqNb;
	}

	public void setSeqNb(String seqNb)
	{
		this.seqNb = seqNb;
	}

	public String getProccessName()
	{
		return proccessName;
	}

	public void setProccessName(String proccessName)
	{
		this.proccessName = proccessName;
	}

	public String getVer()
	{
		return ver;
	}

	public void setVer(String ver)
	{
		this.ver = ver;
	}

	public String getInstanceId()
	{
		return instanceId;
	}

	public void setInstanceId(String instanceId)
	{
		this.instanceId = instanceId;
	}

	public String getStatus()
	{
		return status;
	}

	public void setStatus(String status)
	{
		this.status = status;
	}

	public String getVariables()
	{
		return variables;
	}

	public void setVariables(String variables)
	{
		this.variables = variables;
	}

	public ByteArrayBlob getParentXml()
	{
		return parentXml;
	}

	public void setParentXml(ByteArrayBlob parentXml)
	{
		this.parentXml = parentXml;
	}

	public String getTmStamp()
	{
		return tmStamp;
	}

	public void setTmStamp(String tmStamp)
	{
		this.tmStamp = tmStamp;
	}

	public void set(BPELInstanceVO vo)
	{
		this.msgSn = vo.msgSn;
		this.msgCd = vo.msgCd;
		this.callTyp = vo.callTyp;
		this.sndNode = vo.sndNode;
		this.sndAppCd = vo.sndAppCd;
		this.sndDt = vo.sndDt;
		this.sndTm = vo.sndTm;
		this.seqNb = vo.seqNb;
		this.proccessName = vo.proccessName;
		this.ver = vo.ver;
		this.instanceId = vo.instanceId;
		this.status = vo.status;
		this.variables = vo.variables;
		this.parentXml = vo.parentXml;
		this.tmStamp = vo.tmStamp;
	}

	public static long getSerialVersionUID()
	{
		return serialVersionUID;
	}

	public StringBuffer toJson()
	{
		StringBuffer buf = new StringBuffer();
		buf.append(JsonUtil.obj2json(this));
		return buf;
		// StringBuffer buf = new StringBuffer();
		// buf.append('{');
		// if (msgSn != null)
		// {
		// if (buf.length() > 2) buf.append(',');
		// buf.append("msgSn:'");
		// buf.append(msgSn);
		// buf.append('\'');
		// }
		// if (msgCd != null)
		// {
		// if (buf.length() > 2) buf.append(',');
		// buf.append("msgCd:'");
		// buf.append(msgCd);
		// buf.append('\'');
		// }
		// if (callTyp != null)
		// {
		// if (buf.length() > 2) buf.append(',');
		// buf.append("callTyp:'");
		// buf.append(callTyp);
		// buf.append('\'');
		// }
		// if (sndNode != null)
		// {
		// if (buf.length() > 2) buf.append(',');
		// buf.append("sndNode:'");
		// buf.append(sndNode);
		// buf.append('\'');
		// }
		// if (sndAppCd != null)
		// {
		// if (buf.length() > 2) buf.append(',');
		// buf.append("sndAppCd:'");
		// buf.append(sndAppCd);
		// buf.append('\'');
		// }
		// if (sndDt != null)
		// {
		// if (buf.length() > 2) buf.append(',');
		// buf.append("sndDt:'");
		// buf.append(sndDt);
		// buf.append('\'');
		// }
		// if (sndTm != null)
		// {
		// if (buf.length() > 2) buf.append(',');
		// buf.append("sndTm:'");
		// buf.append(sndTm);
		// buf.append('\'');
		// }
		// if (seqNb != null)
		// {
		// if (buf.length() > 2) buf.append(',');
		// buf.append("seqNb:'");
		// buf.append(seqNb);
		// buf.append('\'');
		// }
		// if (proccessName != null)
		// {
		// if (buf.length() > 2) buf.append(',');
		// buf.append("proccessName:'");
		// buf.append(proccessName);
		// buf.append('\'');
		// }
		// if (ver != null)
		// {
		// if (buf.length() > 2) buf.append(',');
		// buf.append("ver:'");
		// buf.append(ver);
		// buf.append('\'');
		// }
		// if (instanceId != null)
		// {
		// if (buf.length() > 2) buf.append(',');
		// buf.append("instanceId:'");
		// buf.append(instanceId);
		// buf.append('\'');
		// }
		// if (status != null)
		// {
		// if (buf.length() > 2) buf.append(',');
		// buf.append("status:'");
		// buf.append(status);
		// buf.append('\'');
		// }
		// if (variables != null)
		// {
		// if (buf.length() > 2) buf.append(',');
		// buf.append("variables:'");
		// buf.append(variables);
		// buf.append('\'');
		// }
		// if (parentXml != null)
		// {
		// if (buf.length() > 2) buf.append(',');
		// buf.append("parentXml:'");
		// buf.append(parentXml.toString().replaceAll("'", "\""));
		// buf.append('\'');
		// }
		// if (tmStamp != null)
		// {
		// if (buf.length() > 2) buf.append(',');
		// buf.append("tmStamp:'");
		// buf.append(tmStamp);
		// buf.append('\'');
		// }
		// buf.append('}');
		// return buf;
	}

	public void afterLoad()
	{
		// TODO Auto-generated method stub

	}

	public void beforeLoad()
	{
		// TODO Auto-generated method stub

	}

	public void setManualSeq(Long seq)
	{

	}

	public void destory()
	{

	}

	public String toString()
	{
		StringBuffer buf = new StringBuffer(128);
		buf.append(getClass().getName() + "(serialVersionUID=" + serialVersionUID + "):");
		buf.append(toJson());
		return buf.toString();
	}
}
