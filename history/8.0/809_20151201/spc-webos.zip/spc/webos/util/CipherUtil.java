package spc.webos.util;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

public class CipherUtil
{
	static final String ALG_DES = "DES";

	/**
	 * �ԳƼ��ܷ���
	 * 
	 * @param byteSource
	 *            ��Ҫ���ܵ�����
	 * @return �������ܵ�����
	 * @throws Exception
	 */
	public static byte[] desEncrypt(byte[] byteSource, byte[] key) throws Exception
	{
		return desEncrypt(byteSource, 0, byteSource.length, key);
	}

	public static byte[] desEncrypt(byte[] byteSource, int offset, int len, byte[] key)
			throws Exception
	{
		Cipher cipher = Cipher.getInstance(ALG_DES);
		cipher.init(Cipher.ENCRYPT_MODE,
				SecretKeyFactory.getInstance(ALG_DES).generateSecret(new DESKeySpec(key)));
		return cipher.doFinal(byteSource, offset, len);
	}

	public static byte[] desDecrypt(byte[] byteSource, byte[] key) throws Exception
	{
		return desDecrypt(byteSource, 0, byteSource.length, key);
	}

	/**
	 * �Գƽ��ܷ���
	 * 
	 * @param byteSource
	 *            ��Ҫ���ܵ�����
	 * @return �������ܵ�����
	 * @throws Exception
	 */
	public static byte[] desDecrypt(byte[] byteSource, int offset, int len, byte[] key)
			throws Exception
	{
		Cipher cipher = Cipher.getInstance(ALG_DES);
		cipher.init(Cipher.DECRYPT_MODE,
				SecretKeyFactory.getInstance(ALG_DES).generateSecret(new DESKeySpec(key)));
		return cipher.doFinal(byteSource, offset, len);
	}
}
