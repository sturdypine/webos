package spc.webos.util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;

public class BeanPropertyUtil
{
	final static Map CLASS_FIELD = new HashMap();

	/**
	 * ���Դ�Сд������´�class�л�ȡ׼ȷ��Bean������
	 * 
	 * @param clazz
	 * @param fieldName
	 * @return
	 */
	public static String getProperty(Class clazz, String fieldName)
	{
		Map field = getClazzField(clazz);
		String attrField = (String) field.get(fieldName.toLowerCase());
		return attrField == null ? null : attrField;
	}

	public static Map getClazzField(Class clazz)
	{
		synchronized (CLASS_FIELD)
		{
			Map field = (Map) CLASS_FIELD.get(clazz);
			if (field != null) return field;
			field = new HashMap();
			while (!clazz.equals(Object.class))
			{
				Field[] fields = clazz.getDeclaredFields();
				for (int i = 0; fields != null && i < fields.length; i++)
				{
					if (Modifier.isStatic(fields[i].getModifiers())) continue;
					String fname = fields[i].getName();
					field.put(fname.toLowerCase(), fname);
				}
				clazz = clazz.getSuperclass();
			}
			CLASS_FIELD.put(clazz, field);
			return field;
		}
	}

	public static void bean2map(Object bean, Map map)
	{
		Field[] fields = bean.getClass().getDeclaredFields();
		for (int i = 0; i < fields.length; i++)
		{
			String name = fields[i].getName();
			if (fields[i].getModifiers() == 4) continue; // ˽�е���Ϊ�ⲿ��������
			Object value = null;
			try
			{
				Method m = bean.getClass().getDeclaredMethod(
						"get" + Character.toUpperCase(name.charAt(0)) + name.substring(1), null);
				value = m.invoke(bean, null);
			}
			catch (Exception e)
			{
			}
			if (value == null) continue;
			map.put(name, value);
		}
	}
}
