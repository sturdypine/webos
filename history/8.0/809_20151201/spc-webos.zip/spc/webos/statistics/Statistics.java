package spc.webos.statistics;

public class Statistics implements java.io.Serializable
{
	private static final long serialVersionUID = 1L;
	private long start; // ͳ�ƿ�ʼʱ��
	private long request; // �ۼ�����
	private long response; // �ۼ���Ӧ
	private long success; // �ۼƳɹ�
	private long failBiz; // �ۼ�ʧ��, ҵ��ԭ��
	private long failSys; // �ۼ�ʧ��, ϵͳԭ��
	private long cost; // �ۼƴ�������ʱ��

	private String maxSN; // �����ʱ����ˮ
	private int maxCost; // �����ʱ��
	private String minSN; // ��С����ʱ����ˮ
	private int minCost; // ��С����ʱ��

	public Statistics()
	{
		reset();
	}

	public int getMaxCost()
	{
		return maxCost;
	}

	public void setMaxCost(int maxCost)
	{
		this.maxCost = maxCost;
	}

	public int getMinCost()
	{
		return minCost;
	}

	public void setMinCost(int minCost)
	{
		this.minCost = minCost;
	}

	public synchronized void reset()
	{
		start = System.currentTimeMillis();
		request = response = success = failBiz = failSys = cost = maxCost = 0;
		minCost = Integer.MAX_VALUE;
	}

	public synchronized void success(String sn, int cost)
	{
		this.cost += cost;
		if (cost > maxCost)
		{
			maxCost = cost;
			maxSN = sn;
		}
		if (cost < minCost)
		{
			minCost = cost;
			minSN = sn;
		}
		success++;
		response++;
	}

	public synchronized void fail(String retCd, String sn, int cost)
	{
		this.cost += cost;
		if (cost > maxCost)
		{
			maxCost = cost;
			maxSN = sn;
		}
		if (cost < minCost)
		{
			minCost = cost;
			minSN = sn;
		}
		if (retCd.startsWith("1") || retCd.startsWith("9")) failSys++;
		else failBiz++;
		response++;
	}

	public synchronized void request()
	{
		request++;
	}

	public long getCost()
	{
		return cost;
	}

	public long getRequest()
	{
		return request;
	}

	public long getResponse()
	{
		return response;
	}

	public long getSuccess()
	{
		return success;
	}

	public long getFailBiz()
	{
		return failBiz;
	}

	public long getFailSys()
	{
		return failSys;
	}

	public long getStart()
	{
		return start;
	}

	public String getMaxSN()
	{
		return maxSN;
	}

	public void setMaxSN(String maxSN)
	{
		this.maxSN = maxSN;
	}

	public String getMinSN()
	{
		return minSN;
	}

	public void setMinSN(String minSN)
	{
		this.minSN = minSN;
	}
}
