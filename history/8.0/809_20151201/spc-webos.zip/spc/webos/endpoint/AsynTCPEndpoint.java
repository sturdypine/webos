package spc.webos.endpoint;

import java.io.IOException;
import java.net.InetAddress;
import java.util.Map;

import org.xsocket.connection.IDataHandler;
import org.xsocket.connection.NonBlockingConnection;

import spc.webos.util.StringX;
import spc.webos.util.bytes.BytesUtil;

public class AsynTCPEndpoint extends AbstractTCPEndpoint
{
	public void execute(Executable exe) throws Exception
	{
		int fail = 0;
		while (!exe.cnnSnd)
		{
			try
			{
				exe.resTime = 0;
				if (longCnn) longCnn(exe, getCurrentIP(exe), getCurrentPort(exe));
				else shortCnn(exe, getCurrentIP(exe), getCurrentPort(exe));
			}
			catch (Exception e)
			{
				if (!exe.cnnSnd && fail < retryTimes) log.warn("", e);
				else throw e;
				fail++;
			}
		}
	}

	protected synchronized void longCnn(Executable exe, String ip, int port) throws Exception
	{
		if (nbc == null) nbc = createNonBlockingConnection(exe, ip, port,
				createDataHandler(exe, ip, port));
		try
		{
			send(nbc, exe, ip, port);
		}
		catch (Exception e)
		{
			try
			{
				nbc.close();
			}
			catch (Exception ee)
			{
			}
			nbc = null;
			throw e;
		}
	}

	protected void shortCnn(Executable exe, String ip, int port) throws Exception
	{
		ask4cnn(); // �����������󲢷���������������
		AsynTCPClientHandler handler = (AsynTCPClientHandler) createDataHandler(exe, ip, port);
		try
		{
			NonBlockingConnection nbc = createNonBlockingConnection(exe, ip, port, handler);
			// 702_20140225 ���û��Ӧ����������¼������� 808һ�ɰ󶨴����¼�
			if (exe.timeout > 0) nbc.setIdleTimeoutMillis(exe.timeout * 1000);
			else if (soTimeout > 0) nbc.setIdleTimeoutMillis(soTimeout); // 808,����*1000
			send(nbc, exe, ip, port);
		}
		catch (Exception e)
		{
			handler.releaseCnn(); // �����������ʧ�����ͷ����ӿ�����
			throw e;
		}
		finally
		{
			try
			{ // �������޷��ػ����ǵ���ģʽ��ֱ��close��
				if (exe.withoutReturn || simplex)
				{
					if (log.isInfoEnabled()) log.info("nbc close, simplex:" + simplex + ", return:"
							+ !exe.isWithoutReturn() + ", sleepMillis:" + sleepMillis + ", remote:"
							+ nbc.getRemoteAddress());
					// 808, ʹ��handler�ķ������ͷ����ӣ���ֹ����ط��ͷ�����ʱ����й¶
					handler.releaseCnn();
					if (sleepMillis > 0) Thread.sleep(sleepMillis);
					nbc.close();
				}
			}
			catch (Exception ee)
			{
			}
		}
	}

	protected NonBlockingConnection createNonBlockingConnection(Executable exe, String ip,
			int port, IDataHandler handler) throws Exception
	{
		if (log.isInfoEnabled()) log.info("cnn::" + ip + ":" + port + ", cnnT" + cnnTimeout
				+ ", soT:" + soTimeout + ", tT:" + exe.timeout);
		return new NonBlockingConnection(InetAddress.getByName(ip), port, handler, cnnTimeout);
	}

	protected IDataHandler createDataHandler(Executable exe, String ip, int port)
	{
		return new AsynTCPClientHandler(this, exe, ip, port);
	}

	protected void send(NonBlockingConnection nbc, Executable exe, String ip, int port)
			throws Exception
	{
		if (log.isInfoEnabled()) log.info("ATCP  timeout:" + exe.getTimeout() + ", return:"
				+ !exe.isWithoutReturn() + ", len:"
				+ (exe.request == null ? 0 : exe.request.length) + ", cnnNum:" + currentCnnNum);
		exe.reqTime = System.currentTimeMillis();
		if (dhl.hdrLen <= 0)
		{
			send(nbc, http ? packHttpRequest(exe.request, exe.reqHttpHeaders) : exe.request);
			exe.cnnSnd = true; // ���ͳɹ���־
			log.info("suc snd no hdrlen");
		}
		else
		{ // ���ͳ���ͷ��Ϣ
			byte[] lenbytes = lenBytes(exe.request);
			send(nbc, BytesUtil.merge(lenbytes, exe.request));
			exe.cnnSnd = true; // ���ͳɹ���־
			log.info("suc snd hdrlen:" + new String(lenbytes));
		}
	}

	protected void send(NonBlockingConnection nbc, byte[] buf) throws Exception
	{
		if (isTrace() && log.isInfoEnabled()) log.info("trace snd:" + StringX.base64(buf) + "\n"
				+ new String(buf));
		else if (log.isDebugEnabled()) log.debug("snd:" + StringX.base64(buf) + "\n"
				+ new String(buf));
		nbc.write(buf, 0, buf.length);
		nbc.flush();
	}

	public String toString(int port)
	{
		return "ATCP://" + ip + ":" + port + ", simplex:" + simplex + ", longCnn:" + longCnn + ":"
				+ dhl.hdrLen + ":" + dhl.len2bcd + ":" + dhl.hdrLenBinary;
	}

	public AsynTCPEndpoint()
	{
	}

	public AsynTCPEndpoint(String location)
	{
		createEndpoint(location);
	}

	public void destory()
	{
		try
		{
			if (nbc != null)
			{
				log.info("close nbc:: " + nbc.getRemoteAddress() + ", open:" + nbc.isOpen());
				if (nbc.isOpen()) nbc.close();
			}
		}
		catch (IOException e)
		{
		}
		super.destory();
	}

	public Map createEndpoint(String location)
	{
		Map extParams = super.createEndpoint(location);
		if (extParams == null) return null;
		String val = (String) extParams.get("logName");
		if (!StringX.nullity(val)) logName = val;

		return extParams;
	}

	protected NonBlockingConnection nbc; // ������
	protected String logName; // �첽Ӧ����߳���־��

	public String getLogName()
	{
		return logName;
	}

	public void setLogName(String logName)
	{
		this.logName = logName;
	}
}
