package spc.webos.endpoint;

import spc.webos.exception.AppException;

/**
 * �첽TCP�ص�����
 * 
 * @author chenjs
 * 
 */
public interface ITCPCallback
{
	void response(Executable exe, AsynTCPEndpoint endpoint, String ip, int port) throws Throwable;

	void fail(Executable exe, AsynTCPEndpoint endpoint, String ip, int port, AppException appEx) throws Throwable;
}
