package spc.webos.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * genarated by sturdypine.chen Email: sturdypine@gmail.com description:
 */
public class OrgVO implements ValueObject
{
	public static final long serialVersionUID = 20080121L;
	// ����������Ӧ�ֶε�����
	String id; // ����
	String code; // 
	String parentId; // 
	String name; // 
	String sname; // 
	String type; // 
	String directors;
	String leaders;
	String abolishFlag; // 

	// �ʹ�VO�����������VO����

	// �ʹ�VO�������������Sql����
	// Note: ���������Sql����ΪString, Inegter...��Java final classʱ�� ֻ��ʹ��Object����
	// ����ʱ��ֻ��ͨ��
	// Object��toString()������ʹ�á�
	public static final String TABLE = "sys_org";
	public static final String[] BLOB_FIELD = null;
	public static final String SEQ_NAME = "id";

	public OrgVO()
	{
	}

	public OrgVO(String id)
	{
		this.id = id;
	}

	public void setPrimary(String id)
	{
		this.id = id;
	}

	public String getPrimary(String delim)
	{
		StringBuffer buf = new StringBuffer();
		buf.append(this.id);
		return buf.toString();
	}

	public Map getPrimary()
	{
		Map m = new HashMap();
		m.put("id", id);
		return m;
	}

	public String getTable()
	{
		return TABLE;
	}

	public String[] getBlobField()
	{
		return BLOB_FIELD;
	}

	public String getKeyName()
	{
		return SEQ_NAME;
	}

	public Serializable getKey()
	{
		return id;
	}

	// set all properties to NULL
	public void setNULL()
	{
		this.id = null;
		this.code = null;
		this.parentId = null;
		this.name = null;
		this.sname = null;
		this.type = null;
		this.abolishFlag = null;
	}

	public boolean equals(Object o)
	{
		if (this == o) return true;
		if (!(o instanceof OrgVO)) return false;
		OrgVO obj = (OrgVO) o;
		if (!id.equals(obj.id)) return false;
		if (!code.equals(obj.code)) return false;
		if (!parentId.equals(obj.parentId)) return false;
		if (!name.equals(obj.name)) return false;
		if (!sname.equals(obj.sname)) return false;
		if (!type.equals(obj.type)) return false;
		if (!abolishFlag.equals(obj.abolishFlag)) return false;
		return true;
	}

	// ֻ����������ɢ��
	public int hashCode()
	{
		long hashCode = getClass().hashCode();
		if (id != null) hashCode += id.hashCode();
		return (int) hashCode;
	}

	public int compareTo(Object o)
	{
		return -1;
	}

	// set all properties to default value...
	public void init()
	{
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getCode()
	{
		return code;
	}

	public void setCode(String code)
	{
		this.code = code;
	}

	public String getParentId()
	{
		return parentId;
	}

	public void setParentId(String parentId)
	{
		this.parentId = parentId;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getSname()
	{
		return sname;
	}

	public void setSname(String sname)
	{
		this.sname = sname;
	}

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public String getAbolishFlag()
	{
		return abolishFlag;
	}

	public void setAbolishFlag(String abolishFlag)
	{
		this.abolishFlag = abolishFlag;
	}

	public void set(OrgVO vo)
	{
		this.id = vo.id;
		this.code = vo.code;
		this.parentId = vo.parentId;
		this.name = vo.name;
		this.sname = vo.sname;
		this.type = vo.type;
		this.abolishFlag = vo.abolishFlag;
	}

	public static long getSerialVersionUID()
	{
		return serialVersionUID;
	}

	public StringBuffer toJson()
	{
		StringBuffer buf = new StringBuffer();
		buf.append('{');
		if (id != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("id:'");
			buf.append(id);
			buf.append('\'');
		}
		if (code != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("code:'");
			buf.append(code);
			buf.append('\'');
		}
		if (parentId != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("parentId:'");
			buf.append(parentId);
			buf.append('\'');
		}
		if (name != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("name:'");
			buf.append(name);
			buf.append('\'');
		}
		if (sname != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("sname:'");
			buf.append(sname);
			buf.append('\'');
		}
		if (type != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("type:'");
			buf.append(type);
			buf.append('\'');
		}
		if (abolishFlag != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("abolishFlag:'");
			buf.append(abolishFlag);
			buf.append('\'');
		}
		buf.append('}');
		return buf;
	}

	public void destory()
	{

	}

	public String toString()
	{
		StringBuffer buf = new StringBuffer(128);
		buf.append(getClass().getName() + "(serialVersionUID="
				+ serialVersionUID + "):");
		buf.append(toJson());
		return buf.toString();
	}

	public String getDirectors()
	{
		return directors;
	}

	public void setDirectors(String directors)
	{
		this.directors = directors;
	}

	public String getLeaders()
	{
		return leaders;
	}

	public void setLeaders(String leaders)
	{
		this.leaders = leaders;
	}

	public void afterLoad()
	{
		// TODO Auto-generated method stub
		
	}

	public void beforeLoad()
	{
		// TODO Auto-generated method stub
		
	}

	public void setManualSeq(Long seq)
	{
		// TODO Auto-generated method stub
		
	}
}
