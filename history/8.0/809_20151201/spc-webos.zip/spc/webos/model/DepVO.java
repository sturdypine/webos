package spc.webos.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import spc.webos.util.JsonUtil;

/**
* genarated by sturdypine.chen
* Email: sturdypine@gmail.com
* description: 
*/
public class DepVO implements ValueObject
{
	public static final long serialVersionUID = 20120406L;
	// ����������Ӧ�ֶε�����
	String id; // 
	String name; // 
	String parentId; // 
	String orgId; // 
	Integer level; // 
	String directors;
	String leaders;
	Integer status; // 

	// �ʹ�VO�����������VO����
	
	// �ʹ�VO�������������Sql����
	// Note: ���������Sql����ΪString, Inegter...��Java final classʱ�� ֻ��ʹ��Object���� ����ʱ��ֻ��ͨ��
	// Object��toString()������ʹ�á�
	public static final String TABLE = "SYS_DEP";
	public static final String[] BLOB_FIELD = null;
	public static final String SEQ_NAME = "null";

	
	public DepVO()
	{
	}
	
	public void setPrimary()
	{
	}
	
	public String getPrimary(String delim)
	{
		StringBuffer buf = new StringBuffer();
		return buf.toString();
	}
	
	public Map getPrimary()
	{
		Map m = new HashMap();
		return m;
	}
	
	public String getTable()
	{
		return TABLE;
	}
	
	public String[] getBlobField()
	{
		return BLOB_FIELD;
	}
	
	public String getKeyName()
	{
		return SEQ_NAME;
	}
	
	public Serializable getKey()
	{
		return null;
	}
	
	// set all properties to NULL
	public void setNULL()
	{
    	this.id = null;
    	this.name = null;
    	this.parentId = null;
    	this.orgId = null;
    	this.level = null;
    	this.status = null;
	}
	
	public boolean equals(Object o)
	{
		if (this == o) return true;
		if (!(o instanceof DepVO)) return false;
		DepVO obj = (DepVO) o;
		if (!id.equals(obj.id)) return false;
		if (!name.equals(obj.name)) return false;
		if (!parentId.equals(obj.parentId)) return false;
		if (!orgId.equals(obj.orgId)) return false;
		if (!level.equals(obj.level)) return false;
		if (!status.equals(obj.status)) return false;
		return true;
	}
	
	// ֻ����������ɢ��
	public int hashCode()
	{
		long hashCode = getClass().hashCode();
		return (int)hashCode;
	}
	
	public int compareTo(Object o)
	{
		return -1;
	}

	// set all properties to default value...
	public void init()
	{
	}
	
    public String getId()
    {
        return id;
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public String getName()
    {
        return name;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getParentId()
    {
        return parentId;
    }
    
    public void setParentId(String parentId)
    {
        this.parentId = parentId;
    }
    
    public String getOrgId()
    {
        return orgId;
    }
    
    public void setOrgId(String orgId)
    {
        this.orgId = orgId;
    }
    
    public Integer getLevel()
    {
        return level;
    }
    
    public void setLevel(Integer level)
    {
        this.level = level;
    }
    
    public Integer getStatus()
    {
        return status;
    }
    
    public void setStatus(Integer status)
    {
        this.status = status;
    }
    
	
	public String getDirectors()
	{
		return directors;
	}

	public void setDirectors(String directors)
	{
		this.directors = directors;
	}

	public String getLeaders()
	{
		return leaders;
	}

	public void setLeaders(String leaders)
	{
		this.leaders = leaders;
	}

	public void set(DepVO vo)
	{
    	this.id = vo.id;
    	this.name = vo.name;
    	this.parentId = vo.parentId;
    	this.orgId = vo.orgId;
    	this.level = vo.level;
    	this.status = vo.status;
	}
	
	public static long getSerialVersionUID()
	{
		return serialVersionUID;
	}
	
	public StringBuffer toJson()
	{
		StringBuffer buf = new StringBuffer();
		buf.append(JsonUtil.obj2json(this));
		return buf;
	}
	
	public void afterLoad()
	{
		// TODO Auto-generated method stub
	}

	public void beforeLoad()
	{
		// TODO Auto-generated method stub
	}

	public void setManualSeq(Long seq)
	{
		
	}
	
	public void destory()
	{

	}
	
	public String toString()
	{
		StringBuffer buf = new StringBuffer(128);
		buf.append(getClass().getName() + "(serialVersionUID=" + serialVersionUID + "):");
		buf.append(toJson());
		return buf.toString();
	}
	
	public Object clone()
	{
		DepVO obj = new DepVO();
		obj.set(this);
		return obj;
	}
}
