package spc.webos.jsrmi.service.invoker;

import java.lang.reflect.Method;

public class MatchedResult implements Comparable {
	private final int weight;
	private final Method method;

	public MatchedResult(int weight, Method method) {
		this.weight = weight;
		this.method = method;
	}

	public Method getMethod() {
		return method;
	}

	public int getWeight() {
		return weight;
	}

	public int compareTo(Object o) {
		MatchedResult that = (MatchedResult) o;
		if (this.weight > that.weight) {
			return -1;
		} else if (this.weight < that.weight) {
			return 1;
		} else {
			return 0;
		}
	}
	
}
