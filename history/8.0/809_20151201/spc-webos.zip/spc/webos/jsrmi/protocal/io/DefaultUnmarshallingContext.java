
package spc.webos.jsrmi.protocal.io;

import java.util.ArrayList;
import java.util.List;
import spc.webos.jsrmi.protocal.converters.Converter;
import spc.webos.jsrmi.protocal.converters.ConverterLookup;


public class DefaultUnmarshallingContext implements UnmarshallingContext {

	private List objects;
	private ConverterLookup converterLookup;
	private StreamReader streamReader;

	public DefaultUnmarshallingContext(ConverterLookup converterLookup, StreamReader in) {
		this.converterLookup = converterLookup;
		this.streamReader = in;
		this.objects = new ArrayList();
	}
	
	public Object convertAnother() {
		streamReader.moveDown();
		Converter converter = converterLookup.lookupConverterForTagName(streamReader.getNodeName());
		Object object = converter.unmarshal(streamReader, this);
		streamReader.moveUp();
		return object;
	}

	public void addObject(Object object) {
		this.objects.add(object);
	}

	public List getObjects() {
		return this.objects;
	}

}
