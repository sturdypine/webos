package spc.webos.jsrmi.protocal.converters.map;

import java.util.Iterator;
import java.util.Map;

import spc.webos.data.ICompositeNode;
import spc.webos.jsrmi.protocal.converters.Converter;
import spc.webos.jsrmi.protocal.io.MarshallingContext;
import spc.webos.jsrmi.protocal.io.StreamReader;
import spc.webos.jsrmi.protocal.io.StreamWriter;
import spc.webos.jsrmi.protocal.io.UnmarshallingContext;
import spc.webos.jsrmi.protocal.util.ClassUtil;
import spc.webos.jsrmi.protocal.util.DateUtil;

public class MapConverter extends AbstractMapConverter implements Converter
{
	public boolean canConvert(Class type)
	{
		if (type == null) return false;
		return Map.class.isAssignableFrom(type)
				|| ICompositeNode.class.isAssignableFrom(type);
	}

	public void marshalMapObject(Object value, MarshallingContext context,
			StreamWriter streamWriter)
	{
		Map map = null;
		if (value instanceof ICompositeNode) map = ((ICompositeNode) value)
				.mapValue();
		else map = (Map) value;
		for (Iterator iter = map.keySet().iterator(); iter.hasNext();)
		{
			Object key = iter.next();
			Object val = map.get(key);
			if (val == null) continue; // don't put null value
			context.convertAnother(key);
			context.convertAnother(val);
		}
	}

	public Object unmarshal(StreamReader reader,
			UnmarshallingContext unmarshallingContext)
	{
		reader.moveDown();
		String type = reader.getValue();
		reader.moveUp();

		if (type.equals("java.sql.Date")) { return dealWithSqlDate(reader,
				unmarshallingContext); }

		if (type.equals("") || type.equals("java.util.Map")) type = "java.util.HashMap";

		Object obj = ClassUtil.newInstanceOfType(type);
		unmarshallingContext.addObject(obj);

		while (reader.hasMoreChildren())
		{
			if (obj instanceof Map)
			{
				((Map) obj).put(unmarshallingContext.convertAnother(),
						unmarshallingContext.convertAnother());
			}
			else
			{
				String fieldName = (String) unmarshallingContext
						.convertAnother();
				Object value = unmarshallingContext.convertAnother();
				ClassUtil.setFieldValue(obj, fieldName, value);
			}
		}

		return obj;
	}

	private Object dealWithSqlDate(StreamReader reader,
			UnmarshallingContext unmarshallingContext)
	{
		reader.moveDown();
		reader.moveUp();
		reader.moveDown();
		java.util.Date result = DateUtil.fromUTCString(reader.getValue());
		java.sql.Date sqlDate = new java.sql.Date(result.getTime());
		unmarshallingContext.addObject(sqlDate);
		reader.moveUp();
		return sqlDate;
	}

}
