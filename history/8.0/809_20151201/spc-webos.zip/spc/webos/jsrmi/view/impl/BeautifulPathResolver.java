package spc.webos.jsrmi.view.impl;

import java.util.ArrayList;
import java.util.List;
import spc.webos.jsrmi.view.PathResolver;

public class BeautifulPathResolver implements PathResolver {

	/**
	 * path seperator
	 */
	private static final String PARAMETER_DELIMETER = "/";
	
	private String path;
	
	private String requestService;
	private String[] parameters;
	
	public BeautifulPathResolver(String path) {
		if (path == null) throw 
			new IllegalArgumentException("The path should not be null");
		
		this.path = path;
		
		String[] splited = this.path.split(PARAMETER_DELIMETER);
		List wordList = new ArrayList();
		for (int i = 0; i < splited.length; i++) {
			String word = splited[i].trim();
			if (word.equals("") || 
					word.equals(PARAMETER_DELIMETER)) {
				continue;
			}
			wordList.add(word);
		}
		
		this.requestService = (String) (wordList.get(0));
		
		List paramsList = new ArrayList();
		for (int i = 1; i < wordList.size(); i++) {
			paramsList.add(wordList.get(i));
		}
		this.parameters = (String[])paramsList.toArray(
				new String[paramsList.size()]);
	}

	public String getRequestService() {
		return this.requestService;
	}

	public String[] getParameters() {
		return this.parameters;
	}

}
