package spc.webos.flownode.impl;

import java.util.ArrayList;
import java.util.List;

import spc.webos.data.IMessage;
import spc.webos.exception.AppException;
import spc.webos.flownode.IFlowContext;
import spc.webos.flownode.IFlowNode;
import spc.webos.util.StringX;

/**
 * ��Ⱥģʽִ��һ��fnode�ڵ㡣
 * 
 * @author spc
 * 
 */
public class ClusterCFNode extends AbstractCFNode
{
	public void flow(IMessage msg, IFlowContext cxt) throws Exception
	{
		int count = 0; // 2012-08-15, ��count��1��Ϊ0
		int start = cursor();
		while (true)
		{
			if (start >= fnodes.size()) start = 0;
			count++;
			try
			{
				((IFlowNode) fnodes.get(start)).execute(msg, cxt);
				return;
			}
			catch (Exception e)
			{
				if (!isClusterEx(e) || count >= fnodes.size()) throw e;
			}
			start++;
		}
	}

	protected boolean isClusterEx(Exception e)
	{
		if (clusterRetCd != null && e instanceof AppException) return StringX.contain(clusterRetCd,
				((AppException) e).getCode(), true);
		else return clusterEx == null || clusterEx.contains(e);
	}

	protected int cursor()
	{
		if (algorithm == 0) return ((int) (cursor++)) % fnodes.size();
		else if (algorithm == 1) return (int) (Math.random() * 1000000) % fnodes.size();
		return 0;
	}

	protected int algorithm = 1; // Ⱥ���㷨: 1 ������һ��ʹ�õ���һ���� 2 �����ʼ�� 0 ʼ�մ�0��ʼ
	protected long cursor = 0;
	protected int retryInterval;
	protected List fnodes;
	protected List clusterEx;
	protected String[] clusterRetCd;

	public int getRetryInterval()
	{
		return retryInterval;
	}

	public void setRetryInterval(int retryInterval)
	{
		this.retryInterval = retryInterval;
	}

	public List getFnodes()
	{
		return fnodes;
	}

	public void setFnodes(List fnodes)
	{
		this.fnodes = fnodes;
	}

	public void setClusterEx(String exceptions) throws ClassNotFoundException
	{
		if (StringX.nullity(exceptions)) return;
		String[] exs = StringX.split(exceptions, StringX.COMMA);
		List exps = new ArrayList();
		for (int i = 0; i < exs.length; i++)
			exps.add(Class.forName(exs[i]));
		this.clusterEx = exps;
	}

	public void setClusterRetCd(String[] clusterRetCd)
	{
		this.clusterRetCd = clusterRetCd;
	}

	public void setAlgorithm(int algorithm)
	{
		this.algorithm = algorithm;
	}
}
