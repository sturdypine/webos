package spc.webos.flownode.impl;

import spc.webos.config.AppConfig;
import spc.webos.data.IMessage;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.StringX;

public class AppConfigRefreshAFNode extends AbstractFNode
{
	protected String lastDBVerDt;

	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		String dbVerDt = StringX.null2emptystr(msg.findAtomInRequest("dbVerDt", null));
		if (!StringX.nullity(dbVerDt) && dbVerDt.equals(lastDBVerDt))
		{
			msg.setInResponse("info", "lastDBVerDt(" + lastDBVerDt + ") has been triggered !!!");
			return null;
		}
		lastDBVerDt = dbVerDt;
		AppConfig.getInstance().refresh();
		return null;
	}
}
