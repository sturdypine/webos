package spc.webos.flownode.impl;

import java.io.Writer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.springframework.util.StringUtils;

import spc.webos.constant.Common;
import spc.webos.data.IMessage;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.flownode.IFlowNode;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

public abstract class FreeMarkerAFNode extends AbstractFNode
{
	protected String path = StringX.EMPTY_STRING; // ģ��·��
	protected Map sql;
	protected Map template; // ÿ�����ı�Ż�ȡfreemarkerģ���������Ϣ
	protected Map before; // sql ִ��ǰ��IFlowNode�ڵ�
	protected Map after; // sql ִ�к��IFlowNode�ڵ�
	protected boolean sqlIsTemplate; // SQL�Ƿ�Ҳ��ģ��ģʽ
	protected String charset = Common.CHARSET_UTF8;
	protected int mode = 0; // 0: query, 1: excute, 2: dirtyquery

	public boolean support(IMessage msg)
	{
		return sql != null && sql.containsKey(msg.getMsgCd());
	}

	/**
	 * ִ��Ԥִ�нڵ�
	 * 
	 * @param msg
	 * @param cxt
	 * @throws Exception
	 */
	protected void before(IMessage msg, IFlowContext cxt) throws Exception
	{
		IFlowNode beforeFNode = null;
		if (before != null) beforeFNode = (IFlowNode) before.get(msg.getMsgCd());
		if (beforeFNode != null) beforeFNode.execute(msg, cxt);
	}

	protected void after(IMessage msg, IFlowContext cxt) throws Exception
	{
		IFlowNode afterFNode = null;
		if (after != null) afterFNode = (IFlowNode) after.get(msg.getMsgCd());
		if (afterFNode != null) afterFNode.execute(msg, cxt);
	}

	protected void freemarker(IMessage msg, IFlowContext cxt, String template, String[] batchSql,
			Writer writer, Map root) throws Exception
	{
		root = SystemUtil.freemarker(root, msg);
		if (cxt != null) root.put("cxt", cxt);

		if (batchSql != null)
		{
			if (mode == 0) persistence.query(batchSql, root, root);
			else if (mode == 1) persistence.execute(batchSql, root, root);
			else persistence.dquery(batchSql, root, root);
		}
		freemarker(template, root, writer);
	}

	// 805, Ϊ��֧��ͨ�����ݿ⶯̬��ȡģ��
	protected void freemarker(String template, Map root, Writer writer) throws Exception
	{
		SystemUtil.freemarker(path + template, root, writer);
	}

	public void init() throws Exception
	{
		super.init();
		if (sql == null || sqlIsTemplate) return;
		// ��Ϊÿ��������õ���,�Ÿ�����SQL�ڵ���String[]��ʽ
		Map sqlMap = new HashMap();
		Iterator keys = sql.keySet().iterator();
		while (keys.hasNext())
		{
			String key = keys.next().toString();
			String value = sql.get(key).toString();
			sqlMap.put(key, StringUtils.delimitedListToStringArray(value, StringX.COMMA));
		}
		sql = sqlMap;
	}

	protected String getTemplate(IMessage msg) throws Exception
	{
		String msgCd = msg.getMsgCd();
		if (template == null) return msgCd;
		String t = (String) template.get(msgCd);
		if (t == null) return msgCd;
		Map root = SystemUtil.freemarker(null, msg);
		String templateId = SystemUtil.freemarker(t, root);
		return StringX.trim(templateId);
	}

	protected String[] getSqls(IMessage msg) throws Exception
	{
		if (sql == null) return null;
		if (!sqlIsTemplate) return (String[]) sql.get(msg.getMsgCd()); // ���SQL���÷�ģ�����û���

		String sqlTemplate = (String) sql.get(msg.getMsgCd());
		if (sqlTemplate == null) return null;
		Map root = SystemUtil.freemarker(null, msg);
		return StringUtils.delimitedListToStringArray(
				StringX.trim(SystemUtil.freemarker(sqlTemplate, root)), StringX.COMMA);
	}

	public void setSqlIsTemplate(boolean sqlIsTemplate)
	{
		this.sqlIsTemplate = sqlIsTemplate;
	}

	public void setBefore(Map before)
	{
		this.before = before;
	}

	public void setAfter(Map after)
	{
		this.after = after;
	}

	public void setSql(Map sql)
	{
		this.sql = sql;
	}

	public void setPath(String path)
	{
		if (path.endsWith("/")) this.path = path;
		else this.path = path + '/';
	}

	public String getCharset()
	{
		return charset;
	}

	public int getMode()
	{
		return mode;
	}

	public void setMode(int mode)
	{
		this.mode = mode;
	}

	public void setCharset(String charset)
	{
		this.charset = charset;
	}

	public Map getTemplate()
	{
		return template;
	}

	public void setTemplate(Map template)
	{
		this.template = template;
	}
}
