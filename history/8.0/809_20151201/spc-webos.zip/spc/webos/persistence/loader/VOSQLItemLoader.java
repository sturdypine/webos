package spc.webos.persistence.loader;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.cglib.beans.BulkBean;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.store.MemoryStoreEvictionPolicy;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.springframework.core.io.Resource;
import org.springframework.util.StringUtils;

import spc.webos.data.CompositeNode;
import spc.webos.data.INode;
import spc.webos.log.Log;
import spc.webos.model.MsgSchemaVO;
import spc.webos.persistence.BulkBeanItem;
import spc.webos.persistence.IPersistence;
import spc.webos.persistence.Persistence;
import spc.webos.persistence.SQLItem;
import spc.webos.persistence.Script;
import spc.webos.util.StringX;
import spc.webos.util.tree.TreeNode;
import freemarker.template.Template;

/**
 * ����ģʽSqlItem���������
 * 
 * @author Hate
 * 
 */
public class VOSQLItemLoader
{
	/**
	 * ��ȡһ��Ŀ¼�µ������ļ�
	 * 
	 * @param voSQLMap
	 *            ֱ�Ӷ���ʽ���ʵ�SQL�������
	 * @param voMapping
	 *            ÿ��vo�����й�������vo���Ե�������Ϣ
	 * @throws Exception
	 */
	public static void readMappingDir(Resource path, Map voSQLMap, Map voMapping,
			Map voManualSequenceMap, Map voValidatorMap, CacheManager cacheManager)
			throws Exception
	{
		File file = path.getFile();
		if (!file.exists()) log.warn("cannot load mapping file dir: " + file.getAbsolutePath());
		File[] files = file.listFiles();
		for (int i = 0; files != null && i < files.length; i++)
		{
			try
			{
				if (files[i].getName().endsWith("xml"))
				{
					readClassXML(new FileInputStream(files[i]), voSQLMap, voMapping,
							voManualSequenceMap, voValidatorMap, cacheManager);
					if (log.isInfoEnabled()) log.info("loaded file: " + files[i].getName());
				}
			}
			catch (Exception e)
			{
				System.err.println("load file failure:" + files[i].getName());
				throw e;
			}
		}
	}

	/**
	 * ��ȡһ�������ļ������е�Class˵��
	 * 
	 * @param location
	 * @param voSQLMap
	 * @throws Exception
	 */
	public static void readClassXML(InputStream location, Map voSQLMap, Map voMapping,
			Map voManualSequenceMap, Map voValidatorMap, CacheManager cacheManager)
			throws Exception
	{
		SAXReader reader = new SAXReader(false);
		Document doc = reader.read(location);
		Element root = doc.getRootElement();
		String ds = root.attributeValue("ds");
		if (StringX.nullity(ds)) ds = root.attributeValue("jt");
		List classes = root.elements("class");
		for (int i = 0; i < classes.size(); i++)
		{
			Element classElement = (Element) classes.get(i);
			ClassDesc classDesc = new ClassDesc();

			classDesc.ds = ds;
			TreeNode validatorRoot = new TreeNode();
			Object sequence = readProperty(classDesc, classElement, cacheManager, validatorRoot); // ��ȡһ��VO�������
			try
			{ // modified by chenjs 2011-12-01 ����಻��������־���沢����������Ϣ
				Class clazz = Class.forName(classDesc.getName());
				if (sequence != null) voManualSequenceMap.put(clazz, sequence);

				// process... ����SQLģ��
				voSQLMap.put(clazz, process(classDesc));
				if (validatorRoot.getChildren() != null && validatorRoot.getChildren().size() > 0) voValidatorMap
						.put(clazz, validatorRoot); // �����Ҫ��֤

				// ��ȡVo��������Vo������������
				classDesc.setVoProperties(new ArrayList());
				readResultProperty(classDesc, classElement, "many-to-one"); // ��ȡmany-to-oneģʽ������VO����
				readResultProperty(classDesc, classElement, "one-to-many"); // ��ȡone-to-manyģʽ������VO����
				readResultProperty(classDesc, classElement, "result"); // ��ȡresult����
				if (classDesc.getVoProperties().size() > 0) voMapping
						.put(clazz, convert(classDesc));
			}
			catch (ClassNotFoundException cnfe)
			{
				log.warn("ClassNotFoundException for [[" + classDesc.getName() + "]]!!!");
				continue;
			}
		}
		location.close();
	}

	/**
	 * ��һ��VO�й������Ե�������Ϣ��List�е�ClassVOPropertyDesc��ʽ�� ���List�е�BulkBeanItem��ʽ��
	 * ���Persistence��ʹ�õ�����
	 * 
	 * @param classDesc
	 * @return
	 * @throws Exception
	 */
	static BulkBeanItem convert(ClassDesc classDesc) throws Exception
	{
		BulkBeanItem bulkBeanItem = new BulkBeanItem();
		List voProperties = classDesc.getVoProperties();
		// 1. ����VO�����й�����VO����List��������Ϣ
		Class clazz = Class.forName(classDesc.name);
		Class[] clazzArray = new Class[voProperties.size()];
		String[] setter = new String[voProperties.size()];
		String[] getter = new String[voProperties.size()];
		for (int i = 0; i < voProperties.size(); i++)
		{
			ResultPropertyDesc propertyDesc = (ResultPropertyDesc) voProperties.get(i);
			clazzArray[i] = clazz.getDeclaredField(propertyDesc.getName()).getType();
			String name = StringUtils.capitalize(propertyDesc.getName());
			setter[i] = "set" + name;
			getter[i] = "get" + name;
		}
		bulkBeanItem.setVoProperties(BulkBean.create(clazz, getter, setter, clazzArray));

		// ÿһ������VO���� ������ Sql��ѯ����
		List prop = new ArrayList(voProperties.size());
		for (int i = 0; i < voProperties.size(); i++)
		{
			Object[] bulkBeans = new Object[4];
			prop.add(bulkBeans);
			ResultPropertyDesc propertyDesc = (ResultPropertyDesc) voProperties.get(i);
			bulkBeans[2] = clazz.getDeclaredField(propertyDesc.getName()).getType();
			if (propertyDesc.getSelect() != null)
			{ // �����Բ��ǹ�������VO���ԣ� ����һ����ͨ��sql����
				bulkBeans[0] = propertyDesc.getSelect();
				continue;
			}
			bulkBeans[3] = Class.forName(propertyDesc.getJavaType()); // ֻ��Թ�������������VOʱ������

			// ��������VO���Ժ͹�����VO����֮��������ϵ
			// ��������
			clazzArray = new Class[propertyDesc.getter.length];
			setter = new String[propertyDesc.getter.length];
			getter = new String[propertyDesc.getter.length];
			for (int j = 0; j < propertyDesc.getter.length; j++)
			{
				clazzArray[j] = clazz.getDeclaredField(propertyDesc.getter[j]).getType();
				String name = StringUtils.capitalize(propertyDesc.getter[j]);
				setter[j] = "set" + name;
				getter[j] = "get" + name;
			}
			bulkBeans[0] = BulkBean.create(clazz, getter, setter, clazzArray);

			// ����VO������
			setter = new String[propertyDesc.getter.length];
			getter = new String[propertyDesc.getter.length];
			for (int j = 0; j < propertyDesc.getter.length; j++)
			{
				String name = StringUtils.capitalize(propertyDesc.setter[j]);
				setter[j] = "set" + name;
				getter[j] = "get" + name;
			}
			bulkBeans[1] = BulkBean.create(Class.forName(propertyDesc.getJavaType()), getter,
					setter, clazzArray);
		}
		bulkBeanItem.setProperties(prop);
		return bulkBeanItem;
	}

	/**
	 * ��ȡVo�й�������VO���Ե�������Ϣ�� Ҳ������ȡ����Sql������Ϊ���������
	 * 
	 */
	static void readResultProperty(ClassDesc classDesc, Element classElement, String type)
			throws Exception
	{
		List property = classElement.elements(type);
		for (int i = 0; i < property.size(); i++)
		{
			Element ele = (Element) property.get(i);
			ResultPropertyDesc propertyDesc = new ResultPropertyDesc();
			propertyDesc.setName(ele.attributeValue("property"));
			propertyDesc.setJavaType(ele.attributeValue("javaType", "String"));
			propertyDesc.setSelect(ele.attributeValue("select"));
			propertyDesc.setRemark(ele.attributeValue("remark"));
			propertyDesc.setManyToOne(true);
			if (propertyDesc.getSelect() == null)
			{
				propertyDesc.setManyToOne(type.equals("many-to-one"));
				readVOPropertyRelation(propertyDesc, ele);
			}
			classDesc.getVoProperties().add(propertyDesc);
		}
	}

	/**
	 * ��ȡVO������Թ�ϵ, �൱�ڱ���������ϵ�� ���˱�(VO)�е���Щ�ֶ���ϵ�Ź�����(VO)�е���Щ�ֶε���Ϣ
	 * 
	 */
	static void readVOPropertyRelation(ResultPropertyDesc propertyDesc, Element propertyElement)
			throws Exception
	{
		List properties = propertyElement.elements("map");
		propertyDesc.setter = new String[properties.size()];
		propertyDesc.getter = new String[properties.size()];
		for (int i = 0; i < properties.size(); i++)
		{
			Element ele = (Element) properties.get(i);
			propertyDesc.getter[i] = ele.attributeValue("getter");
			propertyDesc.setter[i] = ele.attributeValue("setter", propertyDesc.getter[i]); // Ĭ����VO����������ͬ
		}
	}

	/**
	 * ��ȡһ���������������Ϣ, ��������к������ݿ�manual sequence�ֶΣ�ֻ����һ��sequence�ֶΣ� ����һ��String[]
	 * {0:��ı����� 1���ֶ���}�Ķ���
	 * 
	 * @param clazzDesc
	 * @param classElement
	 * @throws Exception
	 */
	public static Object[] readProperty(ClassDesc clazzDesc, Element classElement,
			CacheManager cacheManager, TreeNode validatorRoot) throws Exception
	{
		List properties = new ArrayList();
		clazzDesc.setProperties(properties);
		Object[] seq = null;
		clazzDesc.setName(classElement.attributeValue("name"));
		clazzDesc.setTable(classElement.attributeValue("table"));

		String ds = classElement.attributeValue("ds");
		if (StringX.nullity(ds)) ds = classElement.attributeValue("jt");
		if (!StringX.nullity(ds)) clazzDesc.ds = ds;

		boolean validator = "true".equalsIgnoreCase(classElement.attributeValue("validator"));

		clazzDesc.setParent(classElement.attributeValue("parent"));
		clazzDesc.setCache(new Boolean(classElement.attributeValue("cache", "false"))
				.booleanValue());
		clazzDesc.setRemark(classElement.attributeValue("remark"));
		String insertMode = classElement.attributeValue("insertMode");
		if (!StringX.nullity(insertMode)) clazzDesc.setInsertMode(Integer.parseInt(insertMode));

		// ��ȡ�������õĻ�����Ϣ
		if (clazzDesc.isCache() && cacheManager != null)
		{
			List caches = classElement.elements("cache");
			if (caches != null && caches.size() > 0)
			{
				Element cacheEle = (Element) caches.get(0);
				String max = cacheEle.attributeValue("max", "20");
				String timeToLiveSeconds = cacheEle.attributeValue("timeToLiveSeconds", "120");
				String timeToIdleSeconds = cacheEle.attributeValue("timeToIdleSeconds", "120");
				Cache cache = new Cache(Class.forName(clazzDesc.getName()).getName(),
						Integer.parseInt(max), MemoryStoreEvictionPolicy.FIFO, false, null, false,
						Long.parseLong(timeToLiveSeconds), Long.parseLong(timeToIdleSeconds),
						false, 120, null, null);
				cacheManager.addCache(cache);
			}
			else
			{ // Ĭ��
				Cache cache = new Cache(Class.forName(clazzDesc.getName()).getName(), 20,
						MemoryStoreEvictionPolicy.FIFO, false, null, false, 120, 120, false, 120,
						null, null);
				cacheManager.addCache(cache);
			}
		}
		// ��ȡstatic fields
		Element staticFields = classElement.element("static");
		if (staticFields != null)
		{
			List p = staticFields.elements("p");
			for (int i = 0; i < p.size(); i++)
				clazzDesc.getStaticFields().add(((Element) p.get(i)).getText().trim());
		}

		// ��ȡdeclare��Ϣ
		Element declare = classElement.element("declare");
		if (declare != null) clazzDesc.setDeclare(declare.getText());

		declare = classElement.element("insert-preFn");
		if (declare != null) clazzDesc.setInsertPreFn(declare.getText());
		declare = classElement.element("insert-postFn");
		if (declare != null) clazzDesc.setInsertPostFn(declare.getText());

		declare = classElement.element("update-preFn");
		if (declare != null) clazzDesc.setUpdatePreFn(declare.getText());
		declare = classElement.element("update-postFn");
		if (declare != null) clazzDesc.setUpdatePostFn(declare.getText());

		declare = classElement.element("select-preFn");
		if (declare != null) clazzDesc.setSelectPreFn(declare.getText());
		declare = classElement.element("select-postFn");
		if (declare != null) clazzDesc.setSelectPostFn(declare.getText());

		declare = classElement.element("delete-preFn");
		if (declare != null) clazzDesc.setDeletePreFn(declare.getText());
		declare = classElement.element("delete-postFn");
		if (declare != null) clazzDesc.setDeletePostFn(declare.getText());

		Map columnConverter = new HashMap();
		// ����ValueObject��������Ϣ
		List property = classElement.elements("property");
		for (int i = 0; i < property.size(); i++)
		{
			Element ele = (Element) property.get(i);
			ClassPropertyDesc cpd = new ClassPropertyDesc();
			cpd.setName(ele.attributeValue("name"));
			if (validator && validatorRoot != null) validatorRoot.insertChild(create(cpd.getName(),
					ele)); // �����Ҫ��֤
			cpd.setColumn(ele.attributeValue("column", cpd.getName()));
			if (StringX.nullity(cpd.getColumn())) cpd.setColumn(cpd.getName().toUpperCase());
			cpd.setPrimary(new Boolean(ele.attributeValue("primary", "false")).booleanValue());
			cpd.setPrepare(new Boolean(ele.attributeValue("prepare", "false")).booleanValue());
			cpd.setUuid(new Boolean(ele.attributeValue("uuid", "false")).booleanValue());
			String jdbcType = ele.attributeValue("jdbcType");
			if (jdbcType != null) cpd.setJdbcType(jdbcType.toUpperCase());
			cpd.setJavaType(ele.attributeValue("javaType", "String"));
			if (cpd.getJavaType().equalsIgnoreCase("IBlob")) cpd.setPrepare(true);
			String converter = ele.attributeValue("converter", null);
			if (converter != null) columnConverter.put(cpd.getName(), converter);
			if (cpd.getJavaType().equalsIgnoreCase("CompositeNode")) // ���VO����ΪCompositeNode��ô�������XMLת��
			{
				columnConverter.put(cpd.getName(), "XML");
				cpd.setPrepare(true); // ����xml������ܰ���'���в���prepare��ʽ���
			}
			if (cpd.isPrepare()) clazzDesc.setPrepare(true);
			cpd.setDefaultValue(ele.attributeValue("default"));
			String sequence = ele.attributeValue("sequence");
			if (sequence != null)
			{
				cpd.setJavaType("Long");
				cpd.setSequence(sequence.toUpperCase());
				if (sequence.equalsIgnoreCase(ClassPropertyDesc.SEQUENCE_MANUAL))
				{
					seq = new Object[4];
					seq[0] = clazzDesc.table;
					seq[1] = cpd.column;
					seq[2] = clazzDesc.getDataSource();
					// seq[3] ���������ڴ�Ŵ˱������sequenceֵ
				}
			}
			cpd.setNullValue(ele.attributeValue("nullValue"));
			cpd.setRemark(ele.attributeValue("remark"));
			readExp(cpd, ele); // ��ȡinsert, update, select����ʽ
			properties.add(cpd);
		}
		// �����һ���ֶ������ݿ��Զ������ֶΣ������������ modified by spc 2010-02-23
		ClassPropertyDesc cpd = (ClassPropertyDesc) properties.get(0);
		if (ClassPropertyDesc.SEQUENCE_AUTO.equalsIgnoreCase(cpd.getSequence()))
		{ // ��һ���ֶ������ݿ�������������������
			properties.remove(0);
			properties.add(cpd);
		}
		if (columnConverter.size() > 0) clazzDesc.setColumnConverter(columnConverter);

		return seq;
	}

	/**
	 * ����һ������������Ϣ������һ����֤���ڵ�����
	 * 
	 * @param name
	 * @param property
	 * @return
	 */
	protected static TreeNode create(String name, Element property)
	{
		TreeNode tnode = new TreeNode();
		MsgSchemaVO struct = new MsgSchemaVO();
		tnode.setTreeNodeValue(struct);
		struct.setEsbName(name);
		CompositeNode cnode = new CompositeNode();
		List attrs = property.attributes();
		for (int i = 0; i < attrs.size(); i++)
		{
			Attribute attr = (Attribute) attrs.get(i);
			cnode.set(attr.getName(), attr.getValue());
		}
		cnode.toObject(struct);
		if (StringX.nullity(struct.getFtyp()))
		{ // ���������û���ر�����ftyp���ͣ������javaType���ͽ����ж�S, D, F, I, L
			String type = property.attributeValue("javaType", "String");
			struct.setFtyp(String.valueOf((char) INode.TYPE_STRING));
			if ("Double".equals(type) || "Float".equals(type) || "BigDecimal".equals(type)) struct
					.setFtyp(String.valueOf((char) INode.TYPE_DOUBLE));
			else if ("Integer".equals(type) || "Long".equals(type) || "BigInteger".equals(type)) struct
					.setFtyp(String.valueOf((char) INode.TYPE_LONG));
		}
		return tnode;
	}

	/**
	 * ��ȡselect,update,insert����ʽ
	 * 
	 * @param classPropertyDesc
	 * @param propertyElement
	 * @throws Exception
	 */
	public static void readExp(ClassPropertyDesc classPropertyDesc, Element propertyElement)
			throws Exception
	{
		List exp = propertyElement.elements("select");
		if (exp != null && exp.size() == 1)
		{
			String selectExp = ((Element) exp.get(0)).getText();
			classPropertyDesc.setSelect(SQLItemXmlLoader.formatSQL(selectExp).trim());
		}
		exp = propertyElement.elements("update");
		if (exp != null && exp.size() == 1)
		{
			String updateExp = ((Element) exp.get(0)).getText();
			classPropertyDesc.setUpdate(SQLItemXmlLoader.formatSQL(updateExp).trim());
		}
		exp = propertyElement.elements("insert");
		if (exp != null && exp.size() == 1)
		{
			String insertExp = ((Element) exp.get(0)).getText();
			classPropertyDesc.setInsert(SQLItemXmlLoader.formatSQL(insertExp).trim());
		}
	}

	/**
	 * ����SQLģ��
	 * 
	 * @param classDesc
	 *            Java������
	 * @param properties
	 *            Java����������
	 * @param voSQLMap
	 * @throws Exception
	 */
	public static SQLItem[] process(ClassDesc classDesc) throws Exception
	{
		SQLItem[] items = new SQLItem[4];
		StringWriter out = new StringWriter();
		InputStreamReader isr = new InputStreamReader(new VOSQLItemLoader().getClass()
				.getResourceAsStream("sqlitem.ftl"));
		Template t = new Template("SQL_ITEM", isr, null);
		Map root = new HashMap();
		root.put(IPersistence.DB_TYPE_KEY, Persistence.getInstance().getDefautlJdbcTemplate()
				.getDbType());
		root.put("classDesc", classDesc);
		root.put("properties", classDesc.getProperties());

		items[SQLItem.SELECT] = genSQLItem(root, t, out, classDesc, SQLItem.SELECT);
		items[SQLItem.DELETE] = genSQLItem(root, t, out, classDesc, SQLItem.DELETE);
		items[SQLItem.INSERT] = genSQLItem(root, t, out, classDesc, SQLItem.INSERT);
		items[SQLItem.UPDATE] = genSQLItem(root, t, out, classDesc, SQLItem.UPDATE);
		isr.close();
		return items;
	}

	static SQLItem genSQLItem(Map root, Template temp, StringWriter out, ClassDesc classDesc,
			short type) throws Exception
	{
		root.put("sqlType", String.valueOf(type));
		out.getBuffer().setLength(0);
		temp.process(root, out);
		out.flush();
		SQLItem item = new SQLItem();
		item.columnConverters = classDesc.getColumnConverter();
		item.resultClass = classDesc.getName();
		item.jt = classDesc.getDataSource();
		item.sql = SQLItemXmlLoader.formatSQL(out.toString());
		item.t = new Template(classDesc.getName() + ':' + type, new StringReader(item.sql), null);
		item.type = type;
		if (classDesc.isPrepare() && type != SQLItem.SELECT) item.prepared = true;
		else item.type = type;
		if (type == SQLItem.SELECT)
		{
			if (classDesc.getSelectPreFn() != null
					&& classDesc.getSelectPreFn().trim().length() > 0) item.preScript = new Script(
					classDesc.getSelectPreFn(), false, 0, true);
			if (classDesc.getSelectPostFn() != null
					&& classDesc.getSelectPostFn().trim().length() > 0)
			{
				if (item.postScripts == null) item.postScripts = new ArrayList();
				item.postScripts.add(new Script(classDesc.getSelectPostFn(), false, 0, true));
			}
		}
		else if (type == SQLItem.UPDATE)
		{
			if (classDesc.getUpdatePreFn() != null
					&& classDesc.getUpdatePreFn().trim().length() > 0) item.preScript = new Script(
					classDesc.getUpdatePreFn(), false, 0, true);
			if (classDesc.getUpdatePostFn() != null
					&& classDesc.getUpdatePostFn().trim().length() > 0)
			{
				if (item.postScripts == null) item.postScripts = new ArrayList();
				item.postScripts.add(new Script(classDesc.getUpdatePostFn(), false, 0, true));
			}
		}
		else if (type == SQLItem.INSERT)
		{
			if (classDesc.getInsertPreFn() != null
					&& classDesc.getInsertPreFn().trim().length() > 0) item.preScript = new Script(
					classDesc.getInsertPreFn(), false, 0, true);
			if (classDesc.getInsertPostFn() != null
					&& classDesc.getInsertPostFn().trim().length() > 0)
			{
				if (item.postScripts == null) item.postScripts = new ArrayList();
				item.postScripts.add(new Script(classDesc.getInsertPostFn(), false, 0, true));
			}
		}
		else if (type == SQLItem.DELETE)
		{
			if (classDesc.getDeletePreFn() != null
					&& classDesc.getDeletePreFn().trim().length() > 0) item.preScript = new Script(
					classDesc.getDeletePreFn(), false, 0, true);
			if (classDesc.getDeletePostFn() != null
					&& classDesc.getDeletePostFn().trim().length() > 0)
			{
				if (item.postScripts == null) item.postScripts = new ArrayList();
				item.postScripts.add(new Script(classDesc.getDeletePostFn(), false, 0, true));
			}
		}
		return item;
	}

	static Log log = Log.getLogger(VOSQLItemLoader.class);
	// public static final int OPERATOR_SELECT = 0;
	// public static final int OPERATOR_INSERT = 1;
	// public static final int OPERATOR_UPDATE = 2;
	// public static final int OPERATOR_DELETE = 3;
}
