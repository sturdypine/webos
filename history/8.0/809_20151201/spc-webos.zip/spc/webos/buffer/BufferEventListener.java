package spc.webos.buffer;

public interface BufferEventListener
{
	void notifyPut(IBuffer buf, Object value, Thread writer);

	void notifyRemoved(IBuffer buf, Object value, Thread reader);
}
