package spc.webos.queue.ibmmq;

import java.util.ArrayList;
import java.util.List;

import spc.webos.config.AppConfig;
import spc.webos.constant.Common;
import spc.webos.constant.Config;
import spc.webos.queue.AbstractQueueAccess;
import spc.webos.queue.QueueMessage;
import spc.webos.util.StringX;

import com.ibm.mq.MQC;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;

public class QueueAccess extends AbstractQueueAccess
{
	protected MQMultiChannel multiChannel = new MQMultiChannel();

	public QueueAccess()
	{
	}

	public QueueAccess(List<MQCnnPool> cnnpools)
	{
		multiChannel.cnnpools = cnnpools;
	}

	public QueueAccess(MQCnnPool cnnpool)
	{
		multiChannel.cnnpools = new ArrayList<MQCnnPool>();
		multiChannel.cnnpools.add(cnnpool);
	}

	public void destroy()
	{
		multiChannel.destroy();
	}

	public void send(String qname, QueueMessage qmsg) throws Exception
	{
		// 2012-05-16 ���ö�ͨ�����͡�
		// MQMessage mqmsg = qmsg.toMQMessage(new MQMessage());
		// modified by chenjs 2012-11-29 ֧��TLQ���Ƴ�QueueMessage�����MQMessage����
		MQMessage mqmsg = MQMessageUtil.toMQMessage(qmsg, new MQMessage());
		if (log.isDebugEnabled()) log.debug("sn:" + qmsg.sn + ", corId:"
				+ (qmsg.correlationId != null ? new String(qmsg.correlationId) : "") + ", expiry: "
				+ mqmsg.expiry + ", ccsid: " + mqmsg.characterSet + "::" + new String(qmsg.buf));
		else if (log.isInfoEnabled()
				&& (Boolean) AppConfig.getInstance().getProperty(Config.TCP_TRACE, false)) log
				.info("trace sn:" + qmsg.sn + ", corId:"
						+ (qmsg.correlationId != null ? new String(qmsg.correlationId) : "")
						+ ", expiry: " + mqmsg.expiry + ", ccsid: " + mqmsg.characterSet + "::"
						+ new String(qmsg.buf));
		MQPutMessageOptions pmo = new MQPutMessageOptions();
		// pmo.options = MQC.MQPMO_SET_ALL_CONTEXT; // 700_20130929
		multiChannel.sendCluster(qname, pmo, mqmsg, retryTimes, retryInterval);
		// MQManager mqm = (MQManager) cnnPool.borrow();
		// try
		// {
		// if (log.isInfoEnabled()) log.info("sn:" + qmsg.sn + ", corId:"
		// + (qmsg.correlationId != null ? new String(qmsg.correlationId) :
		// ""));
		// if (log.isDebugEnabled()) log.debug("req:" + new String(qmsg.buf,
		// Common.CHARSET_UTF8));
		// Accessor.send(mqm, qname, new MQPutMessageOptions(),
		// qmsg.toMQMessage(new MQMessage()),
		// 0, 0);
		// }
		// catch (MQException mqex)
		// {
		// log.warn("send", mqex);
		// if (Accessor.handleMQException(mqex) ==
		// Accessor.MQ_CONNECTION_BROKER) mqm.disconnect(); // �����ǰ�쳣�������쳣��ر�����
		// throw new AppException(AppRetCode.PROTOCOL_MQ(), new Object[] {
		// qname,
		// String.valueOf(mqex.reasonCode), String.valueOf(mqex.completionCode)
		// });
		// }
		// finally
		// {
		// cnnPool.release(mqm);
		// }
	}

	// 2012-05-12 ʹ��ͨ���б����н���
	public QueueMessage receive(String qname, byte[] correlationId, int timeout) throws Exception
	{
		MQMessage mqmsg = new MQMessage();
		MQGetMessageOptions gmo = new MQGetMessageOptions();
		if (timeout > 0)
		{
			gmo.options = MQC.MQGMO_WAIT;
			gmo.waitInterval = timeout * 1000;
		}
		else if (timeout == 0) gmo.options = MQC.MQGMO_NO_WAIT;
		else
		{
			gmo.options = MQC.MQGMO_WAIT;
			gmo.waitInterval = -1;
		}

		// if (timeout > 0) gmo.waitInterval = timeout * 1000;
		if (matchCorId && correlationId != null)
		{ // matchCorId Ϊ����ĳЩ���ܲ��Գ��ϣ����FAͬ������ 2012-05-30
			gmo.matchOptions = MQC.MQMO_MATCH_CORREL_ID;
			mqmsg.correlationId = correlationId;
			if (log.isDebugEnabled()) log.debug("match corId: " + new String(mqmsg.correlationId));
		}
		else if (log.isDebugEnabled()) log.debug("unmatch: " + matchCorId);
		Accessor.receive(multiChannel.cnnpools, qname, gmo, mqmsg);
		byte[] buf = new byte[mqmsg.getDataLength()];
		mqmsg.readFully(buf);
		if (log.isDebugEnabled()) log.debug("rep:" + new String(buf, Common.CHARSET_UTF8)
				+ "\nrep.base64:" + StringX.base64(buf));
		return new QueueMessage(buf, mqmsg.correlationId, mqmsg.messageId);
	}

	// public QueueMessage receive(String qname, byte[] correlationId, int
	// timeout) throws Exception
	// {
	// MQManager mqm = (MQManager) cnnPool.borrow();
	// try
	// {
	// MQMessage resMQMsg = new MQMessage();
	// MQGetMessageOptions gmo = new MQGetMessageOptions();
	// gmo.options = MQC.MQGMO_WAIT;
	// if (timeout > 0) gmo.waitInterval = timeout * 1000;
	// if (correlationId != null)
	// {
	// gmo.matchOptions = MQC.MQMO_MATCH_CORREL_ID;
	// resMQMsg.correlationId = correlationId;
	// }
	// Accessor.receive(mqm, qname, gmo, resMQMsg);
	// byte[] buf = new byte[resMQMsg.getDataLength()];
	// resMQMsg.readFully(buf);
	// if (log.isDebugEnabled()) log.debug("res:" + new String(buf));
	// return new QueueMessage(buf, resMQMsg.correlationId, resMQMsg.messageId);
	// }
	// catch (MQException mqex)
	// {
	// log.warn("send", mqex);
	// if (Accessor.handleMQException(mqex) == Accessor.MQ_CONNECTION_BROKER)
	// mqm.disconnect(); // �����ǰ�쳣�������쳣��ر�����
	// throw new AppException(AppRetCode.PROTOCOL_MQ(), new Object[] { qname,
	// String.valueOf(mqex.reasonCode), String.valueOf(mqex.completionCode) });
	// }
	// catch (IOException ioe)
	// {
	// throw new AppException(AppRetCode.NET_COMMON(), ioe);
	// }
	// finally
	// {
	// cnnPool.release(mqm);
	// }
	// }

	// 2012-05-16 ʹ��send, recieve��Ϸ������
	public QueueMessage execute(String reqQName, String repQName, QueueMessage qmsg, int timeout)
			throws Exception
	{
		// byte[] corId = qmsg.correlationId; // ����ˮ����Ϊmq��Ϣ������
		// if (log.isDebugEnabled()) log.debug("snd corId:"
		// + (qmsg.correlationId == null ? "" : new
		// String(qmsg.correlationId)));
		// MQMessage reqMQMsg = new MQMessage();
		// reqMQMsg.write(qmsg.buf);
		// // ��������˳�ʱʱ�䡣����Ϣ����ȡ��ʱ��Ӧ���г�ʱʱ�䣬MQ����Ϣ��Чʱ��Ϊ100����
		//
		// if (log.isDebugEnabled()) log.debug("req:" + new String(qmsg.buf));
		// if (corId != null) reqMQMsg.correlationId = corId;
		// if (qmsg.expirySeconds > 0) reqMQMsg.expiry = qmsg.expirySeconds *
		// 10; // 2012-11-01
		// // ������Ϣ�ĳ�ʱʱ��
		// Accessor.sendCluster(sndRandomStart, cnnpools, reqQName, new
		// MQPutMessageOptions(), reqMQMsg, retryTimes,
		// retryInterval); // ������Ϣ

		send(reqQName, qmsg); // 701_20130929

		if (StringX.nullity(repQName))
		{ // added by spc 2011-03-11 ���Ӧ�����Ϊ�գ����ʾ����Ҫ����
			log.info("repQName is null!!!");
			return null;
		}
		return receive(repQName, qmsg.correlationId, timeout);
	}

	// public QueueMessage execute(String reqQName, String repQName,
	// QueueMessage qmsg, int timeout)
	// throws Exception
	// {
	// MQManager mqm = (MQManager) cnnPool.borrow();
	// try
	// {
	// byte[] corId = qmsg.correlationId; // ����ˮ����Ϊmq��Ϣ������
	// if (log.isInfoEnabled()) log.info("start to send sn:" + qmsg.sn +
	// ", timeout:"
	// + timeout);
	// MQMessage reqMQMsg = new MQMessage();
	// reqMQMsg.write(qmsg.buf);
	// // ��������˳�ʱʱ�䡣����Ϣ����ȡ��ʱ��Ӧ���г�ʱʱ�䣬MQ����Ϣ��Чʱ��Ϊ100����
	// // if (qmsg.expirySeconds > 0) reqMQMsg.expiry = qmsg.expirySeconds
	// // * 10;
	//
	// if (log.isDebugEnabled()) log.debug("req:" + new String(qmsg.buf));
	// if (corId != null) reqMQMsg.correlationId = corId;
	// long start = 0;
	// Accessor.send(mqm, reqQName, new MQPutMessageOptions(), reqMQMsg,
	// retryTimes,
	// retryInterval); // ������Ϣ
	// if (StringX.nullity(repQName))
	// { // added by spc 2011-03-11 ���Ӧ�����Ϊ�գ����ʾ����Ҫ����
	// log.info("repQName is null!!!");
	// return null;
	// }
	// if (log.isInfoEnabled())
	// {
	// start = System.currentTimeMillis();
	// log.info("success send sn:" + qmsg.sn);
	// }
	//
	// // ���ݹ������ù�������Ϣ
	// MQMessage repMQMsg = new MQMessage();
	// MQGetMessageOptions gmo = new MQGetMessageOptions();
	// gmo.options = MQC.MQGMO_WAIT;
	// gmo.waitInterval = timeout * 1000;
	// gmo.matchOptions = MQC.MQMO_MATCH_CORREL_ID;
	// repMQMsg.correlationId = corId;
	// Accessor.receive(mqm, repQName, gmo, repMQMsg);
	// if (log.isInfoEnabled())
	// {
	// long end = System.currentTimeMillis();
	// log.info("corId:" + new String(corId) + ", cost:" + (end - start) + ","
	// + (end - repMQMsg.putDateTime.getTimeInMillis()));
	// }
	// byte[] buf = new byte[repMQMsg.getDataLength()];
	// repMQMsg.readFully(buf);
	// if (log.isDebugEnabled()) log.debug("rep buf:" + new String(buf));
	// return new QueueMessage(buf, repMQMsg.correlationId, repMQMsg.messageId);
	// }
	// catch (MQException mqex)
	// {
	// log.warn("QueueAccess: reqQName:" + reqQName + ", repQName:" + repQName,
	// mqex);
	// if (Accessor.handleMQException(mqex) == Accessor.MQ_CONNECTION_BROKER)
	// mqm.disconnect(); // �����ǰ�쳣�������쳣��ر�����
	// throw new AppException(AppRetCode.PROTOCOL_MQ(), new Object[] { repQName,
	// String.valueOf(mqex.reasonCode), String.valueOf(mqex.completionCode) });
	// }
	// catch (Throwable t)
	// {
	// throw new AppException(AppRetCode.NET_COMMON(), t);
	// }
	// finally
	// {
	// cnnPool.release(mqm);
	// }
	// }

	/**
	 * ���ĳ�����У�����������������Ϣ��һЩ�Զ����ƣ����糬ʱת���ȵ�
	 * 
	 * @param qname
	 * @param gmo
	 * @throws Exception
	 */
	// public void browse(String qname, MQGetMessageOptions gmo) throws
	// Exception
	// {
	// MQManager mqm = (MQManager) cnnPool.borrow();
	// MQQueue queue = null;
	// try
	// {
	// queue = mqm.accessQueue(qname, MQC.MQOO_BROWSE);
	// queue.get(new MQMessage(), gmo);
	// }
	// finally
	// {
	// cnnPool.release(mqm);
	// mqm.closeQueue();
	// }
	// }
	public void setCnnPool(MQCnnPool cnnPool)
	{
		multiChannel.cnnpools = new ArrayList<MQCnnPool>();
		multiChannel.cnnpools.add(cnnPool);
	}

	public void setCnnpools(List<MQCnnPool> cnnpools)
	{
		multiChannel.cnnpools = cnnpools;
	}

	public MQCnnPool getFirstMQCnnPool()
	{
		return multiChannel.cnnpools.get(0);
	}

	public MQMultiChannel getMultiChannel()
	{
		return multiChannel;
	}

	public void setMultiChannel(MQMultiChannel multiChannel)
	{
		this.multiChannel = multiChannel;
	}
}
