package spc.webos.acceptor.xsocket;

import java.io.IOException;
import java.net.Socket;

import org.xsocket.connection.INonBlockingConnection;

import spc.webos.endpoint.Endpoint;
import spc.webos.endpoint.EndpointFactory;
import spc.webos.endpoint.Executable;
import spc.webos.util.StringX;

public class PerformanceShieldServerHandler extends DefaultServerHandler
{
	protected byte[] response; // �̶���ǰ�˵�Ӧ������
	protected Endpoint forwardEndpoint; // ת����ַ
	protected byte[] forwardRequest; // ת������
	protected boolean forwardLongCnn; // ת��������
	protected String ip;
	protected int port;
	protected int bufSize = 2048;
	protected int minC = 10; // Ĭ����С��ʱ

	protected boolean doMsg(INonBlockingConnection cnn, byte[] msg, String remoteIP)
			throws IOException
	{
		if (forwardRequest != null)
		{ // Ӧ��֮ǰ��Ҫһ��ת��
			try
			{ // ת���������˵ķ��񵲰�
				long start = System.currentTimeMillis();
				byte[] buf = forwardEndpoint != null ? endpoint(cnn, msg, remoteIP) : socket(cnn,
						msg, remoteIP);
				long cost = System.currentTimeMillis() - start;
				if (cost < minC) Thread.sleep(minC - start);
			}
			catch (Exception e)
			{
				log.warn("endpoint:" + forwardEndpoint + ", ip:" + ip, e);
			} // ת������
		}
		cnn.write(response); // Ȼ��ֱ�������õĽ������
		cnn.flush();
		if (!acceptor.isLongCnn()) cnn.close();
		return true;
	}

	public byte[] endpoint(INonBlockingConnection cnn, byte[] msg, String remoteIP)
			throws Exception
	{
		Executable exe = new Executable();
		exe.request = forwardRequest; // ���ܲ���ʹ�ù̶������������������
		// ת���������˵ķ��񵲰�
		forwardEndpoint.execute(exe);
		return exe.response;
	}

	public static ThreadLocal LOCAL_SOCKET = new ThreadLocal();

	public byte[] socket(INonBlockingConnection cnn, byte[] msg, String remoteIP) throws Exception
	{
		Socket s = (Socket) LOCAL_SOCKET.get();
		if (s == null) s = new Socket(ip, port);
		byte[] buf = new byte[bufSize]; // Ԥ����ȡӦ��Ŀռ�
		int len = 0;
		try
		{
			s.getOutputStream().write(forwardRequest); // "00000000812345678".getBytes()
			s.getOutputStream().flush();
			len = s.getInputStream().read(buf);
		}
		finally
		{
			if (s != null && !forwardLongCnn) s.close();
		}
		if (forwardLongCnn) LOCAL_SOCKET.set(s);
		if (log.isDebugEnabled()) log.debug("len:" + len + "::" + new String(buf, 0, len));
		if (len <= 0) return null;
		byte[] resmsg = new byte[len];
		System.arraycopy(buf, 0, resmsg, 0, len);
		return resmsg;
	}

	public void setResponse(String str)
	{
		response = StringX.decodeBase64(str);
	}

	public void setForwardEndpoint(String forwardEndpoint) throws Exception
	{
		this.forwardEndpoint = EndpointFactory.getInstance().getEndpoint(forwardEndpoint);
	}

	public void setForwardRequest(String forwardRequest)
	{
		this.forwardRequest = StringX.decodeBase64(forwardRequest);
	}

	public void setIp(String ip)
	{
		this.ip = ip;
	}

	public void setPort(int port)
	{
		this.port = port;
	}

	public void setBufSize(int bufSize)
	{
		this.bufSize = bufSize;
	}

	public void setMinC(int minC)
	{
		this.minC = minC;
	}

	public void setForwardLongCnn(boolean forwardLongCnn)
	{
		this.forwardLongCnn = forwardLongCnn;
	}
}
