package spc.webos.acceptor;

import spc.webos.buffer.IBuffer;
import spc.webos.thread.ThreadPool;

public abstract class SendResponseTPool extends ThreadPool
{
	IBuffer repbuf;

	public void setRepbuf(IBuffer repbuf)
	{
		this.repbuf = repbuf;
	}

	public IBuffer getRepbuf()
	{
		return repbuf;
	}
}
