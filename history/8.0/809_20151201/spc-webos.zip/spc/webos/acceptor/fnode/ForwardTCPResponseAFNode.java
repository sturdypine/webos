package spc.webos.acceptor.fnode;

import spc.webos.acceptor.SocketMessage;
import spc.webos.config.AppConfig;
import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.endpoint.Endpoint;
import spc.webos.endpoint.EndpointFactory;
import spc.webos.endpoint.Executable;
import spc.webos.util.StringX;

public class ForwardTCPResponseAFNode extends TCPResponseAFNode
{
	public Object msg2sndobj(IMessage msg) throws Exception
	{
		SocketMessage smsg = (SocketMessage) msg
				.getInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_SOCKETMSG);
		Executable exe = new Executable();
		exe.request = smsg.reqmsg;
		forward(exe, smsg.localPort);
		smsg.repmsg = exe.response;
		return smsg;
	}

	public void forward(Executable exe, int localPort) throws Exception
	{
		Endpoint ep = getEndpoint(localPort);
		if (log.isDebugEnabled()) log.debug("endpoint:" + ep + ",request:"
				+ new String(exe.request, Common.CHARSET_UTF8) + "\nbase64:"
				+ StringX.base64(exe.request));
		ep.execute(exe);
		if (log.isDebugEnabled()) log.debug("response:"
				+ new String(exe.response, Common.CHARSET_UTF8) + "\nbase64:"
				+ StringX.base64(exe.response));
	}

	public Endpoint getEndpoint(int localPort) throws Exception
	{
		String ep = (String) AppConfig.getInstance().getProperty("tcpforward." + localPort, null);
		if (StringX.nullity(ep)) return endpoint;
		return EndpointFactory.getInstance().getEndpoint(ep);
	}

	protected Endpoint endpoint;

	public void setEndpoint(Endpoint endpoint)
	{
		this.endpoint = endpoint;
	}

	public void setEndpoint(String endpoint) throws Exception
	{
		this.endpoint = EndpointFactory.getInstance().getEndpoint(endpoint);
	}
}
