package spc.webos.config;

import java.util.Properties;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

import spc.webos.constant.Common;
import spc.webos.util.StringX;

public class PropertyConfigurer extends PropertyPlaceholderConfigurer
{
	protected String resolvePlaceholder(String placeholder, Properties props)
	{
		String webroot = (String) AppConfig.getInstance().getProperty(Common.WEBAPP_ROOT_PATH_KEY,
				StringX.EMPTY_STRING);
		int index = placeholder.indexOf(delim);
		if (index < 0)
		{
			String value = super.resolvePlaceholder(placeholder, props);
			if (value == null) return null;
			return StringX.replaceAll(value, AppConfig.WEBROOT_KEY, webroot);
		}
		String defValue = placeholder.length() > index + 1 ? placeholder.substring(index + 1)
				: StringX.EMPTY_STRING;
		String value = super.resolvePlaceholder(placeholder.substring(0, index), props);
		if (value == null) value = defValue;
		return StringX.replaceAll(value, AppConfig.WEBROOT_KEY, webroot);
	}

	protected String delim = "?";

	public void setDelim(String delim)
	{
		this.delim = delim;
	}
}
