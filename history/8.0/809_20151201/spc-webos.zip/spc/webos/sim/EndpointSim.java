package spc.webos.sim;

import spc.webos.data.IMessage;
import spc.webos.data.Message;
import spc.webos.endpoint.Endpoint;
import spc.webos.endpoint.Executable;

public class EndpointSim extends Sim
{
	public IMessage execute(IMessage msg, int timeout) throws Exception
	{
		Executable exe = new Executable();
		exe.setRequest(msg.write2bytes());
		exe.setReqTime(System.currentTimeMillis());
		exe.setCorrelationID(new String(msg.getCorrelationID()));
		exe.setTimeout(timeout);
		endpoint.execute(exe);
		IMessage repmsg = new Message(exe.getResponse());
		return repmsg;
	}

	Endpoint endpoint;

	public void setEndpoint(Endpoint endpoint)
	{
		this.endpoint = endpoint;
	}
}
