package spc.webos.data.util;

import spc.webos.log.Log;
import spc.webos.util.StringX;

public abstract class AbstractNodeConverter implements INodeConverter
{
	protected String name;
	protected Log log = Log.getLogger(getClass());

	public void init()
	{
		if (!StringX.nullity(name))
		{
			if (CONVERTERS.containsKey(name)) log.warn("CONVERTER(" + name + ") has bean exsit!!!");
			CONVERTERS.put(name, this);
		}
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}
}