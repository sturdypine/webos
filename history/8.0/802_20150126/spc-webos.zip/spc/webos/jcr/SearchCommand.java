package spc.webos.jcr;

public class SearchCommand implements java.io.Serializable
{
	private static final long serialVersionUID = 1L;
	public int total;
	public int pageSize = 25;
	public int page;
	public String key;

	public SearchCommand()
	{
	}

	public SearchCommand(int page, int pageSize, String key)
	{
		this.page = page;
		this.pageSize = pageSize;
		this.key = key;
	}

	public int getTotal()
	{
		return total;
	}

	public void setTotal(int total)
	{
		this.total = total;
	}

	public String getKey()
	{
		return key;
	}

	public void setKey(String key)
	{
		this.key = key;
	}

	public int getPageSize()
	{
		return pageSize;
	}

	public void setPageSize(int pageSize)
	{
		this.pageSize = pageSize;
	}

	public int getPage()
	{
		return page;
	}

	public void setPage(int page)
	{
		this.page = page;
	}
}
