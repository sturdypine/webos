package spc.webos.queue;

import java.util.List;

import spc.webos.log.Log;
import spc.webos.queue.ibmmq.QueueAccess;
import spc.webos.util.StringX;

/**
 * MQ 2 MQЭ��ת����
 * 
 * @author chenjs
 * 
 */
public class ForwardOnMessage implements IOnMessage
{
	protected Log log = Log.getLogger(getClass());
	protected String qname;
	protected String appId;
	protected IQueueAccess access;

	public void onMessage(Object obj, AccessTPool pool, AbstractReceiverThread thread)
			throws Exception
	{
		QueueMessage qmsg = (QueueMessage) obj;
		if (!StringX.nullity(appId)) qmsg.applicationIdData = appId;
		access.send(qname, qmsg);
	}

	public void setQname(String qname)
	{
		this.qname = qname;
	}

	public void setAppId(String appId)
	{
		this.appId = appId;
	}

	public void setAccess(IQueueAccess access)
	{
		this.access = access;
	}

	public void setAccess(List chls)
	{
		this.access = new QueueAccess(chls);
	}
}
