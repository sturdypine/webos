package spc.webos.beans.propertyeditors;

import java.util.Hashtable;
import java.util.Map;

import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;

public class JsonHashtablePropertyEditor extends JsonMapPropertyEditor
{
	public void setAsText(String text)
	{
		setValue(StringX.nullity(text) ? null : new Hashtable((Map) JsonUtil.json2obj(text)));
	}
}
