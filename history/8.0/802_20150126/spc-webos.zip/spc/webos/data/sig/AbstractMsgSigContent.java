package spc.webos.data.sig;

import spc.webos.log.Log;

public abstract class AbstractMsgSigContent implements IMsgSigContent
{
	protected Log log = Log.getLogger(getClass());
	protected String name;

	public void init() throws Exception
	{
		if (IMsgSigContent.SIG.containsKey(name)) log.warn("IMsgSigContent(" + name
				+ ") repeated!!!");
		IMsgSigContent.SIG.put(name, this);
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}
}
