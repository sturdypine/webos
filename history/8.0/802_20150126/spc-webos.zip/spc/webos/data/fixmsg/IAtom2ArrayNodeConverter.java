package spc.webos.data.fixmsg;

import spc.webos.data.IAtomNode;
import spc.webos.data.INode;
import spc.webos.model.MsgSchemaVO;

public interface IAtom2ArrayNodeConverter
{
	void pack(String[] array, int index, IAtomNode value, MsgSchemaVO schema) throws Exception;

	INode unpack(String[] array, int index, MsgSchemaVO schema) throws Exception;
}
