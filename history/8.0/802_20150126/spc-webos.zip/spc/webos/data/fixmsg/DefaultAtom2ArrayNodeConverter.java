package spc.webos.data.fixmsg;

import spc.webos.data.AtomNode;
import spc.webos.data.IAtomNode;
import spc.webos.data.INode;
import spc.webos.log.Log;
import spc.webos.model.MsgSchemaVO;
import spc.webos.util.StringX;

public class DefaultAtom2ArrayNodeConverter implements IAtom2ArrayNodeConverter
{
	protected Log log = Log.getLogger(getClass());
	public final static String DEFAULT_NUM_VALUE = "0";
	protected boolean floatWithDot = true;

	public void pack(String[] array, int index, IAtomNode value, MsgSchemaVO schema)
			throws Exception
	{
		if (value == null) array[index] = StringX.EMPTY_STRING;
		else array[index] = value.stringValue();
	}

	public INode unpack(String[] array, int index, MsgSchemaVO schema) throws Exception
	{
		return index < array.length ? new AtomNode(array[index]) : null;
	}
}
