package spc.webos.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import spc.webos.util.JsonUtil;

/**
* genarated by sturdypine.chen
* Email: sturdypine@gmail.com
* description: 
*/
public class BeanVO implements ValueObject
{
	public static final long serialVersionUID = 20150115L;
	// ����������Ӧ�ֶε�����
	String id; //  ����
	String bean; // 
	String remark; // 

	// �ʹ�VO�����������VO����
	
	// �ʹ�VO�������������Sql����
	// Note: ���������Sql����ΪString, Inegter...��Java final classʱ�� ֻ��ʹ��Object���� ����ʱ��ֻ��ͨ��
	// Object��toString()������ʹ�á�
	public static final String TABLE = "sys_bean";
	public static final String[] BLOB_FIELD = null;
	public static final String SEQ_NAME = "id";

	
	public BeanVO()
	{
	}
	
	public void setPrimary(String id)
	{
		this.id = id;
	}
	
	public String getPrimary(String delim)
	{
		StringBuffer buf = new StringBuffer();
		buf.append(this.id);
		return buf.toString();
	}
	
	public Map getPrimary()
	{
		Map m = new HashMap();
		m.put("id", id);
		return m;
	}
	
	public String getTable()
	{
		return TABLE;
	}
	
	public String[] getBlobField()
	{
		return BLOB_FIELD;
	}
	
	public String getKeyName()
	{
		return SEQ_NAME;
	}
	
	public Serializable getKey()
	{
		return id;
	}
	
	// set all properties to NULL
	public void setNULL()
	{
    	this.id = null;
    	this.bean = null;
    	this.remark = null;
	}
	
	public boolean equals(Object o)
	{
		if (this == o) return true;
		if (!(o instanceof FTLVO)) return false;
		BeanVO obj = (BeanVO) o;
		if (!id.equals(obj.id)) return false;
		if (!bean.equals(obj.bean)) return false;
		if (!remark.equals(obj.remark)) return false;
		return true;
	}
	
	// ֻ����������ɢ��
	public int hashCode()
	{
		long hashCode = getClass().hashCode();
		if (id != null) hashCode += id.hashCode();
		return (int)hashCode;
	}
	
	public int compareTo(Object o)
	{
		return -1;
	}

	// set all properties to default value...
	public void init()
	{
	}
	
    public String getId()
    {
        return id;
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public String getBean()
    {
        return bean;
    }
    
    public void setBean(String bean)
    {
        this.bean = bean;
    }
    
    public String getRemark()
    {
        return remark;
    }
    
    public void setRemark(String remark)
    {
        this.remark = remark;
    }
    
	
	public void set(BeanVO vo)
	{
    	this.id = vo.id;
    	this.bean = vo.bean;
    	this.remark = vo.remark;
	}
	
	public static long getSerialVersionUID()
	{
		return serialVersionUID;
	}
	
	public StringBuffer toJson()
	{
		StringBuffer buf = new StringBuffer();
		buf.append(JsonUtil.obj2json(this));
		return buf;
	}
	
	public void afterLoad()
	{
		// TODO Auto-generated method stub
	}

	public void beforeLoad()
	{
		// TODO Auto-generated method stub
	}

	public void setManualSeq(Long seq)
	{
		
	}
	
	public void destory()
	{

	}
	
	public String toString()
	{
		StringBuffer buf = new StringBuffer(128);
		buf.append(getClass().getName() + "(serialVersionUID=" + serialVersionUID + "):");
		buf.append(toJson());
		return buf.toString();
	}
	
	public Object clone()
	{
		BeanVO obj = new BeanVO();
		obj.set(this);
		return obj;
	}
}
