package spc.webos.flownode.impl;

import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.service.common.IESBService;

public class ESBAFNode extends AbstractFNode
{
	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		ICompositeNode transaction = esbService.execute(msg.getTransaction());
		msg.setTransaction(transaction);
		return null;
	}

	IESBService esbService;

	public void setEsbService(IESBService esbService)
	{
		this.esbService = esbService;
	}
}
