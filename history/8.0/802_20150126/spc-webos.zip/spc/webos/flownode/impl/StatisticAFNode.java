package spc.webos.flownode.impl;

import java.util.List;

import spc.webos.data.IMessage;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.statistics.IStat;

/**
 * ͳ�����̽ڵ�
 * 
 * @author spc
 * 
 */
public class StatisticAFNode extends AbstractFNode
{
	List stats; // ���в����ͳ�ƿھ��б�

	public void setStats(List stats)
	{
		this.stats = stats;
	}

	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		if (stats == null) return null;
		long cur = System.currentTimeMillis();
		for (int i = 0; i < stats.size(); i++)
		{
			IStat stat = (IStat) stats.get(i);
			stat.trigger(msg, cur);
		}
		return null;
	}
}
