package spc.webos.buffer;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import spc.webos.cache.WaitWithTime;
import spc.webos.log.Log;

public abstract class AbstractBuffer implements IBuffer
{
	// protected boolean available = true;
	protected int cap = DEFAULT_CAP;
	protected String name;
	protected int max; // ���������ֵ
	protected long total; // ���뻺�������
	protected List readers = new LinkedList();
	protected List writers = new LinkedList();
	protected BufferEventListener listener;
	protected Log log = Log.getLogger(getClass());

	public void init() throws Exception
	{
		if (name != null)
		{
			if (BUFFERS.containsKey(name)) throw new RuntimeException(name
					+ " Buffer existed in BUFFERS"); // ��������Ѿ����ڣ�������ͬ��������һ��JVM����
			BUFFERS.put(name, this);
		}
	}

	public List getReaders()
	{
		return readers;
	}

	public List getWriters()
	{
		return writers;
	}

	public boolean isFull()
	{
		return this.size() >= this.cap;
	}

	public boolean isEmpty()
	{
		return this.size() == 0;
	}

	public synchronized Object remove(long timeout) throws TimeoutException
	{
		// �����ʱʱ��<=0, ��ô�����ǰ���Ļ���ֱ�ӷ���null,�������쳣ģʽ
		if (timeout <= 0) return size() <= 0 ? null : remove();
		return remove(new CommonWaitWithTime(CommonWaitWithTime.READ, timeout, this));
	}

	public synchronized Object remove(WaitWithTime wwt) throws TimeoutException
	{
		if (readers.size() < 200) readers.add(Thread.currentThread().getName());
		Object v = null;
		try
		{
			wwt.setTarget(this);
			while (v == null)
			{
				while (wwt.condition())
					wwt.timeWait();
				v = pollFromBuf();
				wwt.announce();
			}
		}
		finally
		{
			readers.remove(Thread.currentThread().getName());
			try
			{
				if (listener != null) listener.notifyRemoved(this, v, Thread.currentThread());
			}
			catch (Exception e)
			{
				log.warn("listener.notifyRemoved", e);
			}
		}
		return v;
	}

	public synchronized Object remove()
	{
		Object v = null;
		if (readers.size() < 200) readers.add(Thread.currentThread().getName());
		try
		{
			while (v == null)
			{
				while (size() <= 0)
				{
					try
					{
						this.wait();
					}
					catch (InterruptedException e)
					{
						log.error("remove:: " + e);
						return null;
					}
				}
				v = pollFromBuf();
				notifyAll();
			}
		}
		finally
		{
			readers.remove(Thread.currentThread().getName());
			try
			{
				if (listener != null) listener.notifyRemoved(this, v, Thread.currentThread());
			}
			catch (Exception e)
			{
				log.warn("listener.notifyRemoved", e);
			}
		}
		return v;
	}

	public synchronized Object put(Object value, long timeout) throws TimeoutException
	{
		// �����ʱʱ��<=0, ��ô�����ǰ���Ļ���ֱ�ӷ���null,�������쳣ģʽ
		if (timeout <= 0) return size() >= cap() ? null : put(value);
		return put(value, new CommonWaitWithTime(CommonWaitWithTime.WRITE, timeout, this));
	}

	public synchronized Object put(Object value, WaitWithTime wwt) throws TimeoutException
	{
		if (writers.size() < 200) writers.add(Thread.currentThread().getName());
		try
		{
			wwt.setTarget(this);
			while (wwt.condition())
			{
				if (log.isDebugEnabled()) log.debug("Wait:Thread("
						+ Thread.currentThread().getName() + "):put.Buffer(" + getName() + ")");
				wwt.timeWait();
			}
			add(value);
			wwt.announce();
			int size = size();
			if (size > max) max = size;
			total++;
		}
		finally
		{
			writers.remove(Thread.currentThread().getName());
			try
			{
				if (listener != null) listener.notifyPut(this, value, Thread.currentThread());
			}
			catch (Exception e)
			{
				log.warn("listener.notifyPut", e);
			}
		}
		// if (log.isDebugEnabled()) log.debug("success to put one object in " +
		// name); // 2010-3-31 ���ܵ�����־�ݹ��ջ���
		return value;
	}

	public synchronized Object put(Object value)
	{
		if (writers.size() < 200) writers.add(Thread.currentThread().getName());
		try
		{
			while (size() >= cap())
			{
				try
				{
					log.info("Wait:Thread(" + Thread.currentThread().getName() + "):put.Buffer("
							+ getName() + ")");
					wait();
				}
				catch (InterruptedException e)
				{
					log.error("put:: " + e);
					return null;
				}
			}
			add(value);
			notifyAll();
			int size = size();
			if (size > max) max = size;
			total++;
		}
		finally
		{
			writers.remove(Thread.currentThread().getName());
			try
			{
				if (listener != null) listener.notifyPut(this, value, Thread.currentThread());
			}
			catch (Exception e)
			{
				log.warn("listener.notifyPut", e);
			}
		}
		return value;
	}

	public void putFirst(Object v)
	{
		addFirst(v);
		try
		{
			if (listener != null) listener.notifyPut(this, v, Thread.currentThread());
		}
		catch (Exception e)
		{
			log.warn("listener.notifyPut", e);
		}
		int size = size();
		if (size > max) max = size;
	}

	public abstract void add(Object v);

	public abstract void addFirst(Object v);

	public abstract Object pollFromBuf();

	public int cap()
	{
		return cap;
	}

	public void setCap(int cap)
	{
		this.cap = cap;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public Map checkStatus(Map param)
	{
		Map status = new HashMap();
		status.put("name", getName());
		status.put("size", new Integer(size()));
		status.put("cap", new Integer(cap()));
		status.put("clazz", getClass().getName());
		status.put("max", new Integer(max));
		status.put("total", new Long(total));
		status.put("readers", readers);
		status.put("writers", writers);
		return status;
	}

	public boolean changeStatus(Map param)
	{
		return false;
	}

	public void refresh()
	{
	}

	public void setListener(BufferEventListener listener)
	{
		this.listener = listener;
	}
}
