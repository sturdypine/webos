
package spc.webos.jsrmi.protocal;

public class InitializeObjectFailedException extends RuntimeException {

	private static final long serialVersionUID = -6552359894410145874L;

	public InitializeObjectFailedException() {
		super();
	}

	public InitializeObjectFailedException(String message, Throwable cause) {
		super(message, cause);
	}

	public InitializeObjectFailedException(String message) {
		super(message);
	}

	public InitializeObjectFailedException(Throwable cause) {
		super(cause);
	}
	
}
