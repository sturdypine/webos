package spc.webos.jsrmi.protocal.converters.map;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import spc.webos.jsrmi.protocal.AccessFieldException;
import spc.webos.jsrmi.protocal.converters.Converter;
import spc.webos.jsrmi.protocal.io.MarshallingContext;
import spc.webos.jsrmi.protocal.io.StreamReader;
import spc.webos.jsrmi.protocal.io.StreamWriter;
import spc.webos.jsrmi.protocal.io.UnmarshallingContext;

public class ObjectConverter extends AbstractMapConverter implements Converter
{
	public static final ObjectConverter objectConverter = new ObjectConverter();
	
	public static final ObjectConverter getInstance()
	{
		return objectConverter;
	}
	
	private ObjectConverter()
	{
	}
	
	public boolean canConvert(Class type)
	{
		if (type == null) return false;
		return Object.class.isAssignableFrom(type);
	}

	protected void marshalMapObject(Object value, MarshallingContext context,
			StreamWriter streamWriter)
	{
		Class clazz = value.getClass();
		for (; clazz != null; clazz = clazz.getSuperclass())
		{
			Field[] fields = clazz.getDeclaredFields();
			for (int i = 0; i < fields.length; i++)
			{
				Field field = fields[i];

				if (Modifier.isTransient(field.getModifiers())
						|| Modifier.isStatic(field.getModifiers())) continue;
				field.setAccessible(true);
				try
				{
					Object v = field.get(value);
					if (v == null) continue;// don't put null value
					context.convertAnother(field.getName());
					context.convertAnother(v);
				}
				catch (Exception e)
				{
//					 e.printStackTrace();
					throw new AccessFieldException("error accessing property ["
							+ field.getName() + "] of class [" + clazz + "]", e);
				}
			}
		}
	}

	public Object unmarshal(StreamReader reader,
			UnmarshallingContext unmarshallingContext)
	{
		throw new UnsupportedOperationException(
				"the MapConverter has done it already");
	}

}
