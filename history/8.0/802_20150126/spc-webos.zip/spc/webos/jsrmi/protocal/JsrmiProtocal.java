
package spc.webos.jsrmi.protocal;

import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import spc.webos.jsrmi.protocal.converters.ConverterLookup;
import spc.webos.jsrmi.protocal.converters.DefaultConverterLookup;
import spc.webos.jsrmi.protocal.io.DefaultMarshallingStrategy;
import spc.webos.jsrmi.protocal.io.FastInputStreamReader;
import spc.webos.jsrmi.protocal.io.FastStreamReader;
import spc.webos.jsrmi.protocal.io.FastStreamWriter;
import spc.webos.jsrmi.protocal.io.MarshallingStrategy;

public class JsrmiProtocal {

	private MarshallingStrategy marshallingStrategy;
	private ConverterLookup converterLookup;

	private static JsrmiProtocal instance = null;
	
	private JsrmiProtocal() {
		marshallingStrategy = new DefaultMarshallingStrategy();
		converterLookup = DefaultConverterLookup.getInstance();
	}
	
	public static JsrmiProtocal getInstance() {
		if (instance == null) {
			instance = new JsrmiProtocal();
		}
		return instance;
	}

	public JsrmiCall deserialize(String source) {
		return unmarshall(new StringReader(source));
	}

	public String serialize(Object value) {
		StringWriter writer = new StringWriter();
		marshall(value, writer);
		return writer.getBuffer().toString();
	}

	public void marshall(Object value, Writer writer) {
		marshallingStrategy.marshal(value, converterLookup, new FastStreamWriter(writer));
	}
	
	public JsrmiCall unmarshall(Reader reader) {
		return marshallingStrategy.unmarshal(new FastStreamReader(reader), converterLookup);
	}
	
	public JsrmiCall unmarshall(InputStream inputStream) {
		return marshallingStrategy.unmarshal(new FastInputStreamReader(inputStream), converterLookup);
	}
}
