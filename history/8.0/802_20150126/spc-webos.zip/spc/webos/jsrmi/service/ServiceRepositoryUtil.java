package spc.webos.jsrmi.service;

import javax.servlet.ServletContext;

public class ServiceRepositoryUtil {
	
	/**
	 * Get service repository from servlet context, if any
	 * @param context the servlet context
	 * @return the repository stored in the servlet context if any
	 */
	public static ServiceRepository getServiceRepository(ServletContext context) {
		Object rep = context.getAttribute(ServiceRepository.WEB_CONTEXT_KEY);
		if (rep == null) {
			return null;
		}
		if (!(rep instanceof ServiceRepository)) {
			throw new IllegalStateException("context attribute is not of type : ServiceRepository" + rep);
		} 
		
		return (ServiceRepository)rep;
	}
}
