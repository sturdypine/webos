package spc.webos.thread;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import spc.webos.log.IDynamicLog;
import spc.webos.log.Log;
import spc.webos.service.IStatus;
import spc.webos.util.SystemUtil;

public abstract class ThreadPool implements IStatus
{
	protected String name;
	protected int size; // �̳߳ش�С
	protected List pool; // �̳߳��еĵ��̴߳�С
	protected long no = 0; // �̱߳��, ��Զ�������ظ�
	protected String logScriptKey; // �߳���־�ű�, ���ڱ���ʽ�ж�
	protected String logName; // ��־��
	protected boolean initStart; // 715, ��ʼ��ʱ�����߳�
	protected boolean threadLog = true; // 711_20140711 �Ƿ�����߳���־����ֻ�޸���־�ļ�����
	protected IDynamicLog dynamicLog;
	public static final Map POOLS = new HashMap();
	protected Log log = Log.getLogger(getClass());

	public abstract DaemonThread borrow();

	public void init() throws Exception
	{
		if (pool != null && pool.size() > 0) return;
		if (name == null) name = SystemUtil.getInstance().getTimeSN(); // �̳߳ر����и�����
		if (POOLS.containsKey(name)) log.warn("ThreadPool(" + name + ") has been exist!!!");
		POOLS.put(name, this);
		pool = new ArrayList();
		for (int i = 1; i <= size; i++)
		{
			DaemonThread t = borrow();
			t.setName(name + "_" + (no++));
			pool.add(t);
		}

		if (initStart)
		{ // 715_20141011 ��������bean���Զ������̳߳�
			log.info("ThreadPool init start all: " + getName());
			startAll();
		}

		Runtime.getRuntime().addShutdownHook(new Thread()
		{
			public void run()
			{
				System.err.println("JVM will stop in " + getClass() + ", name:" + name);
				asynStopAll();
				interruptAll();
			}
		});
	}

	// ���ٳ��е��߳�����
	public void removeThread(int num)
	{
	}

	// ɱ������ָ�����߳���, ����ͨ������״̬��ɱ���߳�,����������߳���wait��, �ǲ�������ɱ����.
	public void removeThread(String name)
	{
		DaemonThread t = getThread(name);
		t.setStatus(DaemonThread.STOPPED);
		removeDeadThread();
	}

	// ��ó���ָ���߳������߳�
	public DaemonThread getThread(String name)
	{
		for (int i = 0; i < pool.size(); i++)
		{
			DaemonThread t = (DaemonThread) pool.get(i);
			if (t.getName().equals(name)) return t;
		}
		return null;
	}

	/*
	 * ���ӳ��е��߳�����
	 */
	public void addThread(int num)
	{
		for (int i = 0; i < num; i++)
		{
			DaemonThread t = borrow();
			t.setName(name + "-" + (no++));
			pool.add(t);
			t.start();
		}

		removeDeadThread();
	}

	// �������е����߳�
	public void removeDeadThread()
	{
		List dead = new ArrayList();
		for (int i = 0; i < pool.size(); i++)
		{
			DaemonThread t = (DaemonThread) pool.get(i);
			if (t.getCurStatus() == DaemonThread.STOPPED) dead.add(t);
		}
		for (int i = 0; i < dead.size(); i++)
		{
			pool.remove(dead.get(i));
		}
	}

	public int getActualSize()
	{
		return pool.size();
	}

	public int getSize()
	{
		return size;
	}

	public void setSize(int size)
	{
		this.size = size;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public void startAll() throws Exception
	{
		init();
		for (int i = 0; i < pool.size(); i++)
		{
			DaemonThread t = (DaemonThread) pool.get(i);
			t.setStatus(DaemonThread.RUNNING);
			t.start();
		}
	}

	public void asynStopAll()
	{
		for (int i = 0; i < pool.size(); i++)
		{
			DaemonThread t = (DaemonThread) pool.get(i);
			t.asynStop();
		}
	}

	public void interruptAll()
	{
		for (int i = 0; i < pool.size(); i++)
		{
			DaemonThread thread = ((DaemonThread) pool.get(i));
			if (thread.status == DaemonThread.STOPPED) continue;
			log.warn("Thread(" + thread.getName() + ") interrupt...");
			thread.release(); // added by spc 2010-12-01 �ͷ���Դ
			try
			{
				thread.interrupt();
			}
			catch (Throwable t)
			{
			}
		}
	}

	public Map checkStatus(Map param)
	{
		Map status = new HashMap();
		status.put("clazz", getClass().getName());
		status.put("name", getName());
		status.put("size", new Integer(getSize()));
		status.put("actualSize", new Integer(getActualSize()));
		status.put("logScriptKey", logScriptKey);
		status.put("logName", logName);
		return status;
	}

	public boolean changeStatus(Map param)
	{
		return false;
	}

	public void refresh()
	{
	}

	public String getLogScriptKey()
	{
		return logScriptKey;
	}

	public void setLogScriptKey(String logScriptKey)
	{
		this.logScriptKey = logScriptKey;
	}

	public String getLogName()
	{
		return logName;
	}

	public void setLogName(String logName)
	{
		this.logName = logName;
	}

	public IDynamicLog getDynamicLog()
	{
		return dynamicLog;
	}

	public void setDynamicLog(IDynamicLog dynamicLog)
	{
		this.dynamicLog = dynamicLog;
	}

	public boolean isThreadLog()
	{
		return threadLog;
	}

	public void setThreadLog(boolean threadLog)
	{
		this.threadLog = threadLog;
	}
}
