package spc.webos.echain.db;

import java.sql.Connection;

import javax.sql.DataSource;

import org.springframework.jdbc.datasource.DataSourceUtils;

import com.ecc.echain.db.DbIPMDefault;
import com.ecc.echain.workflow.exception.WFException;

public class DBControl extends DbIPMDefault
{
	protected static DataSource ds;

	public Connection getConnection() throws WFException
	{
		return DataSourceUtils.getConnection(ds);
	}

	public boolean freeConnection(Connection cn) throws WFException
	{
		DataSourceUtils.releaseConnection(cn, ds);
		return true;
	}

	public void setDs(DataSource ds)
	{
		this.ds = ds;
	}
}
