package spc.webos.endpoint;

import java.io.IOException;
import java.nio.BufferUnderflowException;
import java.nio.channels.ClosedChannelException;

import org.xsocket.MaxReadSizeExceededException;
import org.xsocket.connection.IConnectHandler;
import org.xsocket.connection.IDataHandler;
import org.xsocket.connection.IDisconnectHandler;
import org.xsocket.connection.INonBlockingConnection;

import spc.webos.constant.AppRetCode;
import spc.webos.constant.Common;
import spc.webos.exception.AppException;
import spc.webos.log.Log;
import spc.webos.util.StringX;
import spc.webos.util.bytes.BytesUtil;
import spc.webos.util.http.HTTPHeader;
import spc.webos.util.http.HTTPUtil;

public class AsynTCPClientHandler implements IDataHandler, IConnectHandler, IDisconnectHandler
{
	protected Executable exe;
	protected AsynTCPEndpoint endpoint;
	protected String ip;
	protected int port;
	protected Log log;
	protected boolean doResponse; // �Ƿ�����Ӧ��
	protected boolean releaseCnn; // 808, �Ƿ��ͷ�������

	public AsynTCPClientHandler(AsynTCPEndpoint endpoint, Executable exe, String ip, int port)
	{
		this.endpoint = endpoint;
		this.log = endpoint.log;
		this.exe = exe;
		this.ip = ip;
		this.port = port;
	}

	public boolean onConnect(INonBlockingConnection nbc) throws IOException,
			BufferUnderflowException, MaxReadSizeExceededException
	{
		if (endpoint.log.isDebugEnabled()) endpoint.log.debug("suc to cnn: "
				+ nbc.getRemoteAddress());
		return true;
	}

	public void releaseCnn()
	{
		if (releaseCnn) return;
		endpoint.releaseCnn(); // ��ǰ�����Ѿ��ϵ����ͷ�����
		releaseCnn = true;
	}

	public boolean onDisconnect(INonBlockingConnection nbc) throws IOException
	{
		if (!StringX.nullity(endpoint.logName)) Log.start(endpoint.logName);
		log.info("discnn: " + port + ":" + nbc.getRemoteAddress() + ",open:" + nbc.isOpen()
				+ ",cnnN:" + endpoint.currentCnnNum + ", thread:"
				+ Thread.currentThread().getName());
		// endpoint.releaseCnn(); // ��ǰ�����Ѿ��ϵ����ͷ�����
		releaseCnn();
		try
		{
			if (exe.resTime <= 0 && !exe.withoutReturn && !endpoint.simplex)
			{ // �������û��ӳ������³���onDiscnn������ǳ�ʱ���µ�
				long cost = (System.currentTimeMillis() - exe.reqTime);
				log.warn("Timeout:" + exe.getTimeout() + "," + nbc.getIdleTimeoutMillis() + "::"
						+ ip + ":" + port + ", sn:"
						+ (exe.reqmsg != null ? exe.reqmsg.getMsgSn() : "") + ", cost:" + cost);
				if (exe.callback != null) exe.callback.fail(
						exe,
						endpoint,
						ip,
						port,
						new AppException(AppRetCode.PROTOCOL_SOCKET(), new Object[] {
								String.valueOf(ip),
								String.valueOf(port),
								String.valueOf(exe.getTimeout() + "," + nbc.getIdleTimeoutMillis()
										+ "," + cost) }));
			}
			else if (!doResponse) doResponse(); // ���û�д�����Ӧ��,����server����discnn����ȷ�������������
			// else if (endpoint.dhl.hdrLen <= 0) doResponse(); //
			// ���û�г���ͷ,����server����discnn����ȷ�������������
		}
		catch (Throwable e)
		{
			log.warn("onDiscnn", e);
		}
		finally
		{
			Log.print();
		}
		return false;
	}

	public synchronized boolean onData(INonBlockingConnection nbc) throws IOException,
			BufferUnderflowException, ClosedChannelException, MaxReadSizeExceededException
	{
		if (!StringX.nullity(endpoint.logName)) Log.start(endpoint.logName);
		int available = nbc.available();
		if (log.isInfoEnabled()) log.info("onData:" + available + ", thread:"
				+ Thread.currentThread().getName());
		if (available <= 0) return false;
		try
		{
			if (endpoint.longCnn) longCnn(nbc);
			else shortCnn(nbc);
		}
		catch (Throwable e)
		{
			log.warn("fail read:" + ip + ":" + port + ", longCnn:" + endpoint.longCnn, e);
		}
		finally
		{
			Log.print();
		}
		return true;
	}

	// �����ӵ�Ӧ��ģʽ
	protected void shortCnn(INonBlockingConnection nbc) throws Throwable
	{
		if (endpoint.dhl.hdrLen > 0) nbc.markReadPosition();
		byte[] response = nbc.readBytesByLength(nbc.available());
		if (log.isInfoEnabled()) log.info("response len:" + response.length + ", arrived:"
				+ (exe.response == null ? 0 : exe.response.length) + ", server:"
				+ nbc.getRemoteAddress());
		if (endpoint.isTrace() && log.isInfoEnabled()) log.info("trace response:"
				+ new String(response) + "\nbase64:" + StringX.base64(response));
		else if (log.isDebugEnabled()) log.debug("response:" + new String(response) + "\nbase64:"
				+ StringX.base64(response));
		exe.resTime = System.currentTimeMillis();
		if (endpoint.dhl.hdrLen <= 0)
		{ // ���û��ͷ������Ϣ�����񷽷��ص���Ϣ�����ְ����صĻ�ondata���α�����
			exe.response = (exe.response == null ? response : BytesUtil.merge(exe.response,
					response));
		}
		else
		{ // ȥ�����Ȳ���
			byte[] lenBytes = BytesUtil.arraycopy(response, 0, endpoint.dhl.hdrLen);
			int hlen = endpoint.dhl.length(lenBytes);
			if (log.isInfoEnabled()) log.info("len:" + (response.length - endpoint.dhl.hdrLen)
					+ ", hdrlen:" + hlen + "," + StringX.base64(lenBytes) + ","
					+ new String(lenBytes));
			int remain = endpoint.dhl.remain(response.length, hlen); // ��ǰʣ�౨�ĳ���
			// int remain = len - response.length + endpoint.dhl.hdrLen;
			if (remain > 0)
			{ // ����˴δﵽ�ͻ��˵���Ϣֻ�г���ͷ��û�����ݻ������ݲ�������ȴ����ݻ���
				log.info("wait for " + remain + " bytes!!!");
				nbc.resetToReadMark();
				return;
			}
			nbc.removeReadMark();
			exe.response = BytesUtil.arraycopy(response, endpoint.dhl.hdrLen, response.length
					- endpoint.dhl.hdrLen);
			close(nbc); // ��doResponseǰ�����������ͷ���Դ
			doResponse();
		}
	}

	protected void doResponse() throws Throwable
	{
		if (doResponse)
		{
			log.warn("response done!!!");
			return;
		}
		doResponse = true;
		log.info("do response:" + (exe.response == null ? 0 : exe.response.length) + ", cost:"
				+ (exe.resTime - exe.reqTime));
		if (endpoint.http)
		{
			byte[] response = exe.response;
			HTTPHeader header = new HTTPHeader();
			exe.response = HTTPUtil.unpackResponse(exe.response, header);
			exe.repHttpHeaders = header.params;
			if (header.statusCode != 200)
			{
				log.warn("HTTP statusCode:" + header.statusCode + ", response:"
						+ new String(response, Common.CHARSET_UTF8));
				exe.callback.fail(exe, endpoint, ip, port,
						new AppException(AppRetCode.PROTOCOL_HTTP(), new Object[] { new Integer(
								header.statusCode) }));
				return;
			}
		}

		if (exe.callback != null) exe.callback.response(exe, endpoint, ip, port);
		else log.info("callback is null !!!");
	}

	protected void longCnn(INonBlockingConnection nbc) throws Throwable
	{
		while (nbc.available() > 0)
		{
			exe.response = readBytesByLength(nbc, endpoint.dhl.hdrLen);
			if (exe.callback != null && exe.response != null) exe.callback.response(exe, endpoint,
					ip, port);
			else log.warn("callback or response is null !!!");
		}
	}

	protected byte[] readBytesByLength(INonBlockingConnection nbc, int len) throws Exception
	{
		byte[] lenBytes = nbc.readBytesByLength(endpoint.dhl.hdrLen);
		int hdrLen = endpoint.dhl.length(lenBytes);
		if (log.isInfoEnabled()) log.info("long hdrlen:" + hdrLen);
		byte[] response = nbc.readBytesByLength(hdrLen);
		if (log.isInfoEnabled()) log.info("long asyn response len:" + response.length + ","
				+ new String(lenBytes));
		if (log.isDebugEnabled()) log.debug("long asyn response:" + new String(response)
				+ "\nbase64:" + StringX.base64(response));
		return response;
	}

	protected void close(INonBlockingConnection nbc)
	{
		log.info("close nbc:" + nbc.isOpen() + ",cnnN:" + endpoint.currentCnnNum);
		releaseCnn();
		try
		{
			if (nbc.isOpen()) nbc.close();
		}
		catch (IOException e)
		{
		}
	}
}
