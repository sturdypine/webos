package spc.webos.endpoint;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import spc.webos.constant.AppRetCode;
import spc.webos.data.CompositeNode;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.data.Status;
import spc.webos.endpoint.Endpoint;
import spc.webos.endpoint.Executable;
import spc.webos.exception.AppException;
import spc.webos.log.Log;
import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;
import JClient.CEasyAppClient;
import JClient.CEasyPackage;

/**
 * ����BA�е�Endpoint�����������׳����ĵ�corba����
 * 
 * �����ĺ��Ĳ���Ҫmb������������ʹ��ESBXML��׼���ģ������ĺ�Ӧ�����ж�ֻ�ܺ���ԭ�ӽڵ�
 * ����ʱ��EasyConCorbaEndpoint��ȡrequest�еĽڵ��ֵ���뵽corba�������ݰ�
 * Ӧ��ʱ��EasyConCorbaEndpoint��Ӧ�����ݰ��еı�ǩ��ֵset��response�ڵ���
 * 
 * URI��ʽ��cecorba://ip:port/servicename?retcdLable=..&descLable=..&fieldsMap={
 * esblabel:'cbslabel';esblabel:'cbslabel'} fieldsMapֵ��ʽ��{esblabel,
 * '_jym'(������);esblabel,'_gyh'(��Ա��);esblabel,'_jgm'(������);esblabel,'_hostseqno'(������ˮ��)}
 * �� �� �� �� Ҫ �� �� �� �� �� ������Щ�ֶβ�����ESB���ĵı�ǩ�����淶����fieldmap��esb��׼�ı�ǩ���ƺͺ��ı�ǩ���ƶ�������
 * ���ӣ�cecorba://192.168.20
 * .58:7788/wyyw?retcdLable=Xydm&descLable=Mesg&fieldsMap=
 * {TradeNo:'_jym';ActorNo:'_gyh';OrganNo:'_jgm';HxLsh:'_hostseqno'}
 * 
 * @author zhaoam
 * 
 */
public class CECorbaEndpoint implements Endpoint
{
	public static final String PREFIX = "cecorba";
	protected Log log;
	protected String ip;
	protected String port;
	protected String location;
	protected String serviceName;
	protected String defaultNS;
	protected String fieldsMap;
	protected String retcdLable;
	protected String descLable;
	public Map<String, String> reqfieldsmap;
	public Map<String, String> resfieldsmap;

	public CECorbaEndpoint()
	{
		defaultNS = "DEFAULT";
		retcdLable = "";
		descLable = "";
		reqfieldsmap = new HashMap<String, String>();
		resfieldsmap = new HashMap<String, String>();
		log = Log.getLogger(getClass());
	}

	public CECorbaEndpoint(String location)
	{
		this();
		this.createEndpoint();
	}

	public void setLocation(String location) throws Exception
	{
		this.location = location;
		this.createEndpoint();
	}

	private void createEndpoint()
	{
		if (log.isDebugEnabled()) log.debug((new StringBuilder("location:")).append(location)
				.toString());
		String[] parts = location.split("\\?");
		StringTokenizer st = new StringTokenizer(parts[0], ":");
		List uri = new ArrayList();
		while (st.hasMoreTokens())
			uri.add(st.nextToken());
		this.ip = StringX.trim((String) uri.get(1), "/");
		String strPorts = (String) uri.get(2);
		int idx = strPorts.indexOf('/');
		this.serviceName = strPorts.substring(idx + 1);
		this.port = strPorts.substring(0, idx);
		if (parts.length == 1)
		{
			log.warn("location[" + this.location + "] haven't query params!!!");
		}
		else
		{
			Map extParams = StringX.str2map(parts[1], "&");
			String retcdLable = (String) extParams.get("retcdLable");
			if (!StringX.nullity(retcdLable)) this.retcdLable = retcdLable;

			String descLable = (String) extParams.get("descLable");
			if (!StringX.nullity(descLable)) this.descLable = descLable;

			String defaultNS = (String) extParams.get("defaultNS");
			if (!StringX.nullity(defaultNS)) this.defaultNS = defaultNS;

			String fieldsMap = (String) extParams.get("fieldsMap");

			if (!StringX.nullity(fieldsMap))
			{
				reqfieldsmap = (HashMap<String, String>) JsonUtil.json2obj(fieldsMap);
				for (String key : reqfieldsmap.keySet())
				{
					String value = reqfieldsmap.get(key);
					if (!StringX.nullity(value))
					{
						resfieldsmap.put(value, key);
					}
				}
			}
		}
	}

	public void init() throws Exception
	{

	}

	public void execute(Executable executable) throws Exception
	{
		log.info("Ver:20150610 call...");
		// �½��������ݰ���Ӧ�����ݰ�
		CEasyPackage uppkg = new CEasyPackage();
		CEasyPackage downpkg = new CEasyPackage();
		if (log.isDebugEnabled()) log.debug((new StringBuilder("reqmsg:")).append(
				executable.reqmsg.toString()).toString());
		ICompositeNode request = executable.reqmsg.getRequest(); // ��ȡ����ڵ�
		// ���������ݰ������Ӳ�����ֵ
		uppkg.addString("TradeName", serviceName, defaultNS);// ��������
		for (Iterator iterator = request.keys(); iterator.hasNext();)
		{
			String field = (String) iterator.next();
			String value = (String) request.get(field);
			String label = field;
			if (null != reqfieldsmap.get(field)) // ��ȡ������Ҫ�������ǩ
			label = reqfieldsmap.get(field);
			uppkg.addString(label, value, defaultNS);// ��������
		}

		CEasyAppClient client = new CEasyAppClient();
		// ���ӷ���
		int isfail = client.connServer(serviceName, ip + ":" + port);
		if (isfail == 1)
		{
			log.warn("connServer fail,location is:" + this.toString());
			throw new AppException(AppRetCode.NET_COMMON, "connServer fail,location is:"
					+ this.toString());
		}
		client.UpPkg = uppkg;
		client.DownPkg = downpkg;
		// ������ķ���
		client.callTrade();

		// ����Ӧ���
		ICompositeNode response = new CompositeNode();
		transfPkg2Response(client.DownPkg, response);

		// ����Ӧ��ڵ�
		executable.reqmsg.setResponse(response);
		// �Ƴ�����ڵ�
		executable.reqmsg.setRequest(null);
		// ����״̬��Ϣ
		setStatus(executable, response);
		// ������ͷ��תΪӦ����ͷ
		req2rep(executable.reqmsg);
		client.clearData();
		log.info("call end!");
	}

	public void setStatus(Executable executable, ICompositeNode response)
	{
		Status status = new Status();
		status.setAppCd(executable.reqmsg.getRcvApp());
		status.setIp(ip); // ���ķ���ip
		String retcd = AppRetCode.SUCCESS;
		if (!StringX.nullity((String) response.get(this.retcdLable))) retcd = (String) response
				.get(this.retcdLable);
		status.setRetCd(retcd); // ������
		String desc = "";
		if (!StringX.nullity((String) response.get(this.descLable))) desc = (String) response
				.get(this.descLable);
		status.setDesc(desc);
		executable.reqmsg.setStatus(status);
	}

	public void req2rep(IMessage msg)
	{
		msg.setRefMsgCd(msg.getMsgCd());
		msg.setRefSndNode(StringX.nullity(msg.getSndNode()) ? null : msg.getSndNode());
		msg.setRefSndApp(msg.getSndApp());
		msg.setRefSndDt(msg.getSndDt());
		msg.setRefSeqNb(msg.getSeqNb());
		String seqNb = SystemUtil.getInstance().genSN(15);
		String sndDt = SystemUtil.getInstance().getCurrentDate(SystemUtil.DF_APP8);
		String sndTm = SystemUtil.getInstance().getCurrentDate(SystemUtil.DF_HMS9);
		msg.setSeqNb(seqNb);
		msg.setSndDt(sndDt);
		msg.setSndTm(sndTm);
		msg.setRcvAppCd(msg.getSndApp());
		msg.setSndAppCd(msg.getRcvApp());
	}

	public void transfPkg2Response(CEasyPackage pkg, ICompositeNode response) throws Exception
	{
		for (Iterator itr = pkg.getFields().iterator(); itr.hasNext();)
		{
			String[] st_v = (String[]) itr.next();
			String st_ns = st_v[CEasyPackage.FIELDINDEX_NS];
			String st_key = st_v[CEasyPackage.FIELDINDEX_KEY];
			if (log.isDebugEnabled()) log.debug("response package label:namespace=" + st_ns
					+ ",key=" + st_key + ",value=" + pkg.getString(st_key, st_ns));
			if (!StringX.nullity(st_key))
			{
				String value = pkg.getString(st_key, st_ns);
				String label = st_key;
				if (null != resfieldsmap.get(st_key)) label = resfieldsmap.get(st_key);
				response.set(label, value);
			}
		}
	}

	public void destory()
	{

	}

	public Endpoint clone() throws CloneNotSupportedException
	{
		return null;
	}

	public String toString()
	{
		StringBuffer sbf = new StringBuffer(PREFIX);
		sbf.append("://").append(this.ip).append(":").append(this.port).append("/")
				.append(this.serviceName).append("?retcdLable=").append(this.retcdLable)
				.append("&descLable=").append(this.descLable);
		sbf.append("&fieldsMap=").append(JsonUtil.obj2json(reqfieldsmap));
		sbf.append("&defaultNS=").append(this.defaultNS);
		return sbf.toString();
	}

	public String getIp()
	{
		return ip;
	}

	public void setIp(String ip)
	{
		this.ip = ip;
	}

	public String getPort()
	{
		return port;
	}

	public void setPort(String port)
	{
		this.port = port;
	}

	public String getServiceName()
	{
		return serviceName;
	}

	public void setServiceName(String serviceName)
	{
		this.serviceName = serviceName;
	}

	public String getLocation()
	{
		return location;
	}

	public String getDefaultNS()
	{
		return defaultNS;
	}

	public void setDefaultNS(String defaultNS)
	{
		this.defaultNS = defaultNS;
	}

	public String getFieldsMap()
	{
		return fieldsMap;
	}

	public void setFieldsMap(String fieldsMap)
	{
		this.fieldsMap = fieldsMap;
	}

	public String getRetcdLable()
	{
		return retcdLable;
	}

	public void setRetcdLable(String retcdLable)
	{
		this.retcdLable = retcdLable;
	}

	public String getDescLable()
	{
		return descLable;
	}

	public void setDescLable(String descLable)
	{
		this.descLable = descLable;
	}
}
