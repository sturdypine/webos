package spc.webos.jsrmi.request;

public abstract class AbstractRequestWorker implements RequestWorker
{

	protected String getWorkerRelativePath()
	{

		String pathInfo = RequestContext.getContext().getHttpRequest()
				.getPathInfo();
		// url is "/webos/jsrmi/commonService/method"
		int end = pathInfo.indexOf('/', 1);
		end = pathInfo.indexOf('/', end);
//		System.out.println(pathInfo + ",\nserviceId=" + pathInfo.substring(1, end));
		return pathInfo.substring(1, end);
		// return pathInfo.substring(pathInfo.lastIndexOf('/') + 1);
		// String[] terms = pathInfo.split("/");
		// String prefix = "/" + terms[1]+"/";
		// System.out.print("prefix="+prefix+",
		// "+pathInfo.substring(pathInfo.lastIndexOf('/')+1));
		// String relative = pathInfo.substring(prefix.length());
		// System.out.println(",relative="+relative);
		//		
		// return relative;

	}

	protected String getWorkerName()
	{

		String pathInfo = RequestContext.getContext().getHttpRequest()
				.getPathInfo();

		String[] terms = pathInfo.split("/");

		return terms[1];

	}

	protected String getParameter(String paramName)
	{
		return (String) RequestContext.getContext().getParameter().get(
				paramName);
	}

}
