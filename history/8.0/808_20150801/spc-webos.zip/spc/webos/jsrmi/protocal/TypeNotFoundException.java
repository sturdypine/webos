
package spc.webos.jsrmi.protocal;

public class TypeNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 6059732752519238966L;

	public TypeNotFoundException() {
		super();
	}

	public TypeNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public TypeNotFoundException(String message) {
		super(message);
	}

	public TypeNotFoundException(Throwable cause) {
		super(cause);
	}
	
}
