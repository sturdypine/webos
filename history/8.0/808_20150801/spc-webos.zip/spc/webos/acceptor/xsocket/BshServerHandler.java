package spc.webos.acceptor.xsocket;

import org.xsocket.connection.INonBlockingConnection;

import spc.webos.util.StringX;
import bsh.Interpreter;

public class BshServerHandler extends DefaultServerHandler
{
	protected Interpreter bsh;
	protected String fun; // 810, ���ڸ��ӵ���Ҫ�ຯ���ж��Ƿ��Ĵ������

	public synchronized boolean isShortCnnEnd(INonBlockingConnection cnn, byte[] msg)
	{
		try
		{
			bsh.set("cnn", cnn);
			bsh.set("msg", msg);
			if (StringX.nullity(fun)) bsh.eval("boolean end=fun(cnn,msg);");
			else bsh.eval("boolean end=" + fun + "(cnn,msg);");
			return (Boolean) bsh.get("end");
		}
		catch (Exception e)
		{
			log.warn("short cnn end:", e);
			return true;
		}
	}

	public void setFun(String fun)
	{
		this.fun = fun;
	}

	public void setBsh(String script) throws Exception
	{
		bsh = new Interpreter();
		if (StringX.nullity(fun)) bsh.eval("import " + INonBlockingConnection.class.getName()
				+ ";boolean fun(INonBlockingConnection cnn, byte[] msg){" + script + "}");
		else bsh.eval("import " + INonBlockingConnection.class.getName() + ";" + script);
	}
}
