package spc.webos.queue.ibmmq;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import spc.webos.log.Log;
import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;

import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;

public class MQMultiChannel
{
	protected Log log = Log.getLogger(getClass());
	protected int lastIndex;
	public int algorithm = 2; // 0: ��0��ʼ��1����ʾ�����2����ѯ
	public List<MQCnnPool> cnnpools;

	public int getStartIndex()
	{
		if (algorithm == 0 || cnnpools.size() <= 1) return 0;
		else if (algorithm == 1) lastIndex = ((int) (Math.random() * 1000) % cnnpools.size());
		else lastIndex = (lastIndex + 1) % cnnpools.size();
		if (log.isDebugEnabled()) log.debug("algorithm:" + algorithm + ", start: " + lastIndex
				+ "/" + cnnpools.size());
		return lastIndex;
	}

	public void sendCluster(String qname, MQPutMessageOptions pmo, MQMessage mqmsg, int retryTimes,
			int retryInterval) throws Exception
	{
		Exception ee = null;
		// �������Ϊ��㣬ѭ��һ�鷢��
		int index = getStartIndex();
		for (int i = 0; i < cnnpools.size(); i++)
		{
			if (index >= cnnpools.size()) index = 0;
			MQCnnPool cnnpool = cnnpools.get(index++);
			try
			{
				Accessor.send(cnnpool, qname, pmo, mqmsg, retryTimes, retryInterval);
				return;
			}
			catch (Exception e)
			{
				ee = e;
				log.warn("fail to put:" + cnnpool.getProps() + ", qname:" + qname + ", keepQueue:"
						+ cnnpool.isKeepQueue(), e);
			}
		}
		throw ee;
	}

	public synchronized void destroy()
	{
		if (cnnpools == null) return;
		for (int i = 0; i < cnnpools.size(); i++)
			cnnpools.get(i).destory();
		cnnpools = null;
	}

	public int getAlgorithm()
	{
		return algorithm;
	}

	public void setAlgorithm(int algorithm)
	{
		this.algorithm = algorithm;
	}

	public List<MQCnnPool> getCnnpools()
	{
		return cnnpools;
	}

	public void setCnnpools(List<MQCnnPool> cnnpools)
	{
		this.cnnpools = cnnpools;
	}

	public static MQMultiChannel createInstance(String chls) throws Exception
	{
		Map map = (Map) JsonUtil.json2obj(chls);
		MQMultiChannel mchl = new MQMultiChannel();
		mchl.algorithm = Integer.parseInt(StringX.null2emptystr(map.get("algorithm"), "0"));
		mchl.cnnpools = new ArrayList<MQCnnPool>();
		List<Map> channels = (List<Map>) map.get("channels");
		for (int i = 0; i < channels.size(); i++)
			mchl.cnnpools.add(MQCnnPool.createChl(channels.get(i)));
		return mchl;
	}
}
