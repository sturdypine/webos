package spc.webos.flownode.impl;

import java.lang.reflect.Method;

import spc.webos.data.ArrayNode;
import spc.webos.data.AtomNode;
import spc.webos.data.IArrayNode;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.service.IService;

/**
 * ������call���񲢽����ݷ���
 * <reqeust><method>echainWF.getAllComments</method><arguments><class
 * >java.lang.String</class><value>122</value></arguments
 * ><arguments><class>spc.esb
 * .model.xxxVO</class><value></value></arguments></request>
 * 
 * @author chenjs
 * 
 */
public class MethodInvokeAFNode extends AbstractFNode
{
	public static String METHOD_KEY = "method";
	public static String VALUE_KEY = "value";
	public static String CLASS_KEY = "class";
	public static String ARGS_KEY = "arguments";

	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		IArrayNode args = msg.findArrayInRequest(ARGS_KEY, new ArrayNode());
		String method = msg.findAtomInRequest(METHOD_KEY, null).stringValue();
		int index = method.indexOf('.');
		Object service = IService.SERVICES_PROXY.get(method.substring(0, index));
		Method m = service.getClass().getMethod(method.substring(index + 1), getArgsClass(args));
		Object result = m.invoke(service, getArgs(args));
		msg.setInResponse(VALUE_KEY, result);
		return null;
	}

	protected Class[] getArgsClass(IArrayNode args) throws Exception
	{
		if (args.size() == 0) return null;
		Class[] clazzes = new Class[args.size()];
		for (int i = 0; i < args.size(); i++)
		{
			ICompositeNode arg = (ICompositeNode) args.get(i);
			clazzes[i] = Class.forName(arg.findAtom(CLASS_KEY, new AtomNode("java.lang.String"))
					.stringValue());
		}
		return clazzes;
	}

	protected Object[] getArgs(IArrayNode args) throws Exception
	{
		if (args.size() == 0) return null;
		Object[] objs = new Object[args.size()];
		for (int i = 0; i < args.size(); i++)
		{
			ICompositeNode arg = (ICompositeNode) args.get(i);
			objs[i] = arg2obj(arg);
		}
		return objs;
	}

	protected Object arg2obj(ICompositeNode arg) throws Exception
	{
		if (arg.getNode(VALUE_KEY) == null) return null;
		String clazz = arg.findAtom(CLASS_KEY, new AtomNode("java.lang.String")).stringValue();
		if ("java.lang.String".equalsIgnoreCase(clazz)) return arg.findAtom(VALUE_KEY, null)
				.stringValue();
		if ("java.lang.Integer".equalsIgnoreCase(clazz)) return new Integer(arg.findAtom(VALUE_KEY,
				null).stringValue());
		if ("java.lang.Long".equalsIgnoreCase(clazz)) return new Long(arg.findAtom(VALUE_KEY, null)
				.stringValue());
		if ("java.lang.Double".equalsIgnoreCase(clazz)) return new Double(arg.findAtom(VALUE_KEY,
				null).stringValue());
		if ("java.lang.Boolean".equalsIgnoreCase(clazz)) return arg.findAtom(VALUE_KEY, null)
				.booleanValue();
		if ("java.lang.bytes".equalsIgnoreCase(clazz)) return arg.findAtom(VALUE_KEY, null)
				.byteValue();
		// ʣ�µ��Ǹ��ӽڵ�����
		return arg.findComposite(VALUE_KEY, null).toObject(Class.forName(clazz));
	}
}
