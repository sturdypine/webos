package spc.webos.flownode.impl;

import java.util.Map;

import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

/**
 * ָ��һ��������������ǰ����
 * 
 * @author spc
 * 
 */
public class AssignProcessAFNode extends AbstractFNode
{
	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		msg.setInLocal(MsgLocalKey.LOCAL_JBPM_PROCESS_NAME, getProcessName(msg, cxt));
		return null;
	}

	protected String getProcessName(IMessage msg, IFlowContext cxt) throws Exception
	{
		if (!StringX.nullity(processName)) return processName;
		if (!StringX.nullity(processNameTemplate))
		{
			Map root = SystemUtil.freemarker(null, msg);
			root.put(Common.MODEL_CXT_KEY, cxt);
			return StringX.trim(SystemUtil.freemarker(processNameTemplate, root));
		}
		return null;
	}

	protected String processName;
	protected String processNameTemplate;

	public String getProcessName()
	{
		return processName;
	}

	public void setProcessName(String processName)
	{
		this.processName = processName;
	}

	public String getProcessNameTemplate()
	{
		return processNameTemplate;
	}

	public void setProcessNameTemplate(String processNameTemplate)
	{
		this.processNameTemplate = processNameTemplate;
	}
}
