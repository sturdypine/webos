package spc.webos.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import spc.webos.util.JsonUtil;

/**
 * genarated by sturdypine.chen Email: sturdypine@gmail.com description:
 */
public class FTLVO implements ValueObject
{
	public static final long serialVersionUID = 20141213L;
	// ����������Ӧ�ֶε�����
	String id; // ����
	String ftl; //
	String remark; //

	// ver
	String userCd;// �����û�
	String lastUpdTm;// ������ʱ��
	String verDt; // ���ݰ汾����
	String verStatus;// ���ݰ汾״̬
	String actionNm;// ��������

	// �ʹ�VO�����������VO����

	// �ʹ�VO�������������Sql����
	// Note: ���������Sql����ΪString, Inegter...��Java final classʱ�� ֻ��ʹ��Object����
	// ����ʱ��ֻ��ͨ��
	// Object��toString()������ʹ�á�
	public static final String TABLE = "sys_ftl";
	public static final String[] BLOB_FIELD = null;
	public static final String SEQ_NAME = "id";

	public FTLVO()
	{
	}

	public void setPrimary(String id)
	{
		this.id = id;
	}

	public String getPrimary(String delim)
	{
		StringBuffer buf = new StringBuffer();
		buf.append(this.id);
		return buf.toString();
	}

	public Map getPrimary()
	{
		Map m = new HashMap();
		m.put("id", id);
		return m;
	}

	public String getTable()
	{
		return TABLE;
	}

	public String[] getBlobField()
	{
		return BLOB_FIELD;
	}

	public String getKeyName()
	{
		return SEQ_NAME;
	}

	public Serializable getKey()
	{
		return id;
	}

	// set all properties to NULL
	public void setNULL()
	{
		this.id = null;
		this.ftl = null;
		this.remark = null;
	}

	public boolean equals(Object o)
	{
		if (this == o) return true;
		if (!(o instanceof FTLVO)) return false;
		FTLVO obj = (FTLVO) o;
		if (!id.equals(obj.id)) return false;
		if (!ftl.equals(obj.ftl)) return false;
		if (!remark.equals(obj.remark)) return false;
		return true;
	}

	// ֻ����������ɢ��
	public int hashCode()
	{
		long hashCode = getClass().hashCode();
		if (id != null) hashCode += id.hashCode();
		return (int) hashCode;
	}

	public int compareTo(Object o)
	{
		return -1;
	}

	// set all properties to default value...
	public void init()
	{
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getFtl()
	{
		return ftl;
	}

	public void setFtl(String ftl)
	{
		this.ftl = ftl;
	}

	public String getRemark()
	{
		return remark;
	}

	public void setRemark(String remark)
	{
		this.remark = remark;
	}

	public void set(FTLVO vo)
	{
		this.id = vo.id;
		this.ftl = vo.ftl;
		this.remark = vo.remark;
	}

	public static long getSerialVersionUID()
	{
		return serialVersionUID;
	}

	public StringBuffer toJson()
	{
		StringBuffer buf = new StringBuffer();
		buf.append(JsonUtil.obj2json(this));
		return buf;
	}

	public String getUserCd()
	{
		return userCd;
	}

	public void setUserCd(String userCd)
	{
		this.userCd = userCd;
	}

	public String getLastUpdTm()
	{
		return lastUpdTm;
	}

	public void setLastUpdTm(String lastUpdTm)
	{
		this.lastUpdTm = lastUpdTm;
	}

	public String getVerDt()
	{
		return verDt;
	}

	public void setVerDt(String verDt)
	{
		this.verDt = verDt;
	}

	public String getVerStatus()
	{
		return verStatus;
	}

	public void setVerStatus(String verStatus)
	{
		this.verStatus = verStatus;
	}

	public String getActionNm()
	{
		return actionNm;
	}

	public void setActionNm(String actionNm)
	{
		this.actionNm = actionNm;
	}

	public void afterLoad()
	{
		// TODO Auto-generated method stub
	}

	public void beforeLoad()
	{
		// TODO Auto-generated method stub
	}

	public void setManualSeq(Long seq)
	{

	}

	public void destory()
	{

	}

	public String toString()
	{
		StringBuffer buf = new StringBuffer(128);
		buf.append(getClass().getName() + "(serialVersionUID=" + serialVersionUID + "):");
		buf.append(toJson());
		return buf.toString();
	}

	public Object clone()
	{
		FTLVO obj = new FTLVO();
		obj.set(this);
		return obj;
	}
}
