package spc.webos.buffer;

import java.util.List;
import java.util.Map;

import spc.webos.cache.WaitWithTime;
import spc.webos.util.StringX;

/**
 * ����buffer
 * 
 * @author spc
 * 
 */
public class AliasBuffer implements IBuffer
{
	protected String name;
	protected IBuffer aliasBuf;

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public IBuffer getAliasBuf()
	{
		return aliasBuf;
	}

	public void setAliasBuf(IBuffer aliasBuf)
	{
		this.aliasBuf = aliasBuf;
	}

	public int cap()
	{
		return aliasBuf.cap();
	}

	public List getReaders()
	{
		return aliasBuf.getReaders();
	}

	public List getWriters()
	{
		return aliasBuf.getWriters();
	}

	public void init() throws Exception
	{
		if (!StringX.nullity(name))
		{
			if (BUFFERS.containsKey(name)) throw new RuntimeException(name
					+ " Buffer existed in BUFFERS"); // ��������Ѿ����ڣ�������ͬ��������һ��JVM����
			BUFFERS.put(name, this);
		}
	}

	public boolean isEmpty()
	{
		return aliasBuf.isEmpty();
	}

	public boolean isFull()
	{
		return aliasBuf.isFull();
	}

	public Object put(Object obj, long timeout)
	{
		return aliasBuf.put(obj, timeout);
	}

	public Object put(Object obj)
	{
		return aliasBuf.put(obj);
	}

	public Object put(Object obj, WaitWithTime wwt) throws TimeoutException
	{
		return aliasBuf.put(obj, wwt);
	}

	public void putFirst(Object obj)
	{
		aliasBuf.putFirst(obj);
	}

	public Object remove(long timeout)
	{
		return aliasBuf.remove(timeout);
	}

	public Object remove()
	{
		return aliasBuf.remove();
	}

	public Object remove(WaitWithTime wwt) throws TimeoutException
	{
		return aliasBuf.remove(wwt);
	}

	public List removeAll()
	{
		return aliasBuf.removeAll();
	}

	public int size()
	{
		return aliasBuf.size();
	}

	public Object[] toArray()
	{
		return aliasBuf.toArray();
	}

	public boolean changeStatus(Map param)
	{
		return aliasBuf.changeStatus(param);
	}

	public Map checkStatus(Map param)
	{
		return aliasBuf.checkStatus(param);
	}

	public void refresh() throws Exception
	{
		aliasBuf.refresh();
	}
}
