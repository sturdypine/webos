package spc.webos.buffer;

import spc.webos.constant.AppRetCode;
import spc.webos.exception.AppException;

public class TimeoutException extends AppException
{
	private static final long serialVersionUID = 1L;
	protected long timeout;

	public TimeoutException(long timeout)
	{
		super(AppRetCode.CMMN_BUF_TIMEOUT());
		this.timeout = timeout;
	}

	public long getTimeout()
	{
		return timeout;
	}
}
