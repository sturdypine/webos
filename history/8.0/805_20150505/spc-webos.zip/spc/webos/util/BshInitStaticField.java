package spc.webos.util;

import spc.webos.log.Log;

/**
 * ʹ��Bsh�ű���ʼ��ƽ̨�ڵľ�̬��Ա����
 * 
 * @author spc
 * 
 */
public class BshInitStaticField
{
	protected String script;
	protected Log log = Log.getLogger(getClass());

	public void init() throws Exception
	{
		SystemUtil.bsh(script, null);
		log.info("BshInitStaticField over...");
		if (log.isDebugEnabled()) log.debug("bsh: " + script);
	}

	public void setScript(String script)
	{
		this.script = script;
	}
}
