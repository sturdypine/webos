package spc.webos.flownode.action;

public class CreateMsgAsynCallAction extends FTLCreateMsgAsynCallAction
{
	private static final long serialVersionUID = 1L;

	public CreateMsgAsynCallAction()
	{
		fnodes = "asynESBCall";
	}
}
