package spc.webos.sim;

import org.springframework.context.ApplicationContext;

import spc.webos.data.IMessage;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.data.converter.XMLConverter;
import spc.webos.queue.QueueMessage;
import spc.webos.queue.ibmmq.QueueAccess;
import spc.webos.util.SystemUtil;

public class MQSim extends Sim
{
	QueueAccess access;
	String reqQName = "REQ";
	String repQName;
	IMessageConverter converter = XMLConverter.getInstance();

	public IMessage execute(IMessage msg, int timeout) throws Exception
	{
		String repQName = this.repQName == null ? "REP."
				+ msg.getMsg().get(IMessage.TAG_HEADER_MSG_SNDNODE).toString() + '.'
				+ msg.getMsg().get(IMessage.TAG_HEADER_MSG_SNDAPP).toString() : this.repQName;
		QueueMessage qmsg = access.execute(reqQName, repQName,
				new QueueMessage(msg, converter.serialize(msg)), timeout);
		return converter.deserialize(qmsg.buf);
	}

	public void setAccess(QueueAccess access)
	{
		this.access = access;
	}

	public void setReqQName(String reqQName)
	{
		this.reqQName = reqQName;
	}

	public void setRepQName(String repQName)
	{
		this.repQName = repQName;
	}

	public void setConverter(IMessageConverter converter)
	{
		this.converter = converter;
	}

	public MQSim()
	{
	}

	public MQSim(QueueAccess access, String reqQName, String repQName)
	{
		this.access = access;
		this.reqQName = reqQName;
		this.repQName = repQName;
	}

	public static void main(String[] args) throws Exception
	{
		ApplicationContext cxt = SystemUtil.load(new String[] { "env/context/sim.xml" });
		Sim sim = (Sim) cxt.getBean("sim");
		sim(sim, args);
	}
}
