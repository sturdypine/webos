package spc.webos.jsrmi.request;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public interface RequestWorker {
	
	public void validate(HttpServletRequest request, HttpServletResponse response) throws ValidationException;

	public void processRequest(HttpServletRequest request, HttpServletResponse response) throws IOException;

}
