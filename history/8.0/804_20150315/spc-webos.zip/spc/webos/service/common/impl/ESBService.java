package spc.webos.service.common.impl;

import spc.webos.constant.Common;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.data.Message;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.data.converter.XMLConverter2;
import spc.webos.endpoint.ESB;
import spc.webos.endpoint.Endpoint;
import spc.webos.endpoint.EndpointFactory;
import spc.webos.endpoint.Executable;
import spc.webos.service.Service;
import spc.webos.service.common.IESBService;
import spc.webos.util.StringX;

public class ESBService extends Service implements IESBService
{
	protected int timeout = 30;
	protected String charset = Common.CHARSET_UTF8;
	protected Endpoint esb = ESB.getInstance();
	protected IMessageConverter converter = XMLConverter2.getInstance();

	public ICompositeNode execute(ICompositeNode transaction) throws Exception
	{
		transaction.applyIf(ESB.getInstance().newMessage().getTransaction());
		Message reqmsg = new Message(transaction);
		String callType = reqmsg.getCallType();
		if (StringX.nullity(callType)) reqmsg.setCallType(IMessage.CALLTYP_SYN);
		Executable exe = new Executable();
		exe.request = converter.serialize(reqmsg);
		exe.timeout = timeout;
		esb.execute(exe);
		return converter.deserialize(exe.response).getTransaction();
		// IMessage repmsg = esb.execute(reqmsg, timeout);
		// return repmsg.getTransaction();
	}

	public String esb(String reqXml) throws Exception
	{
		IMessage reqmsg = converter.deserialize(reqXml.getBytes(charset));
		reqmsg.getTransaction().applyIf(ESB.getInstance().newMessage().getTransaction());
		String callType = reqmsg.getCallType();
		if (StringX.nullity(callType)) reqmsg.setCallType(IMessage.CALLTYP_SYN);
		Executable exe = new Executable();
		exe.request = converter.serialize(reqmsg);
		exe.timeout = timeout;
		esb.execute(exe);
		return new String(exe.response, charset);
		// IMessage repmsg = esb.execute(reqmsg, timeout);
		// return new String(messageConverter.serialize(repmsg), charset);
	}

	public void setTimeout(int timeout)
	{
		this.timeout = timeout;
	}

	public void setEsb(Endpoint esb)
	{
		this.esb = esb;
	}

	public void setEsb(String esb) throws Exception
	{
		this.esb = EndpointFactory.getInstance().getEndpoint(esb);
	}

	public void setConverter(IMessageConverter converter)
	{
		this.converter = converter;
	}

	public void setCharset(String charset)
	{
		this.charset = charset;
	}
}
