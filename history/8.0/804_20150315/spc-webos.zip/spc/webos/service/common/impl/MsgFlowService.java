package spc.webos.service.common.impl;

import java.util.Map;

import spc.webos.constant.Common;
import spc.webos.constant.Web;
import spc.webos.data.CompositeNode;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.data.Message;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.data.converter.XMLConverter2;
import spc.webos.flownode.MessageFlow;
import spc.webos.service.Service;
import spc.webos.service.common.IMsgFlowService;
import spc.webos.util.StringX;

public class MsgFlowService extends Service implements IMsgFlowService
{
	public IMessage gridds(Map params) throws Exception
	{
		if (log.isDebugEnabled()) log.debug("params: " + params);
		String xml = StringX.url2xml((String) params.get("XML"));
		if (log.isDebugEnabled()) log.debug("REQ XML: " + xml);
		IMessage msg = converter.deserialize(xml.getBytes(charset));
		// ��ҳģʽ
		String start = StringX.null2emptystr(params.get(Web.REQ_GRIDDS_START));
		String startPath = StringX.null2emptystr(params.get(Web.REQ_GRIDDS_START_PATH));
		if (!StringX.nullity(start) && !StringX.nullity(startPath)) msg.setInRequest(startPath,
				start);
		String limit = StringX.null2emptystr(params.get(Web.REQ_GRIDDS_LIMIT));
		String limitPath = StringX.null2emptystr(params.get(Web.REQ_GRIDDS_LIMIT_PATH));
		if (!StringX.nullity(limit) && !StringX.nullity(limitPath)) msg.setInRequest(limitPath,
				limit);
		return execute(msg);
	}

	public IMessage execute(String xml) throws Exception
	{
		if (log.isDebugEnabled()) log.debug("REQ XML: " + xml);
		return execute(converter.deserialize(xml.getBytes(charset)));
	}

	public IMessage execute(IMessage msg)
	{
		if (log.isDebugEnabled()) log.debug("REQ:" + msg.toXml(true));
		try
		{
			msgFlow.execute(msg);
		}
		catch (Throwable t)
		{
			log.error("msgflow:" + msgFlow.getName(), t);
		}
		if (log.isDebugEnabled()) log.debug("REP:" + msg.toXml(true));
		return msg;
	}

	public ICompositeNode execute(ICompositeNode transaction)
	{
		Message msg = new Message(new CompositeNode(transaction.plainMapValue()));
		execute(msg);
		return msg.getTransaction();
	}

	protected MessageFlow msgFlow;
	protected String charset = Common.CHARSET_UTF8;
	protected IMessageConverter converter = XMLConverter2.getInstance();

	public void setMsgFlow(MessageFlow msgFlow)
	{
		this.msgFlow = msgFlow;
	}

	public void setCharset(String charset)
	{
		this.charset = charset;
	}

	public void setConverter(IMessageConverter converter)
	{
		this.converter = converter;
	}
}
