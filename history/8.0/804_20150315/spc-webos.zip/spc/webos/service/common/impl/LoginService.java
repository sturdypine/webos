package spc.webos.service.common.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import spc.webos.constant.AppRetCode;
import spc.webos.exception.AppException;
import spc.webos.model.MenuVO;
import spc.webos.model.RoleVO;
import spc.webos.model.UserVO;
import spc.webos.persistence.IPersistence;
import spc.webos.service.Service;
import spc.webos.service.common.ILoginService;
import spc.webos.util.BeanPropertyUtil;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;
import spc.webos.web.common.ISessionUserInfo;
import spc.webos.web.common.SessionUserInfo;

public class LoginService extends Service implements ILoginService
{
	protected Map onlineUser = new HashMap();
	protected boolean pwdMD5; // �������MD5�㷨�洢
	protected boolean singleLogin; // �Ƿ񵥵��¼
	protected String menuTailWhere;
	static LoginService LS = new LoginService();

	public Map getOnlineUser()
	{
		return onlineUser;
	}

	public List onlineUser(Map params)
	{
		int start = Integer.parseInt(StringX.null2emptystr(params.get("start"), "0"));
		int limit = Integer.parseInt(StringX.null2emptystr(params.get("limit"), "10000000"));
		SimpleDateFormat df = new SimpleDateFormat(SystemUtil.DF_ALL19);
		Iterator users = onlineUser.values().iterator();
		List onlineUsers = new ArrayList();
		int cursor = -1;
		while (users.hasNext())
		{
			cursor++;
			if (cursor < start) continue;
			ISessionUserInfo sui = (ISessionUserInfo) users.next();
			Map user = new HashMap();
			BeanPropertyUtil.bean2map(sui.getUser(), user);
			user.put("loginDt", df.format(sui.getLoginDt()));
			user.put("loginIP", sui.getLoginIP());
			user.put("lastVisitDt", df.format(sui.getLastVisitDt()));
			onlineUsers.add(user);
			if (start + limit < cursor) break;
		}
		if (log.isInfoEnabled()) log.info("number of online users is : " + onlineUsers.size());
		return onlineUsers;
	}

	public boolean forceLogout(String userCd)
	{
		ISessionUserInfo oldsui = (ISessionUserInfo) onlineUser.get(userCd);
		if (oldsui == null) return false;
		oldsui.getSession().invalidate();
		return true;
	}

	public void register(ISessionUserInfo sui)
	{
		if (!singleLogin) return;
		String userCd = sui.getUserCode();
		ISessionUserInfo oldsui = (ISessionUserInfo) onlineUser.get(userCd);
		if (log.isInfoEnabled()) log.info("online users:" + onlineUser.size() + ", login:"
				+ (oldsui != null));
		if (oldsui != null)
		{ // �û��Ѿ���¼���Ƿ��쳣���õ�¼���������ϴε�¼����ϢʧЧ
			log.warn(sui.getUserCode() + " has login...");
			try
			{
				if (oldsui.getSession() != null) oldsui.getSession().invalidate();
			}
			catch (Exception e)
			{
			}
			onlineUser.remove(userCd);
		}
		onlineUser.put(userCd, sui);
		sui.getSession().setAttribute(ISessionUserInfo.ALL_ONLINE_USER_KEY, onlineUser);
	}

	public boolean isTimeout()
	{
		return ISessionUserInfo.SUI.get() == null;
	}

	public Map getServerInfo()
	{
		Map params = new HashMap();
		params.put("timeout", ISessionUserInfo.SUI.get() == null);
		params.put("sysdt", SystemUtil.getInstance().getCurrentDate(SystemUtil.DF_APP8));
		return params;
	}

	public synchronized void logout()
	{
		log.info("logout, online users:" + onlineUser.size());
		try
		{
			ISessionUserInfo sui = (ISessionUserInfo) ISessionUserInfo.SUI.get();
			if (sui == null) return;
			onlineUser.remove(sui.getUserCode());
			sui.getSession().invalidate();
			if (log.isInfoEnabled()) log.info(sui.getUserCode() + " logout...");
		}
		catch (Exception e)
		{
			log.error("logout", e);
		}
	}

	public synchronized void login(String user, String pwd, String verifyCode)
	{
		if (log.isInfoEnabled()) log.info("login:" + user + ", " + verifyCode);
		SessionUserInfo sui = (SessionUserInfo) ISessionUserInfo.SUI.get();

		UserVO userVO = new UserVO();
		userVO.setCode(user);
		userVO = (UserVO) persistence.find(userVO);
		String password = pwdMD5 ? StringX.md5(pwd.getBytes()) : pwd;
		if (userVO == null || !userVO.getPwd().equals(password)) throw new AppException(
				AppRetCode.CMMN_PWD_ERR(), new Object[] { user });
		userVO.setPwd(null); // ��������Ϊnull
		sui.setRole(getUserRole(userVO));
		sui.setUser(userVO);
		register(sui);
	}

	protected List getUserRole(UserVO userVO)
	{
		String roleId = userVO.getRoleId();
		List roles = StringX.split2list(roleId, StringX.COMMA);
		List menus = new ArrayList();
		for (int i = 0; i < roles.size(); i++)
		{
			RoleVO roleVO = new RoleVO();
			roleVO.setId((String) roles.get(i));
			roleVO = (RoleVO) persistence.find(roleVO);
			if (roleVO == null) continue;
			List menu = StringX.split2list(roleVO.getMenu(), StringX.COMMA);
			for (int j = 0; menu != null && j < menu.size(); j++)
				if (!menus.contains(menu.get(j))) menus.add(menu.get(j));
		}
		return menus;
	}

	public List getMenus()
	{
		SessionUserInfo sui = (SessionUserInfo) ISessionUserInfo.SUI.get();
		if (log.isInfoEnabled()) log.info("menus: " + sui.getRole());
		String menuId = StringX.join(
				(String[]) sui.getRole().toArray(new String[sui.getRole().size()]), "','");
		Map params = new HashMap();
		params.put(IPersistence.SELECT_ATTACH_TAIL_KEY, " and classname is not null and id in('"
				+ menuId + "') "
				+ (StringX.nullity(menuTailWhere) ? StringX.EMPTY_STRING : menuTailWhere)
				+ " order by id"); // oracle ����ʹ�� classname <>''
		// 2010-7-16
		return (List) persistence.get(new MenuVO(), params);
	}

	public int update(UserVO user)
	{
		return update(user, null);
	}

	public int update(UserVO user, String oldPwd)
	{
		SessionUserInfo sui = (SessionUserInfo) ISessionUserInfo.SUI.get();
		if (sui == null)
		{
			log.warn("session is over!!!");
			return 0;
		}
		UserVO sessionUser = (UserVO) sui.getUser();
		// added by chenjs 2012-02-18 ֻ���޸ĵ�ǰ�û���Ϣ
		user.setCode(sessionUser.getCode());
		if (!StringX.nullity(oldPwd) && !StringX.nullity(user.getPwd()))
		{ // ��Ҫ�޸�����, �ȿ�ԭ�����Ƿ�ƥ��
			if (pwdMD5)
			{
				oldPwd = StringX.md5(oldPwd.getBytes());
				user.setPwd(StringX.md5(user.getPwd().getBytes()));
			}
			UserVO oldUser = (UserVO) persistence.find(new UserVO(sessionUser.getCode()));
			if (!oldUser.getPwd().equals(oldPwd)) throw new AppException(AppRetCode.CMMN_PWD_ERR);
		}
		else user.setPwd(null); // �����޸�����
		return persistence.update(user);
	}

	public int insert(UserVO user)
	{
		if (pwdMD5 && !StringX.nullity(user.getPwd())) user.setPwd(StringX.md5(user.getPwd()
				.getBytes()));
		return persistence.insert(user);
	}

	public void setPwdMD5(boolean pwdMD5)
	{
		this.pwdMD5 = pwdMD5;
	}

	public void setSingleLogin(boolean singleLogin)
	{
		this.singleLogin = singleLogin;
	}

	public LoginService()
	{
	}

	public static LoginService getInstance()
	{
		return LS;
	}

	public void setMenuTailWhere(String menuTailWhere)
	{
		this.menuTailWhere = menuTailWhere;
	}
}
