package spc.webos.jsrmi.service.defaults;

import spc.webos.jsrmi.service.NoSuchServiceException;
import spc.webos.jsrmi.service.ServiceCreationFailException;
import spc.webos.jsrmi.service.ServiceFactory;

public class DefaultServiceFactory implements ServiceFactory {
	
	/**
	 * Get the service instance. serviceName indentified by class name
	 * 
	 */
	public Object getService(String serviceId, String serviceName) 
						throws NoSuchServiceException, 
						ServiceCreationFailException {
		String serviceClass = serviceName;
		Object instance = null;
		try {
			instance = Class.forName(serviceClass).newInstance();
		} catch (InstantiationException e) {
			e.printStackTrace();
			throw new ServiceCreationFailException(e);
		} catch (IllegalAccessException e) {
			e.printStackTrace();
			throw new ServiceCreationFailException(e);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw new NoSuchServiceException(e);
		}
		
		return instance;
	}
	
}
