package spc.webos.jsrmi.service;

import java.io.IOException;
import java.io.InputStream;

public class JsrmiInputStream extends InputStream
{
	InputStream is;
	StringBuffer buf;

	public JsrmiInputStream(InputStream is)
	{
		this.is = is;
		buf = new StringBuffer();
	}

	public JsrmiInputStream(InputStream is, StringBuffer buf)
	{
		this.is = is;
		this.buf = buf;
	}

	public int read() throws IOException
	{
		byte b = (byte) is.read();
		buf.append((char) b);
		return b;
	}

	public StringBuffer getContent()
	{
		return buf;
	}
}
