package spc.webos.jsrmi.protocal.converters.collection;

import java.util.Date;

import spc.webos.jsrmi.protocal.ProtocalTag;
import spc.webos.jsrmi.protocal.converters.Converter;
import spc.webos.jsrmi.protocal.io.MarshallingContext;
import spc.webos.jsrmi.protocal.io.StreamReader;
import spc.webos.jsrmi.protocal.io.StreamWriter;
import spc.webos.jsrmi.protocal.io.UnmarshallingContext;
import spc.webos.jsrmi.protocal.util.PrimitiveTypeUtil;

public class ArrayConverter extends AbstractListConverter implements Converter {

	public boolean canConvert(Class type) {
		if (type == null)
			return false;

		return type.isArray();
	}
	
	public void marshalObject(Object value, MarshallingContext context, StreamWriter streamWriter) {
		Object[] array = (Object[]) PrimitiveTypeUtil.toWrapperArrayIfNeeded(value);
		writeListHeader(streamWriter, getArrayType(value.getClass()), array.length);
		for (int i = 0; i < array.length; i++) {
			context.convertAnother(array[i]);
		}
		streamWriter.endNode();
	}
	
	public Object unmarshal(StreamReader reader, UnmarshallingContext unmarshallingContext) {
		throw new UnsupportedOperationException("the CollectionConverter has done it already");
	}

	private String getArrayType(Class clazz) {
		if (clazz.isArray())
			return '[' + getArrayType(clazz.getComponentType());

		String name = clazz.getName();

		if (clazz.equals(String.class))
			return ProtocalTag.TAG_STRING;
		else if (clazz.equals(Object.class))
			return ProtocalTag.TAG_MAP;
		else if (clazz.equals(Date.class))
			return ProtocalTag.TAG_DATE;
		else if (clazz.equals(short.class) || clazz.equals(byte.class) 
				|| clazz.equals(Short.class) || clazz.equals(Byte.class) 
				|| clazz.equals(Integer.class)) 
			return ProtocalTag.TAG_INT; 
		else if (clazz.equals(Long.class)) 
			return ProtocalTag.TAG_LONG;
		else if (clazz.equals(float.class) || clazz.equals(Float.class)
				|| clazz.equals(double.class) || clazz.equals(Double.class)) 
			return ProtocalTag.TAG_DOUBLE; 
		else if (clazz.equals(Boolean.class) || clazz.equals(boolean.class)) 
			return ProtocalTag.TAG_BOOLEAN;
		
		return name;
	}

}
