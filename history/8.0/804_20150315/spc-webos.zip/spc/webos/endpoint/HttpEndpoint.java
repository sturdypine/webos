package spc.webos.endpoint;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.InputStreamRequestEntity;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;

import spc.webos.constant.AppRetCode;
import spc.webos.exception.AppException;
import spc.webos.log.Log;
import spc.webos.util.FileUtil;
import spc.webos.util.StringX;

public class HttpEndpoint implements Endpoint
{
	public HttpEndpoint()
	{
	}

	public HttpEndpoint(String url)
	{
		this.url = url;
	}

	public void execute(Executable exe) throws Exception
	{
		long start = 0;
		if (log.isInfoEnabled())
		{
			log.info("HTTP corId:" + exe.getCorrelationID() + ", timeout:" + exe.getTimeout()
					+ ",url:" + url + ", requestbytes:"
					+ (exe.getRequest() == null ? ")" : exe.getRequest().length));
			start = System.currentTimeMillis();
		}
		int statusCode = -1;
		HttpClient client = new HttpClient();
		PostMethod pm = new PostMethod(url);
		pm.setRequestHeader("Connection", "Keep-Alive");
		client.getHttpConnectionManager().getParams().setConnectionTimeout(5000);
		// added by chenjs 2013-03--25�� ��webservice�п�����Ҫ��дsoapaction
		if (exe.reqHttpHeaders != null && exe.reqHttpHeaders.size() > 0)
		{
			Iterator<String> keys = exe.reqHttpHeaders.keySet().iterator();
			while (keys.hasNext())
			{
				String key = keys.next();
				pm.setRequestHeader(key, exe.reqHttpHeaders.get(key));
			}
		}
		try
		{
			if (exe.getRequest() != null && exe.getRequest().length > 0)
			{
				RequestEntity entity = new InputStreamRequestEntity(new ByteArrayInputStream(
						exe.getRequest()));
				pm.setRequestEntity(entity);
			}

			exe.cnnSnd = true; // httpЭ��������ζ���ɹ�
			statusCode = client.executeMethod(pm);
			if (statusCode != HttpStatus.SC_OK)
			{ // net fail...
				log.error("http err:[[" + url + "]], code:" + statusCode);
				throw new AppException(AppRetCode.PROTOCOL_HTTP(), new Object[] { new Integer(
						statusCode) });
			}
			// ������Ӧ��Ϣ
			InputStream is = pm.getResponseBodyAsStream();
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			FileUtil.is2os(is, baos, false, false);
			byte[] repbuf = baos.toByteArray();
			if (log.isInfoEnabled()) log.info("rep from server:: len:" + repbuf.length + ", cost:"
					+ (System.currentTimeMillis() - start));
			if (log.isDebugEnabled()) log.debug("rep buf:" + new String(repbuf));
			exe.setResponse(repbuf);
		}
		catch (IOException ioe)
		{
			log.error("http err:" + url + ", code:" + statusCode + ", reqbytes base64: "
					+ (exe.request == null ? "" : new String(StringX.encodeBase64(exe.request))),
					ioe);
			throw new AppException(AppRetCode.PROTOCOL_HTTP(), new Object[] { url,
					new Integer(statusCode) });
		}
		finally
		{
			try
			{
				if (pm != null) pm.releaseConnection();
				pm = null;
			}
			catch (Exception e)
			{
			}
		}
	}

	public void init() throws Exception
	{
	}

	public void setUrl(String url)
	{
		this.url = url;
	}

	public void destory()
	{
	}

	public Endpoint clone() throws CloneNotSupportedException
	{
		HttpEndpoint he = new HttpEndpoint();
		he.url = url;
		return he;
	}

	public void setLocation(String location) throws Exception
	{
		this.url = location;
	}

	protected String url; // ��̨url��ַ
	protected Log log = Log.getLogger(getClass());
}
