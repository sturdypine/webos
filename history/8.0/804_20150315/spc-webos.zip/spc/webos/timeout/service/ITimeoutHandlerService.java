package spc.webos.timeout.service;

public interface ITimeoutHandlerService
{
	void doTimeout(Timeout timeout) throws Exception;
}
