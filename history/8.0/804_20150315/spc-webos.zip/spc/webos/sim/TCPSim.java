package spc.webos.sim;

import spc.webos.data.IMessage;
import spc.webos.data.converter.XMLConverter2;
import spc.webos.endpoint.Endpoint;
import spc.webos.endpoint.EndpointFactory;
import spc.webos.endpoint.Executable;

public class TCPSim extends Sim
{
	public IMessage execute(IMessage msg, int timeout) throws Exception
	{
		Executable exe = new Executable();
		exe.request = XMLConverter2.getInstance().serialize(msg);
		exe.timeout = timeout;
		Endpoint endpoint = EndpointFactory.getInstance().getEndpoint(args[3]);
		endpoint.execute(exe);
		return null;
	}

	public static void main(String[] args) throws Exception
	{
		sim(new TCPSim(), args);
	}
}
