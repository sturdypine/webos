package spc.webos.data;

import spc.webos.data.converter.IMessageConverter;
import spc.webos.data.converter.XMLConverter;
import spc.webos.util.StringX;

/**
 * �󸽼�����ϵͳ�е���Ϣͷ
 * 
 * @author spc
 * 
 */
public class BlobMsgHeader extends FixedMessage implements IBlobMsgHeader
{
	private static final long serialVersionUID = 1L;
	public static final String[] FIELDS = { "headLen", "fixLen", "msgCd", "sndMbrCd", "sndAppCd",
			"sndDt", "sndTm", "seqNb", "rcvMbrCd", "rcvAppCd", "callTyp", "refCallTyp", "refMsgCd",
			"refSndMbrCd", "refSndAppCd", "refSndDt", "refSeqNb", "gzip", "sliceNo", "last",
			"fileId", "fileNo" };
	public static final int[] LEN = { 8, 3, 16, 16, 8, 8, 9, 32, 16, 8, 5, 5, 16, 16, 8, 8, 32, 1,
			6, 1, 32, 3 };
	public static final int[] OFFSET = { 0, 8, 11, 27, 43, 51, 59, 68, 100, 116, 124, 129, 134,
			150, 166, 174, 182, 214, 215, 221, 222, 254, 257 };
	public static final int[] TYPE = { TYPE_I, TYPE_I, TYPE_S, TYPE_S, TYPE_S, TYPE_S, TYPE_S,
			TYPE_S, TYPE_S, TYPE_S, TYPE_S, TYPE_S, TYPE_S, TYPE_S, TYPE_S, TYPE_S, TYPE_S, TYPE_S,
			TYPE_I, TYPE_S, TYPE_S, TYPE_I };
	public static final int LENGTH = 257;
	public static final int FIXLEN = 257;
	public final static String YES = "1";
	public final static String NO = "0";
	public static final String EXT_KEY = "blob";
	public static final String[] BLOB_KEYS = { "headLen", "fixLen", "gzip", "sliceNo", "last",
			"fileId", "fileNo" };

	protected byte[] xml;

	public BlobMsgHeader()
	{
		msg = new byte[LENGTH];
		init();
		setLast(NO);
		setHeadLen(LENGTH);
		setFixLen(FIXLEN);
		setGzip(NO);
		setFileNo(0);
		setSliceNo(0);
	}

	public BlobMsgHeader(byte[] msg)
	{
		this.msg = msg;
	}

	public BlobMsgHeader(ICompositeNode cnode)
	{
		msg = new byte[LENGTH];
		set(cnode);
		setHeadLen(LENGTH);
	}

	public String[] fields()
	{
		return FIELDS;
	}

	public int[] len()
	{
		return LEN;
	}

	public int length()
	{
		return LENGTH;
	}

	public int[] offset()
	{
		return OFFSET;
	}

	public int[] type()
	{
		return TYPE;
	}

	public String getSndNodeApp()
	{
		return getSndMbrCd() + getSndAppCd();
	}

	public String getRefSndNodeApp()
	{
		return getRefSndMbrCd() + getRefSndAppCd();
	}

	public String getRcvNodeApp()
	{
		return getRcvMbrCd() + getRcvAppCd();
	}

	public String getMsgSn()
	{
		return getSndNodeApp() + '-' + getSndDt() + '-' + getSeqNb();
	}

	public String getRefMsgSn()
	{
		return getRefSndNodeApp() + '-' + getRefSndDt() + '-' + getRefSeqNb();
	}

	/**
	 * ��һ��ȫ�µı��ı��һ�����������Ʊ���ͷ
	 * 
	 * @param msg
	 * @param converter
	 * @throws Exception
	 */
	public void setMessage(IMessage msg, IMessageConverter converter) throws Exception
	{
		ICompositeNode cnode = (ICompositeNode) msg.findInHeaderExt(BlobMsgHeader.EXT_KEY);
		if (cnode == null) cnode = new CompositeNode();
		cnode.set(msg.getMsg());
		set(cnode);
		setXml(converter.serialize(msg));
	}

	public IMessage toMessage() throws Exception
	{
		return toMessage(XMLConverter.getInstance());
	}

	public IMessage toMessage(IMessageConverter converter) throws Exception
	{
		byte[] xml = getXml();
		IMessage msg = xml == null ? new Message() : converter.deserialize(xml);
		msg.init();
		String msgCd = getMsgCd();
		ICompositeNode mesg = msg.getMsg();
		mesg.set(IMessage.TAG_HEADER_MSG_RCVAPP, getRcvAppCd());
		if (!StringX.nullity(getRcvMbrCd())) mesg.set(IMessage.TAG_HEADER_MSG_RCVNODE,
				getRcvMbrCd());
		mesg.set(IMessage.TAG_HEADER_MSG_CD, msgCd);
		mesg.set(IMessage.TAG_HEADER_CALLTYPE, getCallTyp());
		mesg.set(IMessage.TAG_HEADER_MSG_SN, getSeqNb());
		if (!StringX.nullity(getSndMbrCd())) mesg.set(IMessage.TAG_HEADER_MSG_SNDNODE,
				getSndMbrCd());
		mesg.set(IMessage.TAG_HEADER_MSG_SNDAPP, getSndAppCd());
		mesg.set(IMessage.TAG_SNDDT, getSndDt());
		mesg.set(IMessage.TAG_SNDTM, getSndTm());
		msg.setMsg(mesg);
		if (StringX.nullity(msg.getVersion())) msg.setVersion("1.0");
		// if (!msg.isRequestMsg())
		// modified by chenjs 2011-09-24 ����Ӧ���׼�޸��ˣ����Ա��ı��Ϊ�жϱ�׼
		if (!StringX.nullity(getRefSeqNb()))
		{
			mesg.set(IMessage.TAG_HEADER_MSG_REFMSGCD, getRefMsgCd());
			mesg.set(IMessage.TAG_HEADER_MSG_REFCALLTYP, getRefCallTyp());
			mesg.set(IMessage.TAG_HEADER_MSG_REFSNDSN, getRefSeqNb());
			mesg.set(IMessage.TAG_HEADER_MSG_REFSNDNODE, getRefSndMbrCd());
			mesg.set(IMessage.TAG_HEADER_MSG_REFSNDAPP, getRefSndAppCd());
			mesg.set(IMessage.TAG_HEADER_MSG_REFSNDDT, getRefSndDt());
		}

		ICompositeNode extBlob = toCNode(null);
		extBlob.removeNotIn(BLOB_KEYS);
		msg.setInHeaderExt(BlobMsgHeader.EXT_KEY, extBlob);
		// if (msg.isRequestMsg()) msg.setInRequest(BlobMsgHeader.EXT_KEY,
		// toCNode(null));
		// else msg.setInResponse(BlobMsgHeader.EXT_KEY, toCNode(null));
		return msg;
	}

	public IBlobMsgHeader newInstance()
	{
		return new BlobMsgHeader();
	}

	public byte[] getXml()
	{
		if (xml != null) return xml;
		int fixLen = getFixLen();
		int xmlLen = getHeadLen() - fixLen;
		if (xmlLen <= 0) return null;
		xml = read(fixLen, xmlLen);
		return xml;
	}

	public void setXml(byte[] xml)
	{
		this.xml = xml;
	}

	/**
	 * 
	 * @param containXml
	 *            �Ƿ���XML����
	 * @return
	 */
	public byte[] toMsg(boolean containXml)
	{
		if (!containXml)
		{ // ������xml
			if (msg.length <= FIXLEN) return msg;
			byte[] buf = new byte[FIXLEN];
			System.arraycopy(msg, 0, buf, 0, FIXLEN);
			write(buf, 0, OFFSET[0], LEN[0], StringX.int2str(String.valueOf(FIXLEN), LEN[0])
					.getBytes()); // �������ó���
			return buf;
		}
		if (xml == null || xml.length == 0) return msg;
		byte[] buf = new byte[FIXLEN + xml.length];
		System.arraycopy(msg, 0, buf, 0, FIXLEN);
		System.arraycopy(xml, 0, buf, FIXLEN, xml.length);
		this.msg = buf;
		setHeadLen(buf.length);
		xml = null;
		return msg;
	}

	public byte[] toMsg()
	{
		return toMsg(true);
	}

	/**
	 * ��ǰ����������Ϣ�Ƿ��������������Ƹ���
	 * 
	 * @return
	 */
	public boolean containBlob()
	{
		return msg.length > getHeadLen();
	}

	public boolean containXML()
	{
		return getHeadLen() > getFixLen() || xml != null;
	}

	// ������xml���Ĳ���
	// public ICompositeNode toCNode(ICompositeNode cnode)
	// {
	// CompositeNode cn = new CompositeNode();
	// ext = getExt();
	// if (ext != null && ext.size() > 0) cn.set(ext);
	// ICompositeNode blobext = super.toCNode(cnode);
	// cn.set(EXT_KEY, blobext);
	// return cn;
	// }
	//
	// public void set(ICompositeNode cnode)
	// {
	// ICompositeNode blobext = cnode.findComposite(EXT_KEY, null);
	// if (blobext != null) super.set(cnode);
	//
	// CompositeNode ext = new CompositeNode(cnode);
	// ext.remove(EXT_KEY);
	// setExt(ext);
	// }

	// GEN METHOD
	public int getHeadLen()
	{
		return Integer.parseInt(readStr(OFFSET[0], LEN[0]).trim());
	}

	public void setHeadLen(int headLen)
	{
		writeStr(OFFSET[0], LEN[0], StringX.int2str(String.valueOf(headLen), LEN[0]));
	}

	public int getFixLen()
	{
		return Integer.parseInt(readStr(OFFSET[1], LEN[1]).trim());
	}

	public void setFixLen(int fixLen)
	{
		writeStr(OFFSET[1], LEN[1], StringX.int2str(String.valueOf(fixLen), LEN[1]));
	}

	public String getMsgCd()
	{
		return readStr(OFFSET[2], LEN[2]);
	}

	public void setMsgCd(String msgCd)
	{
		writeStr(OFFSET[2], LEN[2], msgCd);
	}

	public String getSndMbrCd()
	{
		return readStr(OFFSET[3], LEN[3]);
	}

	public void setSndMbrCd(String sndMbrCd)
	{
		writeStr(OFFSET[3], LEN[3], sndMbrCd);
	}

	public String getSndAppCd()
	{
		return readStr(OFFSET[4], LEN[4]);
	}

	public void setSndAppCd(String sndAppCd)
	{
		writeStr(OFFSET[4], LEN[4], sndAppCd);
	}

	public String getSndDt()
	{
		return readStr(OFFSET[5], LEN[5]);
	}

	public void setSndDt(String sndDt)
	{
		writeStr(OFFSET[5], LEN[5], sndDt);
	}

	public String getSndTm()
	{
		return readStr(OFFSET[6], LEN[6]);
	}

	public void setSndTm(String sndTm)
	{
		writeStr(OFFSET[6], LEN[6], sndTm);
	}

	public String getSeqNb()
	{
		return readStr(OFFSET[7], LEN[7]);
	}

	public void setSeqNb(String seqNb)
	{
		writeStr(OFFSET[7], LEN[7], seqNb);
	}

	public String getRcvMbrCd()
	{
		return readStr(OFFSET[8], LEN[8]);
	}

	public void setRcvMbrCd(String rcvMbrCd)
	{
		writeStr(OFFSET[8], LEN[8], rcvMbrCd);
	}

	public String getRcvAppCd()
	{
		return readStr(OFFSET[9], LEN[9]);
	}

	public void setRcvAppCd(String rcvAppCd)
	{
		writeStr(OFFSET[9], LEN[9], rcvAppCd);
	}

	public String getCallTyp()
	{
		return readStr(OFFSET[10], LEN[10]);
	}

	public void setCallTyp(String callTyp)
	{
		writeStr(OFFSET[10], LEN[10], callTyp);
	}

	public String getRefCallTyp()
	{
		return readStr(OFFSET[11], LEN[11]);
	}

	public void setRefCallTyp(String refCallTyp)
	{
		writeStr(OFFSET[11], LEN[11], refCallTyp);
	}

	public String getRefMsgCd()
	{
		return readStr(OFFSET[12], LEN[12]);
	}

	public void setRefMsgCd(String refMsgCd)
	{
		writeStr(OFFSET[12], LEN[12], refMsgCd);
	}

	public String getRefSndMbrCd()
	{
		return readStr(OFFSET[13], LEN[13]);
	}

	public void setRefSndMbrCd(String refSndMbrCd)
	{
		writeStr(OFFSET[13], LEN[13], refSndMbrCd);
	}

	public String getRefSndAppCd()
	{
		return readStr(OFFSET[14], LEN[14]);
	}

	public void setRefSndAppCd(String refSndAppCd)
	{
		writeStr(OFFSET[14], LEN[14], refSndAppCd);
	}

	public String getRefSndDt()
	{
		return readStr(OFFSET[15], LEN[15]);
	}

	public void setRefSndDt(String refSndDt)
	{
		writeStr(OFFSET[15], LEN[15], refSndDt);
	}

	public String getRefSeqNb()
	{
		return readStr(OFFSET[16], LEN[16]);
	}

	public void setRefSeqNb(String refSeqNb)
	{
		writeStr(OFFSET[16], LEN[16], refSeqNb);
	}

	public String getGzip()
	{
		return readStr(OFFSET[17], LEN[17]);
	}

	public void setGzip(String gzip)
	{
		writeStr(OFFSET[17], LEN[17], gzip);
	}

	public int getSliceNo()
	{
		return Integer.parseInt(readStr(OFFSET[18], LEN[18]));
	}

	public void setSliceNo(int sliceNo)
	{
		writeStr(OFFSET[18], LEN[18], StringX.int2str(String.valueOf(sliceNo), LEN[18]));
	}

	public boolean isLast()
	{
		return YES.equals(readStr(OFFSET[19], LEN[19]));
	}

	public String getLast()
	{
		return readStr(OFFSET[19], LEN[19]);
	}

	public void setLast(String last)
	{
		writeStr(OFFSET[19], LEN[19], last);
	}

	public String getFileId()
	{
		return readStr(OFFSET[20], LEN[20]);
	}

	public void setFileId(String fileId)
	{
		writeStr(OFFSET[20], LEN[20], fileId);
	}

	public int getFileNo()
	{
		return Integer.parseInt(readStr(OFFSET[21], LEN[21]).trim());
	}

	public void setFileNo(int fileNo)
	{
		writeStr(OFFSET[21], LEN[21], StringX.int2str(String.valueOf(fileNo), LEN[21]));
	}
}