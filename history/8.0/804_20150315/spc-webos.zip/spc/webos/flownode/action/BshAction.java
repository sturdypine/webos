package spc.webos.flownode.action;

import spc.webos.cache.Map2Cache;
import spc.webos.data.IMessage;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.StringX;
import bsh.Interpreter;

public class BshAction extends AbstractAction
{
	private static final long serialVersionUID = 1L;

	public void execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		if (log.isInfoEnabled()) log.info("BshAction: " + name);
		Interpreter i = getInterpreter(bsh);
		synchronized (i)
		{ // 702_20140121��֤�̰߳�ȫ
			i.set("msg", msg);
			i.eval("fun(msg);");
		}
	}

	protected String bsh;
	static Map2Cache interpreters = new Map2Cache(24 * 3600, 500);

	public static synchronized Interpreter getInterpreter(String script) throws Exception
	{
		Interpreter i = (Interpreter) interpreters.get(script);
		if (i != null) return i;
		i = new Interpreter();
		i.eval("import spc.webos.data.IMessage;void fun(IMessage msg){" + script + "}");
		interpreters.put(script, i);
		return i;
	}

	public String getBsh()
	{
		return bsh;
	}

	public void setBsh(String bsh)
	{
		this.bsh = StringX.removeBshAnnotation(bsh);
	}
}
