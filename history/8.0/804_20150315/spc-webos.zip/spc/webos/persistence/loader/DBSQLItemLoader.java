package spc.webos.persistence.loader;

import java.io.StringReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import spc.webos.constant.Common;
import spc.webos.log.Log;
import spc.webos.model.SQLVO;
import spc.webos.persistence.Persistence;
import spc.webos.persistence.SQLItem;
import spc.webos.util.StringX;
import freemarker.template.Template;

/**
 * 753, ֧�������ݿ�������SQL
 * 
 * @author chenjs
 * 
 */
public class DBSQLItemLoader
{
	static Log log = Log.getLogger(DBSQLItemLoader.class);

	public static void loadSQLItem(Map sqlMap, boolean productMode) throws Exception
	{
		List items = null;
		try
		{
			items = Persistence.getInstance().get(new SQLVO());
		}
		catch (Exception e)
		{
			log.info("fail to load SQLItem in DB:" + e);
		}
		if (items == null) return;
		log.info("SQLItem in DB:" + items.size());
		for (int i = 0; i < items.size(); i++)
		{
			SQLVO vo = (SQLVO) items.get(i);
			addSQLItem2Map(parseItem(new SQLItem(), vo), vo, sqlMap);
		}
	}

	public static void addSQLItem2Map(SQLItem item, SQLVO vo, Map sqlMap)
	{
		Map module = (Map) sqlMap.get(vo.getMdl().trim());
		if (module == null) module = new HashMap();
		module.put(vo.getId().trim(), item);
		sqlMap.put(vo.getMdl().trim(), module);
	}

	public static SQLItem parseItem(SQLItem item, SQLVO vo) throws Exception
	{
		item.type = (short) ((int) vo.getType());
		item.jt = vo.getDs(); // ��ȡjt

		if (item.type == SQLItem.SELECT)
		{ // select
			item.resultClass = StringX.null2emptystr(vo.getResultClass(),
					SQLItem.DEFAULT_RESULT_CLASS);

			// �Ƿ���ֶ�����Сд����
			// String columns = ele.attributeValue("column");
			// if (!StringX.nullity(columns))
			// {
			// item.column = new HashMap();
			// String[] cols = columns.split(",");
			// for (int i = 0; i < cols.length; i++)
			// item.column.put(cols[i].toLowerCase(), cols[i]);
			// }

			// һ��SQL�������洦��, �����Ҫ������Service���Լ�ʵ��.
			// item.cacheBeanName = ele.attributeValue("cacheBeanName", null);
			item.firstRowOnly = Common.YES.equals(vo.getFirstRowOnly());
		}
		item.prepared = Common.YES.equals(vo.getPrepared());
		item.procedure = Common.YES.equals(vo.getProc());
		item.sql = SQLItemXmlLoader.formatSQL(vo.getText());
		item.t = new Template(vo.getMdl() + '.' + vo.getId(), new StringReader(item.sql), null);
		return item;
	}
}
