package spc.webos.util.http;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import spc.webos.util.StringX;

public class HTTPHeader
{
	public String method;
	public String uri;
	public String protocol;
	public int statusCode; // Ӧ��״̬��
	public String statusDesc; // Ӧ��״̬����
	public Map params = new HashMap();

	public HTTPHeader()
	{
	}

	public HTTPHeader(Map params)
	{
		this.params = params;
	}

	public String params2str()
	{
		if (params == null || params.size() == 0) return StringX.EMPTY_STRING;
		StringBuffer buf = new StringBuffer();
		Iterator keys = params.keySet().iterator();
		while (keys.hasNext())
		{
			String key = keys.next().toString();
			buf.append(key + ":" + params.get(key) + "\r\n");
		}
		return buf.toString();
	}

	public String toString()
	{
		StringBuffer buf = new StringBuffer();
		buf.append(method + " " + uri + " " + protocol + "\r\n");
		buf.append(params2str());
		buf.append("\r\n");
		return buf.toString();
	}
}
