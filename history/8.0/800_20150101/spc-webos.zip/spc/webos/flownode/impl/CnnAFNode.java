package spc.webos.flownode.impl;

import spc.webos.data.IMessage;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.endpoint.Endpoint;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;

public class CnnAFNode extends AbstractFNode
{
	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		return null;
	}

	protected Endpoint endpoint;
	protected IMessageConverter messageConverter;

	public void setEndpoint(Endpoint endpoint)
	{
		this.endpoint = endpoint;
	}

	public void setMessageConverter(IMessageConverter messageConverter)
	{
		this.messageConverter = messageConverter;
	}
}
