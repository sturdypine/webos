package spc.webos.buffer;

import spc.webos.cache.WaitWithTime;

public class CommonWaitWithTime extends WaitWithTime
{
	int rw;
	public static final int READ = 0;
	public static final int WRITE = 1;

	public CommonWaitWithTime(int rw)
	{
		this.rw = rw;
	}

	public CommonWaitWithTime(int rw, long timeout)
	{
		this.rw = rw;
		this.timeout = timeout;
	}

	public CommonWaitWithTime(int rw, long timeout, Object target)
	{
		this.rw = rw;
		this.timeout = timeout;
		this.target = target;
	}

	public boolean condition()
	{
		return (rw == READ && ((IBuffer) target).size() <= 0)
				|| (rw == WRITE && ((IBuffer) target).size() >= ((IBuffer) target)
						.cap());
	}
}
