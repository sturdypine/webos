package spc.webos.jsrmi.service.interceptor;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import spc.webos.jsrmi.request.RequestContext;
import spc.webos.jsrmi.service.ServiceInvocationException;

public class AllowOriginalHostOnlyInterceptor implements MethodInterceptor{
	
	private static final Log LOG = LogFactory.getLog(AllowOriginalHostOnlyInterceptor.class);
	
	public Object invoke(MethodInvocation method) throws Throwable {
		
		HttpServletRequest request = RequestContext.getContext().getHttpRequest();

		Cookie[] cookies = request.getCookies();
		
		if (cookies == null || cookies.length <=0) {
			LOG.warn("Some rantankerous user invoke this service, refused. " + method.getClass());
			throw new ServiceInvocationException("Permission error!");
		}
		
		return method.proceed();
	}
}
