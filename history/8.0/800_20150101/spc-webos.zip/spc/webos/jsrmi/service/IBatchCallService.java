package spc.webos.jsrmi.service;

import java.util.List;

public interface IBatchCallService
{
	List doBC(List services, List args);
}
