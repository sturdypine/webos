package spc.webos.jsrmi.service;

import java.io.IOException;
import java.io.Writer;

public class JsrmiWriter extends Writer
{
	Writer writer;
	StringBuffer buf;

	public JsrmiWriter(Writer writer)
	{
		super();
		this.writer = writer;
		buf = new StringBuffer();
	}
	
	public JsrmiWriter(Writer writer, StringBuffer buf)
	{
		super();
		this.writer = writer;
		this.buf = buf;
	}

	public StringBuffer getContent()
	{
		return buf;
	}

	public void write(char cbuf[], int off, int len) throws IOException
	{
		buf.append(cbuf, off, len);
		writer.write(cbuf, off, len);
	}

	public void flush() throws IOException
	{
		writer.flush();
	}

	public void close() throws IOException
	{
		writer.close();
	}
}
