package spc.webos.jsrmi.service.spring;

import javax.servlet.ServletContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import spc.webos.jsrmi.service.JsrmiServiceConfigurer;
import spc.webos.jsrmi.service.NoSuchServiceException;
import spc.webos.jsrmi.service.ServiceCreationFailException;
import spc.webos.jsrmi.service.ServiceFactory;

public class SpringServiceFactory implements ServiceFactory {

	private ServletContext context;
	
	/**
	 * Construct the instance.
	 * 
	 * @param ctx the servlet context
	 */
	public SpringServiceFactory(ServletContext ctx) {
		this.context = ctx;
	}
	
	/**
	 * return serivce via the service id and the service name.
	 */
	public Object getService(String serviceId, String serviceName) throws 
							NoSuchServiceException, ServiceCreationFailException {
		
		WebApplicationContext appCtx = WebApplicationContextUtils.getWebApplicationContext(this.context);
		
		JsrmiServiceConfigurer config = (JsrmiServiceConfigurer) (appCtx.getBean(serviceName));
		
		Object instance = config.getServices().get(serviceId);
		
		if (instance == null) {
			throw new NoSuchServiceException("In configBean '" + serviceName + 
					"', no service named '" + serviceId + "' configed.");
		}
		
		return instance;
		
	}

}
