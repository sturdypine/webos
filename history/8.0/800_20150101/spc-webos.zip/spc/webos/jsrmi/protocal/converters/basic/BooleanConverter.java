package spc.webos.jsrmi.protocal.converters.basic;

import spc.webos.jsrmi.protocal.ProtocalTag;
import spc.webos.jsrmi.protocal.ProtocolException;
import spc.webos.jsrmi.protocal.converters.Converter;
import spc.webos.jsrmi.protocal.io.MarshallingContext;
import spc.webos.jsrmi.protocal.io.StreamWriter;

public class BooleanConverter extends AbstractBasicConverter implements
		Converter
{
	public boolean canConvert(Class type)
	{
		if (type == null) return false;
		return type.equals(boolean.class) || type.equals(Boolean.class);
	}

	public Object fromString(String value)
	{
		if (value.equals("1")) return Boolean.TRUE;
		else if (value.equals("0")) return Boolean.FALSE;
		else throw new ProtocolException("<" + ProtocalTag.TAG_BOOLEAN
				+ "> contains only 1 or 0: " + value);
	}

	public void marshal(Object source, MarshallingContext context,
			StreamWriter streamWriter)
	{
		Boolean b = (Boolean) source;
		streamWriter.startNode(ProtocalTag.TAG_BOOLEAN);
		streamWriter.setValue(String.valueOf(b.booleanValue() ? 1 : 0));
		streamWriter.endNode();
	}
}
