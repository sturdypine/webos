
package spc.webos.jsrmi.protocal.io;

import java.util.List;

/**
 * @author  lenovo
 */
public interface UnmarshallingContext {

	Object convertAnother();

	void addObject(Object object);

	List getObjects();

}
