
package spc.webos.jsrmi.protocal.io;

import java.util.List;

/**
 * @author  lenovo
 */
public interface MarshallingContext {

	void convertAnother(Object value);

	List getObjects();

	void addObjectRef(Object object);

}
