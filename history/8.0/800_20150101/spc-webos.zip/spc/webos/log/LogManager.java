package spc.webos.log;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import spc.webos.buffer.CommonBuffer;
import spc.webos.buffer.IBuffer;

/**
 * ��������ϵͳ���첽��־. ��Ҫ�ǶԲ�ͬ����־�ļ���ר�ŵ��߳���������־��¼,���������־��¼���ٶ�
 * 
 * @author spc
 * 
 */
public class LogManager
{
	protected Map threads = new HashMap();
	protected LogThread defThread;
	static LogManager LOG_MANAGER = new LogManager();
	protected Logger log = Logger.getLogger(getClass());

	public void init()
	{
		if (defThread == null)
		{
			defThread = new LogThread();
			defThread.setBuf(new CommonBuffer("LOG.DEF", 500));
			defThread.init();
		}
	}

	// �ж��첽��־�߳����Ƿ��Ѿ���������
	public boolean isStarted()
	{
		return defThread != null;
	}

	/**
	 * ֹͣ������־�߳�
	 */
	public void asynStopAll()
	{
		try
		{
			if (defThread != null) defThread.asynStop();
			defThread = null;
			if (threads == null) return;
			Iterator t = threads.values().iterator();
			while (t.hasNext())
				((LogThread) t.next()).asynStop();
		}
		catch (Exception e)
		{
		}
	}

	public void interruptAll()
	{
		try
		{
			if (defThread != null) defThread.interrupt();
			defThread = null;
			if (threads == null) return;
			Iterator t = threads.values().iterator();
			while (t.hasNext())
				((LogThread) t.next()).interrupt();
		}
		catch (Exception e)
		{
		}
	}

	// ����־����ȡ��־����
	public IBuffer getLogBuf(String logName)
	{
		LogThread thread = (LogThread) threads.get(logName);
		return thread != null ? thread.getBuf() : defThread.getBuf();
	}

	// ��õ�ǰ��־�������Ϣ
	public String getLogBufSizeInfo()
	{
		StringBuffer buf = new StringBuffer();
		buf.append("DEF:" + defThread.buf.size());
		if (threads == null || threads.size() == 0) return buf.toString();
		Iterator t = threads.values().iterator();
		while (t.hasNext())
		{
			LogThread lt = (LogThread) t.next();
			buf.append(',');
			buf.append(lt.getName());
			buf.append(':');
			buf.append(lt.buf.size());
		}
		return buf.toString();
	}

	private LogManager()
	{
	}

	public static LogManager getInstance()
	{
		return LOG_MANAGER;
	}

	public void setThreads(Map threads)
	{
		Iterator keys = threads.keySet().iterator();
		while (keys.hasNext())
		{
			String key = keys.next().toString();
			if (this.threads.containsKey(key))
			{
				log.warn("LogManager has contain " + key + " LogThread!!!");
				continue;
			}
			LogThread thread = (LogThread) threads.get(key);
			thread.init();
			threads.put(key, thread);
		}
	}

	public void setDefThread(LogThread defThread)
	{
		this.defThread = defThread;
	}
}
