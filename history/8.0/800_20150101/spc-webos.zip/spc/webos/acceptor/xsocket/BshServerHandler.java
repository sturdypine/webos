package spc.webos.acceptor.xsocket;

import org.xsocket.connection.INonBlockingConnection;

import bsh.Interpreter;

public class BshServerHandler extends DefaultServerHandler
{
	Interpreter bsh;

	public synchronized boolean isShortCnnEnd(INonBlockingConnection cnn, byte[] msg)
	{
		try
		{
			bsh.set("cnn", cnn);
			bsh.set("msg", msg);
			bsh.eval("boolean end=fun(cnn,msg);");
			return (Boolean) bsh.get("end");
		}
		catch (Exception e)
		{
			log.warn("short cnn end:", e);
			return true;
		}
	}

	public void setBsh(String script) throws Exception
	{
		bsh = new Interpreter();
		bsh.eval("import " + INonBlockingConnection.class.getName()
				+ ";boolean fun(INonBlockingConnection cnn, byte[] msg){" + script + "}");
	}
}
