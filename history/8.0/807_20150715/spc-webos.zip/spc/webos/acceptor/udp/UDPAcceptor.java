package spc.webos.acceptor.udp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import spc.webos.acceptor.Acceptor;
import spc.webos.acceptor.SocketMessage;
import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.Message;
import spc.webos.log.Log;
import spc.webos.util.StringX;

/**
 * ����UDPЭ��ı�������
 * 
 * @author chenjs
 * 
 */
public class UDPAcceptor extends Acceptor
{
	protected DatagramSocket dataSocket;
	protected byte[] receiveByte;
	protected DatagramPacket inPacket;

	public UDPAcceptor()
	{
		maxbytes = 100000; // Ĭ��100K
	}

	public void init() throws Exception
	{
		setName("UDP-" + port);
		dataSocket = new DatagramSocket(port);
		dataSocket.setReceiveBufferSize(maxbytes);
		receiveByte = new byte[maxbytes];
		inPacket = new DatagramPacket(receiveByte, receiveByte.length);
		super.init();
	}

	public void execute() throws Exception
	{
		if (!StringX.nullity(getLogName())) Log.start(getLogName(), false);
		dataSocket.receive(inPacket);
		caseNum++;
		InetAddress clientAddress = inPacket.getAddress();
		if (log.isInfoEnabled()) log.info("UDP:localPort:" + port + ",remote: " + clientAddress
				+ ", port:" + inPacket.getPort() + ", caseNum:" + caseNum + ", len: "
				+ inPacket.getLength());
		byte[] buf = new byte[inPacket.getLength()];
		System.arraycopy(inPacket.getData(), 0, buf, 0, buf.length);
		// debug������־�ᵼ��udp server�����������𶪰�����
		if (log.isDebugEnabled()) log.debug("base64:" + StringX.base64(buf) + "\nstr:"
				+ new String(buf));
		if (reqbuf != null) reqbuf.put(socketmsg2msg(new SocketMessage(null, buf, getHdrLen(),
				getRepbuf(), Common.ACCEPTOR_PROTOCOL_UDP, isLen2bcd(), isHdrLenBinary()),
				(clientAddress != null ? clientAddress.getHostAddress() : StringX.EMPTY_STRING)));
		Log.print();
	}

	protected Object socketmsg2msg(SocketMessage smsg, String remoteIP) throws Exception
	{
		if (getConverter() == null) return smsg;
		IMessage msg = new Message();
		int index = remoteIP.indexOf(':');
		msg.setInLocal(MsgLocalKey.ACCEPTOR_REMOTE_HOST, index > 0 ? remoteIP.substring(0, index)
				: remoteIP);
		int localPort = (smsg.localPort <= 0 ? getPort() : smsg.localPort);
		msg.setInLocal(MsgLocalKey.ACCEPTOR_LOCAL_PORT, String.valueOf(localPort));
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_SOCKETMSG, smsg); // ���������Ϣ��ԭʼ��Ϣ
		msg.setInLocal(MsgLocalKey.ACCEPTOR_PROTOCOL, smsg.protocol);
		msg.setInLocal(MsgLocalKey.LOCAL_REP_BUFFER, smsg.repbuf);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, smsg.reqmsg);
		msg.setInLocal(MsgLocalKey.LOCAL_MSG_CONVERTER, getConverter());
		msg.setInLocal(MsgLocalKey.LOCAL_MSGCVT_DELAY, Boolean.TRUE); // �ӳٽ���
		if (getMsgFlow() != null) msg.setInLocal(MsgLocalKey.LOCAL_MSG_MSGFLOW, getMsgFlow());
		return msg;
	}
}
