package spc.webos.flownode.impl;

import java.util.List;

import spc.webos.data.IMessage;
import spc.webos.flownode.IFlowContext;
import spc.webos.flownode.IFlowNode;

/**
 * ����ִ�и�fnodes
 * 
 * @author spc
 * 
 */
public class SequenceCFNode extends AbstractCFNode
{
	protected List fnodes;

//	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
//	{
//		long s = 0;
//		if (log.isInfoEnabled()) s = System.currentTimeMillis();
//		// �����������쳣������
//		boolean exHandler = (exFNode != null && !msg.isContainExFnode());
//		if (exHandler) msg.setContainExFnode(true);
//		try
//		{
//			if (before != null) before.execute(msg, cxt);
//			for (int i = 0; i < fnodes.size(); i++)
//			{
//				IFlowNode fn = (IFlowNode) fnodes.get(i);
//				fn.execute(msg, cxt);
//			}
//			if (after != null) after.execute(msg, cxt);
//		}
//		catch (Exception e)
//		{
//			if (!exHandler) throw e; // ��ǰ���̻���û�������쳣��������
//			msg.setEx(e);
//			try
//			{
//				exFNode.execute(msg, cxt);
//			}
//			catch (Exception t)
//			{
//				log.fatal("ex in exFNode", t);
//			}
//		}
//		finally
//		{ // ��ǰ���̽����󣬸ı��Լ��ı�����쳣������־
//			if (exHandler) msg.setContainExFnode(false);
//			try
//			{
//				if (finalFNode != null) finalFNode.execute(msg, cxt);
//			}
//			catch (Exception e)
//			{
//				log.fatal("ex in finalFNode", e);
//			}
//		}
//		if (log.isInfoEnabled()) log.info(getClass() + ":thread:"
//				+ Thread.currentThread().getName() + ", cost:" + (System.currentTimeMillis() - s));
//		return null;
//	}

	public void flow(IMessage msg, IFlowContext cxt) throws Exception
	{
		for (int i = 0; i < fnodes.size(); i++)
		{
			IFlowNode fn = (IFlowNode) fnodes.get(i);
			fn.execute(msg, cxt);
		}
	}

	public List getFnodes()
	{
		return fnodes;
	}

	public void setFnodes(List fnodes)
	{
		this.fnodes = fnodes;
	}
}
