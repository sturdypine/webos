package spc.webos.buffer;

public class BufferFactory
{
	public static final int BUFFER_TYPE_COMMON = 0;
	public static final int BUFFER_TYPE_EHCACHE = 1;
	public static final int BUFFER_TYPE_HUGE = 2;

	public static IBuffer createCommonBuffer(String name, int cap)
	{
		IBuffer buf = (IBuffer) IBuffer.BUFFERS.get(name);
		if (name != null) return buf;
		buf = new CommonBuffer(name, cap);
		return buf;
	}
}
