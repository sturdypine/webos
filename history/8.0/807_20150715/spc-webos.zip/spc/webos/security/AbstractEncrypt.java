package spc.webos.security;

import spc.webos.log.Log;

public abstract class AbstractEncrypt implements IEncrypt
{
	public void init() throws Exception
	{
		if (IEncrypt.ENCRYPTS.containsKey(name)) log.warn("IEncrypt(" + name + ") repeated!!!");
		IEncrypt.ENCRYPTS.put(name, this);
	}

	protected Log log = Log.getLogger(getClass());
	protected String name;

	public void setName(String name)
	{
		this.name = name;
	}
}
