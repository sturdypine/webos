package spc.webos.service.common;

import java.util.List;
import java.util.Map;

import spc.webos.model.UserVO;
import spc.webos.web.common.ISessionUserInfo;

public interface ILoginService
{
	boolean forceLogout(String userCd);

	List onlineUser(Map params); // ������������û�sessio

	void login(String userCode, String pwd, String verifyCode);

	void register(ISessionUserInfo sui);

	void logout();

	int update(UserVO user, String oldPwd);

	int update(UserVO user);

	int insert(UserVO user);

	// ��õ�ǰ����Ȩ�޵Ĳ˵�
	List getMenus();

	boolean isTimeout();

	Map getServerInfo();

	// void updatePwd(String oldPwd, String newPwd);
	//
	// void updateUserInfo(UserVO vo);
}
