package spc.webos.sim;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import spc.webos.data.IMessage;
import spc.webos.data.Message;
import spc.webos.log.Log;
import spc.webos.util.FileUtil;
import spc.webos.util.SystemUtil;

public abstract class Sim extends Thread
{
	protected Log log = Log.getLogger(MQSim.class);
	// protected String msgPath; // �����͵�ģ�ⱨ��·��
	protected int threadNum; // �������͵��߳���
	protected int times; // ���̷߳��ʹ���
	protected int timeout = 5;
	protected byte[] sndMsg;
	long totalNum = 0; // �ܹ�ִ�б���
	private int startedThreadNum = 0; // �������߳���
	String[] args; // ��������

	public void sim() throws Exception
	{
		log.info("sim....");
		totalNum = 0;
		for (int i = 0; i < threadNum; i++)
		{
			Thread t = new Thread(this);
			t.setName("SIM-" + i);
			t.start();
			startedThreadNum++;
		}
		// log.info("sim over...");
	}

	public void run()
	{
		try
		{
			IMessage sndMsg = new Message(this.sndMsg);
			sndMsg.init();
			for (int i = 0; i < times; i++)
			{
				// IMessage sndMsg = new Message(this.sndMsg);
				// sndMsg.init();
				// �޸ĵ�ǰ���ĵķ���ʱ�����ˮ
				String dt = new SimpleDateFormat(SystemUtil.DF_SALL17).format(new Date());
				String sn = SystemUtil.getTimeSN(8) + SystemUtil.random(7);
				sndMsg.getMsg().set(IMessage.TAG_SNDDT, dt.substring(0, 8));
				sndMsg.getMsg().set(IMessage.TAG_SNDTM, dt.substring(8, 14));
				sndMsg.getMsg().set(IMessage.TAG_HEADER_MSG_SN, sn);
				String corId = dt.substring(0, 8) + '-' + sn;
				sndMsg.setCorrelationID(corId.getBytes()); // ��Ϣ������Ҳ������ˮ��
				long start = System.currentTimeMillis();
				execute(sndMsg, timeout);
				// Thread.sleep(100);
				long end = System.currentTimeMillis() - start;
				if (log.isInfoEnabled()) log.info(Thread.currentThread().getName() + "'s, NO:" + i
						+ ", SN: " + sn + ", COST:" + +end);
				addTotalNum();
			}
		}
		catch (Exception e)
		{
			log.error("run", e);
		}
		finally
		{
			endThread();
		}
	}

	protected synchronized void endThread()
	{
		startedThreadNum--;
		if (startedThreadNum <= 0)
		{
			System.out.println("End sim:" + System.currentTimeMillis() + ", totalNum:" + totalNum);
//			Main.stop();
		}
	}

	protected synchronized void addTotalNum()
	{
		totalNum++;
	}

	public int getStartedThreadNum()
	{
		return startedThreadNum;
	}

	public abstract IMessage execute(IMessage msg, int timeout) throws Exception;

	public static void sim(Sim sim, String[] args) throws Exception
	{
		sim.args = args;
		sim.sndMsg = FileUtil.file2bytes(new File(args[0]));
		if (args.length > 1) sim.setTimes(Integer.parseInt(args[1]));
		else sim.setTimes(1);
		if (args.length > 2) sim.setThreadNum(Integer.parseInt(args[2]));
		else sim.setThreadNum(1);
		System.out.println("Start sim:" + System.currentTimeMillis());
		sim.sim();
		while (sim.getStartedThreadNum() > 0)
		{
			try
			{
				Thread.sleep(2000);
			}
			catch (Exception e)
			{
			}
		}
		System.out.println("Sim over...");
	}

	public void setTimeout(int timeout)
	{
		this.timeout = timeout;
	}

	public void setThreadNum(int threadNum)
	{
		this.threadNum = threadNum;
	}

	public void setTimes(int times)
	{
		this.times = times;
	}
}
