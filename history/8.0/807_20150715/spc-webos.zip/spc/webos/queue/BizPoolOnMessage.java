package spc.webos.queue;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import spc.webos.log.Log;
import spc.webos.thread.DaemonThread;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

/**
 * ��������������MQ��ȡ�̡߳����ɴ�����ҵ���̳߳ؽ��д���
 * 
 * @author chenjs
 * 
 */
public class BizPoolOnMessage implements IOnMessage
{
	protected Log log = Log.getLogger(getClass());
	protected ExecutorService bizpool;
	protected int size;
	protected int maxBlockSize = -1; // 753,
	protected IOnMessage onMessage;
	// 702_2014022 ���ô����̳߳�
	public static int QUEUE_BIZ_POOL_SIZE = 100; // MQ���������̳߳ش�С
	public static ExecutorService QUEUE_EXECUTOR = Executors
			.newFixedThreadPool(QUEUE_BIZ_POOL_SIZE);

	public BizPoolOnMessage(int size, IOnMessage onMessage)
	{
		this.size = size;
		if (size > 0) bizpool = Executors.newFixedThreadPool(size);
		this.onMessage = onMessage;
	}

	public BizPoolOnMessage(IOnMessage onMessage)
	{
		this.onMessage = onMessage;
	}

	public BizPoolOnMessage()
	{
	}

	public void onMessage(Object obj, AccessTPool pool, AbstractReceiverThread thread)
			throws Exception
	{
		if (log.isDebugEnabled()) log.debug("add thread in "
				+ (bizpool == null ? "public(" + QUEUE_BIZ_POOL_SIZE : "private(" + size)
				+ ") biz pool...");
		if (bizpool != null)
		{
			if (maxBlockSize >= 0) isBlock();
			bizpool.execute(new BizThread(this, obj, pool, thread));
		}
		else QUEUE_EXECUTOR.execute(new BizThread(this, obj, pool, thread));
	}

	public synchronized boolean isBlock() throws InterruptedException
	{
		if (maxBlockSize < 0) return false;
		while (((ThreadPoolExecutor) bizpool).getQueue().size() > maxBlockSize)
		{
			log.warn("Blocking:: maxBlockSize:" + maxBlockSize + ", active:"
					+ ((ThreadPoolExecutor) bizpool).getActiveCount());
			this.wait();
		}
		return true;
	}

	public synchronized void releaseThread()
	{
		this.notifyAll();
	}

	public void init() throws Exception
	{
	}

	public void destroy()
	{
		if (bizpool == null) return;
		log.warn("destroy thread pool, isShutdown:" + bizpool.isShutdown());
		if (!bizpool.isShutdown()) bizpool.shutdown();
	}

	public void setOnMessage(IOnMessage onMessage)
	{
		this.onMessage = onMessage;
	}

	public void setPoolSize(int size)
	{
		bizpool = Executors.newFixedThreadPool(size);
	}
}

class BizThread extends DaemonThread
{
	BizPoolOnMessage bizPoolOnMessage;
	Object obj;
	AccessTPool pool;
	AbstractReceiverThread thread;

	public BizThread(BizPoolOnMessage bizPoolOnMessage, Object obj, AccessTPool pool,
			AbstractReceiverThread thread)
	{
		this.bizPoolOnMessage = bizPoolOnMessage;
		this.obj = obj;
		this.pool = pool;
		this.thread = thread;
		setName("Biz_" + pool.getName() + "_" + SystemUtil.random(6));
	}

	public void run()
	{
		long start = System.currentTimeMillis();
		status = curStatus = RUNNING;
		if (getName() != null) THREADS.put(getName(), this); // �̻߳�����
		String str = "";
		Log log = bizPoolOnMessage.log;
		try
		{
			if (!StringX.nullity(pool.getLogName())) Log.start(pool.getLogName());

			long qstart = (obj instanceof QueueMessage) ? ((QueueMessage) obj).createTm : 0; // �Ӷ��������ȡ������ʱ��
			str = "do("
					+ ((obj instanceof QueueMessage) ? new String(
							((QueueMessage) obj).correlationId) : StringX.EMPTY_STRING) + ")"; // ������ˮ�ſ��Դ���־��������ʱ��

			if (log.isDebugEnabled()) log.debug(str + ") start...");
			bizPoolOnMessage.onMessage.onMessage(obj, pool, thread);
			long end = System.currentTimeMillis();
			log.info(str + ", bizcost:" + (end - start) + ", cost:" + (end - qstart));
		}
		catch (Throwable t)
		{
			log.warn(str + " fail:", t);
		}
		finally
		{
			if (getName() != null) THREADS.remove(getName()); // �߳�ֹͣ��ɾ��
			curStatus = status = STOPPED; // ֹͣ��ǰ�߳�
			release(); // �ͷ���Դ
			log.info(str + ") stop, cost:" + (System.currentTimeMillis() - start));
			Log.print();
			bizPoolOnMessage.releaseThread();
		}
	}

	public void execute()
	{
	}
}