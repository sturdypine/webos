package spc.webos.queue;

import java.io.File;
import java.io.InputStream;

import spc.webos.data.IBlobMsgHeader;
import spc.webos.data.IMessage;

public interface IBlobQueueAccess extends IQueueAccess
{
	IMessage receive(String qname, boolean segment, int timeout) throws Exception;

	IMessage receive(String qname, IBlobMessageCreator blob, boolean segment, int timeout)
			throws Exception;

	IMessage receive(String qname, IBlobMessageCreator blob, boolean segment, int timeout,
			byte[] correlationId) throws Exception;

	void send(String qname, InputStream is, IBlobMsgHeader header, boolean segment)
			throws Exception;

	/**
	 * ����MQ���ʹ�ĸ�����Ϣ��Ӧ�ó�����Ϣ���з�Ƭ����
	 * 
	 * @param qname
	 *            ���͵Ķ�����
	 * @param is
	 *            ������
	 * @param len
	 *            ���͵��ܳ���
	 * @param sliceBuf
	 *            ÿƬ��С һ��Ϊ1M
	 * @param header
	 *            mq��Ϣ����
	 * @throws Exception
	 */
	void send(String qname, InputStream is, IBlobMsgHeader header, boolean segment,
			byte[] correlationId) throws Exception;

	void send(String qname, File[] files, boolean[] gzip, IBlobMsgHeader header, boolean segment,
			byte[] correlationId) throws Exception;
}
