package spc.webos.queue.ibmmq;

import java.io.File;
import java.io.InputStream;
import java.util.List;

import spc.webos.data.IBlobMsgHeader;
import spc.webos.data.IMessage;
import spc.webos.queue.DefaultBlobMessageCreator;
import spc.webos.queue.IBlobMessageCreator;
import spc.webos.queue.IBlobQueueAccess;

/**
 * MQ����Ϣ�ķ�Ƭ����
 * 
 * @author spc
 * 
 */
public class BlobQueueAccess extends QueueAccess implements IBlobQueueAccess
{
	protected int sliceSize = 90000; // Ĭ�Ϸ�ƬΪ90 K
	protected IBlobMessageCreator creator = new DefaultBlobMessageCreator();

	public BlobQueueAccess()
	{
	}

	public BlobQueueAccess(MQCnnPool cnnPool)
	{
		super(cnnPool);
	}

	public BlobQueueAccess(MQCnnPool cnnPool, IBlobMessageCreator creator)
	{
		super(cnnPool);
		this.creator = creator;
	}

	public BlobQueueAccess(List<MQCnnPool> cnnpools, IBlobMessageCreator creator)
	{
		super(cnnpools);
		this.creator = creator;
	}

	public IMessage receive(String qname, boolean segment, int timeout) throws Exception
	{
		return receive(qname, creator, segment, timeout);
	}

	public IMessage receive(String qname, IBlobMessageCreator blob, boolean segment, int timeout)
			throws Exception
	{
		return receive(qname, blob, segment, timeout, null);
	}

	public IMessage receive(String qname, IBlobMessageCreator blob, boolean segment, int timeout,
			byte[] correlationId) throws Exception
	{
		MQCnnPool cnnPool = getFirstMQCnnPool();
		MQManager mqm = null;
		try
		{
			mqm = (MQManager) cnnPool.borrow();
			return Accessor.receive(mqm, qname, blob == null ? creator : blob, segment,
					correlationId, timeout);
		}
		finally
		{
			cnnPool.release(mqm);
		}
	}

	public void send(String qname, InputStream is, IBlobMsgHeader header, boolean segment)
			throws Exception
	{
		send(qname, is, header, segment, null);
	}

	/**
	 * ����MQ���ʹ�ĸ�����Ϣ��Ӧ�ó�����Ϣ���з�Ƭ����
	 * 
	 * @param qname
	 *            ���͵Ķ�����
	 * @param is
	 *            ������
	 * @param len
	 *            ���͵��ܳ���
	 * @param sliceBuf
	 *            ÿƬ��С һ��Ϊ1M
	 * @param header
	 *            mq��Ϣ����
	 * @throws Exception
	 */
	public void send(String qname, InputStream is, IBlobMsgHeader header, boolean segment,
			byte[] correlationId) throws Exception
	{
		MQCnnPool cnnPool = getFirstMQCnnPool();
		MQManager mqm = null;
		try
		{
			mqm = (MQManager) cnnPool.borrow();
			// 2012-06-10 ����ũ����������Ʊ�ĸ������ͻ���
			// if (header instanceof BlobMsgHeader0) Accessor.send0(mqm,
			// qname,is,(BlobMsgHeader0) header, sliceSize, correlationId);
			// else
			Accessor.send(mqm, qname, is, header, segment, sliceSize, correlationId);
		}
		finally
		{
			cnnPool.release(mqm);
		}
	}

	public void send(String qname, File[] files, boolean[] gzip, IBlobMsgHeader header,
			boolean segment, byte[] correlationId) throws Exception
	{
		MQCnnPool cnnPool = getFirstMQCnnPool();
		MQManager mqm = null;
		try
		{
			mqm = (MQManager) cnnPool.borrow();
			Accessor.send(mqm, qname, files, gzip, header, segment, sliceSize, correlationId);
		}
		finally
		{
			cnnPool.release(mqm);
		}
	}

	/**
	 * ����һ��RFH2��MQ��Ϣ
	 * 
	 * @param header
	 * @param buf
	 * @param size
	 *            buf����Ч��Ϣ����
	 * @return
	 * @throws Exception
	 */
	// public static MQMessage createMQRFH2(BlobMsgHeader header, byte[] buf,
	// int offset, int size)
	// throws Exception
	// {
	// MQMessage qmsg = new MQMessage();
	// qmsg.format = MQC.MQFMT_RF_HEADER_2;
	//
	// // format the data to multiple 4.
	// int rfhStrucLength = MQC.MQRFH_STRUC_LENGTH_FIXED_2 + 14 * 4 +
	// buf.length;
	// // ����ͷ���ֵ�ʱ�䳤��
	// ICompositeNode cnode = header.toCNode(null);
	// Iterator values = cnode.mapValue().values().iterator();
	// while (values.hasNext())
	// rfhStrucLength +=
	// values.next().toString().getBytes(Common.CHARSET_UTF8).length;
	//
	// // RFH2 Part 1: Header Part
	// qmsg.writeString("RFH "); // StrucID
	// qmsg.writeInt4(MQC.MQRFH_VERSION_2); // Version
	// qmsg.writeInt4(rfhStrucLength); // StrucLength
	// qmsg.writeInt4(MQC.MQENC_NATIVE); // Encoding
	// qmsg.writeInt4(MQC.MQCCSI_DEFAULT); // CodedCharSetID
	// qmsg.writeString(MQC.MQFMT_NONE); // Format
	// qmsg.writeInt4(MQC.MQRFH_NO_FLAGS); // Flags
	// qmsg.writeInt4(1208); // NameValueCCSID
	//
	// // part2: filehead info.
	// // qmsg.writeInt4(header.getVer().length());
	// // qmsg.writeString(header.getVer());
	// qmsg.writeInt4(header.getMsgCd().length());
	// qmsg.writeString(header.getMsgCd());
	// qmsg.writeInt4(header.getSndMbrCd().length());
	// qmsg.writeString(header.getSndMbrCd());
	// qmsg.writeInt4(header.getSndAppCd().length());
	// qmsg.writeString(header.getSndAppCd());
	// qmsg.writeInt4(header.getSndDt().length());
	// qmsg.writeString(header.getSndDt());
	// qmsg.writeInt4(header.getSndTm().length());
	// qmsg.writeString(header.getSndTm());
	// qmsg.writeInt4(header.getSeqNb().length());
	// qmsg.writeString(header.getSeqNb());
	// qmsg.writeInt4(header.getRcvMbrCd().length());
	// qmsg.writeString(header.getRcvMbrCd());
	// qmsg.writeInt4(header.getRcvAppCd().length());
	// qmsg.writeString(header.getRcvAppCd());
	// qmsg.writeInt4(header.getGzip().length());
	// qmsg.writeString(header.getGzip());
	// // qmsg.writeInt4(header.getSliceNo().length());
	// // qmsg.writeString(header.getSliceNo());
	// qmsg.writeInt4(header.getFileId().length());
	// qmsg.writeString(header.getFileId());
	// // byte[] desc = header.getDesc().getBytes(Common.CHARSET_UTF8);
	// // qmsg.writeInt4(desc.length);
	// // qmsg.write(desc);
	// // qmsg.writeInt4(m_mcd_data.getBytes().length); // NameValueLength
	// // qmsg.writeString(m_mcd_data); // NameValueData <mcd>
	//
	// // part3: content
	// qmsg.write(buf, offset, size); // Actual MESSAGE data
	// return qmsg;
	// }
	//
	// public static byte[] parseMQRFH2(MQMessage qmsg, BlobMsgHeader header,
	// OutputStream os)
	// throws Exception
	// {
	// qmsg.seek(0); // Set read position back to the beginning of
	//
	// // Part 1: read RFH header
	// String rfhStrucID = qmsg.readString(4); // MQC.MQRFH_STRUC_ID,
	// // OfByteLength
	// // MQRFH_VERSION_1 or MQRFH_VERSION_2
	// int rfhVersion = qmsg.readInt();
	// // MQRFH_STRUC_LENGTH_FIXED or MQRFH_STRUC_LENGTH_FIXED_2
	// int rfhStrucLength = qmsg.readInt();
	// int rfhEncoding = qmsg.readInt(); // MQC.MQENC_NATIVE
	// int rfhCodedCharSetId = qmsg.readInt(); // MQC.MQCCSI_DEFAULT
	// String rfhFormat = qmsg.readString(8); // MQFMT_RF_HEADER_2
	// int rfhFlags = qmsg.readInt(); // MQC.MQRFH_NO_FLAGS
	// int rfhNameValueCCSID = qmsg.readInt(); // 1208 - UTF-8
	// if (log.isInfoEnabled()) log.info("rfhStrucID = " + rfhStrucID +
	// "\n rfhVersion = "
	// + rfhVersion + "\n rfhStrucLength = " + rfhStrucLength +
	// "\n rfhEncoding = "
	// + rfhEncoding + "\n rfhCodedCharSetId" + rfhCodedCharSetId +
	// "\n rfhFormat = "
	// + rfhFormat + "\n rfhFlags = " + rfhFlags + "\n rfhNameValueCCSID = "
	// + rfhNameValueCCSID);
	//
	// // Part 2: read FileHeader info.
	//
	// // Part 3: read payload
	// int pos = qmsg.getDataOffset(); // Current Position
	// int dataLen = qmsg.getDataLength(); // Number of bytes remaining
	// byte[] rfhDataBytes = new byte[dataLen];
	// qmsg.seek(pos); // Set read position back to the beginning of
	// qmsg.readFully(rfhDataBytes);
	//
	// os.write(rfhDataBytes, rfhStrucLength, dataLen - rfhStrucLength);
	// return rfhDataBytes;
	// }

	public void setCreator(IBlobMessageCreator creator)
	{
		this.creator = creator;
	}

	public void setSliceSize(int sliceSize)
	{
		this.sliceSize = sliceSize;
	}
}
