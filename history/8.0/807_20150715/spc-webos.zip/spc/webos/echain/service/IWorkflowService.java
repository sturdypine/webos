package spc.webos.echain.service;

import java.util.List;
import java.util.Map;

import com.ecc.echain.workflow.engine.WFCFace;

public interface IWorkflowService extends WFCFace
{
	List getAllComments(Map evo) throws Exception;

	List getInstanceList(Map evo) throws Exception;

	List getSubFlow(Map evo) throws Exception;

	List getWFNameList(Map evo) throws Exception;

	List getWFTreatedNodeList(Map evo) throws Exception;

	List getWorkFlowHistory(Map evo) throws Exception;

	List wfBatchCompleteJob(Map evo) throws Exception;

	List wfBatchSaveJob(Map evo) throws Exception;
}
