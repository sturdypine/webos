package spc.webos.echain.log;

import spc.webos.log.Log;

public class Logger implements com.ecc.echain.log.Log
{
	protected Log log = Log.getLogger("echain");

	public void log(String component, int type, String message)
	{
		log(component, type, message, null);
	}

	public void log(String component, int type, String msg, Throwable t)
	{
		switch (type)
		{
			case 0: // DEBUG
				log.debug(msg, t);
				break;
			case 1: // TRACE
				log.debug(msg, t);
				break;
			case 2: // INFO:
				log.info(msg, t);
				break;
			case 3:// WARNING:
				log.warn(msg, t);
				break;
			case 4:// ERROR:
				log.error(msg, t);
				break;
			case 5:// FATAL:
				log.fatal(msg, t);
				break;
		}
	}

	public void init(String logSettingFile)
	{
	}
}
