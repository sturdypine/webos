package spc.webos.jsrmi.protocal.converters;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

import spc.webos.data.AtomNode;
import spc.webos.jsrmi.protocal.ProtocalTag;
import spc.webos.jsrmi.protocal.ProtocolException;
import spc.webos.jsrmi.protocal.converters.basic.AtomNodeConverter;
import spc.webos.jsrmi.protocal.converters.basic.BooleanConverter;
import spc.webos.jsrmi.protocal.converters.basic.DateConverter;
import spc.webos.jsrmi.protocal.converters.basic.DoubleConverter;
import spc.webos.jsrmi.protocal.converters.basic.IntegerConverter;
import spc.webos.jsrmi.protocal.converters.basic.LongConverter;
import spc.webos.jsrmi.protocal.converters.basic.NullConverter;
import spc.webos.jsrmi.protocal.converters.basic.StringConverter;
import spc.webos.jsrmi.protocal.converters.collection.ArrayConverter;
import spc.webos.jsrmi.protocal.converters.collection.CollectionConverter;
import spc.webos.jsrmi.protocal.converters.map.MapConverter;
import spc.webos.jsrmi.protocal.converters.map.ObjectConverter;

public class DefaultConverterLookup implements ConverterLookup
{

	private Map converterCache;
	private Map tagNameConverterCache;
	private ArrayList converters;
	Converter nullConverter;

	static final DefaultConverterLookup defaultConverterLookup = new DefaultConverterLookup();

	public static DefaultConverterLookup getInstance()
	{
		return defaultConverterLookup;
	}

	private DefaultConverterLookup()
	{
		converters = new ArrayList(13);
		converterCache = new HashMap();
		nullConverter = new NullConverter();
		tagNameConverterCache = new Hashtable(10);

		registerDefaultConverters();
	}

	public Converter lookupConverterForType(Class type)
	{
		Converter result = null;
		if (converterCache.get(type) == null)
		{
			for (int i = 0; i < converters.size(); i++)
			{
				Converter converter = (Converter) converters.get(i);
				if (converter.canConvert(type))
				{
					converterCache.put(type, converter);
					result = converter;
					break;
				}
			}
		}
		else
		{
			result = (Converter) converterCache.get(type);
		}
		return result;
	}

	protected void registerDefaultConverters()
	{
		BooleanConverter booleanConverter = new BooleanConverter();
		DoubleConverter doubleConverter = new DoubleConverter();
		IntegerConverter integerConverter = new IntegerConverter();
		LongConverter longConverter = new LongConverter();
		StringConverter stringConverter = new StringConverter();
		DateConverter dateConverter = new DateConverter();
		CollectionConverter collectionConverter = new CollectionConverter();
		MapConverter mapConverter = new MapConverter();
		ArrayConverter arrayConverter = new ArrayConverter();
		SqlDateConverter sqlDateConverter = new SqlDateConverter();
		ExceptionConverter exceptionConverter = new ExceptionConverter();
		AtomNodeConverter atomNodeConverter = new AtomNodeConverter();
		ObjectConverter objectConverter = ObjectConverter.getInstance();

		converters.add(nullConverter);
		converters.add(booleanConverter);
		converters.add(doubleConverter);
		converters.add(integerConverter);
		converters.add(longConverter);
		converters.add(stringConverter);
		converters.add(dateConverter);
		converters.add(collectionConverter);
		converters.add(mapConverter);
		converters.add(arrayConverter);
		converters.add(sqlDateConverter);
		converters.add(exceptionConverter);
		converters.add(atomNodeConverter);
		// Should be last one
		converters.add(objectConverter);

		tagNameConverterCache.put(ProtocalTag.TAG_BOOLEAN, booleanConverter);
		tagNameConverterCache.put(ProtocalTag.TAG_STRING, stringConverter);
		tagNameConverterCache.put(ProtocalTag.TAG_INT, integerConverter);
		tagNameConverterCache.put(ProtocalTag.TAG_LONG, longConverter);
		tagNameConverterCache.put(ProtocalTag.TAG_DOUBLE, doubleConverter);
		tagNameConverterCache.put(ProtocalTag.TAG_NULL, nullConverter);
		tagNameConverterCache.put(ProtocalTag.TAG_DATE, dateConverter);
		tagNameConverterCache.put(ProtocalTag.TAG_LIST, collectionConverter);
		tagNameConverterCache.put(ProtocalTag.TAG_MAP, mapConverter);
		tagNameConverterCache
				.put(ProtocalTag.TAG_REF, new ReferenceConverter());

		converterCache.put(Boolean.class, booleanConverter);
		converterCache.put(boolean.class, booleanConverter);
		converterCache.put(String.class, stringConverter);
		converterCache.put(Integer.class, integerConverter);
		converterCache.put(int.class, integerConverter);
		converterCache.put(Long.class, longConverter);
		converterCache.put(long.class, longConverter);
		converterCache.put(Double.class, doubleConverter);
		converterCache.put(double.class, doubleConverter);
		converterCache.put(Date.class, dateConverter);
		converterCache.put(ArrayList.class, collectionConverter);
		converterCache.put(LinkedList.class, collectionConverter);
		converterCache.put(HashSet.class, collectionConverter);
		converterCache.put(Vector.class, collectionConverter);
		converterCache.put(TreeSet.class, collectionConverter);
		converterCache.put(HashMap.class, mapConverter);
		converterCache.put(TreeMap.class, mapConverter);
		converterCache.put(AtomNode.class, atomNodeConverter);
	}

	public Converter getNullConverter()
	{
		return nullConverter;
	}

	public Converter lookupConverterForTagName(String tagName)
	{
		Object converter = tagNameConverterCache.get(tagName);
		if (converter == null) { throw new ProtocolException(
				"unrecoganized tag: " + tagName); }

		return (Converter) converter;
	}
}
