
package spc.webos.jsrmi.protocal.util;

public class PrimitiveTypeUtil {

	public static Object toWrapperArrayIfNeeded(Object value) {
		
		if (value.getClass().equals(int[].class)) {
			int[] primitiveValues = (int[])value;
			Integer[] wrapperValues = new Integer[primitiveValues.length];
			for (int i = 0; i < primitiveValues.length; i++) {
				wrapperValues[i] = new Integer(primitiveValues[i]);
			}
	
			return wrapperValues;
		}
		
		if (value.getClass().equals(short[].class)) {
			short[] primitiveValues = (short[])value;
			Integer[] wrapperValues = new Integer[primitiveValues.length];
			for (int i = 0; i < wrapperValues.length; i++) {
				wrapperValues[i] = new Integer(primitiveValues[i]);
			}
			return wrapperValues;
		}
		
		if (value.getClass().equals(byte[].class)) {
			byte[] primitiveValues = (byte[])value;
			Integer[] wrapperValues = new Integer[primitiveValues.length];
			for (int i = 0; i < wrapperValues.length; i++) {
				wrapperValues[i] = new Integer(primitiveValues[i]);
			}
			return wrapperValues;
		}
		
		if (value.getClass().equals(long[].class)) {
			long[] primitiveValues = (long[])value;
			Long[] wrapperValues = new Long[primitiveValues.length];
			for (int i = 0; i < wrapperValues.length; i++) {
				wrapperValues[i] = new Long(primitiveValues[i]);
			}
			return wrapperValues;
		}
		
		if (value.getClass().equals(float[].class)) {
			float[] primitiveValues = (float[])value;
			Double[] wrapperValues = new Double[primitiveValues.length];
			for (int i = 0; i < wrapperValues.length; i++) {
				wrapperValues[i] = new Double(primitiveValues[i]);
			}
			return wrapperValues;
		}
		
		if (value.getClass().equals(double[].class)) {
			double[] primitiveValues = (double[])value;
			Double[] wrapperValues = new Double[primitiveValues.length];
			for (int i = 0; i < wrapperValues.length; i++) {
				wrapperValues[i] = new Double(primitiveValues[i]);
			}
			return wrapperValues;
		}
		
		if (value.getClass().equals(boolean[].class)) {
			boolean[] primitiveValues = (boolean[])value;
			Boolean[] wrapperValues = new Boolean[primitiveValues.length];
			for (int i = 0; i < wrapperValues.length; i++) {
				wrapperValues[i] = new Boolean(primitiveValues[i]);
			}
			return wrapperValues;
		}
		
		if (value.getClass().equals(char[].class)) {
			char[] primitiveValues = (char[])value;
			String[] wrapperValues = new String[primitiveValues.length];
			for (int i = 0; i < wrapperValues.length; i++) {
				wrapperValues[i] = String.valueOf(primitiveValues[i]);
			}
			return wrapperValues;
		}
		
		return value;
	}

}
