
package spc.webos.jsrmi.protocal.converters.collection;

import spc.webos.jsrmi.protocal.ProtocalTag;
import spc.webos.jsrmi.protocal.converters.AbstractReferencableConverter;
import spc.webos.jsrmi.protocal.converters.Converter;
import spc.webos.jsrmi.protocal.io.StreamWriter;

public abstract class AbstractListConverter extends AbstractReferencableConverter implements Converter {
	
	protected void writeListHeader(StreamWriter streamWriter, String type, int size) {
		streamWriter.startNode(ProtocalTag.TAG_LIST);
		//����Ҫָ������
		streamWriter.startNode(ProtocalTag.TAG_TYPE);
		streamWriter.setValue(type);
		streamWriter.endNode();
		streamWriter.startNode(ProtocalTag.TAG_LENGTH);
		streamWriter.setValue(String.valueOf(size));
		streamWriter.endNode();	
	}
	
}
