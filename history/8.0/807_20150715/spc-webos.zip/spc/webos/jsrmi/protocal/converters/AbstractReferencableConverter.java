
package spc.webos.jsrmi.protocal.converters;

import spc.webos.jsrmi.protocal.ProtocalTag;
import spc.webos.jsrmi.protocal.io.MarshallingContext;
import spc.webos.jsrmi.protocal.io.StreamWriter;

public abstract class AbstractReferencableConverter implements Converter {

	public final void marshal(Object value, MarshallingContext context, StreamWriter streamWriter) {
		
		int objectIndex = context.getObjects().indexOf(value);
		if (objectIndex > -1) {
			streamWriter.startNode(ProtocalTag.TAG_REF);
			streamWriter.setValue(String.valueOf(objectIndex));
			streamWriter.endNode();
			return;
		} 
		
		context.addObjectRef(value);
		marshalObject(value, context, streamWriter);
	}

	protected abstract void marshalObject(Object value, MarshallingContext context, StreamWriter streamWriter);
}
