package spc.webos.jsrmi.web;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class RequestUtils {
	private static final Map _localeMap = new HashMap();

	static {
		Locale[] locales = Locale.getAvailableLocales();
		for (int i = 0; i < locales.length; i++) {
			_localeMap.put(locales[i].toString(), locales[i]);
		}
	}

	public static Locale getLocale(String s) {
		Locale result = null;

		synchronized (_localeMap) {
			result = (Locale) _localeMap.get(s);
		}

		if (result == null) {
			String[] terms = s.split("_");

			switch (terms.length) {
			case 1:

				result = new Locale(terms[0], "");
				break;

			case 2:

				result = new Locale(terms[0], terms[1]);
				break;

			case 3:

				result = new Locale(terms[0], terms[1], terms[2]);
				break;

			default:

				throw new IllegalArgumentException("Unable to convert '" + s
						+ "' to a Locale.");
			}

			synchronized (_localeMap) {
				_localeMap.put(s, result);
			}

		}

		return result;

	}
}
