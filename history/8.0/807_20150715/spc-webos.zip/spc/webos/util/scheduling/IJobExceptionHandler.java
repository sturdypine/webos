package spc.webos.util.scheduling;

public interface IJobExceptionHandler
{
	void handle(MethodInvokingJobDetail invoker, Throwable t);
}
