package spc.webos.util;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Method;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.xml.ResourceEntityResolver;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.context.event.ContextStoppedEvent;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

import spc.webos.config.AppConfig;
import spc.webos.constant.AppRetCode;
import spc.webos.constant.Common;
import spc.webos.constant.Config;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.CompositeNode;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.data.Status;
import spc.webos.exception.AppException;
import spc.webos.exception.MsgErrException;
import spc.webos.log.Log;
import spc.webos.message.AppMessageSource;
import spc.webos.message.DictMessageSource;
import spc.webos.model.BeanVO;
import spc.webos.model.BshVO;
import spc.webos.model.FTLVO;
import spc.webos.persistence.Persistence;
import spc.webos.service.IService;
import spc.webos.util.netinfo.NetworkInfo;
import spc.webos.web.common.ISessionUserInfo;
import bsh.Interpreter;
import freemarker.cache.ClassTemplateLoader;
import freemarker.cache.FileTemplateLoader;
import freemarker.cache.MultiTemplateLoader;
import freemarker.cache.TemplateLoader;
import freemarker.ext.beans.BeansWrapper;
import freemarker.template.Configuration;
import freemarker.template.DefaultObjectWrapper;
import freemarker.template.Template;

/**
 * ϵͳ������
 * 
 * @author spc
 * 
 */
public final class SystemUtil implements ResourceLoaderAware, ApplicationContextAware
{
	static ApplicationContext APPCXT; // ��ǰspring����
	public static String LOCAL_HOST_IP = "127.0.0.1"; // ����ip��ַ
	public static String MAC = null; // ��ǰ������mac��ַ
	public static String RETCD_PATH = "MSG/"; // ��������Ϣ·��
	public static String DICT_PATH = "DICT/"; // �����ֵ���Ϣ·��
	public final static Date JVM_START_TIME = new Date(); // ��ǰjvm����������ʱ��
	public static String TEMPFILE_DIR = "classpath:env/tmpfile"; // ��ʱ�ļ���

	public static String FTS_AGENT; // �������FTS�ļ�����ڵ�����
	public static String APP = "ESB";// ϵͳӦ��ID,���������ڵ�ϵͳ���, ���ܳ���3���ַ�
	public static String JVM = "SPC"; // jvm��ʾ���е�����������൱��ģ��, ���ܳ���3���ַ�
	public static String JVMDESC = "sturdypine@gmail.com"; // JVM����
	public static String NODE; // �ڵ�� = "0000", modified by spc
	// 2010-5-28ȡ��Ĭ�����Ľڵ��
	public static final String DF_ALL23 = "yyyy-MM-dd HH:mm:ss SSS";
	public static final String DF_ALL19 = "yyyy-MM-dd HH:mm:ss";
	public static final String DF_DB210 = "yyyy-MM-dd";
	public static final String DF_APP6 = "yyMMdd";
	public static final String DF_APP8 = "yyyyMMdd";
	public static final String DF_HMSS12 = "HH:mm:ss SSS";
	public static final String DF_HMS6 = "HHmmss";
	public static final String DF_HMS9 = "HHmmssSSS";
	public static final String DF_HMS8 = "HH:mm:ss";
	public static final String DF_HMAS400S8 = "HH.mm.ss";
	public static final String DF_SALL13 = "yyyyMMddHHmmss";
	public static final String DF_SALL14 = "yyyyMMddHHmmss";
	public static final String DF_SALL17 = "yyyyMMddHHmmssSSS";
	public static final String DF_SN15 = "yyMMddHHmmssSSS";
	final static Log log = Log.getLogger(SystemUtil.class);
	private static long LAST_TIME = 0; // ��Ϊ�����������ˮ�����ɵĻ�����ÿ������һ��Ψһ��ʱ�䣬���һ�������������������δ��һ����
	ISystemTime systemTime; // ��ȡϵͳʱ��Ľӿ�
	private static String autowireBeans; // 715_20141015
											// spring��������ʱ��esb_config�������Զ�װ���bean

	public void init() throws Exception
	{
		initFreemarkerConf();
	}

	List templateLocations = new ArrayList(); // ģ��·��
	Configuration ftlCfg; // ����ϵͳ��ftl��������
	Map ftlCache = new HashMap(); // 800, ��DB�ȵط���ȡ��ftl

	public void setFtlCache(Map cache)
	{
		ftlCache = (cache == null ? new HashMap() : cache);
	}

	public Map getFtlCache()
	{
		return ftlCache;
	}

	public void addFtl(String id, Template t)
	{
		ftlCache.put(id, t);
	}

	public Configuration getFtlCfg()
	{
		return ftlCfg;
	}

	public void setFtlCfg(Configuration ftlCfg)
	{
		this.ftlCfg = ftlCfg;
	}

	public Map loadFTLInDB() throws IOException
	{
		Map cache = new HashMap();
		List ftls = null;
		try
		{
			ftls = Persistence.getInstance().get(new FTLVO());
		}
		catch (Exception e)
		{
			log.info("fail to load FTL in DB:" + e);
		}
		if (ftls == null) return cache;
		Configuration cfg = new Configuration();
		cfg.setNumberFormat("0");
		for (int i = 0; i < ftls.size(); i++)
		{
			FTLVO vo = (FTLVO) ftls.get(i);
			cache.put(vo.getId(), new Template(vo.getId(), new StringReader(vo.getFtl()), cfg));
		}
		if (log.isInfoEnabled()) log.info("FTL in DB: " + cache.keySet());
		setFtlCache(cache);
		return cache;
	}

	public static String freemarker(String t, Map root) throws Exception
	{
		StringWriter sw = new StringWriter();
		Configuration cfg = new Configuration();
		cfg.setNumberFormat("0");
		SystemUtil.freemarker(new Template("sysutil", new StringReader(t), cfg), root, sw);
		return sw.toString();
	}

	public static String freemarker(Template t, Map root) throws Exception
	{
		StringWriter sw = new StringWriter();
		freemarker(t, root, sw);
		return sw.toString();
	}

	public static Map freemarker(Map root, IMessage msg)
	{
		root = freemarker(root);
		if (msg == null) return root;
		ICompositeNode transaction = msg.getTransaction();
		ICompositeNode request = transaction.findComposite(IMessage.PATH_REQUEST,
				new CompositeNode());
		ICompositeNode response = transaction.findComposite(IMessage.PATH_RESPONSE,
				new CompositeNode());
		root.put(Common.MODEL_MSG, transaction);
		root.put(Common.MODEL_XML, transaction);
		root.put(Common.MODEL_MSG_REQUEST, request);
		root.put(Common.MODEL_MSG_RESPONSE, response);
		root.put(Common.MODEL_MSG_OBJ, msg);
		root.put(Common.MODEL_MSG_SN, msg.getMsgSn());
		root.put(Common.MODEL_MSG_CD, msg.getMsgCd());
		root.put(Common.MODEL_MSG_LOCAL, msg.getLocal());
		root.put(Common.MODEL_MSG_ATTR, msg.getAttr());
		root.put(Common.MODEL_MSG_LOCAL_BPL_VARS, msg.getInLocal(MsgLocalKey.LOCAL_BPL_VARIABLES));
		IMessage pmsg = (IMessage) msg.getInLocal(MsgLocalKey.LOCAL_PARENT_MSG);
		if (pmsg != null)
		{
			root.put(Common.MODEL_PARENT_MSG, pmsg.getTransaction());
			root.put(Common.MODEL_MSG_PREQUEST, pmsg.getRequest());
			root.put(Common.MODEL_MSG_PRESPONSE, pmsg.getResponse());
		}
		return root;
	}

	public static Map freemarker(Map root)
	{
		if (root == null) root = new HashMap();
		// root.put(Common.MODEL_SERVICE_KEY,
		// SystemUtil.getInstance().getServices());
		root.put(Common.MODEL_SERVICE_KEY, IService.SERVICES_PROXY);
		root.put(Common.MODEL_ROOT_KEY, root);
		root.put(Common.MODEL_STATICS_KEY, BeansWrapper.getDefaultInstance().getStaticModels());
		root.put(Common.MODEL_ENUMS_KEY, BeansWrapper.getDefaultInstance().getEnumModels());
		root.put(Common.MODEL_SUI_KEY, ISessionUserInfo.SUI.get());
		root.put(Common.MODEL_APP_CFG_KEY, AppConfig.getInstance().getConfig());
		root.put(Common.MODEL_SYS_UTIL_KEY, SystemUtil.getInstance());
		root.put(Common.MODEL_FILE_UTIL_KEY, FileUtil.getInstance());
		root.put(Common.MODEL_JSON_UTIL_KEY, JsonUtil.getInstance());
		// root.put(Common.MODEL_REPORT_UTIL_OLD_KEY, ReportUtil.getInstance());
		root.put(Common.MODEL_REPORT_UTIL_KEY, ReportUtil.getInstance());
		root.put(Common.MODEL_STRINGX_KEY, StringX.STRINGX);
		root.put(Common.MODEL_DICT_KEY, DictMessageSource.getInstance().getDict());
		root.put(Common.MODEL_APPMS, AppMessageSource.getInstance().getDict());
		root.put(Common.MODEL_CALENDAR, Calendar.getInstance());
		return root;
	}

	public static Writer freemarker(Template t, Map root, Writer writer) throws Exception
	{
		t.process(freemarker(root), writer);
		return writer;
	}

	public static String ftl(String id, Map root) throws Exception
	{
		StringWriter sw = new StringWriter();
		freemarker(id, root, sw);
		return sw.toString();
	}

	public static Writer freemarker(String templateId, Map root, Writer writer) throws Exception
	{
		Template t = (Template) getInstance().ftlCache.get(templateId);
		if (t == null) t = getInstance().getFtlCfg().getTemplate(templateId + ".ftl");
		return freemarker(t, root, writer);
	}

	// 2012-09-01 for FTL �ж�һ�������Ƿ�ΪMap����
	public static boolean isMap(Object o)
	{
		return o instanceof Map;
	}

	public static boolean isList(Object o)
	{
		return o instanceof List;
	}

	public void initFreemarkerConf() throws Exception
	{
		if (templateLocations == null) return;
		if (ftlCfg == null)
		{
			ftlCfg = new Configuration();
			ftlCfg.setDefaultEncoding(Common.CHARSET_UTF8);
		}
		ftlCfg.setNumberFormat("0"); // 2012-09-01 ��������������ֵ${age}����1000�����������
		List loaders = new ArrayList();
		try
		{ // ��Щ��web�����, ����Ҫspring��������Ϣ
			loaders.add(new ClassTemplateLoader(FreeMarkerConfigurer.class, StringX.EMPTY_STRING));
		}
		catch (Throwable t)
		{
		}
		loaders.add(new ClassTemplateLoader(SystemUtil.class, "/"));
		// class path �µ�ģ��
		for (int i = 0; i < templateLocations.size(); i++)
		{
			String location = (String) templateLocations.get(i);
			Resource path = resourceLoader.getResource(location);
			File file = path.getFile();
			loaders.add(new FileTemplateLoader(file));
		}
		MultiTemplateLoader mtl = new MultiTemplateLoader(
				(TemplateLoader[]) loaders.toArray(new TemplateLoader[loaders.size()]));
		ftlCfg.setTemplateLoader(mtl);
		ftlCfg.setObjectWrapper(new DefaultObjectWrapper());
		// ���ʱ��ģ�������µ�ʱ����, ����Ϊ��λ ����������,��ʱ��������ô�����6*60*60(S), ����ʱ���������С�����2(S),
		// default is 5 s
		if (log.isInfoEnabled()) log.info("product: " + AppConfig.isProductMode()
				+ " for set ftl update_daly...");
		ftlCfg.setSetting(Configuration.TEMPLATE_UPDATE_DELAY_KEY,
				AppConfig.isProductMode() ? "999999999" : "0");
	}

	// bsh start...
	Map bshCache = new HashMap();

	public void setBshCache(Map cache)
	{
		bshCache = (cache == null ? new HashMap() : cache);
	}

	public Map loadBshInDB() throws Exception
	{
		Map cache = new HashMap();
		List bshs = null;
		try
		{
			bshs = Persistence.getInstance().get(new BshVO());
		}
		catch (Exception e)
		{
			log.info("fail to load Bsh in DB:" + e);
		}
		if (bshs == null) return cache;
		for (int i = 0; i < bshs.size(); i++)
		{
			BshVO vo = (BshVO) bshs.get(i);
			Interpreter inter = new Interpreter();
			inter.eval("Object bsh(java.util.Map params){" + vo.getBsh() + "}");
			cache.put(vo.getId(), inter);
		}
		if (log.isInfoEnabled()) log.info("Bsh in DB: " + cache.keySet());
		setBshCache(cache);
		return cache;
	}

	public static Object exeBsh(String id, Map params) throws Exception
	{
		Interpreter inter = (Interpreter) getInstance().bshCache.get(id);
		if (inter == null) return null;
		synchronized (inter)
		{ // 702_20140121��֤�̰߳�ȫ
			inter.set("params", params);
			inter.eval("Object ret = bsh(params);");
			return inter.get("ret");
		}
	}

	public static Interpreter bsh(String script, Map params) throws Exception
	{
		return bsh(new Interpreter(), script, params);
	}

	public static Interpreter bsh(Interpreter inter, String script, Map params) throws Exception
	{
		inter.setClassLoader(Thread.currentThread().getContextClassLoader());
		if (params != null)
		{
			Iterator keys = params.keySet().iterator();
			while (keys.hasNext())
			{
				String key = keys.next().toString();
				inter.set(key, params.get(key));
			}
		}
		if (!StringX.nullity(script)) inter.eval(script);
		return inter;
	}

	// bsh end...

	// ����������ˮ�ŵĻ�������֤һ��jvm��ÿ�λ��һ��Ψһ��15λ��ʱ�ӱ��
	public synchronized String getTimeSN()
	{
		long time = System.currentTimeMillis();
		if (time <= LAST_TIME) time = LAST_TIME + 1; // �����ǰʱ�����һʱ����ͬһ���룬�������������һ����
		LAST_TIME = time;
		return new SimpleDateFormat(DF_SN15).format(new Date(time));
	}

	public synchronized static String getTimeSN(int num)
	{
		long time = System.currentTimeMillis();
		if (time <= LAST_TIME) time = LAST_TIME + 1; // �����ǰʱ�����һʱ����ͬһ���룬�������������һ����
		LAST_TIME = time;
		String str = String.valueOf(time);
		return num > str.length() ? str : str.substring(str.length() - num);
	}

	/**
	 * ����һ��Ψһ��32λ��ˮ�� XXX(3λϵͳ����)+ XX(2λ���������,�൱��ģ����߼�Ⱥ����ģʽ�µĸ��������)+
	 * XXXX(6λ�ڲ��ţ�����C���Ի����µĽ��̺�)+ XXXX(4λ�����,������Ϣ)+ yyyyMMddhhmmssSSS(17Ϊ���뼶��ʱ��)
	 * 
	 * @return
	 */
	public String genSN()
	{
		String sn = JVM + getTimeSN() + random(16);
		return sn.substring(0, 32);
	}

	public String genSN(int num)
	{
		String sn = JVM + (num >= 24 ? getCurrentDate(DF_APP6) + getTimeSN(8) : getTimeSN(8));
		if (sn.length() < num) sn += random(num - sn.length());
		return sn.substring(0, num);
	}

	// �������ַ���
	public static String random(int len)
	{
		String random = String.valueOf(Math.random()).substring(2)
				+ String.valueOf(Math.random()).substring(2);
		random = random.replaceAll("E", StringX.EMPTY_STRING).replaceAll("-", StringX.EMPTY_STRING);
		return len > random.length() ? random : random.substring(random.length() - len);
	}

	public static String getLocalHostIP()
	{
		return LOCAL_HOST_IP;
	}

	public void setApplicationContext(ApplicationContext appCxt)
	{
		APPCXT = appCxt;
	}

	public ApplicationContext getAppCxt()
	{
		return APPCXT;
	}

	public static String getMessage(String code, String defaultMessage)
	{
		return getMessage(code, null, defaultMessage, null);
	}

	public static String getMessage(String code, Object[] args, String defaultMessage)
	{
		return getMessage(code, args, defaultMessage, null);
	}

	public static String getMessage(String code, List args, String defaultMessage)
	{
		return getMessage(code, (args != null ? args.toArray() : null), defaultMessage, null);
	}

	public static String getMessage(String code, Object[] args, Locale locale)
	{
		return getMessage(code, args, null, locale);
	}

	public static String getMessage(String code, Object[] args, String def, Locale locale)
	{
		if (StringX.nullity(def)) def = StringX.getMessageFormat(args == null ? 0 : args.length);
		try
		{
			return APPCXT.getMessage(code, args, def, locale);
		}
		catch (Exception e)
		{
			// e.printStackTrace();
			log.warn("Fail to get error desc for " + code, e);
		}
		return new MessageFormat(def).format(args);
	}

	public static String getMessage(String path, String code, Object[] args, Locale locale)
	{
		String sep = StringX.COMMA;
		if (code.indexOf(sep) < 0) return APPCXT.getMessage(path + AppMessageSource.SEPARATOR
				+ code, args, locale);
		// ���ڶ�ѡ
		StringBuffer buf = new StringBuffer();
		String[] ccode = StringX.split(code, sep);
		for (int i = 0; i < ccode.length; i++)
		{
			if (buf.length() > 0) buf.append(sep);
			buf.append(APPCXT
					.getMessage(path + AppMessageSource.SEPARATOR + ccode[i], args, locale));
		}
		// System.out.println(buf);
		return buf.toString();
	}

	/**
	 * ͨ���쳣����һ����Ϣ״̬
	 * 
	 * @param prefix
	 *            ��Ϣ����ǰ׺
	 * @param ex
	 *            �쳣
	 * @return
	 */
	public static Status ex2status(String prefix, Throwable ex)
	{
		Status status = new Status();
		if (!StringX.nullity(NODE)) status.setMbrCd(NODE);
		status.setAppCd(APP);
		status.setIp(SystemUtil.LOCAL_HOST_IP);
		String retCd = StringX.EMPTY_STRING;
		if (ex instanceof AppException)
		{ // ϵͳ����֪�쳣
			AppException appEx = (AppException) ex;
			if (log.isDebugEnabled())
			{
				Object[] args = appEx.getArgs();
				StringBuffer buf = new StringBuffer();
				for (int i = 0; args != null && i < args.length; i++)
					buf.append(args[i] + ",");
				log.debug("err,args:" + buf, ex);
			}
			if (appEx.getStatus() != null)
			{ // �쳣���Ѿ����б�׼���쳣��Ϣ
				if (log.isDebugEnabled()) log.debug("appEx status: " + appEx.getStatus());
				return appEx.getStatus();
			}
			retCd = appEx.getCode();
			// status.setRetCd(appEx.getCode());
			if (!StringX.nullity(appEx.getDefErrMsg()))
			{ // ���������Ĭ����Ϣ��ʹ��Ĭ��
				status.setDesc(appEx.getDefErrMsg());
			}
			else if (StringX.nullity(appEx.getCode())
					|| AppRetCode.CMM_BIZ_ERR().equals(appEx.getCode()))
			{ // ���������ͨ��ҵ�������ʹ��Ĭ����Ϣ
				retCd = AppRetCode.CMM_BIZ_ERR();
				// status.setRetCd(AppRetCode.CMM_BIZ_ERR);
				status.setDesc(appEx.getDefErrMsg());
			}
			else if (ex instanceof MsgErrException) status.setDesc(prefix
					+ ((MsgErrException) ex).getErrors().getErrDesc());
			else if (StringX.nullity(appEx.getMsgFormat()))
			{ // ����쳣û������Ϣ����ģ���ʽʹ�ø��ݷ����뵽���ݿ���Ѱ�Ҹ�ʽ
				status.setDesc(prefix
						+ getMessage(SystemUtil.RETCD_PATH + retCd, appEx.getArgs(),
								appEx.getDefErrMsg(), null));
			}
			else
			{ // ����쳣��ָ����msgformat
				status.setDesc(prefix
						+ new MessageFormat(appEx.getMsgFormat()).format(appEx.getArgs()));
			}
			status.setLocation(JVM() + "::" + appEx.getLocation());
		}
		else
		{ // δ֪�쳣
			log.warn("undef ex, prefix:" + prefix, ex);
			retCd = (ex instanceof NullPointerException) ? AppRetCode.CMMN_NULLPOINT_EX
					: AppRetCode.CMMN_UNDEF_EX;
			String desc = ex.toString() + StringX.stackTrace(ex.getStackTrace(), 5);
			if (desc.length() > 900) desc = desc.substring(0, 900);
			if (desc.startsWith("java.lang.Exception")) desc = desc.substring(20);
			if (StringX.isContainCN(desc)) retCd = AppRetCode.CMM_BIZ_ERR(); // ����쳣�к�������,����Ϊ��ͨ��ҵ�����
			status.setDesc(prefix + desc);
			status.setLocation(JVM() + "::" + AppException.getLocation(ex.getStackTrace()));
		}
		status.setRetCd(retCd);
		return status;
	}

	// ����spring����
	public static synchronized ApplicationContext load(String[] files) throws Exception
	{
		if (APPCXT != null)
		{
			log.info("spring context has been loaded...");
			return APPCXT;
		}
		log.info("start to load spring context in classpath:"
				+ Thread.currentThread().getContextClassLoader().getResource(StringX.EMPTY_STRING)
						.getFile());
		APPCXT = new ClassPathXmlApplicationContext(files);
		SystemUtil.loadAutowireBeans(); // 804_20150315 �Զ�װ��bean, MB�в����Զ�����bean
		Runtime.getRuntime().addShutdownHook(hook = new Thread()
		{
			public void run()
			{
				log.warn("ShutdownHook: jvm will halt...");
				if (SystemUtil.getInstance().getAppCxt() == null) return;
				try
				{
					SystemUtil.unload();
				}
				catch (Exception e)
				{
					log.warn("unload context for jvm halt...", e);
				}
			}
		});
		return APPCXT;
	}

	// 715_201011 ��̬��ǰspring context����һ��bean����
	public static String SPRING_BEAN_PREFIX = "<beans xmlns=\"http://www.springframework.org/schema/beans\" "
			+ "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:p=\"http://www.springframework.org/schema/p\" "
			+ "xmlns:context=\"http://www.springframework.org/schema/context\" xmlns:util=\"http://www.springframework.org/schema/util\" "
			+ "xsi:schemaLocation=\"http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans-3.0.xsd http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context-3.0.xsd http://www.springframework.org/schema/util http://www.springframework.org/schema/util/spring-util-3.0.xsd\">";

	static Map beanCache = new HashMap(); // 801_20150115

	// 801_20150115
	public static Map loadBeanInDB() throws IOException
	{
		Map cache = new HashMap();
		List beans = null;
		try
		{
			beans = Persistence.getInstance().get(new BeanVO());
		}
		catch (Exception e)
		{
			log.info("fail to load Bean in DB:" + e);
		}
		if (beans == null) return cache;
		for (int i = 0; i < beans.size(); i++)
		{
			BeanVO vo = (BeanVO) beans.get(i);
			cache.put(vo.getId(), vo.getBean());
		}
		if (log.isInfoEnabled()) log.info("Bean in DB: " + cache.keySet());
		return beanCache = cache;
	}

	public static void loadXMLBean(String beanXML) throws Exception
	{
		log.info("bean xml:" + beanXML);
		if (StringX.nullity(beanXML)) return;
		XmlBeanDefinitionReader xbdr = new XmlBeanDefinitionReader(
				(BeanDefinitionRegistry) ((ConfigurableApplicationContext) APPCXT).getBeanFactory());
		xbdr.setResourceLoader(APPCXT);
		xbdr.setEntityResolver(new ResourceEntityResolver(APPCXT));
		beanXML = SPRING_BEAN_PREFIX + beanXML + "</beans>";
		xbdr.loadBeanDefinitions(new ByteArrayResource(beanXML.getBytes(Common.CHARSET_UTF8)));
	}

	public static void registerBeans()
	{ // ��Ҫ����spring�е�bean
		String[] beans = ((ConfigurableApplicationContext) APPCXT).getBeanDefinitionNames();
		for (int i = 0; i < beans.length; i++)
			APPCXT.getBean(beans[i]);
	}

	public static void loadBean(String[] location) throws Exception
	{
		log.info("bean xml location:" + location);
		XmlBeanDefinitionReader xbdr = new XmlBeanDefinitionReader(
				(BeanDefinitionRegistry) ((ConfigurableApplicationContext) APPCXT).getBeanFactory());
		xbdr.setResourceLoader(APPCXT);
		xbdr.setEntityResolver(new ResourceEntityResolver(APPCXT));
		xbdr.loadBeanDefinitions(location);
	}

	public static synchronized void loadBean(String beanId) throws Exception
	{
		log.info("load bean id:" + beanId + " in sys_bean or esb_config");
		String beanXML = (String) beanCache.get(beanId); // 801_20150115���ȼ������ݿ��������
		if (beanXML == null) beanXML = (String) AppConfig.getInstance().getProperty(
				Config.SPRING_BEAN + "." + beanId, null);
		loadXMLBean(beanXML);
	}

	public Object loadBean(String beanId, Class clazz)
	{
		Object bean = getBean(beanId, clazz);
		if (bean != null) return bean;
		synchronized (APPCXT)
		{ // �Ӻ�ͬ���㣬�������
			bean = getBean(beanId, clazz);
			if (bean != null) return bean;
			try
			{
				loadBean(beanId);
				return getBean(beanId, clazz);
			}
			catch (Throwable t)
			{
				log.error("fail to load bean: " + beanId, t);
			}
		}
		return null;
	}

	public static void loadAutowireBeans() throws Exception
	{ // 715_20141015 �Զ�װ��bean
		log.info("load autowireBeans:" + autowireBeans);
		if (StringX.nullity(autowireBeans)) return;
		String[] beanIds = StringX.split(autowireBeans, StringX.COMMA);
		for (int i = 0; i < beanIds.length; i++)
			loadBean(beanIds[i]);
		registerBeans();
	}

	// 715 end

	static Thread hook;

	// ж��spring����
	public static synchronized void unload() throws Exception
	{
		if (APPCXT == null)
		{
			log.debug("app spring context is null!!!");
			return;
		}
		log.warn(SystemUtil.getInstance().getCurrentDate(SystemUtil.DF_SALL17) + " JVM("
				+ SystemUtil.JVM + ") App(" + SystemUtil.APP + ") spring context unload...");
		try
		{
			APPCXT.publishEvent(new ContextStoppedEvent(APPCXT));
		}
		finally
		{
			APPCXT = null;
		}
	}

	// ����jvm��Ϣ
	public static void debugJvm()
	{
		log.info("Booting JVM...webos version:" + Common.VERSION() + ", version date:"
				+ Common.VERSION_DATE() + ", webapp.root: "
				+ System.getProperty(Common.WEBAPP_ROOT_PATH_KEY));
		if (log.isDebugEnabled())
		{
			Iterator keys = System.getProperties().keySet().iterator();
			while (keys.hasNext())
			{
				String key = keys.next().toString();
				if (key.startsWith("java")) log.debug(key + ":"
						+ System.getProperties().getProperty(key));
			}
		}
	}

	public static void invoke(String[] beanMethods)
	{
		if (log.isDebugEnabled()) log.debug("start to invoke: " + beanMethods);
		for (int i = 0; i < beanMethods.length; i++)
		{
			int index = beanMethods[i].indexOf('.');
			String beanId = beanMethods[i].substring(0, index);
			Object target = SystemUtil.getInstance().getBean(beanId, null);
			if (target == null) continue;
			Method method = findMethod(beanMethods[i]);
			try
			{
				if (log.isDebugEnabled()) log.debug("start to invoke:" + beanMethods[i]);
				method.invoke(target, null);
			}
			catch (Exception e)
			{
				log.warn("fail to invoke: " + beanMethods[i], e);
			}
		}
	}

	public static Method findMethod(String beanMethod)
	{
		int index = beanMethod.indexOf('.');
		return findMethod(beanMethod.substring(0, index), beanMethod.substring(index + 1));
	}

	public static Method findMethod(String beanId, String method)
	{
		Object target = SystemUtil.getInstance().getBean(beanId, null);
		if (target == null) return null;
		Method[] candidates = target.getClass().getMethods();
		for (int i = 0; i < candidates.length; i++)
		{
			Method candidate = candidates[i];
			if (candidate.getName().equals(method))
			{
				Class[] paramTypes = candidate.getParameterTypes();
				if (paramTypes.length == 0) return candidate;
			}
		}
		return null;
	}

	public String getCurrentDate(String format)
	{
		return new SimpleDateFormat(format).format(getCurrentDate());
	}

	public Date getCurrentDate()
	{
		return systemTime == null ? new Date() : systemTime.current();
	}

	public static SystemUtil getInstance()
	{
		return SYSTEM_UTIL;
	}

	public static String relativePath2AbsolutePath(String dir) throws Exception
	{
		ResourceLoader resourceLoader = SYSTEM_UTIL.getResourceLoader();
		if (resourceLoader != null) return resourceLoader.getResource(StringX.null2emptystr(dir))
				.getFile().getAbsolutePath();
		return new File(Thread.currentThread().getContextClassLoader().getResource(dir).toURI())
				.getAbsolutePath();
	}

	protected Map springBeanCache = new Hashtable(200, 0.6f);

	public Object getBean(String beanId, Class clazz)
	{
		if (StringX.nullity(beanId)) return null;
		Object obj = springBeanCache.get(beanId);
		if (obj != null && (clazz == null || obj.getClass() == clazz)) return obj;
		if (APPCXT == null)
		{
			log.fatal("appCxt is null!!!");
			return null;
		}
		try
		{
			obj = clazz == null ? APPCXT.getBean(beanId) : APPCXT.getBean(beanId, clazz);
		}
		catch (NoSuchBeanDefinitionException nsbde)
		{
			if (log.isDebugEnabled()) log.debug("cannot load bean in spring cxt for bean id: "
					+ beanId
					+ (clazz != null ? ", class: " + clazz.getName() : StringX.EMPTY_STRING));
		}
		if (obj != null) springBeanCache.put(beanId, obj);
		return obj;
	}

	public void setResourceLoader(ResourceLoader resourceLoader)
	{
		this.resourceLoader = resourceLoader;
	}

	protected ResourceLoader resourceLoader;
	final static SystemUtil SYSTEM_UTIL = new SystemUtil();

	public ResourceLoader getResourceLoader()
	{
		return resourceLoader;
	}

	static
	{
		try
		{
			LOCAL_HOST_IP = NetworkInfo.getLocalHost();
			if (LOCAL_HOST_IP == null) LOCAL_HOST_IP = StringX.EMPTY_STRING;
			// ��ֹIP��ַ����
			if (LOCAL_HOST_IP.length() > 15) LOCAL_HOST_IP = LOCAL_HOST_IP.substring(0, 15);
			// MAC = NetworkInfo.getMacAddress();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public String getApp()
	{
		return APP;
	}

	public void setApp(String app)
	{
		APP = app;
	}

	public void setFtsAgent(String ftsAgent)
	{
		FTS_AGENT = ftsAgent;
	}

	public String getJvm()
	{
		return JVM;
	}

	public void setJvm(String jvm)
	{
		JVM = jvm;
	}

	public void setJvmDesc(String jvmDesc)
	{
		JVMDESC = jvmDesc;
	}

	public String getNode()
	{
		return NODE;
	}

	public void setNode(String node)
	{
		NODE = node;
	}

	public void setSystemTime(ISystemTime systemTime)
	{
		this.systemTime = systemTime;
	}

	public void setTemplateLocations(List templateLocations)
	{
		this.templateLocations = templateLocations;
	}

	public void setTempfileDir(String tempfileDir)
	{
		TEMPFILE_DIR = tempfileDir;
	}

	public static File getTempfileDir() throws IOException
	{
		return SYSTEM_UTIL.getResourceLoader().getResource(TEMPFILE_DIR).getFile();
	}

	public static String JVM()
	{
		return JVM;
	}

	public static String getAutowireBeans()
	{
		return autowireBeans;
	}

	public void setAutowireBeans(String autowireBeans)
	{
		SystemUtil.autowireBeans = autowireBeans;
	}
}
