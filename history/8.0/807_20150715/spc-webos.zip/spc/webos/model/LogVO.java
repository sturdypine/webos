package spc.webos.model;

import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.util.Date;
import java.util.Map;

import spc.webos.util.StringX;

public class LogVO implements ValueObject
{
	private static final long serialVersionUID = 1L;
	Date dt;
	String clazz;
	String method;
	int line;
	String level;
	String throwable;
	String msg;

	// public final static String DEBUG = "DEB";
	// public final static String INFO = "INF";
	// public final static String WARN = "WAR";
	// public final static String ERROR = "ERR";
	// public final static String FATAL = "FAT";

	public LogVO()
	{
	}

	public LogVO(String level, Object msg, Throwable t)
	{
		dt = new Date();
		this.level = level;
		this.msg = msg != null ? msg.toString() : StringX.EMPTY_STRING;
		if (t != null)
		{
			try
			{
				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw, true);
				t.printStackTrace(pw); // ��Щ�����Ī������ı�nullpointexception, spc
				// 2010-05-28
				pw.flush();
				sw.flush();
				// if (sw.getBuffer().length() > 1000)
				// sw.getBuffer().setLength(1000);
				this.throwable = sw.toString();
			}
			catch (Exception e)
			{
				this.throwable = t.toString();
			}
		}
		if (throwable == null) throwable = StringX.EMPTY_STRING;
		StackTraceElement[] stack = new Throwable().getStackTrace();
		if (stack == null || stack.length < 3)
		{
			clazz = method = StringX.EMPTY_STRING;
			line = -1;
		}
		else
		{
			clazz = stack[2].getClassName();
			if (!clazz.startsWith("spc.webos.echain.log"))
			{
				method = stack[2].getMethodName();
				line = stack[2].getLineNumber();
			}
			else
			{
				clazz = stack[5].getClassName();
				method = stack[5].getMethodName();
				line = stack[5].getLineNumber();
			}
		}
	}

	public Date getDt()
	{
		return dt;
	}

	public void setDt(Date dt)
	{
		this.dt = dt;
	}

	public String getClazz()
	{
		return clazz;
	}

	public void setClazz(String clazz)
	{
		this.clazz = clazz;
	}

	public String getMethod()
	{
		return method;
	}

	public void setMethod(String method)
	{
		this.method = method;
	}

	public int getLine()
	{
		return line;
	}

	public void setLine(int line)
	{
		this.line = line;
	}

	public String getLevel()
	{
		return level;
	}

	public void setLevel(String level)
	{
		this.level = level;
	}

	public String getMsg()
	{
		return msg;
	}

	public void setMsg(String msg)
	{
		this.msg = msg;
	}

	public String getThrowable()
	{
		return throwable;
	}

	public void setThrowable(String throwable)
	{
		this.throwable = throwable;
	}

	public void afterLoad()
	{
		// TODO Auto-generated method stub

	}

	public void beforeLoad()
	{
		// TODO Auto-generated method stub

	}

	public String[] getBlobField()
	{
		// TODO Auto-generated method stub
		return null;
	}

	public Serializable getKey()
	{
		// TODO Auto-generated method stub
		return null;
	}

	public String getKeyName()
	{
		// TODO Auto-generated method stub
		return null;
	}

	public String getPrimary(String delim)
	{
		// TODO Auto-generated method stub
		return null;
	}

	public Map getPrimary()
	{
		// TODO Auto-generated method stub
		return null;
	}

	public String getTable()
	{
		// TODO Auto-generated method stub
		return null;
	}

	public void setManualSeq(Long seq)
	{
		// TODO Auto-generated method stub

	}

	public void setNULL()
	{
		// TODO Auto-generated method stub

	}

	public StringBuffer toJson()
	{
		// TODO Auto-generated method stub
		return null;
	}

	public int compareTo(Object arg0)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	public void destory()
	{
		// TODO Auto-generated method stub

	}

	public void init()
	{
		// TODO Auto-generated method stub

	}
}
