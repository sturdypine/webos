package spc.webos.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
* genarated by sturdypine.chen
* Email: sturdypine@gmail.com
* description: 
*/
public class MenuVO implements ValueObject
{
	public static final long serialVersionUID = 20100609L;
	// ����������Ӧ�ֶε�����
	String id; //  ����
	String text; // 
	String parentId; // 
	String className; // 
	String js; // 
	String mpath; // 
	String iconCls; // 
	String autorun;
	String lang; // ���ʻ�����

	// �ʹ�VO�����������VO����
	
	// �ʹ�VO�������������Sql����
	// Note: ���������Sql����ΪString, Inegter...��Java final classʱ�� ֻ��ʹ��Object���� ����ʱ��ֻ��ͨ��
	// Object��toString()������ʹ�á�
	public static final String TABLE = "sys_menu";
	public static final String[] BLOB_FIELD = null;
	public static final String SEQ_NAME = "id";

	
	public MenuVO()
	{
	}
	
	public void setPrimary(String id)
	{
		this.id = id;
	}
	
	public String getPrimary(String delim)
	{
		StringBuffer buf = new StringBuffer();
		buf.append(this.id);
		return buf.toString();
	}
	
	public Map getPrimary()
	{
		Map m = new HashMap();
		m.put("id", id);
		return m;
	}
	
	public String getTable()
	{
		return TABLE;
	}
	
	public String[] getBlobField()
	{
		return BLOB_FIELD;
	}
	
	public String getKeyName()
	{
		return SEQ_NAME;
	}
	
	public Serializable getKey()
	{
		return id;
	}
	
	// set all properties to NULL
	public void setNULL()
	{
    	this.id = null;
    	this.text = null;
    	this.parentId = null;
    	this.className = null;
    	this.js = null;
    	this.mpath = null;
    	this.iconCls = null;
	}
	
	public boolean equals(Object o)
	{
		if (this == o) return true;
		if (!(o instanceof MenuVO)) return false;
		MenuVO obj = (MenuVO) o;
		if (!id.equals(obj.id)) return false;
		if (!text.equals(obj.text)) return false;
		if (!parentId.equals(obj.parentId)) return false;
		if (!className.equals(obj.className)) return false;
		if (!js.equals(obj.js)) return false;
		if (!mpath.equals(obj.mpath)) return false;
		if (!iconCls.equals(obj.iconCls)) return false;
		return true;
	}
	
	// ֻ����������ɢ��
	public int hashCode()
	{
		long hashCode = getClass().hashCode();
		if (id != null) hashCode += id.hashCode();
		return (int)hashCode;
	}
	
	public int compareTo(Object o)
	{
		return -1;
	}

	// set all properties to default value...
	public void init()
	{
	}
	
    public String getId()
    {
        return id;
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public String getText()
    {
        return text;
    }
    
    public void setText(String text)
    {
        this.text = text;
    }
    
    public String getParentId()
    {
        return parentId;
    }
    
    public void setParentId(String parentId)
    {
        this.parentId = parentId;
    }
    
    public String getClassName()
    {
        return className;
    }
    
    public void setClassName(String className)
    {
        this.className = className;
    }
    
    public String getJs()
    {
        return js;
    }
    
    public void setJs(String js)
    {
        this.js = js;
    }
    
    public String getLang()
	{
		return lang;
	}

	public void setLang(String lang)
	{
		this.lang = lang;
	}

	public String getMpath()
    {
        return mpath;
    }
    
    public void setMpath(String mpath)
    {
        this.mpath = mpath;
    }
    
    public String getIconCls()
    {
        return iconCls;
    }
    
    public void setIconCls(String iconCls)
    {
        this.iconCls = iconCls;
    }
	
	public String getAutorun()
	{
		return autorun;
	}

	public void setAutorun(String autorun)
	{
		this.autorun = autorun;
	}

	public void set(MenuVO vo)
	{
    	this.id = vo.id;
    	this.text = vo.text;
    	this.parentId = vo.parentId;
    	this.className = vo.className;
    	this.js = vo.js;
    	this.mpath = vo.mpath;
    	this.iconCls = vo.iconCls;
	}
	
	public static long getSerialVersionUID()
	{
		return serialVersionUID;
	}
	
	public StringBuffer toJson()
	{
		StringBuffer buf = new StringBuffer();
		buf.append('{');
		if (id != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("id:'");
			buf.append(id);
			buf.append('\'');
		}
		if (text != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("text:'");
			buf.append(text);
			buf.append('\'');
		}
		if (parentId != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("parentId:'");
			buf.append(parentId);
			buf.append('\'');
		}
		if (className != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("className:'");
			buf.append(className);
			buf.append('\'');
		}
		if (js != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("js:'");
			buf.append(js);
			buf.append('\'');
		}
		if (mpath != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("mpath:'");
			buf.append(mpath);
			buf.append('\'');
		}
		if (iconCls != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("iconCls:'");
			buf.append(iconCls);
			buf.append('\'');
		}
		buf.append('}');
		return buf;
	}
	
	public void afterLoad()
	{
		// TODO Auto-generated method stub

	}

	public void beforeLoad()
	{
		// TODO Auto-generated method stub

	}

	public void setManualSeq(Long seq)
	{
		
	}
	
	public void destory()
	{

	}
	
	public String toString()
	{
		StringBuffer buf = new StringBuffer(128);
		buf.append(getClass().getName() + "(serialVersionUID=" + serialVersionUID + "):");
		buf.append(toJson());
		return buf.toString();
	}
}
