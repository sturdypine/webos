package spc.webos.acceptor.xsocket;

import java.net.InetAddress;
import java.util.HashMap;
import java.util.Map;

import org.xsocket.connection.INonBlockingConnection;

import spc.webos.log.Log;

/**
 * 751, ����һ���ͻ���IP���������������
 * 
 * @author chenjs
 * 
 */
public class MaxInstOfClient
{
	Log log = Log.getLogger(getClass());
	int maxInstC = 0;
	Map instances = new HashMap(); // ÿ������ʵ����Ӧ��IP��ַ���ͷ�����ʱ�޷����Զ��IP
	Map instOfClient = new HashMap();

	public MaxInstOfClient()
	{
	}

	public MaxInstOfClient(int maxInstC)
	{
		this.maxInstC = maxInstC;
	}

	public synchronized boolean onCnn(INonBlockingConnection cnn)
	{
		if (maxInstC <= 0) return true;
		InetAddress address = cnn.getRemoteAddress();
		String remoteIP = address.getHostAddress();
		Integer instOfC = (Integer) instOfClient.get(remoteIP);
		if (instOfC == null) instOfC = 0;
		if (instOfC >= maxInstC)
		{
			log.warn("Too many cnn:" + address + "#" + instOfC + "/" + maxInstC + "#"
					+ instOfClient.size() + "/" + instances.size());
			return false;
		}
		instances.put(cnn, remoteIP);
		instOfClient.put(remoteIP, instOfC + 1);
		log.info("ip:" + remoteIP + "#" + instOfC + "#" + instOfClient.size() + "/"
				+ instances.size());
		return true;
	}

	public synchronized void onDiscnn(INonBlockingConnection cnn)
	{
		if (maxInstC <= 0) return;
		String remoteIP = (String) instances.get(cnn);
		instances.remove(cnn);
		if (remoteIP == null)
		{
			log.info("cannot get remoteIP by " + cnn.getRemoteAddress());
			return;
		}

		Integer instOfC = (Integer) instOfClient.get(remoteIP);
		if (instOfC == null)
		{
			log.warn("instOfC is null by " + remoteIP);
			return;
		}
		if (instOfC <= 1) instOfClient.remove(remoteIP);
		else instOfClient.put(remoteIP, instOfC - 1);

		log.info("IP:" + remoteIP + "#" + instOfC + "#" + instOfClient.size() + "/"
				+ instances.size());
	}

	public synchronized void clear()
	{
		instOfClient.clear();
		instances.clear();
	}

	public int getMaxInstC()
	{
		return maxInstC;
	}

	public void setMaxInstC(int maxInstC)
	{
		this.maxInstC = maxInstC;
	}
}
