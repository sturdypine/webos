package spc.webos.acceptor;

/**
 * 715, ��ĳһ��tcp�˿ڽ�����Ϣ��ͳ��
 * 
 * @author chenjs
 * 
 */
public class Stat
{
	public long requestNum;
	public long responseNum;

	public synchronized void request()
	{
		requestNum++;
	}

	public synchronized void response()
	{
		responseNum++;
	}
}
