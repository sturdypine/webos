package spc.webos.web.common;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import spc.webos.model.UserVO;

public class SessionUserInfo implements ISessionUserInfo, Serializable, Cloneable
{
	private static final long serialVersionUID = 1L;
	// ����Ա������Ϣ
	// String instCd; // ��������
	// String account; // ����Ա����
	protected List role; // ��ɫID
	// ����Ա��½�Ŀͻ�����Ϣ
	protected String loginIP; // ��½��IP
	protected Date loginDt; // ��½ʱ��
	protected Date lastVisitDt; // ��һ�η��ʷ�����ʱ��
	protected String verifyCode;

	protected UserVO user;
	protected Map transientParams = new HashMap();
	protected Map permanence = new HashMap();
	// Integer screenWidth; // �ͻ�����ʾ������
	// Integer screenHeight; // �ͻ�����ʾ���߶�
	// String sessionID; // ���û���Session�е�Id
	protected String urlKey = String.valueOf(Math.random()).substring(2);

	transient HttpSession session; // ��ǰ�û���session
	transient HttpServletRequest request;
	transient HttpServletResponse response;

	public HttpServletRequest getRequest()
	{
		return request;
	}

	public void setRequest(HttpServletRequest request)
	{
		this.request = request;
	}

	public HttpServletResponse getResponse()
	{
		return response;
	}

	public void setResponse(HttpServletResponse response)
	{
		this.response = response;
	}

	public void setInPermanence(String key, Serializable value)
	{
		permanence.put(key, value);
	}

	public Object getInPermanence(String key)
	{
		return permanence.get(key);
	}

	public void setTransientInSession(String key, TransientInSession tis)
	{
		transientParams.put(key, tis);
	}

	public void setTransientInSession(String key, Serializable value)
	{
		transientParams.put(key, new TransientInSession(value));
	}

	public Object getTransient(String key)
	{
		TransientInSession tis = (TransientInSession) transientParams.get(key);
		return tis == null ? null : tis.getObj();
	}

	public TransientInSession getTransientInSession(String key)
	{
		return (TransientInSession) transientParams.get(key);
	}

	public void setVerifyCode(String verifyCode)
	{
		this.verifyCode = verifyCode;
	}

	public String getVerifyCode()
	{
		return this.verifyCode;
	}

	public String getLoginIP()
	{
		return loginIP;
	}

	public void setLoginIP(String loginIP)
	{
		this.loginIP = loginIP;
	}

	public String getUserCode()
	{
		return user == null ? null : user.getCode();
	}
	
	public String getOrgId()
	{
		return user == null ? null : user.getOrgId();
	}

	public List getUserRole()
	{
		return role;
	}

	public boolean containSqlId(String sqlId)
	{
		return true;
	}

	public void removeExpiredTransient()
	{
		if (this.transientParams.size() == 0) return;
		long currentTimeMillis = System.currentTimeMillis();
		Iterator iter = this.transientParams.keySet().iterator();
		while (iter.hasNext())
		{
			String key = (String) iter.next();
			TransientInSession tis = getTransientInSession(key);
			if (tis.isExpired(currentTimeMillis)) transientParams.remove(key);
		}
	}

	public String getUrlKey()
	{
		return urlKey;
	}

	public String getInstCd()
	{
		return "";
	}

	public List getRole()
	{
		return role;
	}

	public void setRole(List role)
	{
		this.role = role;
	}

	public HttpSession getSession()
	{
		return session;
	}

	public void setSession(HttpSession session)
	{
		this.session = session;
	}

	public Date getLoginDt()
	{
		return this.loginDt;
	}

	public void setLoginDt(Date loginDate)
	{
		this.loginDt = loginDate;
	}

	public Object getUser()
	{
		return user;
	}

	public void setUser(UserVO user)
	{
		this.user = user;
	}

	public Map getTransientParams()
	{
		return transientParams;
	}

	public void setTransientParams(Map transientParams)
	{
		this.transientParams = transientParams;
	}

	public Date getLastVisitDt()
	{
		return lastVisitDt;
	}

	public void setLastVisitDt(Date lastVisitDt)
	{
		this.lastVisitDt = lastVisitDt;
	}
}
