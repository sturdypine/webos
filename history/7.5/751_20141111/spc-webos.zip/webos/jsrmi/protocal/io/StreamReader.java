
package spc.webos.jsrmi.protocal.io;

/**
 * @author  lenovo
 */
public interface StreamReader {

	boolean hasMoreChildren();

	void moveDown();

	void moveUp();

	String getNodeName();

	String getValue();

	void close();

}
