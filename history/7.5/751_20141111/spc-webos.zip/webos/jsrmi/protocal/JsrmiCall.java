
package spc.webos.jsrmi.protocal;

public class JsrmiCall {

	private String methodName;
	private Object[] arguments;
	private Class[] argumentTypes;

	public JsrmiCall(String methodName, Object[] arguments) {
		this.methodName = methodName;
		this.arguments = arguments;
		
		Class[] types = new Class[this.arguments.length];
		for (int i = 0; i < arguments.length; i++) {
			types[i] = arguments[i].getClass();
		}
		this.argumentTypes = types;
	}

	public String getMethodName() {
		return this.methodName;
	}

	public Object[] getArguments() {
		return this.arguments;
	}
	
	public Class[] getArgumentTypes() {
		return argumentTypes;
	}
	
	public String toString() {
		if (arguments.length == 0) return methodName + "()";
		StringBuffer buffer = new StringBuffer();
		for (int i = 0; i < arguments.length; i++) {
			buffer.append(",");
			buffer.append(arguments[i]);
		}
		return methodName+"("+buffer.toString().substring(1)+")";
	}
	
}
