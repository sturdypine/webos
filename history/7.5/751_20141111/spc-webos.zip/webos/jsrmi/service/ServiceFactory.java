package spc.webos.jsrmi.service;

public interface ServiceFactory {
	
	/**
	 * Default implementation
	 */
	public static final String DEFAULT = "default";
	
	/**
	 * Spring implementation
	 */
	public static final String SPRING = "spring";	
	
	/**
	 * return a service instance based on the serviceId and the service name. 
	 * 
	 * @param serviceId the service key, such a loginService, dataService...
	 * @param serviceName the name, may be className by the default implementation, 
	 *        and the spring config bean name by the spring implementation
	 * @return service instance
	 * @throws NoSuchServiceException if serivice id not found
	 * @throws ServiceCreationFailException if service creation failed
	 */
	public Object getService(String serviceId, String serviceName) 
			throws NoSuchServiceException, ServiceCreationFailException;
}
