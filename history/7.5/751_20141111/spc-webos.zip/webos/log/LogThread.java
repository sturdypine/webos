package spc.webos.log;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import spc.webos.buffer.CommonBuffer;
import spc.webos.buffer.IBuffer;
import spc.webos.persistence.IPersistence;
import spc.webos.persistence.Persistence;
import spc.webos.thread.DaemonThread;
import freemarker.template.Configuration;
import freemarker.template.Template;

/**
 * <head><style
 * type=text/css>body{font-family:verdana,arial,helvetica,sans-serif
 * ;font-size:smaller
 * ;}h1{font-size:large;}tr{font-size:smaller;}th,td{border-left:1px solid
 * #000000;border-bottom:1px solid
 * #000000;padding:2px;}th{color:#000000;background
 * :#e9e9f2;}table{padding:0px;margin:0px;border-top:1px solid
 * #000000;border-right:1px solid
 * #000000;}table.info{color:#000000;background:#e9e9f2
 * ;}table.data{color:#000000
 * ;background:#ffffff;}td.label{text-align:right;}td.value
 * {font-weight:bold;}tr.
 * even{color:#000000;background:#ffffff;}tr.odd{color:#000000
 * ;background:#eeeeee;}</style></head>
 * 
 * @author chenjs
 * 
 */
public class LogThread extends Thread
{
	protected int status = DaemonThread.STOPPED;
	IBuffer buf;
	Template template;
	private boolean init;

	static Template DEF;
	static Template HTM_URL;
	static Template HTM_ESB;
	static Template TXT_URL;
	static Template TXT_ESB;
	static IPersistence persistence = Persistence.getInstance();
	public static long trans = 0; // ҵ����
	// public static boolean write2db = false; // �Ƿ�д��־�����ݿ�
	public static String DEF_TXT_PLAIN = "<#if (curLine==1)>\n\n</#if>[${r.dt?string('dd HH:mm:ss SSS')} ${r.level} ${r.clazz} ${r.method} ${r.line}] ${r.msg}<#if (r.throwable!='')>\n${r.throwable}</#if>";
	public static String DEF_TXT_URL = "<#if (curLine==1)>\n\n\n------------------------------------------------------------------------------------------------------\n----------------<#if (ext?exists)>Method: ${ext.method?default('')}  Url: ${ext.url?default('')} <#if (ext.SUI?exists&&ext.SUI.user?exists)>loginIP:${ext.SUI.loginIP?default('')} Code:${ext.SUI.user.code}</#if></#if>\n</#if>[${r.dt?string('dd HH:mm:ss SSS')} ${r.level} ${r.clazz} ${r.method} ${r.line}] ${r.msg}<#if (r.throwable!='')>\n${r.throwable}</#if>";
	public static String DEF_TXT_ESB = "<#if (curLine==1)>\n\n\n######## <#if ((ext?exists)&&(ext.msg?exists))>sn:${ext.msgSn?default('')}  msgCd:${ext.msgCd?default('')}  thread:${ext.THREADNAME?default('')} --------</#if>\n</#if>[${r.dt?string('dd HH:mm:ss SSS')} ${r.level} ${r.clazz} ${r.method} ${r.line}] ${r.msg}<#if (r.throwable!='')>\n${r.throwable}</#if>";
	public static String DEF_HTM_URL = "<#if (curLine==1)><table align=center width=98% cellpadding=5 cellspacing=0 style='margin-top:0px;border-width:1px;border-style:solid;border-color:black;'></#if><#if (curLine==1)><tr bgcolor=#FFCC99 height=30><td colspan=6 style='border-bottom: #000 1px solid;text-align:center'><#if (ext?exists)><b>Method</b> : ${ext.method?default('')}&nbsp;&nbsp;<b>Url</b> : ${ext.url?default('')}&nbsp;&nbsp;<#if (ext.SUI?exists&&ext.SUI.user?exists)><b>loginIP</b>:${ext.SUI.loginIP?default('')}&nbsp;&nbsp;<b>Code</b>:${ext.SUI.user.code}&nbsp;&nbsp;<br></#if></#if></#if><tr<#if (r.level=='ERR'||r.level=='FAT')> bgcolor=#ff00</#if>><td width=12% style='border-bottom: #CAECB2 1px solid;'>${r.dt?string('dd HH:mm:ss SSS')}<td width=4%  style='border-bottom: #CAECB2 1px solid;'>${r.level}<td width=28% style='border-bottom: #CAECB2 1px solid;word-break:break-all;'>${r.clazz}<td width=6% style='border-bottom: #CAECB2 1px solid;'>${r.method}<td width=5%  style='border-bottom: #CAECB2 1px solid;'>${r.line}<td  width=45% style='border-bottom: #CAECB2 1px solid; border-left: #CAECB2 1px solid;word-break:break-all;'>${r.msg?html}<#if (r.throwable!='')><tr><td colspan=6><b>${r.throwable}</#if><#if (lines==curLine)></table><br></#if>";
	public static String DEF_HTM_ESB = "<#if (curLine==1)><table align=center width=98% cellpadding=5 cellspacing=0 style='margin-top:0px;border-width:1px;border-style:solid;border-color:black;'></#if><#if (curLine==1)><tr bgcolor=#FFCC99 height=30><td colspan=6 style='border-bottom: #000 1px solid;text-align:center'><#if ((ext?exists)&&(ext.msg?exists))><b>SN</b>:${ext.sn?default('-')}&nbsp;&nbsp;<b>TransId</b>:${ext.msgCd?default('-')}&nbsp;&nbsp;<b>Thread</b>:${ext.THREADNAME?default('')}</#if></#if><tr<#if (r.level=='ERR'||r.level=='FAT')> bgcolor=#ff00</#if>><td width=12% style='border-bottom: #CAECB2 1px solid;'>${r.dt?string('dd HH:mm:ss SSS')}<td width=4%  style='border-bottom: #CAECB2 1px solid;'>${r.level}<td width=28% style='border-bottom: #CAECB2 1px solid;word-break:break-all;'>${r.clazz}<td width=6% style='border-bottom: #CAECB2 1px solid;'>${r.method}<td width=5%  style='border-bottom: #CAECB2 1px solid;'>${r.line}<td  width=45% style='border-bottom: #CAECB2 1px solid; border-left: #CAECB2 1px solid;word-break:break-all;'>${r.msg?html}<#if (r.throwable!='')><tr><td colspan=6><b>${r.throwable}</#if><#if (lines==curLine)></table><br></#if>";
	static Logger LOG = Logger.getLogger(LogThread.class);

	public LogThread()
	{
		setDaemon(true);
	}

	static
	{
		try
		{
			DEF = new Template("def", new StringReader(DEF_TXT_PLAIN), new Configuration());
			HTM_URL = new Template("hurl", new StringReader(DEF_HTM_URL), new Configuration());
			HTM_ESB = new Template("hesb", new StringReader(DEF_HTM_ESB), new Configuration());
			TXT_URL = new Template("turl", new StringReader(DEF_TXT_URL), new Configuration());
			TXT_ESB = new Template("tesb", new StringReader(DEF_TXT_ESB), new Configuration());
		}
		catch (Exception e)
		{
		}
	}

	public void init()
	{
		if (init)
		{
			LOG.warn("LogThread(" + getName() + ") has been init!!!");
			return;
		}
		if (buf == null) buf = new CommonBuffer(getName(), 100); // ���ϵͳ��û����LogThread��ô���ó�����־��ʽ
		if (template == null) template = TXT_ESB;
		this.start();
		init = true;
	}

	static synchronized long getTrans()
	{
		long t = System.currentTimeMillis();
		if (t > trans) trans = t;
		else trans++;
		return trans;
	}

	public void setTemplate(String t)
	{
		try
		{
			if (t != null) template = new Template("Log", new StringReader(t), new Configuration());
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		if (template == null) template = HTM_URL;
	}

	public static void print(Object[] objArr, Template template)
	{
		try
		{
			List content = (List) objArr[0]; // ��־����
			Logger log = (Logger) objArr[1]; // ��־����
			StringWriter sw = new StringWriter();
			Map root = new HashMap();
			root.put("lines", new Integer(content.size()));
			root.put("ext", objArr[2]);
			for (int i = 0; i < content.size(); i++)
			{
				sw.getBuffer().setLength(0);
				root.put("r", content.get(i));
				try
				{
					root.put("curLine", new Integer(i + 1));
					template.process(root, sw);
					log.error(sw.getBuffer());
				}
				catch (Throwable t)
				{
					LOG.error("LogThread.run.T", t);
				}
			}
		}
		catch (Throwable t)
		{
			LOG.error("LogThread.run.print", t);
		}
	}

	public void setPersistence(IPersistence persistence)
	{
		LogThread.persistence = persistence;
	}

	public IBuffer getBuf()
	{
		return buf;
	}

	public void setBuf(IBuffer buf)
	{
		this.buf = buf;
	}

	public Template getTemplate()
	{
		return template;
	}

	public void setTemplate(Template template)
	{
		this.template = template;
	}

	public void setType(int type)
	{
		if (type == 0) template = TXT_ESB;
		else if (type == 1) template = HTM_ESB;
		else if (type == 2) template = TXT_URL;
		else if (type == 3) template = HTM_URL;
		else template = DEF;
	}

	public void asynStop()
	{
		LOG.warn("log thread(" + getName() + ") will stop...");
		status = DaemonThread.STOPPED;
	}

	public void run()
	{
		status = DaemonThread.RUNNING;
		if (LOG.isInfoEnabled()) LOG.info("success to boot log thread: " + buf.getName());
		while (status == DaemonThread.RUNNING)
		{
			try
			{
				Object[] result = (Object[]) buf.remove();
				if (result != null) print(result, template);
			}
			catch (Throwable e)
			{
				LOG.error("LogThread.run", e);
			}
		}
		LOG.info("log thread(" + getName() + ") stopped...");
	}
}
