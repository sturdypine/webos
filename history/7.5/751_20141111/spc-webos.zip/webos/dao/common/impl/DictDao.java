package spc.webos.dao.common.impl;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import spc.webos.cache.ICache;
import spc.webos.dao.DbDataAccessObject;
import spc.webos.dao.common.DictDesc;
import spc.webos.dao.common.IDictDao;
import spc.webos.dao.common.OptionMap;

/**
 * �����ֵ��Dao...����ϵͳ�����ֵ����
 * 
 * @author Hate
 * 
 */
public class DictDao extends DbDataAccessObject implements IDictDao
{
	public DictDesc getDictDesc(String code)
	{
		Map paramMap = new HashMap(1);
		paramMap.put("cd", code);
		Map map = getVO(paramMap);
		return map == null ? null : (DictDesc) map.get(code);
	}

	public List getAllTableDesc()
	{
		return (List) this.persistence.execute("common.tableDesc", null);
	}

	public void getAllDictDescVO(ICache cache) throws Exception
	{
		OptionMap resultMap = getVO(new HashMap());
		Iterator keys = resultMap.keySet().iterator();
		while (keys.hasNext())
		{
			String key = (String) keys.next();
			cache.put(key, (Serializable) resultMap.get(key));
		}
	}

	OptionMap getVO(Map paramMap)
	{// "ddd.getDDD" Integer.intValue()
		List list = (List) persistence.execute(ddSqlId, paramMap);
		if (list == null || list.size() == 0) return null;
		paramMap.clear();
		OptionMap resultMap = new OptionMap();

		String zero = "0";
		for (int i = 0; i < list.size(); i++)
		{
			List row = (List) list.get(i);
			DictDesc vo = new DictDesc();
			String code = (String) row.get(0);
			resultMap.put(code, vo);
			String[] item = new String[row.size() - 2];
			item[0] = code;
			item[1] = (String) row.get(1);
			for (int j = 2; j < row.size() - 2; j++)
				item[j] = (String) row.get(j + 2);
			vo.setItem(item);
			// vo.setCode(code);
			// vo.setName(row.get(1).toString());
			// vo.setDefaultValue((String) (row.get(2)));
			// System.out.println(row);
			if (zero.equals(row.get(2).toString())) continue; // û���ӽڵ�

			paramMap.put("parentCd", row.get(0).toString());
			paramMap.put("tbType", row.get(3).toString());
			vo.setDict(getVO(paramMap));
		}
		return resultMap;
	}

	protected String ddSqlId = "common.getDD";

	public void setDdSqlId(String ddSqlId)
	{
		this.ddSqlId = ddSqlId;
	}
}
