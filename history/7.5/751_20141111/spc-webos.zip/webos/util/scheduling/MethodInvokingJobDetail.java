package spc.webos.util.scheduling;

import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.Scheduler;
import org.quartz.StatefulJob;
import org.springframework.beans.factory.BeanClassLoaderAware;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.support.ArgumentConvertingMethodInvoker;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;
import org.springframework.util.MethodInvoker;

import spc.webos.log.Log;
import spc.webos.util.StringX;

public class MethodInvokingJobDetail extends ArgumentConvertingMethodInvoker implements
		FactoryBean, BeanNameAware, BeanClassLoaderAware, BeanFactoryAware, InitializingBean
{
	private String name;
	private String group = Scheduler.DEFAULT_GROUP;
	private String targetBeanName;
	private boolean concurrent = true;
	private String[] jobListenerNames;
	private String beanName;
	private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
	private BeanFactory beanFactory;
	private JobDetail jobDetail;
	protected String logName;
	protected boolean threadLog = true; // added by chenjs 2011-12-20
	IJobExceptionHandler jobExceptionHandler = DefaultLogJobExHandler.getInstance();
	public final static Log log = Log.getLogger(MethodInvokingJobDetail.class);

	public void setJobExceptionHandler(IJobExceptionHandler jobExceptionHandler)
	{
		this.jobExceptionHandler = jobExceptionHandler;
	}

	public void setLogName(String logName)
	{
		this.logName = logName;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public void setGroup(String group)
	{
		this.group = group;
	}

	public void setTargetBeanName(String targetBeanName)
	{
		this.targetBeanName = targetBeanName;
	}

	public void setJobListenerNames(String[] names)
	{
		this.jobListenerNames = names;
	}

	public void setBeanName(String beanName)
	{
		this.beanName = beanName;
	}

	public void setBeanClassLoader(ClassLoader classLoader)
	{
		this.beanClassLoader = classLoader;
	}

	public void setBeanFactory(BeanFactory beanFactory)
	{
		this.beanFactory = beanFactory;
	}

	protected Class resolveClassName(String className) throws ClassNotFoundException
	{
		return ClassUtils.forName(className, this.beanClassLoader);
	}

	public void afterPropertiesSet() throws ClassNotFoundException, NoSuchMethodException
	{
		prepare();
		String name = (this.name != null ? this.name : this.beanName);
		Class jobClass = (this.concurrent ? (Class) MethodInvokingJob.class
				: StatefulMethodInvokingJob.class);
		this.jobDetail = new JobDetail(name, this.group, jobClass);
		this.jobDetail.getJobDataMap().put("methodInvoker", this);
		this.jobDetail.setVolatility(true);
		this.jobDetail.setDurability(true);
		if (this.jobListenerNames != null)
		{
			for (int i = 0; i < this.jobListenerNames.length; i++)
			{
				this.jobDetail.addJobListener(this.jobListenerNames[i]);
			}
		}

		postProcessJobDetail(this.jobDetail);
	}

	protected void postProcessJobDetail(JobDetail jobDetail)
	{
	}

	public Class getTargetClass()
	{
		Class targetClass = super.getTargetClass();
		if (targetClass == null && this.targetBeanName != null)
		{
			Assert.state(this.beanFactory != null,
					"BeanFactory must be set when using 'targetBeanName'");
			targetClass = this.beanFactory.getType(this.targetBeanName);
		}
		return targetClass;
	}

	public Object getTargetObject()
	{
		Object targetObject = super.getTargetObject();
		if (targetObject == null && this.targetBeanName != null)
		{
			Assert.state(this.beanFactory != null,
					"BeanFactory must be set when using 'targetBeanName'");
			targetObject = this.beanFactory.getBean(this.targetBeanName);
		}
		return targetObject;
	}

	public Object getObject()
	{
		return this.jobDetail;
	}

	public Class getObjectType()
	{
		return JobDetail.class;
	}

	public boolean isSingleton()
	{
		return true;
	}

	public void setThreadLog(boolean threadLog)
	{
		this.threadLog = threadLog;
	}

	public boolean isConcurrent()
	{
		return concurrent;
	}

	public void setConcurrent(boolean concurrent)
	{
		this.concurrent = concurrent;
	}

	public static class MethodInvokingJob extends QuartzJobBean
	{
		protected static final Log log = Log.getLogger(MethodInvokingJob.class);
		private MethodInvoker methodInvoker;

		public void setMethodInvoker(MethodInvoker methodInvoker)
		{
			this.methodInvoker = methodInvoker;
		}

		protected void executeInternal(JobExecutionContext context) throws JobExecutionException
		{
			MethodInvokingJobDetail invoker = (MethodInvokingJobDetail) methodInvoker;
			if (!StringX.nullity(invoker.logName)) Log.start(invoker.logName, invoker.threadLog);
			try
			{
				if (log.isInfoEnabled()) log.info("start to job, target:"
						+ methodInvoker.getTargetClass().getName() + "."
						+ methodInvoker.getTargetMethod());
				methodInvoker.invoke();
			}
			catch (Throwable t)
			{
				if (invoker.jobExceptionHandler != null) invoker.jobExceptionHandler.handle(
						invoker, t);
				else log.warn("no jobExceptionHandler", t);
			}
			finally
			{
				if (log.isInfoEnabled()) log.info("end to job...\n\n");
				if (!StringX.nullity(invoker.logName)) Log.print();
				Log.printNotice();
			}
		}
	}

	public static class StatefulMethodInvokingJob extends MethodInvokingJob implements StatefulJob
	{
	}
}
