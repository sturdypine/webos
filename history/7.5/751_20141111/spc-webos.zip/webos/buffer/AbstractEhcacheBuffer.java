package spc.webos.buffer;

import java.util.List;

import net.sf.ehcache.Cache;

public abstract class AbstractEhcacheBuffer extends AbstractBuffer
{
	protected Cache cache;
	public static final int DEFAULT_CAP = 5000;

	public AbstractEhcacheBuffer()
	{
	}

	public AbstractEhcacheBuffer(String name)
	{
		this(name, DEFAULT_CAP);
	}

	public AbstractEhcacheBuffer(String name, int cap)
	{
		this.name = name;
		this.cap = cap;
	}

	public synchronized List removeAll()
	{
		cache.removeAll();
		notifyAll();
		return null;
	}

	public int size()
	{
		return cache.getSize();
	}

	public Object[] toArray()
	{
		return null;
	}

	public void setCache(Cache cache)
	{
		this.cache = cache;
	}
}
