package spc.webos.flownode.impl;

import java.util.ArrayList;
import java.util.List;

import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.flownode.IFlowContext;
import spc.webos.queue.QueueMessage;
import spc.webos.queue.ibmmq.MQCnnPool;
import spc.webos.queue.ibmmq.MQMessageUtil;
import spc.webos.queue.ibmmq.MQMultiChannel;

import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;

/**
 * ִ�������н���Ϣֱ�ӷ���ָ����MQ����
 * 
 * @author chenjs
 * 
 */
public class MQPutAFNode extends QueuePutAFNode
{
	protected void send(String qname, Object qmsg) throws Exception
	{
		multiChannel.sendCluster(qname, pmo, (MQMessage) qmsg, retryTimes, retryInterval);
	}

	protected Object getQMessage(IMessage msg, IFlowContext cxt) throws Exception
	{
		MQMessage mqmsg = (MQMessage) msg.getInLocal(MsgLocalKey.MQPUT_MQMSG_KEY);
		if (mqmsg != null) return mqmsg;
		QueueMessage qmsg = (QueueMessage) super.getQMessage(msg, cxt);
		// return qmsg.toMQMessage(new MQMessage());
		// modified by chenjs 2012-11-29 ֧��TLQ���Ƴ�QueueMessage�����MQMessage����
		return MQMessageUtil.toMQMessage(qmsg, new MQMessage());
	}

	protected MQPutMessageOptions pmo = new MQPutMessageOptions();
	protected int retryTimes = 1, retryInterval = 100;
	protected MQMultiChannel multiChannel = new MQMultiChannel();

	public void setRetryTimes(int retryTimes)
	{
		this.retryTimes = retryTimes;
	}

	public void setRetryInterval(int retryInterval)
	{
		this.retryInterval = retryInterval;
	}

	public void setCnnpool(MQCnnPool cnnpool)
	{
		multiChannel.cnnpools = new ArrayList<MQCnnPool>();
		multiChannel.cnnpools.add(cnnpool);
	}

	public void setCnnpools(List<MQCnnPool> cnnpools)
	{
		multiChannel.cnnpools = cnnpools;
	}

	public void setRandom(boolean random)
	{
		if (random) multiChannel.algorithm = 1;
	}

	public MQMultiChannel getMultiChannel()
	{
		return multiChannel;
	}

	public void setMultiChannel(MQMultiChannel multiChannel)
	{
		this.multiChannel = multiChannel;
	}
}
