package spc.webos.flownode.impl;

import java.util.ArrayList;
import java.util.List;

import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.flownode.util.AsynESBCallDelayTask;

/**
 * �첽ִ�нڵ�, for JBPM3AsynCFNode �ڵ�����ͼʹ��
 * 
 * @author spc
 * 
 */
public class AsynESBCallAFNode extends AbstractFNode
{
	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		if (log.isDebugEnabled()) log.debug("current msg is: " + msg.toXml(true));
		IMessage parent = (IMessage) msg.getInLocal(MsgLocalKey.LOCAL_PARENT_MSG);
		if (parent == null)
		{
			log.info("parent msg is null!!!");
			parent = msg;
		}

		// ��call ESB�������뵱ǰ��Ϣ����ʱ���������б���
		String qname = (mqPutAFNode == null ? this.qname : mqPutAFNode.getQname());
		if (log.isInfoEnabled()) log.info("add AsynESBCallDelayTask to parent: qname: " + qname);
		// ���ܵ�ǰ�����ǵ�һ�α�bpl��������ô��ǰ�̻߳�����msg����Ϊ������
		addDelayTask(new AsynESBCallDelayTask(msg, cxt, qname, mqPutAFNode));
		return null;
	}

	public static void addDelayTask(AsynESBCallDelayTask task)
	{
		List tasks = (List) DelayTasks.get();
		if (tasks == null) DelayTasks.set(tasks = new ArrayList());
		tasks.add(task);
	}

	public static List removeDelayTask()
	{
		List tasks = (List) DelayTasks.get();
		DelayTasks.set(null);
		return tasks;
	}

	protected MQPutAFNode mqPutAFNode;
	protected String qname;
	public static ThreadLocal DelayTasks = new ThreadLocal();

	public void setMqPutAFNode(MQPutAFNode mqPutAFNode)
	{
		this.mqPutAFNode = mqPutAFNode;
	}

	public String getQname()
	{
		return qname;
	}

	public void setQname(String qname)
	{
		this.qname = qname;
	}
}
