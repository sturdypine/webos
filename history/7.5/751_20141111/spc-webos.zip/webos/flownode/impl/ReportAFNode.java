package spc.webos.flownode.impl;

import java.io.StringWriter;

import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.data.converter.XMLConverter;
import spc.webos.flownode.IFlowContext;

/**
 * ����Ϣ�������ͨ�õĲ�ѯ���ܣ� ʹ��ftlģ�弼�������ڶ�̬�޸�
 * 
 * @author spc
 * 
 */
public class ReportAFNode extends FreeMarkerAFNode
{
	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		StringWriter sw = new StringWriter();
		before(msg, cxt);
		freemarker(msg, cxt, getTemplate(msg), getSqls(msg), sw, null);
		String result = sw.toString();
		msg.setInLocal(RPT_STR_KEY, result);
		ICompositeNode response = XMLConverter.getInstance().deserialize2composite(
				result.getBytes(charset));
		msg.setInLocal(RPT_MSG_KEY, response);
		msg.getResponse().set(response);
		after(msg, cxt);
		return null;
	}

	public final static String RPT_STR_KEY = ReportAFNode.class.getName() + "$RPT_STR";
	public final static String RPT_MSG_KEY = ReportAFNode.class.getName() + "$RPT_MSG";
}
