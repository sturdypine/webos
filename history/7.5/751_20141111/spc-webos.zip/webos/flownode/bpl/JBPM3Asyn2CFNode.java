package spc.webos.flownode.bpl;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jbpm.graph.def.Action;
import org.jbpm.graph.def.DelegationException;
import org.jbpm.graph.def.Event;
import org.jbpm.graph.def.Node;
import org.jbpm.graph.def.ProcessDefinition;
import org.jbpm.graph.exe.ProcessInstance;
import org.jbpm.graph.exe.Token;
import org.springframework.core.io.Resource;

import spc.webos.cache.ICache;
import spc.webos.config.AppConfig;
import spc.webos.constant.AppRetCode;
import spc.webos.constant.Common;
import spc.webos.constant.Config;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.AtomNode;
import spc.webos.data.IMessage;
import spc.webos.data.Status;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.data.converter.XMLConverter2;
import spc.webos.exception.AppException;
import spc.webos.flownode.IFlowContext;
import spc.webos.flownode.IFlowNode;
import spc.webos.flownode.action.IAfterAsynCall;
import spc.webos.flownode.impl.AbstractCFNode;
import spc.webos.flownode.impl.AsynESBCallAFNode;
import spc.webos.jdbc.blob.ByteArrayBlob;
import spc.webos.model.BPELInstanceVO;
import spc.webos.model.BPELNodeVO;
import spc.webos.model.BPELProcessDefinitionVO;
import spc.webos.persistence.IPersistence;
import spc.webos.util.FileUtil;
import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

/**
 * ��ʹ�����ݿ���Ϊ�첽�洢���ʣ���ʹ��cluster cache
 * 
 * @author chenjs
 * 
 */
public class JBPM3Asyn2CFNode extends AbstractCFNode
{
	public void flow(IMessage msg, IFlowContext cxt) throws Exception
	{
		ProcessInstance instance = null;
		IMessage parent = null;
		Status status = null;
		Map variables = new HashMap();
		BPELNodeVO nodeVO = null;
		BPELInstanceVO instanceVO = null;
		try
		{
			if (msg.isRequestMsg())
			{ // is a request message...
				parent = msg; // first create BPL. parent is current msg.
				instanceVO = new BPELInstanceVO();
				instance = createProcessInstance(msg, cxt, instanceVO);
			}
			else
			{ // is a response message...
				status = msg.getStatus();
				if (log.isInfoEnabled()) log.info("submsg status: " + status);
				instance = resumeProcessInstance(msg.getRefMsgSn(), cxt); // ʹ�õ�ǰ�ӱ��ĵ���ˮ�Ż�ȡ������Ϣ

				nodeVO = (BPELNodeVO) instance.getContextInstance().getVariable(
						INSTANCE_VAR_KEY_nodeVO); // ������ʵ�������л�ȡnodeVO
				instanceVO = (BPELInstanceVO) instance.getContextInstance().getVariable(
						INSTANCE_VAR_KEY_instanceVO); // ������ʵ�������л�ȡinstanceVO
				if (log.isDebugEnabled()) log.debug("PI vars: " + instanceVO + ",  " + nodeVO);

				// handle response msg to parent msg
				parent = converter.deserialize(instanceVO.getParentXml().bytes()); // �ָ�������״̬
				msg.setInLocal(MsgLocalKey.LOCAL_PARENT_MSG, parent);
				parent.setInLocal(MsgLocalKey.LOCAL_SUB_MSG, msg);

				// 2012-05-16 ��ǰ���̶����Ѿ��浱ǰ����ʵ���������л��ˡ�
				ProcessDefinition processDefinition = instance.getProcessDefinition();
				Node lastNode = processDefinition.getNode(nodeVO.getNode()); // ���һ��ִ�еĽڵ�
				if (lastNode == null) log.warn("lastNode(" + nodeVO.getNode() + ") is null!!!");
				else
				{ // �������첽���ã��õ����һ��ִ�еĽڵ㣬Ȼ��������һ�νڵ��Ӧ��ӳ���ϵ
					Event evt = lastNode.getEvent("node-enter");
					List actions = evt == null ? null : evt.getActions();
					if (actions != null && actions.size() > 0)
					{
						Action action = (Action) actions.get(0);
						Object delegation = action.getActionDelegation().instantiate();
						if (delegation instanceof IAfterAsynCall) ((IAfterAsynCall) delegation)
								.after(parent, msg, cxt);
						else log.warn("delegation" + delegation.getClass()
								+ " is not IAfterAsynCall!!!");
					}
				}
				instanceVO.setParentXml(new ByteArrayBlob(converter.serialize(parent)));
				if (log.isDebugEnabled()) log.debug("after response msg, parent msg is: "
						+ instanceVO.getParentXml());
				// read instance history variables
				if (!StringX.nullity(instanceVO.getVariables())) variables = (Map) JsonUtil
						.json2obj(instanceVO.getVariables());

				// sub service is fail and bpl node's failabort flag is abort
				// when fail
				if (Common.YES.equals(nodeVO.getFailAbort()) && status.isFail())
				{
					log.warn("failAbort=1, status:" + status.toCNode());
					throw new AppException(status);
				}
			}

			// to execute next node
			instance.getContextInstance().setTransientVariable(IFlowContext.JBPM_FLOW_CXT_KEY, cxt);
			instance.getContextInstance().setTransientVariable(IFlowContext.JBPM_MSG_KEY, parent);
			instance.getContextInstance().setTransientVariable(Common.MODEL_MSG, parent); // ����ǰ������Ϊ���̵���ʱ����
			if (!parent.getLocal().containsKey(MsgLocalKey.LOCAL_BPL_VARIABLES)) parent.setInLocal(
					MsgLocalKey.LOCAL_BPL_VARIABLES, variables);
			instance.getContextInstance().setVariables(variables);

			Token token = instance.getRootToken();
			token.signal();

			// chenjs 2012-09-11 ����finally��ִ��
			// if (parent != msg) msg.addDelayTasks(parent.getDelayTask()); //
			// �������е�δ��ʱ������������뵽��ǰ���Ļ�����
			variables = (Map) parent.getInLocal(MsgLocalKey.LOCAL_BPL_VARIABLES);
			if (instance.hasEnded())
			{ // jpdl has normal end...
				if (log.isInfoEnabled()) log.info("id: " + instance.getId() + ", pmsgcd:"
						+ parent.getMsgCd() + ", psn: " + parent.getMsgSn() + " will end...");
				if (log.isDebugEnabled()) log.debug("parent: " + parent.toXml(true));
				// parent.setMsgLocal(null); // 2012-01-25 chenjs ɾ�����ĵ�local��Ϣ
				if (endFNode != null) endFNode.execute(parent, cxt);
				else log.warn("endFNode is null!!!");
				// if (parent != msg) msg.addDelayTasks(parent.getDelayTask());
				// // �������е�δ��ʱ������������뵽��ǰ���Ļ�����
				deleteProcessInstance(parent.getMsgSn()); // ʹ�ø�������ˮ��ɾ������ʵ��
			}
			else
			{ // ��������ִ���м��instanceVO & nodeVO
				instance.getContextInstance().setVariable(INSTANCE_VAR_KEY_instanceVO, instanceVO);
				BPELNodeVO bnvo = (BPELNodeVO) parent.getInLocal(MsgLocalKey.LOCAL_LAST_NODE);
				instance.getContextInstance().setVariable(INSTANCE_VAR_KEY_nodeVO, bnvo);
				if (bplPersistence != null) bplPersistence.insert(bnvo);
				IMessage nsubmsg = (IMessage) parent.getInLocal(MsgLocalKey.LOCAL_NSUB_MSG);

				saveProcessInstance(instance, nsubmsg.getMsgSn()); // ��������ʵ��
			}
		}
		catch (Throwable e)
		{ // �κ��쳣��ɾ��������Ϣ
			if (e instanceof DelegationException) e = (Exception) ((DelegationException) e)
					.getCause();
			// if (instanceVO != null) instanceVO.setStatus(Status.STATUS_FAIL);
			try
			{
				if (instance != null)
				{
					log.warn("force to end PI: " + instance.getId() + ", psn:" + parent.getMsgSn());
					instance.end();
					deleteProcessInstance(parent.getMsgSn()); // ʹ�ø�������ˮ��ɾ������ʵ��
				}
			}
			catch (Exception ex)
			{
				log.warn("handle ex and end instance", ex);
			}
			failAbort(msg, parent, e, cxt);
		}
		finally
		{ // chenjs 2012-09-11 ��֤catch�е��ӳ�����Ҳ�ᱻ����
			List tasks = AsynESBCallAFNode.removeDelayTask();
			msg.addDelayTasks(tasks);
			if (log.isInfoEnabled()) log.info("add delay tasks: "
					+ (tasks == null ? 0 : tasks.size()));
			// if (parent != msg) msg.addDelayTasks(parent.getDelayTask()); //
			// �������е�δ��ʱ������������뵽��ǰ���Ļ�����
		}
	}

	public JBPM3Asyn2CFNode()
	{
		name = "jbpm3Asyn2";
	}

	public boolean support(IMessage msg)
	{
		return true;
	}

	protected void failAbort(IMessage msg, IMessage parent, Throwable t, IFlowContext cxt)
			throws Exception
	{
		if (log.isInfoEnabled()) log.info("failAbort for sn:" + msg.getMsgSn(), t);
		if (parent == null)
		{
			log.error("failAbort: cannot find parent msg:" + msg.toXml(true));
			return;
		}
		parent.setStatus(SystemUtil.ex2status(parent.getFixedErrDesc(), t));
		// parent.setMsgLocal(null); // 2012-01-25 chenjs ɾ�����ĵ�local��Ϣ
		if (endFNode != null) endFNode.execute(parent, cxt);
	}

	/**
	 * ������һ������ı��ġ��������Ϊ
	 * 
	 * @param msg
	 * @param cxt
	 * @throws Exception
	 */
	protected ProcessInstance createProcessInstance(IMessage msg, IFlowContext cxt,
			BPELInstanceVO instanceVO) throws Exception
	{
		ProcessDefinition pdefinition = null;
		String msgCd = msg.getMsgCd();
		byte[] jpdl32 = msg.findAtomInRequest(DYNAMIC_JPDL32_KEY,
				new AtomNode(StringX.EMPTY_STRING)).byteValue();
		if (jpdl32 != null && jpdl32.length > 0)
		{ // 2012-06-05 ֧��ǰ�˷�����ͼ��̬����
			if (log.isInfoEnabled()) log.info("dynamic jpdl32:" + jpdl32.length);
			if (log.isDebugEnabled()) log.debug("dynamic jpdl32: "
					+ new String(jpdl32, Common.CHARSET_UTF8));
			pdefinition = ProcessDefinition.parseXmlString(StringX.trim(new String(jpdl32,
					Common.CHARSET_UTF8)));
		}
		else pdefinition = getProcessDefinition(msgCd);

		if (pdefinition == null)
		{
			if (log.isInfoEnabled()) log.info("process " + msgCd + " not in "
					+ processDefinitions.keySet());
			throw new AppException(AppRetCode.CMM_BIZ_ERR, "cannot find process definition by "
					+ msgCd);
		}
		if (log.isInfoEnabled()) log.info("process:" + pdefinition.getDescription());
		ProcessInstance instance = new ProcessInstance(pdefinition);

		// insert a row to BPELInstance for a start
		// msg.getMsg().toObject(instanceVO);
		instanceVO.setMsgSn(msg.getMsgSn());
		instanceVO.setMsgCd(msgCd);
		instanceVO.setProccessName(msgCd);
		instanceVO.setVer(String.valueOf(pdefinition.getVersion()));
		instanceVO.setInstanceId(String.valueOf(instance.getId()));
		// instanceVO.setStatus(Status.STATUS_UNDERWAY);
		instanceVO.setParentXml(new ByteArrayBlob(converter.serialize(msg)));
		// instanceVO.setTmStamp(SystemUtil.getInstance().getCurrentDate(SystemUtil.DF_SALL17));
		if (bplPersistence != null) bplPersistence.insert(instanceVO);
		return instance;
	}

	/**
	 * Ӧ������ʱ�ָ�����ʵ��
	 * 
	 * @param msg
	 * @param cxt
	 * @return
	 */
	protected ProcessInstance resumeProcessInstance(String msgSn, IFlowContext cxt)
			throws Exception
	{
		log.info("resume PI");
		boolean gzip = (Boolean) AppConfig.getInstance().getProperty(Config.JBPM3_gzip, false);
		byte[] buf = (byte[]) clusterCache.get(msgSn, false);
		if (log.isInfoEnabled()) log.info("sn:" + msgSn + ", len: "
				+ (buf == null ? 0 : buf.length) + ", gzip:" + gzip);
		ProcessInstance pi = (ProcessInstance) FileUtil.deserialize(buf, gzip);
		log.info("resume PI end");
		return pi;
	}

	protected void saveProcessInstance(ProcessInstance instance, String msgSn) throws Exception
	{
		// 2012-06-12 ɾ����ʱ����
		instance.getContextInstance().getTransientVariables().clear();
		log.info("save PI");
		boolean gzip = (Boolean) AppConfig.getInstance().getProperty(Config.JBPM3_gzip, false);
		int expiry = (Integer) AppConfig.getInstance().getProperty(Config.JBPM3_expiry, 120);
		byte[] buf = FileUtil.serialize(instance, gzip);
		if (log.isInfoEnabled()) log.info("sn:" + msgSn + ", len: " + buf.length + ", gzip:" + gzip
				+ ", expiry:" + expiry);
		if (log.isDebugEnabled()) log.debug("PI.base64:" + StringX.base64(buf));
		clusterCache.put(msgSn, buf, expiry);
		log.info("save PI end");
	}

	/**
	 * ���̽���ִ����ϣ�ɾ������ʵ��
	 * 
	 * @param msgSn
	 */
	protected void deleteProcessInstance(String msgSn)
	{
		if (log.isDebugEnabled()) log.debug("delete PI, sn: " + msgSn);
	}

	protected ProcessDefinition getProcessDefinition(String msgCd)
	{
		return (ProcessDefinition) processDefinitions.get(msgCd);
	}

	public void init() throws Exception
	{
		super.init();
		refresh();
	}

	public void refresh() throws Exception
	{
		log.info("refresh... ");
		Map pDefinitions = new HashMap();
		loadFromDisk(pDefinitions);
		loadFromDB(pDefinitions);
		processDefinitions = pDefinitions;
		if (log.isInfoEnabled()) log
				.info("load process definitions:" + processDefinitions.keySet());
	}

	protected void loadFromDB(Map processDefinitions) throws Exception
	{
		if (!persistence.contain(BPELProcessDefinitionVO.class)) return;
		// log.info("loadFromDB..");
		BPELProcessDefinitionVO pd = new BPELProcessDefinitionVO();
		pd.setProccessType("JBPM3"); // 2012-06-13 ֻ����jbpm3���͵�����
		Map params = new HashMap(); // 2012-06-13 ���汾˳����м��أ�����Ĭ�����°汾��Map��
		params.put(IPersistence.SELECT_ATTACH_TAIL_KEY, " order by ver");
		List pdefs = persistence.get(pd, params);
		for (int i = 0; pdefs != null && i < pdefs.size(); i++)
		{
			BPELProcessDefinitionVO pdvo = (BPELProcessDefinitionVO) pdefs.get(i);
			if (log.isInfoEnabled()) log.info("loading process definition from DB:"
					+ pdvo.getName());

			String jpdl = StringX.trim(new String(pdvo.getDefinition().bytes(), jpdlCharset));
			try
			{
				ProcessDefinition definition = ProcessDefinition.parseXmlString(jpdl);
				definition.setVersion(Integer.parseInt(pdvo.getVer()));
				processDefinitions.put(definition.getName(), definition);
			}
			catch (Exception e)
			{
				log.warn("jpdl:[[" + jpdl + "]]", e);
			}
		}
	}

	protected void loadFromDisk(Map processDefinitions) throws Exception
	{
		if (jpdlDir == null) return;
		File dir = jpdlDir.getFile();
		if (!dir.exists())
		{
			log.error("jpdl dir is no exist:" + dir.getAbsolutePath());
			return;
		}
		readDir(dir, processDefinitions);
	}

	protected void readDir(File dir, Map processDefinitions) throws Exception
	{
		log.info("loadFromDisk:" + dir.getAbsolutePath());
		File[] subfile = dir.listFiles();
		for (int i = 0; i < subfile.length; i++)
		{
			if (subfile[i].isDirectory())
			{
				readDir(subfile[i], processDefinitions);
				continue;
			}
			if (subfile[i].getName().equalsIgnoreCase(PROCESS_DEF_FILE_NAME))
			{
				String jpdl = StringX
						.trim(new String(FileUtil.file2bytes(subfile[i]), jpdlCharset));
				try
				{
					ProcessDefinition definition = ProcessDefinition.parseXmlString(jpdl);
					if (log.isInfoEnabled()) log.info("loading process definition from disk:"
							+ definition.getName());
					processDefinitions.put(definition.getName(), definition);
				}
				catch (Exception e)
				{
					log.warn("jpdl:[[" + jpdl + "]]", e);
				}
			}
		}
	}

	protected IPersistence bplPersistence;
	protected ICache clusterCache; // ���ڼ�Ⱥ�洢���̻���
	protected String jpdlCharset = Common.CHARSET_UTF8;
	protected IFlowNode endFNode; // ��Ϸ����Ӧ������
	protected Resource jpdlDir;
	protected Map processDefinitions = new HashMap(); // ���̶���
	public final static String PROCESS_DEF_FILE_NAME = "processdefinition.xml";
	public final static String BPEL_KEY = "BPL";
	public final static String INSTANCE_VAR_KEY_instanceVO = "_instanceVO";
	public final static String INSTANCE_VAR_KEY_nodeVO = "_nodeVO";
	public static String DYNAMIC_JPDL32_KEY = "jpdl32";
	protected IMessageConverter converter = new XMLConverter2(false); // bpl�洢ʱ��ɾ��transaction/local��ǩ

	public void setBplPersistence(IPersistence bplPersistence)
	{
		this.bplPersistence = bplPersistence;
	}

	public void setConverter(IMessageConverter converter)
	{
		this.converter = converter;
	}

	public void setJpdlCharset(String jpdlCharset)
	{
		this.jpdlCharset = jpdlCharset;
	}

	public void setEndFNode(IFlowNode endFNode)
	{
		this.endFNode = endFNode;
	}

	public void setJpdlDir(Resource jpdlDir)
	{
		this.jpdlDir = jpdlDir;
	}

	// public void setPinstanceGzip(boolean pinstanceGzip)
	// {
	// this.pinstanceGzip = pinstanceGzip;
	// }
	//
	// public void setPinstanceExpireSeconds(int pinstanceExpireSeconds)
	// {
	// this.pinstanceExpireSeconds = pinstanceExpireSeconds;
	// }

	public void setClusterCache(ICache clusterCache)
	{
		this.clusterCache = clusterCache;
	}
}
