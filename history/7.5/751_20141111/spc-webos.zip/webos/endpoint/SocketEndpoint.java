package spc.webos.endpoint;

public class SocketEndpoint extends TCPEndpoint
{
	public SocketEndpoint()
	{
	}

	public SocketEndpoint(String location)
	{
		super(location);
	}
}