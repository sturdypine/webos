package spc.webos.queue;

import java.io.Serializable;
import java.text.SimpleDateFormat;

import spc.webos.util.SystemUtil;

import com.ibm.mq.MQException;
import com.ibm.mq.MQQueue;

/**
 * ������Ϣ�����ڼ��
 * 
 * @author spc
 * 
 */
public class Queue implements Serializable
{
	private static final long serialVersionUID = 1L;
	protected String qm;
	protected String name;
	protected Integer curDepth;
	protected Integer maxDepth;
	protected Integer maxMsgLen;
	protected Integer inputCnt;
	protected Integer outputCnt;
	protected String crtDtTm;
	protected String visitDtTm;

	public Queue()
	{
	}

	public Queue(String qmname, String name, MQQueue q) throws MQException
	{
		this.qm = qmname;
		this.name = name;
		curDepth = q.getCurrentDepth();
		maxDepth = q.getMaximumDepth();
		maxMsgLen = q.getMaximumMessageLength();
		inputCnt = q.getOpenInputCount();
		outputCnt = q.getOpenOutputCount();
		SimpleDateFormat df = new SimpleDateFormat(SystemUtil.DF_SALL17);
		crtDtTm = df.format(q.getCreationDateTime().getTime());
		visitDtTm = df.format(SystemUtil.getInstance().getCurrentDate());
	}

	public String getVisitDtTm()
	{
		return visitDtTm;
	}

	public void setVisitDtTm(String visitDtTm)
	{
		this.visitDtTm = visitDtTm;
	}

	public Integer getCurDepth()
	{
		return curDepth;
	}

	public void setCurDepth(Integer curDepth)
	{
		this.curDepth = curDepth;
	}

	public Integer getMaxDepth()
	{
		return maxDepth;
	}

	public void setMaxDepth(Integer maxDepth)
	{
		this.maxDepth = maxDepth;
	}

	public Integer getMaxMsgLen()
	{
		return maxMsgLen;
	}

	public void setMaxMsgLen(Integer maxMsgLen)
	{
		this.maxMsgLen = maxMsgLen;
	}

	public String getQm()
	{
		return qm;
	}

	public void setQm(String qm)
	{
		this.qm = qm;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public Integer getInputCnt()
	{
		return inputCnt;
	}

	public void setInputCnt(Integer inputCnt)
	{
		this.inputCnt = inputCnt;
	}

	public Integer getOutputCnt()
	{
		return outputCnt;
	}

	public void setOutputCnt(Integer outputCnt)
	{
		this.outputCnt = outputCnt;
	}

	public String getCrtDtTm()
	{
		return crtDtTm;
	}

	public void setCrtDtTm(String crtDtTm)
	{
		this.crtDtTm = crtDtTm;
	}
}
