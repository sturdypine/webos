package spc.webos.echain.advice;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

import spc.webos.log.Log;
import spc.webos.util.StringX;
import spc.webos.web.common.ISessionUserInfo;

import com.ecc.echain.workflow.engine.EVO;

/**
 * ���ڽ�session�е���Ϣ���뵽EVO�С�
 * 
 * @author chenjs
 * 
 */
public class EVOAdvice implements MethodInterceptor
{
	protected Log log = Log.getLogger(getClass());

	public Object invoke(MethodInvocation mi) throws Throwable
	{
		if (log.isDebugEnabled()) log.debug("start " + mi.getThis().getClass() + ":"
				+ mi.getMethod());
		Object[] args = mi.getArguments();
		if (args != null && args.length > 0)
		{
			ISessionUserInfo sui = (ISessionUserInfo) ISessionUserInfo.SUI.get();
			for (int i = 0; i < args.length; i++)
			{
				if (args[i] instanceof EVO)
				{
					EVO evo = (EVO) args[i];
					if (StringX.nullity(evo.getCurrentUserID())) evo.setCurrentUserID(sui
							.getUserCode());
					if (StringX.nullity(evo.getOrgid())) evo.setOrgid(sui.getOrgId());
				}
			}
		}
		return mi.proceed();
	}
}
