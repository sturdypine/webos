package spc.webos.data.validator;

import java.util.HashMap;
import java.util.Map;

import spc.webos.data.IMessage;

public interface IMessageValidator
{
	MessageErrors validate(IMessage msg, MessageErrors errors);

	final Map VALIDATOR = new HashMap();
}
