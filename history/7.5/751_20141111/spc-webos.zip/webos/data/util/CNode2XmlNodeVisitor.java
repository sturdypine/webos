package spc.webos.data.util;

import spc.webos.data.IArrayNode;
import spc.webos.data.IAtomNode;
import spc.webos.data.ICompositeNode;
import spc.webos.data.INode;
import spc.webos.model.MsgSchemaVO;
import spc.webos.util.StringX;
import spc.webos.util.tree.TreeNode;

/**
 * ��һ���ڵ���ݱ���schema�������л�Ϊһ���ַ����������ֶε�˳��
 * 
 * @author spc
 * 
 */
public class CNode2XmlNodeVisitor implements INodeVisitor
{
	protected boolean pretty;
	protected int level; // ��ǰ�ṹ�������Ĳ�Σ���prettyģʽ�¾����м���\t
	protected StringBuffer buf = new StringBuffer();

	public CNode2XmlNodeVisitor()
	{
	}

	public CNode2XmlNodeVisitor(boolean pretty, int level)
	{
		this.pretty = pretty;
		this.level = level;
	}

	public void clear()
	{
		buf.setLength(0);
	}

	public boolean start(INode node, TreeNode nodeSchema) throws Exception
	{
		if (node == null) return true;
		MsgSchemaVO schema = (MsgSchemaVO) nodeSchema.getTreeNodeValue();

		if (schema.getFtyp().charAt(0) == INode.TYPE_MAP
				|| schema.getFtyp().charAt(0) == INode.TYPE_ARRAY)
		{
			if (node instanceof IAtomNode) return true; // ˵��Ϊ�սڵ�
			if ((node instanceof ICompositeNode) && ((ICompositeNode) node).size() <= 0) return true;
			if ((node instanceof IArrayNode) && ((IArrayNode) node).size() <= 0) return true;
		}
		buf.append(pretty());
		buf.append('<');
		buf.append(getTagName(node, nodeSchema));
		buf.append('>');
		if (schema.getFtyp().charAt(0) == INode.TYPE_MAP
				|| schema.getFtyp().charAt(0) == INode.TYPE_ARRAY)
		{
			level++;
		}
		return true;
	}

	protected String getTagName(INode node, TreeNode nodeSchema)
	{
		MsgSchemaVO schema = (MsgSchemaVO) nodeSchema.getTreeNodeValue();
		return schema.getEsbName();
	}

	public boolean end(INode node, TreeNode nodeSchema) throws Exception
	{
		if (node == null) return true;
		MsgSchemaVO schema = (MsgSchemaVO) nodeSchema.getTreeNodeValue();

		if (schema.getFtyp().charAt(0) == INode.TYPE_MAP
				|| schema.getFtyp().charAt(0) == INode.TYPE_ARRAY)
		{
			if (node instanceof IAtomNode) return true; // ˵��Ϊ�սڵ�
			if ((node instanceof ICompositeNode) && ((ICompositeNode) node).size() <= 0) return true;
			if ((node instanceof IArrayNode) && ((IArrayNode) node).size() <= 0) return true;
			level--;
			buf.append(pretty());
		}
		else
		{
			buf.append(getValue(node, nodeSchema));
		}
		buf.append('<');
		buf.append('/');
		buf.append(getTagName(node, nodeSchema));
		buf.append('>');
		return true;
	}

	protected String pretty()
	{
		if (!pretty) return StringX.EMPTY_STRING;
		StringBuffer buf = new StringBuffer();
		buf.append('\n');
		for (int i = 0; i < level; i++)
			buf.append('\t');
		return buf.toString();
	}

	protected String getValue(INode node, TreeNode nodeSchema)
	{
		String v = ((IAtomNode) node).stringValue();
		if (v.indexOf('<') >= 0) v = StringX.replaceAll(v, "<", "&lt;");
		if (v.indexOf('>') >= 0) v = StringX.replaceAll(v, ">", "&gt;");
		if (v.indexOf('&') >= 0) v = StringX.replaceAll(v, "&", "&amp;");
		return v;
	}

	public StringBuffer toXml()
	{
		return buf;
	}
}
