package spc.webos.persistence;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.cglib.beans.BulkBean;
import net.sf.cglib.proxy.LazyLoader;
import spc.webos.model.ValueObject;

public class LazyResultLoader implements LazyLoader
{
	Persistence persistence;
	Object vo; // 
	Object[] bulkBeans;
	Map paramMap;

	public LazyResultLoader(Persistence persistence, Object[] bulkBeans,
			Object vo, Map paramMap)
	{
		this.persistence = persistence;
		this.bulkBeans = bulkBeans;
		this.vo = vo;
		this.paramMap = paramMap;
	}

	public Object loadObject() throws Exception
	{
		if (bulkBeans[0] instanceof String)
		{ // �����Բ��ǹ�������VO���ԣ� ����һ����ͨ��sql����
			// String key = "_FIRST_ROW_ONEY_";
			// paramMap.put(key, new Boolean(false));
			Map map = new HashMap(paramMap); // ����paramMap���̲߳���ȫ��,��Ҫ���¶������
			map.put("_VO_", vo); // ����ԭ�������ԣ�
			// System.out.println("map = " + map);
			return persistence.execute((String) bulkBeans[0], map);
		}
		Object[] values = new Object[((BulkBean) bulkBeans[0]).getGetters().length];
		((BulkBean) bulkBeans[0]).getPropertyValues(vo, values);

		ValueObject property = (ValueObject) ((Class) bulkBeans[3])
				.newInstance();
		((BulkBean) bulkBeans[1]).setPropertyValues(property, values);

		return (Class) bulkBeans[2] != List.class ? (Object) persistence
				.find(property) : (Object) persistence.get(property);
	}
}
