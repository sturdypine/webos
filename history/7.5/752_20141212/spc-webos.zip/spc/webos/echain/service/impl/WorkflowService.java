package spc.webos.echain.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import spc.webos.echain.service.IWorkflowService;

import com.ecc.echain.workflow.engine.EVO;
import com.ecc.echain.workflow.engine.WorkFlowClient;
import com.ecc.echain.workflow.exception.WFException;
import com.ecc.echain.workflow.model.CommentVO;

public class WorkflowService extends EChainService implements IWorkflowService
{
	protected WorkFlowClient client = WorkFlowClient.getInstance();

	public boolean ClearAllWF()
	{
		return client.ClearAllWF();
	}

	public boolean ClearAllWFInstance()
	{
		return client.ClearAllWFInstance();
	}

	public boolean DelInstance(String arg0)
	{
		return client.DelInstance(arg0);
	}

	public boolean DelWF(String arg0)
	{
		return client.DelWF(arg0);
	}

	public EVO SubFlowSetSubmit(EVO arg0) throws WFException
	{
		return client.SubFlowSetSubmit(fillEVO(arg0));
	}

	public List batchInstanceSignIn(List arg0) throws WFException
	{
		for (int i = 0; i < arg0.size(); i++)
		{
			EVO evo = (EVO) arg0.get(i);
			fillEVO(evo);
		}
		return client.batchInstanceSignIn(arg0);
	}

	public Vector getAllComments(EVO arg0) throws WFException
	{
		return client.getAllComments(fillEVO(arg0));
	}

	public EVO getAnnounceUserList(EVO arg0) throws WFException
	{
		return client.getAnnounceUserList(fillEVO(arg0));
	}

	public EVO getChangeUser(EVO arg0) throws WFException
	{
		return client.getChangeUser(fillEVO(arg0));
	}

	public Map getCurrentNode(EVO arg0) throws WFException
	{
		return client.getCurrentNode(fillEVO(arg0));
	}

	public EVO getInstanceInfo(EVO arg0) throws WFException
	{
		return client.getInstanceInfo(fillEVO(arg0));
	}

	public Vector getInstanceList(EVO arg0) throws WFException
	{
		return client.getInstanceList(fillEVO(arg0));
	}

	public EVO getInstanceNodeUserList(EVO arg0) throws WFException
	{
		return client.getInstanceNodeUserList(fillEVO(arg0));
	}

	public EVO getNextNodeList(EVO arg0) throws WFException
	{
		return client.getNextNodeList(fillEVO(arg0));
	}

	public HashMap getNodeControlFormAction(EVO arg0) throws WFException
	{
		return client.getNodeControlFormAction(fillEVO(arg0));
	}

	public HashMap getNodeControlFormField(EVO arg0) throws WFException
	{
		return client.getNodeControlFormField(fillEVO(arg0));
	}

	public EVO getNodeUserList(EVO arg0) throws WFException
	{
		return client.getNodeUserList(fillEVO(arg0));
	}

	public EVO getPreNodeUser(EVO arg0) throws WFException
	{
		return client.getPreNodeUser(fillEVO(arg0));
	}

	public Vector getSubFlow(EVO arg0) throws WFException
	{
		return client.getSubFlow(fillEVO(arg0));
	}

	public CommentVO getUserComment(EVO arg0) throws WFException
	{
		return client.getUserComment(fillEVO(arg0));
	}

	public Map getWFExtProperties(String arg0) throws WFException
	{
		return client.getWFExtProperties(arg0);
	}

	public Vector getWFNameList(EVO arg0) throws WFException
	{
		return client.getWFNameList(fillEVO(arg0));
	}

	public Map getWFNodeExtProperties(String arg0) throws WFException
	{
		return client.getWFNodeExtProperties(arg0);
	}

	public HashMap getWFNodeList(EVO arg0) throws WFException
	{
		return client.getWFNodeList(fillEVO(arg0));
	}

	public Map getWFNodeRouteExtProperties(String arg0) throws WFException
	{
		return client.getWFNodeRouteExtProperties(arg0);
	}

	public Map getWFNodeRouteExtProperties(String arg0, String arg1) throws WFException
	{
		return client.getWFNodeRouteExtProperties(arg0, arg1);
	}

	public EVO getWFSignByAppID(EVO arg0) throws WFException
	{
		return client.getWFSignByAppID(fillEVO(arg0));
	}

	public List getWFTreatedNodeList(EVO arg0) throws WFException
	{
		return client.getWFTreatedNodeList(fillEVO(arg0));
	}

	public Vector getWorkFlowHistory(EVO arg0) throws WFException
	{
		return client.getWorkFlowHistory(fillEVO(arg0));
	}

	public String getWorkFlowVersion()
	{
		return client.getWorkFlowVersion();
	}

	public EVO initializeWFWholeDocUNID(EVO arg0) throws WFException
	{
		return client.initializeWFWholeDocUNID(fillEVO(arg0));
	}

	public EVO instanceSignIn(EVO arg0) throws WFException
	{
		return client.instanceSignIn(fillEVO(arg0));
	}

	public EVO instanceSignOff(EVO arg0) throws WFException
	{
		return client.instanceSignOff(fillEVO(arg0));
	}

	public EVO resetBizseqno(EVO arg0) throws WFException
	{
		return client.resetBizseqno(fillEVO(arg0));
	}

	public EVO resetCurrentNodeUser(EVO arg0) throws WFException
	{
		return client.resetCurrentNodeUser(fillEVO(arg0));
	}

	public EVO resetUrgentTreat(EVO arg0) throws WFException
	{
		return client.resetUrgentTreat(fillEVO(arg0));
	}

	public boolean sendAnnounce(EVO arg0) throws WFException
	{
		return client.sendAnnounce(fillEVO(arg0));
	}

	public void sendMail(String arg0, String arg1, String arg2, String arg3, Map arg4)
	{
		client.sendMail(arg0, arg1, arg2, arg3, arg4);
	}

	public void sendSMS(String arg0, String arg1, String arg2, String arg3, Map arg4)
	{
		client.sendSMS(arg0, arg1, arg2, arg3, arg4);
	}

	public EVO setAppSign(EVO arg0) throws WFException
	{
		return client.setAppSign(fillEVO(arg0));
	}

	public boolean setComment(EVO arg0) throws WFException
	{
		return client.setComment(fillEVO(arg0));
	}

	public EVO setSPStatus(EVO arg0) throws WFException
	{
		return client.setSPStatus(fillEVO(arg0));
	}

	public EVO taskSignIn(EVO arg0) throws WFException
	{
		return client.taskSignIn(fillEVO(arg0));
	}

	public EVO taskSignOff(EVO arg0) throws WFException
	{
		return client.taskSignOff(fillEVO(arg0));
	}

	public EVO wfAssist(EVO arg0) throws WFException
	{
		return client.wfAssist(fillEVO(arg0));
	}

	public List wfBatchCompleteJob(EVO arg0) throws WFException
	{
		return client.wfBatchCompleteJob(fillEVO(arg0));
	}

	public List wfBatchSaveJob(EVO arg0) throws WFException
	{
		return client.wfBatchSaveJob(fillEVO(arg0));
	}

	public EVO wfCallBack(EVO arg0) throws WFException
	{
		return client.wfCallBack(fillEVO(arg0));
	}

	public EVO wfCancel(EVO arg0) throws WFException
	{
		return client.wfCancel(fillEVO(arg0));
	}

	public EVO wfChange(EVO arg0) throws WFException
	{
		return client.wfChange(fillEVO(arg0));
	}

	public EVO wfCompleteJob(EVO arg0) throws WFException
	{
		return client.wfCompleteJob(fillEVO(arg0));
	}

	public EVO wfDelInstance(EVO arg0) throws WFException
	{
		return client.wfDelInstance(fillEVO(arg0));
	}

	public EVO wfEnd(EVO arg0) throws WFException
	{
		return client.wfEnd(fillEVO(arg0));
	}

	public EVO wfHang(EVO arg0) throws WFException
	{
		return client.wfHang(fillEVO(arg0));
	}

	public EVO wfJump(EVO arg0) throws WFException
	{
		return client.wfJump(fillEVO(arg0));
	}

	public EVO wfJump2First(EVO arg0) throws WFException
	{
		return client.wfJump2First(fillEVO(arg0));
	}

	public EVO wfReturnBack(EVO arg0) throws WFException
	{
		return client.wfReturnBack(fillEVO(arg0));
	}

	public EVO wfSaveJob(EVO arg0) throws WFException
	{
		return client.wfSaveJob(fillEVO(arg0));
	}

	public EVO wfTakeBack(EVO arg0) throws WFException
	{
		return client.wfTakeBack(fillEVO(arg0));
	}

	public EVO wfUrge(EVO arg0) throws WFException
	{
		return client.wfUrge(fillEVO(arg0));
	}

	public EVO wfWake(EVO arg0) throws WFException
	{
		return client.wfWake(fillEVO(arg0));
	}

	public EVO wfWithdrawUser(EVO arg0) throws WFException
	{
		return client.wfWithdrawUser(fillEVO(arg0));
	}

	// added methods
	public List getAllComments(Map evo) throws Exception
	{
		return getAllComments(map2evo(evo));
	}

	public List getInstanceList(Map evo) throws Exception
	{
		return getInstanceList(map2evo(evo));
	}

	public List getSubFlow(Map evo) throws Exception
	{
		return getSubFlow(map2evo(evo));
	}

	public List getWFNameList(Map evo) throws Exception
	{
		return getWFNameList(map2evo(evo));
	}

	public List getWFTreatedNodeList(Map evo) throws Exception
	{
		return getWFTreatedNodeList(map2evo(evo));
	}

	public List getWorkFlowHistory(Map evo) throws Exception
	{
		return getWorkFlowHistory(map2evo(evo));
	}

	public List wfBatchCompleteJob(Map evo) throws Exception
	{
		return wfBatchCompleteJob(map2evo(evo));
	}

	public List wfBatchSaveJob(Map evo) throws Exception
	{
		return wfBatchSaveJob(map2evo(evo));
	}
}
