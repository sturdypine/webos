package spc.webos.flownode.action;

import spc.webos.cache.Map2Cache;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.StringX;
import bsh.Interpreter;

public class BshCreateMsgAsynCallAction extends AbstractCreateMsgAsynCallAction
{
	private static final long serialVersionUID = 20131225L;

	public void execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		IMessage nsubmsg = createSubRequestMsg(msg, cxt);
		msg.setInLocal(MsgLocalKey.LOCAL_NSUB_MSG, nsubmsg); // 2012-05-12�����´������ӱ���
		before(msg, nsubmsg, cxt);
		executeTargetFNode(nsubmsg, cxt);
	}

	public IMessage createSubRequestMsg(IMessage parent, IFlowContext cxt) throws Exception
	{
		if (log.isInfoEnabled()) log.info("create sub request msg in " + name);
		IMessage nsubmsg = newMessage(parent);
		if (StringX.nullity(reqBsh))
		{
			log.info("request bsh is null...");
			nsubmsg.setRequest(parent.getRequest());
			return nsubmsg;
		}
		Interpreter i = getInterpreter(reqBsh);
		synchronized (i)
		{ // 702_20140121��֤�̰߳�ȫ
			i.set("parent", parent);
			i.set("sub", nsubmsg);
			i.eval("fun(parent, sub);");
		}
		if (log.isTraceEnabled()) log.trace("sub:" + nsubmsg.toXml(true));
		return nsubmsg;
	}

	public void after(IMessage parent, IMessage submsg, IFlowContext cxt) throws Exception
	{
		if (log.isInfoEnabled()) log.info("after response msg in " + name);
		if (StringX.nullity(repBsh))
		{
			log.info("response bsh is null...");
			return;
		}
		parent.setInLocal(MsgLocalKey.LOCAL_NSUB_MSG, submsg); // ����ǰӦ���ӱ��ķ��븸������ʱ�ռ�
		Interpreter i = getInterpreter(repBsh);
		i.set("parent", parent);
		i.set("sub", submsg);
		i.eval("fun(parent, sub);");
		if (log.isTraceEnabled()) log.trace("parent:" + parent.toXml(true));
	}

	protected String reqBsh; // �����±���bsh�Ų�
	protected String repBsh; // Ӧ����bsh�Ų�
	static Map2Cache interpreters = new Map2Cache(24 * 3600, 500);

	public static synchronized Interpreter getInterpreter(String script) throws Exception
	{
		Interpreter i = (Interpreter) interpreters.get(script);
		if (i != null) return i;
		i = new Interpreter();
		i.eval("import spc.webos.data.IMessage;void fun(IMessage parent,IMessage sub){" + script
				+ "}");
		interpreters.put(script, i);
		return i;
	}

	public String getReqBsh()
	{
		return reqBsh;
	}

	public void setReqBsh(String reqBsh)
	{
		this.reqBsh = StringX.removeBshAnnotation(reqBsh);
	}

	public String getRepBsh()
	{
		return repBsh;
	}

	public void setRepBsh(String repBsh)
	{
		this.repBsh = StringX.removeBshAnnotation(repBsh);
	}

	public BshCreateMsgAsynCallAction()
	{
		fnodes = "asynESBCall";
	}
}
