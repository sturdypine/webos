package spc.webos.flownode.decision;

import java.util.List;
import java.util.Map;

import org.jbpm.graph.exe.ExecutionContext;
import org.jbpm.graph.node.DecisionHandler;

import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.flownode.IDecision;
import spc.webos.flownode.IFlowContext;
import spc.webos.log.Log;

public abstract class AbstractDecision implements IDecision, DecisionHandler
{
	private static final long serialVersionUID = 1L;
	protected String name;
	protected String ext;
	protected transient Log log = Log.getLogger(getClass());
	protected static transient ThreadLocal CUR_MSG = new ThreadLocal();

	public String decide(ExecutionContext ecxt) throws Exception
	{
		IFlowContext cxt = (IFlowContext) ecxt.getContextInstance().getTransientVariable(
				IFlowContext.JBPM_FLOW_CXT_KEY);
		IMessage msg = (IMessage) ecxt.getContextInstance().getTransientVariable(
				IFlowContext.JBPM_MSG_KEY);
		CUR_MSG.set(msg);
		try
		{
			return decide(msg, cxt);
		}
		finally
		{
			CUR_MSG.set(null);
		}
	}

	public static void setInMsgLocal(String key, Object value)
	{
		current().setInLocal(key, value);
	}

	public static void removeMsgLocal(String key)
	{
		current().getLocal().remove(key);
	}

	public static Object getJbpmVariable(String key)
	{
		Map variables = (Map) (current().getInLocal(MsgLocalKey.LOCAL_BPL_VARIABLES));
		if (variables != null) return variables.get(key);
		return null;
	}

	public static void setJbpmVariable(String key, Object value)
	{
		Map variables = (Map) (current().getInLocal(MsgLocalKey.LOCAL_BPL_VARIABLES));
		if (variables != null) variables.put(key, value);
	}

	public static void removeJbpmVariable(String key)
	{
		Map variables = (Map) current().getInLocal(MsgLocalKey.LOCAL_BPL_VARIABLES);
		if (variables != null) variables.remove(key);
	}

	public static void setInMsg(String path, Object value)
	{
		current().getTransaction().set(path, value);
	}

	public static void removeFromMsg(String path)
	{
		current().getTransaction().remove(path);
	}

	public static void removeFromMsg(List paths)
	{
		if (paths == null) return;
		for (int i = 0; i < paths.size(); i++)
			removeFromMsg(paths.get(i).toString());
	}

	public static IMessage current()
	{
		return (IMessage) CUR_MSG.get();
	}

	public void init() throws Exception
	{
		if (name != null) DECISIONS.put(name, this);
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getExt()
	{
		return ext;
	}

	public void setExt(String ext)
	{
		this.ext = ext;
	}
}
