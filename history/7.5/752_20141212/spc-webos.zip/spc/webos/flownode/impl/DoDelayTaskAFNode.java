package spc.webos.flownode.impl;

import java.util.List;

import spc.webos.data.IMessage;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IDelayTask;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.StringX;

/**
 * ִ����ʱ��������
 * 
 * @author spc
 * 
 */
public class DoDelayTaskAFNode extends AbstractFNode
{
	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		IDelayTask delayTask = null;
		try
		{
			List delayTasks = msg.getDelayTask();
			if (log.isDebugEnabled()) log.debug("DelayTask number is " + delayTasks.size());
			for (int i = 0; i < delayTasks.size(); i++)
			{
				delayTask = (IDelayTask) delayTasks.get(i);
				if (log.isInfoEnabled()) log.info("start delayTask: " + delayTask.getName());
				delayTask.execute();
			}
		}
		catch (Exception e)
		{
			if (!logex) throw e;
			log.warn(
					"delayTask: "
							+ (delayTask == null ? StringX.EMPTY_STRING : delayTask.getName()), e);
		}
		return null;
	}

	protected boolean logex; // ��������쳣��־��T�ڵ㽫����throw exeption

	public void setLogex(boolean logex)
	{
		this.logex = logex;
	}
}
