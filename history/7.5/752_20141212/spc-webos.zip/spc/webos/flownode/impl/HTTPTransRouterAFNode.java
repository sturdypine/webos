package spc.webos.flownode.impl;

import java.util.HashMap;
import java.util.Map;

import spc.webos.acceptor.SocketMessage;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.flownode.IFlowNode;

public class HTTPTransRouterAFNode extends AbstractFNode
{
	protected Map trans = new HashMap(); // ֱ�ӵĽ�����������Ϣ
	protected IFlowNode defaultFNode; // Ĭ�Ͻ��ܴ����Ľڵ�

	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		SocketMessage smsg = (SocketMessage) msg
				.getInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_SOCKETMSG);
		IFlowNode fnode = null;
		if (smsg.reqHttpHdr != null)
		{
			String uri = smsg.reqHttpHdr.uri.toLowerCase();
			fnode = (IFlowNode) trans.get(uri);
			if (fnode == null) log.info("undefined uri:" + uri);
		}
		if (fnode == null) fnode = defaultFNode;
		fnode.execute(msg, cxt);
		return null;
	}

	public void setTrans(Map trans)
	{
		this.trans = trans;
	}

	public void setDefaultFNode(IFlowNode defaultFNode)
	{
		this.defaultFNode = defaultFNode;
	}
}
