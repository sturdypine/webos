package spc.webos.flownode.impl;

import java.util.List;
import java.util.Map;

import spc.webos.constant.AppRetCode;
import spc.webos.data.IMessage;
import spc.webos.exception.AppException;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.flownode.IFlowNode;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

/**
 * ���������message���ģ�����ָ���Ľ�����transid�ҵ�ָ���ķ�����
 * 
 * @author spc
 * 
 */
public class TransRouterAFNode extends AbstractFNode
{
	protected Map trans; // ֱ�ӵĽ�����������Ϣ
	protected List supported; // ���ദ�����̾�֧��ĳһ�����͵Ľ����룬�����ǵ���������
	protected IFlowNode defaultFNode; // Ĭ�Ͻ��ܴ����Ľڵ�
	final static TransRouterAFNode TRANS_ROUTER = new TransRouterAFNode();

	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		String msgCd = msg.getMsgCd();
		IFlowNode fnode = getFNode(msg);
		if (log.isInfoEnabled()) log.info("start msgCd:" + msgCd + ",fnode: "
				+ (fnode != null ? fnode.getClass().getName() : StringX.EMPTY_STRING));
		if (fnode == null) fnode = defaultFNode;
		if (fnode == null) throw new AppException(AppRetCode.MSGCD_UNDEFINDED());
		fnode.execute(msg, cxt);
		return null;
	}

	public IFlowNode getFNode(IMessage msg)
	{
		String msgCd = msg.getMsgCd();
		IFlowNode fnode = null;
		if (trans != null)
		{
			fnode = (IFlowNode) trans.get(msgCd);
			if (fnode != null) return fnode;
		}
		fnode = getFlowNode(msgCd);
		if (fnode != null) return fnode;

		fnode = (IFlowNode) SystemUtil.getInstance().getBean(msgCd, IFlowNode.class);
		if (fnode != null) return fnode;

		if (supported != null)
		{
			for (int i = 0; i < supported.size(); i++)
			{
				IFlowNode fn = (IFlowNode) supported.get(i);
				if (fn.support(msg)) return fn;
			}
		}
		return null;
	}

	private TransRouterAFNode()
	{
	}

	public static TransRouterAFNode getInstance()
	{
		return TRANS_ROUTER;
	}

	public void setTrans(Map trans)
	{
		this.trans = trans;
	}

	public void setSupported(List supported)
	{
		this.supported = supported;
	}

	public void setDefaultFNode(IFlowNode defaultFNode)
	{
		this.defaultFNode = defaultFNode;
	}
}
