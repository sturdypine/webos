package spc.webos.pool;

public class ByteObjectPool extends ObjectPool
{
	int len;

	public ByteObjectPool(int len)
	{
		this.len = len;
	}

	public ByteObjectPool(int len, int max)
	{
		this.len = len;
		super.max = max;
	}

	public Object newIntance()
	{
		return new byte[len];
	}

	public static final ByteObjectPool ByteObjectPool_1024 = new ByteObjectPool(
			1024);
}
