package spc.webos.jsrmi.service.defaults;

public final class ServiceHolder {
	
	private String serviceId;
	private String serviceName;
	private String factoryId;
	
	/**
	 * create a service holder
	 * 
	 * @param serviceId the service id
	 * @param serviceName the service name
	 * @param factoryId the factory id, such as 'default' or 'spring'
	 */
	public ServiceHolder(String serviceId, String serviceName, String factoryId) {
		this.serviceId = serviceId;
		this.serviceName = serviceName;
		this.factoryId = factoryId;
	}
	
	public String getFactoryId() {
		return factoryId;
	}

	public String getServiceId() {
		return serviceId;
	}

	public String getServiceName() {
		return serviceName;
	}
	
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append(super.toString());
		buffer.append("{serviceId=");
		buffer.append(this.serviceId);
		buffer.append(",serviceName=");
		buffer.append(this.serviceName);
		buffer.append(",factoryId=");
		buffer.append(this.factoryId);
		buffer.append("}");
		
		return buffer.toString();
	}
	
}
