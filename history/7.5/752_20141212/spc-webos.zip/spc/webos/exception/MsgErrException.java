package spc.webos.exception;

import spc.webos.constant.AppRetCode;
import spc.webos.data.validator.MessageErrors;

/**
 * ���ļ������쳣����
 * 
 * @author spc
 * 
 */
public class MsgErrException extends AppException
{
	private static final long serialVersionUID = 1L;

	public MsgErrException(MessageErrors errors)
	{
		super(AppRetCode.MSG_ERRS(), null, errors);
	}

	public MsgErrException(String code, Object[] args, MessageErrors errors)
	{
		super(code, args, errors);
	}

	public MessageErrors getErrors()
	{
		return (MessageErrors) detail;
	}
}
