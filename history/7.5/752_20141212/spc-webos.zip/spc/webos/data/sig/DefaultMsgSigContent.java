package spc.webos.data.sig;

import java.util.List;

import spc.webos.data.IMessage;
import spc.webos.data.INode;
import spc.webos.model.MsgSchemaVO;
import spc.webos.util.StringX;

public class DefaultMsgSigContent extends AbstractMsgSigContent
{
	protected boolean containLastDelim = true; // ��������ǩ������ʱ�������һ���ָ���
	protected String delim = "|"; // �ָ���
	protected boolean ignoreBlankSigCnt = true; // ���ǩ������Ϊ�գ������ǩ����

	public DefaultMsgSigContent()
	{
	}

	public DefaultMsgSigContent(String delim, boolean containLastDelim, boolean ignoreBlankSigCnt)
	{
		this.delim = delim;
		this.containLastDelim = containLastDelim;
		this.ignoreBlankSigCnt = ignoreBlankSigCnt;
	}

	// ƴ���ǩ��,����"|"�ָ�
	public byte[] getSigCnts(IMessage msg, String nodeCd, List sigCnts, String charset)
			throws Exception
	{
		StringBuffer buf = new StringBuffer();
		for (int i = 0; i < sigCnts.size(); i++)
		{
			Object[] items = (Object[]) sigCnts.get(i);
			String sigCnt = sigCnt(msg, nodeCd, (INode) items[0], (MsgSchemaVO) items[1]); // ��ǰ�ڵ��schema������Ϣ
			if (sigCnt == null) continue;
			if (StringX.nullity(sigCnt) && ignoreBlankSigCnt) continue; // ���ǩ������Ϊ�հף������
			buf.append(sigCnt);
			if (i < sigCnts.size() - 1 || containLastDelim) buf.append(delim);
		}
		if (log.isDebugEnabled()) log.debug("nodeCd:" + nodeCd + ", charset:" + charset
				+ ", sigCnts:[[" + buf + "]]");
		return buf.toString().getBytes(charset);
	}

	protected String sigCnt(IMessage msg, String nodeCd, INode value, MsgSchemaVO schema)
			throws Exception
	{
		INode2SigContent ansc = (INode2SigContent) INode2SigContent.SIGS.get(schema.getSig());
		if (ansc == null)
		{
			log.warn("IAtomNodeSigContent is null by: " + schema.getSig() + " !!!");
			return StringX.EMPTY_STRING;
		}
		return ansc.sigCnt(msg, nodeCd, value, schema);
	}

	public boolean isContainLastDelim()
	{
		return containLastDelim;
	}

	public void setContainLastDelim(boolean containLastDelim)
	{
		this.containLastDelim = containLastDelim;
	}

	public String getDelim()
	{
		return delim;
	}

	public void setDelim(String delim)
	{
		this.delim = delim;
	}

	public boolean isIgnoreBlankSigCnt()
	{
		return ignoreBlankSigCnt;
	}

	public void setIgnoreBlankSigCnt(boolean ignoreBlankSigCnt)
	{
		this.ignoreBlankSigCnt = ignoreBlankSigCnt;
	}
}
