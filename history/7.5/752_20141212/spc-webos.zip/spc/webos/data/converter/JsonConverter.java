package spc.webos.data.converter;

import java.util.Map;

import spc.webos.constant.Common;
import spc.webos.data.CompositeNode;
import spc.webos.data.IMessage;
import spc.webos.data.Message;
import spc.webos.log.Log;
import spc.webos.util.JsonUtil;

public class JsonConverter implements IMessageConverter
{
	protected String charset = Common.CHARSET_UTF8;
	protected Log log = Log.getLogger(getClass());

	public IMessage deserialize(byte[] buf, int offset, int len) throws Exception
	{
		return deserialize(buf, offset, len, null);
	}

	public IMessage deserialize(byte[] buf, int offset, int len, IMessage reqmsg) throws Exception
	{
		String json = new String(buf, offset, len, charset);
		try
		{
			return new Message(new CompositeNode((Map) JsonUtil.json2obj(json)));
		}
		catch (Exception e)
		{
			log.warn("offset:" + offset + ",len:" + len + ",json:" + json + ",e:" + e);
			throw e;
		}
	}

	public IMessage deserialize(byte[] buf) throws Exception
	{
		return deserialize(buf, 0, buf.length, null);
	}

	public IMessage deserialize(byte[] buf, IMessage reqmsg) throws Exception
	{
		return deserialize(buf, 0, buf.length, reqmsg);
	}

	public byte[] serialize(IMessage msg) throws Exception
	{
		return JsonUtil.obj2json(msg.getTransaction()).getBytes(charset);
	}

	public void setCharset(String charset)
	{
		this.charset = charset;
	}
}
