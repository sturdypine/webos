package spc.webos.data.sig;

import spc.webos.data.IMessageSchema;
import spc.webos.data.util.MessageUtil;
import spc.webos.log.Log;
import spc.webos.security.ISignature;

/**
 * ����ǩ����
 * 
 * @author spc
 * 
 */
public class MessageSignature
{
	/**
	 * ESB ����ǩ��
	 * 
	 * @param nodeCd
	 *            ���սڵ���
	 * @param msg
	 * @return
	 * @throws Exception
	 */
	public byte[] sig(String node, byte[] msg) throws Exception
	{
		byte[] body = MessageUtil.getBody(msg);
		String strSig = getSignature(node).sign(node, body, null);
		return MessageUtil.addSignature(msg, strSig.getBytes());
	}

	/**
	 * ESB ������ǩ
	 * 
	 * @param nodeCd
	 *            ���ͷ��ڵ��
	 * @param msg
	 * @return
	 * @throws Exception
	 */
	public boolean unsig(String node, byte[] msg) throws Exception
	{
		byte[] sigs = MessageUtil.getSignature(msg);
		if (sigs == null)
		{
			log.warn("canot find signature in msg:" + node);
			return false;
		}
		return getSignature(node).unsign(node, new String(sigs), MessageUtil.getBody(msg), null);
	}

	public ISignature getSignature(String node)
	{
		return sig;
	}

	protected IMessageSchema msgSchema; // ��֤��Դ��������������ǩ���ı��Ľṹ��Ϣ
	protected ISignature sig; // Ĭ�ϵ�ǩ���ӿ�
	public final static Log log = Log.getLogger(MessageSignature.class);

	public void setSig(ISignature sig)
	{
		this.sig = sig;
	}

	public void setMsgSchema(IMessageSchema msgSchema)
	{
		this.msgSchema = msgSchema;
	}
}
