package spc.webos.thread;

import spc.webos.data.IMessage;
import spc.webos.data.converter.IMessageConverter;

public interface IBufferMessage
{
	IMessage toMessage(IMessageConverter converter) throws Exception;
}
