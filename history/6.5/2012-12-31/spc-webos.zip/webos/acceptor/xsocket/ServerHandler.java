package spc.webos.acceptor.xsocket;

import spc.webos.buffer.IBuffer;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.flownode.MessageFlow;

public class ServerHandler extends DefaultServerHandler
{
	protected IBuffer reqbuf; // ����buffer
	protected int hdrLen = 8; // ÿ�����ĵ�ͷ���ȣ�����������ǰ���ĵĳ���
	protected boolean len2bcd; // ������Ϣbcd
	protected IMessageConverter converter; // ָ��ת���ӿ�
	protected MessageFlow msgFlow; // ָ���������ĵ���Ϣ��

	public void setHdrLen(int hdrLen)
	{
		this.hdrLen = hdrLen;
	}

	public void setReqbuf(IBuffer reqbuf)
	{
		this.reqbuf = reqbuf;
	}

	public IBuffer getReqbuf()
	{
		return reqbuf;
	}

	public void setConverter(IMessageConverter converter)
	{
		this.converter = converter;
	}

	public void setLen2bcd(boolean len2bcd)
	{
		this.len2bcd = len2bcd;
	}

	public void setMsgFlow(MessageFlow msgFlow)
	{
		this.msgFlow = msgFlow;
	}

	public int getHdrLen()
	{
		return hdrLen;
	}

	public boolean isLen2bcd()
	{
		return len2bcd;
	}

	public IMessageConverter getConverter()
	{
		return converter;
	}

	public MessageFlow getMsgFlow()
	{
		return msgFlow;
	}
}
