package spc.webos.acceptor.tcp;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.net.Socket;

import spc.webos.acceptor.SocketMessage;
import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.Message;
import spc.webos.thread.BufferMsgReceiver;
import spc.webos.util.FileUtil;

public class SocketMsgReceiver extends BufferMsgReceiver
{
	// ��buffer�л��acceptor, socket����
	protected IMessage obj2msg(Object obj) throws Exception
	{
		if (!(obj instanceof Object[])) return super.obj2msg(obj);
		TCPAcceptor acceptor = (TCPAcceptor) ((Object[]) obj)[0];
		Socket s = (Socket) ((Object[]) obj)[1];

		BufferedInputStream bis = new BufferedInputStream(s.getInputStream());
		byte[] buf = null;
		if (acceptor.getHdrLen() > 0)
		{ // chenjs 2012-12-12
			byte[] lenBytes = new byte[acceptor.getHdrLen()];
			bis.read(lenBytes);
			int len = acceptor.length(lenBytes);
			if (acceptor.getMaxbytes() > 0 && len > acceptor.getMaxbytes())
			{
				handleOverSizeMsg(acceptor, s, len);
				return null;
			}
			buf = FileUtil.readMsgWithLen(bis, len);
		}
		else
		{ // û���κν�����־��ǰ���Ƕ����ӷ�����
			buf = FileUtil.readMsgWithLen(bis, null); // ���������ж�ȡ������������
		}
		return buf2msg(acceptor, s, buf);
	}

	protected IMessage buf2msg(TCPAcceptor acceptor, Socket s, byte[] buf) throws Exception
	{
		if (buf == null)
		{
			log.debug("buf is null!!!");
			return null; // ˵���������Ѿ��ر�
		}
		Message msg = new Message();
		SocketMessage smsg = new SocketMessage(s, s.getOutputStream(), buf, acceptor.getHdrLen(),
				null, Common.ACCEPTOR_PROTOCOL_TCPIP);
		String ip = smsg.remoteAddress.getHostAddress();
		int index = ip.indexOf(':');
		msg.setInLocal(MsgLocalKey.ACCEPTOR_REMOTE_HOST, index > 0 ? ip.substring(0, index) : ip);
		msg.setInLocal(MsgLocalKey.ACCEPTOR_LOCAL_PORT, String.valueOf(smsg.localPort));
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_SOCKETMSG, smsg); // ���������Ϣ��ԭʼ��Ϣ
		msg.setInLocal(MsgLocalKey.ACCEPTOR_PROTOCOL, smsg.protocol);
		msg.setInLocal(MsgLocalKey.LOCAL_REP_BUFFER, smsg.repbuf);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, smsg.reqmsg);
		msg.setInLocal(MsgLocalKey.LOCAL_MSG_CONVERTER, acceptor.getConverter());
		msg.setInLocal(MsgLocalKey.LOCAL_MSGCVT_DELAY, Boolean.TRUE); // �ӳٽ���
		if (acceptor.getMsgFlow() != null) msg.setInLocal(MsgLocalKey.LOCAL_MSG_MSGFLOW,
				acceptor.getMsgFlow());
		delay(msg);
		return msg;
	}

	protected boolean handleOverSizeMsg(TCPAcceptor acceptor, Socket s, int len) throws IOException
	{
		log.warn("too long msg, localPort:" + acceptor.getPort() + ",remote: "
				+ s.getRemoteSocketAddress() + ", len:" + len + ", maxbytes:"
				+ acceptor.getMaxbytes() + ", cnn will close!!!");
		s.close();
		return false;
	}
}
