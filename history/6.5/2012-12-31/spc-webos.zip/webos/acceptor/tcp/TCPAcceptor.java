package spc.webos.acceptor.tcp;

import java.net.ServerSocket;

import spc.webos.acceptor.Acceptor;

/**
 * ����Ľ���tcp����Ľ�����
 * 
 * @author spc
 * 
 */
public class TCPAcceptor extends Acceptor
{
	protected ServerSocket server;

	public void execute()
	{
		try
		{
			if (log.isInfoEnabled()) log.info("TCPAcceptor(" + getName()
					+ ") start to listen to port: " + port);
			server = new ServerSocket(port);
			while (status == RUNNING)
				startHandleThread();
		}
		catch (Throwable t)
		{
			log.error("TCPAcceptor(" + getName() + ").execute", t);
		}
		finally
		{
			release();
		}
	}

	public void startHandleThread() throws Exception
	{
		new HandlerThread(this, server.accept()).start();
//		if(reqbuf!=null) reqbuf.put(new Object[]{this, server.accept()});
	}

	public void release()
	{
		log.warn("TCPAcceptor(" + getName() + ") stop to listen to port: " + port);
		super.release();
		try
		{
			if (server != null) server.close();
		}
		catch (Exception e)
		{
			log.error("TCPAcceptor.close", e);
		}
		server = null;
	}
}
