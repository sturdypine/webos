package spc.webos.acceptor;

import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;

import org.xsocket.connection.INonBlockingConnection;

import spc.webos.buffer.IBuffer;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.thread.IBufferMessage;

/**
 * socketЭ����뱨��
 * 
 * @author spc
 * 
 */
public class SocketMessage implements IBufferMessage
{
	public byte[] reqmsg; // ����������
	public byte[] repmsg; // Ӧ��������
	public int hdrLen; // ���ķ��Ͷ���ͷ����
	public boolean containHdrLenSelf; // 2012-11-26 chenjs ��Щģʽ����ͷ��Ϣ�������ȱ���
	public boolean len2bcd;
	public boolean hdrLenBinary;
	public int localPort; // ���񷽽��ܶ˿�
	public boolean endFlag;
	public String protocol; // Э��
	public InetAddress remoteAddress; // Զ�̿ͻ������ӵ�ַ
	public InetAddress localAddress; // ����˽ӿ�
	public IBuffer repbuf; // Ӧ��buffer
	public INonBlockingConnection nbc;
	public OutputStream os; // socketЭ��
	public Socket socket;

	public SocketMessage()
	{
	}

	public SocketMessage(Socket s, OutputStream os, byte[] reqmsg, int hdrLen, IBuffer repbuf,
			String protocol)
	{
		this.socket = s;
		this.reqmsg = reqmsg;
		this.os = os;
		this.hdrLen = hdrLen;
		remoteAddress = s.getInetAddress();
		localAddress = s.getLocalAddress();
		this.repbuf = repbuf;
		this.protocol = protocol;
		this.localPort = s.getLocalPort();
	}

	public SocketMessage(INonBlockingConnection nbc, byte[] reqmsg, int hdrLen,
			boolean containHdrLenSelf, IBuffer repbuf, String protocol, boolean len2bcd,
			boolean hdrLenBinary)
	{
		this(nbc, reqmsg, hdrLen, false, repbuf, protocol);
		this.len2bcd = len2bcd;
		this.hdrLenBinary = hdrLenBinary;
		this.containHdrLenSelf = containHdrLenSelf;
	}

	public SocketMessage(INonBlockingConnection nbc, byte[] reqmsg, int hdrLen, IBuffer repbuf,
			String protocol, boolean len2bcd, boolean hdrLenBinary)
	{
		this(nbc, reqmsg, hdrLen, false, repbuf, protocol);
		this.len2bcd = len2bcd;
		this.hdrLenBinary = hdrLenBinary;
	}

	public SocketMessage(INonBlockingConnection nbc, byte[] reqmsg, int hdrLen, boolean endFlag,
			IBuffer repbuf, String protocol)
	{
		this.localPort = nbc.getLocalPort();
		this.reqmsg = reqmsg;
		this.nbc = nbc;
		this.hdrLen = hdrLen;
		this.endFlag = endFlag;
		remoteAddress = nbc.getRemoteAddress();
		localAddress = nbc.getLocalAddress();
		this.repbuf = repbuf;
		this.protocol = protocol;
	}

	public IMessage toMessage(IMessageConverter converter) throws Exception
	{
		IMessage msg = converter.deserialize(reqmsg);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_SOCKETMSG, this); // ���������Ϣ��ԭʼ��Ϣ
		msg.setInLocal(MsgLocalKey.ACCEPTOR_PROTOCOL, protocol);
		if (repbuf != null) msg.setInLocal(MsgLocalKey.LOCAL_REP_BUFFER, repbuf);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, reqmsg);
		return msg;
	}
}
