package spc.webos.jsrmi.service.spring;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.ServletContext;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import spc.webos.jsrmi.service.JsrmiServiceConfigurer;

public class SpringUtils
{

	/**
	 * get configed buffalo bean names from servlet context
	 * 
	 * @param context
	 *            the servlet contex
	 * @return the map, with form servicdId - serviceBeanName
	 */
	public static Map getConfigedBeanNames(ServletContext context)
	{
		Map services = new HashMap();
		if (context == null) return null;
		WebApplicationContext appCtx = WebApplicationContextUtils
				.getWebApplicationContext(context);
		if (appCtx == null)
		{
			// the appContext does not exist.
			return services;
		}

		// add batchCall
		String batchCallName = "jsrmiBatchCallService";
		String[] jsrmiConfigBeanNames = appCtx
				.getBeanNamesForType(JsrmiServiceConfigurer.class);

		for (int i = 0; i < jsrmiConfigBeanNames.length; i++)
		{
			String beanName = jsrmiConfigBeanNames[i];
			JsrmiServiceConfigurer configBean = (JsrmiServiceConfigurer) appCtx
					.getBean(beanName, JsrmiServiceConfigurer.class);
			Map singleServices = configBean.getServices();
			if (batchCallName != null)
			{
				String serviceName = "BCS";
				singleServices.put(serviceName, appCtx.getBean(batchCallName));
				services.put(serviceName, beanName);
				batchCallName = null;
			}
			Iterator iter = singleServices.keySet().iterator();
			while (iter.hasNext())
			{
				String serviceName = (String) iter.next();
				services.put(serviceName, beanName);
			}
		}

		return services;
	}

}
