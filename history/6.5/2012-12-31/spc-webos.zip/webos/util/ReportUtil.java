package spc.webos.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * �����Ĺ�����
 * 
 * @author spc
 * 
 */
public class ReportUtil
{
	public final static ReportUtil REPORTUTIL = new ReportUtil();

	public static ReportUtil getInstance()
	{
		return REPORTUTIL;
	}

	// һ����Ա��������Ҫ�����������ļ�Լд��
	public static Object getValue(List data, Map rowIndex, String row,
			Object defaultValue, String col)
	{
		if (rowIndex == null || data == null) return defaultValue;
		if (!rowIndex.containsKey(row)) return defaultValue;
		Integer r = (Integer) rowIndex.get(row);
		if (row == null || r == null) return defaultValue;
		return getValue(data, r.intValue(), defaultValue, col);
	}

	public static Object getValue(List data, int row, Object defaultValue,
			String col)
	{
		Object value = null;
		try
		{ // ����������col����������,����Ϊ���н����ΪList����ΪMap
			value = ((List) data.get(row)).get(Integer.parseInt(col));
		}
		catch (NumberFormatException nfe)
		{
			value = ((Map) data.get(row)).get(col);
		}
		return value == null
				|| (value instanceof String && ((String) value).length() == 0) ? defaultValue
				: value;
	}

	// ���еĺ�ֵ���
	public static Object getDivideValue(List data, Map rowIndex, List row1,
			List row2, Object defaultValue, String col)
	{
		Object n1 = getSumValue(data, rowIndex, row1, null, col);
		Object n2 = getSumValue(data, rowIndex, row2, null, col);
		try
		{
			double v2 = Double.parseDouble(n2.toString());
			if (n1 == null || n2 == null || v2 == 0) return defaultValue;
			return new Double(Double.parseDouble(n1.toString()) / v2);
		}
		catch (NumberFormatException nfe)
		{
		}
		return defaultValue;
	}

	public static Double divide(Object v1, Object v2, Object def)
	{
		double f = Double.parseDouble(v1.toString());
		double s = Double.parseDouble(v2.toString());
		if (Math.abs(s) < 0.00000000000000001) return new Double(def.toString());
		return new Double(f / s);
	}

	// ���������λ��ĳ��, ���������
	public static Object getDivideValue(List data, Map rowIndex, String row,
			Object defaultValue, String col1, String col2)
	{
		Object n1 = getValue(data, rowIndex, row, null, col1);
		Object n2 = getValue(data, rowIndex, row, null, col2);
		try
		{
			if (n1 == null || n2 == null
					|| Double.parseDouble(n2.toString()) == 0) return defaultValue;
			return new Double(Double.parseDouble(n1.toString())
					/ Double.parseDouble(n2.toString()));
		}
		catch (NumberFormatException nfe)
		{
		}
		return defaultValue;
	}

	// ��ȡĳһ�еĺϼ�
	public static Object getColSumValue(List data, Object defaultValue,
			String col)
	{
		if (data == null || data.size() == 0) return defaultValue;
		double sum = 0;
		for (int i = 0; i < data.size(); i++)
		{
			Object value = getValue(data, i, defaultValue, col);
			sum += value == null ? 0 : Double.parseDouble(value.toString());
		}
		return new Double(sum);
	}

	// ָ����һ����Ԫ��ϼ�
	public static Object getSumValue(List data, Map rowIndex, List cells,
			Object defaultValue)
	{
		if (rowIndex == null || data == null) return defaultValue;
		double sum = 0;
		Integer zero = new Integer(0);
		for (int i = 0; i < cells.size(); i++)
		{
			List cell = (List) cells.get(i);
			sum += Double.parseDouble(getValue(data, rowIndex,
					(String) cell.get(0), zero, (String) cell.get(1))
					.toString());
		}
		return new Double(sum);
	}

	// ָ��һ�������е�ĳ�кϼ�
	public static Object getSumValue(List data, Map rowIndex, List rows,
			Object defaultValue, String col)
	{

		if (rowIndex == null || data == null) return defaultValue;
		double sum = 0;
		Integer zero = new Integer(0);
		for (int i = 0; i < rows.size(); i++)
			sum += Double.parseDouble(getValue(data, rowIndex,
					(String) rows.get(i), zero, col).toString());
		return new Double(sum);
	}

	// ָ��һ�������е�ĳ�кϼ� ͬ��
	public static Object getSumValue(List data, Map rowIndex, String[] rows,
			Object defaultValue, String col)
	{
		if (rowIndex == null || data == null) return defaultValue;
		double sum = 0;
		Integer zero = new Integer(0);
		for (int i = 0; i < rows.length; i++)
			sum += Double.parseDouble(getValue(data, rowIndex,
					(String) rows[i], zero, col).toString());
		return new Double(sum);
	}

	// ָ��һ�������е�ĳ�о�ֵ
	public static Object getAvgValue(List data, Map rowIndex, List rows,
			Object defaultValue, String col)
	{
		if (rowIndex == null || data == null) return defaultValue;
		double sum = 0;
		int count = 0;
		for (int i = 0; i < rows.size(); i++)
		{
			Object value = getValue(data, rowIndex, (String) rows.get(i), null,
					col);
			if (value == null
					|| (value instanceof String && ((String) value).length() == 0)) continue;
			sum += Double.parseDouble(value.toString());
			count++;
		}
		return count == 0 ? defaultValue : new Double(sum / count);
	}

	// ָ��һ�������е�ĳ�о�ֵ ͬ��
	public static Object getAvgValue(List data, Map rowIndex, String[] rows,
			Object defaultValue, String col)
	{
		if (rowIndex == null || data == null) return defaultValue;
		double sum = 0;
		int count = 0;
		for (int i = 0; i < rows.length; i++)
		{
			Object value = getValue(data, rowIndex, (String) rows[i], null, col);
			if (value == null
					|| (value instanceof String && ((String) value).length() == 0)) continue;
			sum += Double.parseDouble(value.toString());
			count++;
		}
		return count == 0 ? defaultValue : new Double(sum / count);
	}

	// ���ط����������ʽ����
	public static List getRegRow(List data, Map ri, String regRow)
	{
		List rows = new ArrayList();
		Pattern p = Pattern.compile(regRow);
		Iterator keys = ri.keySet().iterator();
		while (keys.hasNext())
		{
			String key = (String) keys.next();
			if (!p.matcher(key).matches()) continue;
			rows.add(key);
		}
		return rows;
	}

	// ָ�����������ϲ����������ʽ����ͳ��, �ʺ��ڻ��������й���,��Ҫ���и������Ž���С�Ƶ����
	// ͳ�ƽ��Ϊ С��, �ܼ�¼��, ��ֵ
	public static Object[] getRegStat(List data, Map ri, String regRow,
			String col)
	{
		double sum = 0;
		int count = 0;
		Integer zero = new Integer(0);
		Pattern p = Pattern.compile(regRow);
		Iterator keys = ri.keySet().iterator();
		while (keys.hasNext())
		{
			String key = (String) keys.next();
			if (!p.matcher(key).matches()) continue;
			count++;
			sum += Double.parseDouble(getValue(data,
					((Integer) ri.get(key)).intValue(), zero, col).toString());
		}
		return new Object[] { new Double(sum), new Integer(count),
				count <= 0 ? new Double(0) : new Double(sum / count) };
	}

	// ��ָ������ʼ�е������е�ָ���н���ͳ��
	public static double getSumValue(List data, String start, String end,
			String col)
	{
		double sum = 0;
		Integer zero = new Integer(0);
		int s = Integer.parseInt(start);
		int e = Integer.parseInt(end);
		for (int i = s; i <= e; i++)
			sum += Double.parseDouble(getValue(data, i, zero, col).toString());
		return sum;
	}
}
