package spc.webos.queue;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.thread.IBufferMessage;

//import com.ibm.mq.MQMessage;

/**
 * �Ӷ����л�ȡ����Ϣ
 * 
 * @author chenjs
 * 
 */
public class QueueMessage implements Serializable, IBufferMessage
{
	private static final long serialVersionUID = 1L;
	public byte[] messageId; // ������Ϣ��, ������Ϣ����
	public byte[] correlationId; //
	public byte[] buf; // ������Ϣ����
	public long inBufTime; // ����bufferʱ��
	public int expirySeconds; // ��Ϣ�Ľ�����е���Чʱ��
	public String sn; // ��ˮ��
	public Object msg; // ��Ϣ�ڴ����, һ����Message
	public String qname; // ��ȡ��Ϣʱ,���϶�����
	public Map qmprops; // ��Ϣ��Դ�Ķ��й�������Ϣ
	public Map attribute; // ��Ϣ����
	public int ccsid = 1208;
	public int persistence;
	public Date putDateTime; // ����Ϣʱ��
	public Object mqmsg; // һ���������Ҫ���ô˶����ڸ�������ʱʹ��
	public int feedback;
	public String applicationIdData;
	public String applicationOriginData;
	public String putAppName;
	public int priority;
	public long createTm = System.currentTimeMillis(); // ��ǰ������ʱ��, ���ڵ���BA��MQ��ȡ��Ϣ������Ϣ������ȫ��ʱ��

	public QueueMessage()
	{
	}

	public QueueMessage(byte[] buf)
	{
		this.buf = buf;
	}

	public QueueMessage(byte[] buf, byte[] correlationId, byte[] messageId)
	{
		this(buf, correlationId, messageId, 0, null);
	}

//	public QueueMessage(MQMessage mqmsg, String qname) throws IOException
//	{
//		this.qname = qname;
//		if (mqmsg == null) return;
//		this.mqmsg = mqmsg;
//		ccsid = mqmsg.characterSet;
//		correlationId = mqmsg.correlationId;
//		messageId = mqmsg.messageId;
//		putAppName = mqmsg.putApplicationName;
//		putDateTime = mqmsg.putDateTime.getTime();
//		buf = new byte[mqmsg.getMessageLength()];
//		feedback = mqmsg.feedback;
//		applicationIdData = mqmsg.applicationIdData;
//		applicationOriginData = mqmsg.applicationOriginData;
//		persistence = mqmsg.persistence;
//		mqmsg.readFully(buf);
//		this.createTm = System.currentTimeMillis();
//	}
//
//	public QueueMessage(MQMessage mqmsg, byte[] buf, String qname) throws IOException
//	{
//		this.qname = qname;
//		if (mqmsg == null) return;
//		this.mqmsg = mqmsg;
//		this.buf = buf;
//		ccsid = mqmsg.characterSet;
//		feedback = mqmsg.feedback;
//		applicationIdData = mqmsg.applicationIdData;
//		applicationOriginData = mqmsg.applicationOriginData;
//		correlationId = mqmsg.correlationId;
//		messageId = mqmsg.messageId;
//		putAppName = mqmsg.putApplicationName;
//		putDateTime = mqmsg.putDateTime.getTime();
//		persistence = mqmsg.persistence;
//		this.createTm = System.currentTimeMillis();
//	}

	public QueueMessage(byte[] buf, byte[] correlationId, byte[] messageId, String qname)
	{
		this(buf, correlationId, messageId, 0, qname);
	}

	public QueueMessage(byte[] buf, byte[] correlationId, byte[] messageId, int expirySeconds)
	{
		this(buf, correlationId, messageId, expirySeconds, null);
	}

	public QueueMessage(byte[] buf, byte[] correlationId, byte[] messageId, int expirySeconds,
			String qname)
	{
		this.buf = buf;
		this.correlationId = correlationId;
		this.messageId = messageId;
		this.expirySeconds = expirySeconds;
		this.qname = qname;
		this.createTm = System.currentTimeMillis();
	}

	public QueueMessage(IMessage msg, byte[] buf, byte[] correlationId, byte[] messageId,
			String qname)
	{
		this(buf, correlationId, messageId, 0, qname);
		this.msg = msg;
	}

	public QueueMessage(IMessage msg, byte[] buf)
	{
		this.msg = msg;
		this.buf = buf;
		this.sn = msg.getMsgSn();
		// correlationId = msg.getCorrelationID();
		// if (correlationId == null)
		// {
		// String sn = msg.isRequestMsg() ? msg.getMsgSn() : msg.getRefMsgSn();
		correlationId = msg.getMQCorId().getBytes();
		// sn.substring(sn.length() - 24).getBytes(); // MQ����Ϣ������ֻ����24λ
		// }
		this.expirySeconds = msg.getExpirySeconds() * 10;
		this.createTm = System.currentTimeMillis();
	}
	
	public QueueMessage(IMessage msg, byte[] buf, int expirySeconds)
	{
		this.msg = msg;
		this.buf = buf;
		this.sn = msg.getMsgSn();
		this.correlationId = msg.getMQCorId().getBytes();
		this.expirySeconds = expirySeconds;
		this.createTm = System.currentTimeMillis();
	}

	public QueueMessage(Object obj, byte[] buf, String sn, byte[] correlationId, byte[] messageId,
			int expirySeconds)
	{
		this.msg = obj;
		this.buf = buf;
		this.sn = sn;
		this.messageId = messageId;
		this.correlationId = correlationId;
		this.expirySeconds = expirySeconds;
		this.createTm = System.currentTimeMillis();
	}

	public QueueMessage(Object obj, byte[] buf, String sn, byte[] correlationId, byte[] messageId)
	{
		this.msg = obj;
		this.buf = buf;
		this.sn = sn;
		this.messageId = messageId;
		this.correlationId = correlationId;
	}

//	public MQMessage toMQMessage(MQMessage mqmsg) throws IOException
//	{
//		if (correlationId != null) mqmsg.correlationId = correlationId;
//		if (messageId != null) mqmsg.messageId = messageId;
//		if (expirySeconds > 0) mqmsg.expiry = expirySeconds * 10;
//		if (!StringX.nullity(applicationIdData)) mqmsg.applicationIdData = applicationIdData;
//		if (!StringX.nullity(applicationOriginData)) mqmsg.applicationOriginData = applicationOriginData;
//		if (!StringX.nullity(putAppName)) mqmsg.putApplicationName = putAppName;
//		mqmsg.persistence = persistence;
//		mqmsg.feedback = feedback;
//		if (priority >= 0) mqmsg.priority = priority; // added by chenjs.
//														// 2011-05-11 ������Ϣ�����ȼ�����
//		if (ccsid > 0) mqmsg.characterSet = ccsid;
//		mqmsg.write(buf);
//		return mqmsg;
//	}

	public byte[] getMessageId()
	{
		return messageId;
	}

	public void setMessageId(byte[] messageId)
	{
		this.messageId = messageId;
	}

	public byte[] getCorrelationId()
	{
		return correlationId;
	}

	public void setCorrelationId(byte[] correlationId)
	{
		this.correlationId = correlationId;
	}

	public byte[] getBuf()
	{
		return buf;
	}

	public void setBuf(byte[] buf)
	{
		this.buf = buf;
	}

	public long getInBufTime()
	{
		return inBufTime;
	}

	public void setInBufTime(long inBufTime)
	{
		this.inBufTime = inBufTime;
	}

	public int getExpirySeconds()
	{
		return expirySeconds;
	}

	public void setExpirySeconds(int expirySeconds)
	{
		this.expirySeconds = expirySeconds;
	}

	public String getSn()
	{
		return sn;
	}

	public void setSn(String sn)
	{
		this.sn = sn;
	}

	public Object getMsg()
	{
		return msg;
	}

	public void setMsg(Object msg)
	{
		this.msg = msg;
	}

	public String getQname()
	{
		return qname;
	}

	public void setQname(String qname)
	{
		this.qname = qname;
	}

	public Map getAttribute()
	{
		return attribute;
	}

	public void setAttribute(Map attribute)
	{
		this.attribute = attribute;
	}

	public Date getPutDateTime()
	{
		return putDateTime;
	}

	public void setPutDateTime(Date putDateTime)
	{
		this.putDateTime = putDateTime;
	}

	public IMessage toMessage(IMessageConverter converter) throws Exception
	{
		IMessage msg = converter.deserialize(buf);
		msg.setCorrelationID(correlationId);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_QMSG, this); // ���������Ϣ��ԭʼ��Ϣ
		msg.setInLocal(MsgLocalKey.ACCEPTOR_PROTOCOL, Common.ACCEPTOR_PROTOCOL_QUEUE_MQ);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, buf);
		return msg;
	}

	public int getFeedback()
	{
		return feedback;
	}

	public void setFeedback(int feedback)
	{
		this.feedback = feedback;
	}

	public String getApplicationIdData()
	{
		return applicationIdData;
	}

	public void setApplicationIdData(String applicationIdData)
	{
		this.applicationIdData = applicationIdData;
	}

	public String getApplicationOriginData()
	{
		return applicationOriginData;
	}

	public void setApplicationOriginData(String applicationOriginData)
	{
		this.applicationOriginData = applicationOriginData;
	}

	public String getPutAppName()
	{
		return putAppName;
	}

	public void setPutAppName(String putAppName)
	{
		this.putAppName = putAppName;
	}

	public int getPriority()
	{
		return priority;
	}

	public void setPriority(int priority)
	{
		this.priority = priority;
	}
}
