package spc.webos.queue.jms;

import spc.webos.queue.AccessTPool;
import spc.webos.thread.DaemonThread;

public class JMSThreadPool extends AccessTPool
{
	public DaemonThread borrow()
	{
		return null;
//		if (AccessThread.RW_READ == rw) return new ReceiverThread(this, props,
//				buffers);
//		return new SenderThread(this, props, buffers);
	}
}
