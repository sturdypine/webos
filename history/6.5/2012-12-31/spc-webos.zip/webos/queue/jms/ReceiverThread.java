package spc.webos.queue.jms;

import javax.jms.BytesMessage;

import org.springframework.jms.core.JmsTemplate;

import spc.webos.data.IMessage;
import spc.webos.queue.AbstractReceiverThread;
import spc.webos.queue.QueueMessage;

public class ReceiverThread extends AbstractReceiverThread
{
	JmsTemplate jms;

	public void setJms(JmsTemplate jms)
	{
		this.jms = jms;
	}

	public Object receive(String queueName)
	{
		// System.out.println("ReceiverThread.."
		// + Thread.currentThread().getName());
		QueueMessage qmsg = null;
		try
		{
			BytesMessage msg = (BytesMessage) jms.receive(queueName);
			if (msg == null) return qmsg;
			byte[] content = new byte[(int) msg.getBodyLength()];
			msg.readBytes(content);
			// eaiMsg = new EAIMessage(content);
			// eaiMsg.setCorrelationID(eaiMsg.getTransSN());
			// preProcess(eaiMsg);
			// System.out.println("ReceiverThread.."
			// + Thread.currentThread().getName()
			// + ".get="
			// + content.length
			// + ","
			// + new String(content)+"\n\n");
		}
		catch (Exception e)
		{
			log.error(getClass().getName() + ",queueName:" + queueName, e);
		}
		return qmsg;
	}

	// Ԥ����������Ϣ
	public void preProcess(IMessage msg)
	{
	}
}
