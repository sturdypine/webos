package spc.webos.web.filter;

import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * ��ֹ�ͻ��˶�ʱ�䷴�����������. 
 * @author Hate
 *
 */

public class AntiFlushReqFilter extends AbstractURLFilter
{
	int interval = -1; // millis...
	static String LAST_VIST_TIME_KEY = "_LAST_VIST_TIME_";

	public void filter(ServletRequest req, ServletResponse res, FilterChain chain, String patternURL)
			throws IOException, ServletException
	{
		if (interval <= 0)
		{
			chain.doFilter(req, res);
			return;
		}
		HttpServletRequest request = (HttpServletRequest) req;
		HttpSession session = request.getSession(true);
		Long timeMillis = (Long) session.getAttribute(LAST_VIST_TIME_KEY);
		long currentTimeMillis = System.currentTimeMillis();
		if (timeMillis == null || currentTimeMillis - timeMillis.longValue() <= interval)
		{
			chain.doFilter(req, res);
			session.setAttribute(LAST_VIST_TIME_KEY, new Long(currentTimeMillis));
			return;
		}
	}

	public void setInterval(int interval)
	{
		this.interval = interval;
	}
}
