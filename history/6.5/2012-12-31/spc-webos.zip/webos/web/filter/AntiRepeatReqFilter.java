package spc.webos.web.filter;

import java.io.IOException;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * ��ֹһ��URL��ĳ��ָ����ģʽ���ظ�����
 * 
 * @author Hate
 * 
 */
public class AntiRepeatReqFilter extends AbstractURLFilter
{
	static final String LAST_VISIT_URI = "_FILTER_LAST_VISIT_URI_";
	static final String LAST_VISIT_METHOD = "_FILTER_LAST_VISIT_METHOD_";

	public void filter(ServletRequest req, ServletResponse res, FilterChain chain, String patternURL)
			throws IOException, ServletException
	{
		HttpServletRequest request = (HttpServletRequest) req;
		HttpSession session = request.getSession(true);
		String lastURI = (String) session.getAttribute(LAST_VISIT_URI);
		String uri = request.getRequestURI();
		String method = request.getMethod();
//		System.out.println("AntiRepeatReqFilter " + lastURI + ", " + uri);
		if (lastURI == null || !lastURI.equals(uri))
		{
			chain.doFilter(req, res);
			session.setAttribute(LAST_VISIT_URI, uri);
			session.setAttribute(LAST_VISIT_METHOD, method);
			return;
		}
		Map paramMap = queryStringToMap(patternURL);
		String patternMethod = null;
		if (paramMap != null) patternMethod = (String) paramMap.get("pattern");
		if (patternMethod == null) patternMethod = "PP"; // Ĭ����ֹģʽΪ����ͬ��URL��������Postģʽ������
		String lastMethod = (String) session.getAttribute(LAST_VISIT_METHOD);
		String currentPattern = Character.toString(lastMethod.charAt(0))
				+ Character.toString(method.charAt(0));

		session.setAttribute(LAST_VISIT_URI, uri);
		session.setAttribute(LAST_VISIT_METHOD, method);
		if (patternMethod.indexOf(currentPattern) >= 0)
		{ // �ظ�����
			System.out.println("AntiRepeatReqFilter: repeat request...");
			return;
		}
		chain.doFilter(req, res);
	}
}
