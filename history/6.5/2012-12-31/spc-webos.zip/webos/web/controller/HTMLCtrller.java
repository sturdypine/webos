package spc.webos.web.controller;

import java.io.FileInputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.io.Resource;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import spc.webos.constant.Common;
import spc.webos.util.FileUtil;
import spc.webos.util.StringX;

/**
 * ��ĳЩ��Դxml�ȵȱ��html��ʽ���
 * 
 * @author spc
 * 
 */
public class HTMLCtrller implements Controller
{
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response)
			throws Exception
	{
		String cnt = new String(FileUtil.is2bytes(new FileInputStream(dir.getFile()
				.getAbsolutePath() + '/' + request.getParameter("file"))), charset);
		response.getWriter().print(StringX.toHTML(cnt));
		return null;
	}

	protected Resource dir;
	protected String charset = Common.CHARSET_UTF8;

	public void setDir(Resource dir)
	{
		this.dir = dir;
	}

	public void setCharset(String charset)
	{
		this.charset = charset;
	}
}
