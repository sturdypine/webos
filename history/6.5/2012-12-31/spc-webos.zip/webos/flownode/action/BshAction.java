package spc.webos.flownode.action;

import java.util.HashMap;
import java.util.Map;

import spc.webos.data.IMessage;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.SystemUtil;

public class BshAction extends AbstractAction
{
	private static final long serialVersionUID = 1L;

	void execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		Map params = new HashMap();
		params.put("msg", msg);
		SystemUtil.bsh(bsh, params);
	}

	protected String bsh;

	public String getBsh()
	{
		return bsh;
	}

	public void setBsh(String bsh)
	{
		this.bsh = bsh;
	}
}
