package spc.webos.flownode.impl;

import java.util.HashMap;
import java.util.Map;

import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

public class PersistenceAFNode extends AbstractFNode
{
	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		Map params = new HashMap();
		SystemUtil.freemarker(params);
		Map results = new HashMap();
		persistence.execute(StringX.split((String) msg.getInLocal(MsgLocalKey.JDBC_SQL_ID),
				StringX.COMMA), params, results);
		String resultKey = (String) msg.getInLocal(MsgLocalKey.JDBC_RESULT);
		if (!StringX.nullity(resultKey)) msg.setInLocal(resultKey, results);
		return null;
	}
}
