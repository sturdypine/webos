package spc.webos.flownode.impl;

import java.util.ArrayList;
import java.util.List;

import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.flownode.IFlowContext;
import spc.webos.queue.QueueMessage;
import spc.webos.queue.ibmmq.Accessor;
import spc.webos.queue.ibmmq.MQCnnPool;
import spc.webos.queue.ibmmq.MQMessageUtil;

import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;

/**
 * ִ�������н���Ϣֱ�ӷ���ָ����MQ����
 * 
 * @author chenjs
 * 
 */
public class MQPutAFNode extends QueuePutAFNode
{
	protected void send(String qname, Object qmsg) throws Exception
	{
		Accessor.sendCluster(randomStart, cnnpools, qname, pmo, (MQMessage) qmsg, retryTimes,
				retryInterval);
	}

	protected Object getQMessage(IMessage msg, IFlowContext cxt) throws Exception
	{
		MQMessage mqmsg = (MQMessage) msg.getInLocal(MsgLocalKey.MQPUT_MQMSG_KEY);
		if (mqmsg != null) return mqmsg;
		QueueMessage qmsg = (QueueMessage) super.getQMessage(msg, cxt);
		if (log.isDebugEnabled()) log.debug("MQ buf:" + new String(qmsg.buf, Common.CHARSET_UTF8));
		// return qmsg.toMQMessage(new MQMessage());
		// modified by chenjs 2012-11-29 ֧��TLQ���Ƴ�QueueMessage�����MQMessage����
		return MQMessageUtil.toMQMessage(qmsg, new MQMessage());
	}

	protected MQPutMessageOptions pmo = new MQPutMessageOptions();
	protected List<MQCnnPool> cnnpools;
	protected boolean randomStart = true; // ��Ⱥģʽ��ʹ���������ʼ

	public void setCnnpool(MQCnnPool cnnpool)
	{
		this.cnnpools = new ArrayList<MQCnnPool>();
		cnnpools.add(cnnpool);
	}

	public void setCnnpools(List<MQCnnPool> cnnpools)
	{
		this.cnnpools = cnnpools;
	}

	public void setRandomStart(boolean randomStart)
	{
		this.randomStart = randomStart;
	}
}
