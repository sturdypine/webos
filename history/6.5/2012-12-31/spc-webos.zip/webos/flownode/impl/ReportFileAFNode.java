package spc.webos.flownode.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import spc.webos.data.IMessage;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;
import freemarker.template.Configuration;
import freemarker.template.Template;

/**
 * ��������������SQL�Ľ����ģ���ļ�����ָ�������õ�ַ������һ���ļ�������ļ�ϵͳ, һ�����ı�ſ��Զ�Ӧ����ļ�
 * 
 * @author spc
 * 
 */
public class ReportFileAFNode extends FreeMarkerAFNode
{
	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		Map paths = getFilePath(msg);
		if (paths == null || paths.size() == 0)
		{
			if (log.isInfoEnabled()) log.info("target file path is null");
			return null;
		}
		if (log.isInfoEnabled()) log.info("target file path is: " + paths);
		List targetFiles = new ArrayList();
		Iterator keys = paths.keySet().iterator();
		while (keys.hasNext())
		{
			String key = keys.next().toString();
			String p = paths.get(key).toString();
			int index = p.lastIndexOf('/');
			File parentFile = new File(SystemUtil.getInstance().getResourceLoader().getResource(
					baseFilePath).getFile(), p.substring(0, index));
			if (!parentFile.exists()) parentFile.mkdirs();
			File targetFile = new File(parentFile, p.substring(index + 1));
			if (targetFile.exists()) targetFile.delete();
			targetFile.createNewFile();
			Writer writer = null;
			try
			{
				writer = new OutputStreamWriter(new FileOutputStream(targetFile), charset);
				freemarker(msg, cxt, key, getSqls(msg), writer, null);
				targetFiles.add(targetFile);
			}
			finally
			{
				if (writer != null) writer.close();
			}
		}
		msg.setInLocal(TARGET_FILES_KEY, targetFiles);
		return null;
	}

	protected Map getFilePath(IMessage msg) throws Exception
	{
		if (filePath == null) return null;
		Map fpath = (Map) filePath.get(msg.getMsgCd());
		if (fpath == null) return null;
		Map path = new HashMap();
		StringWriter sw = new StringWriter();
		Iterator keys = fpath.keySet().iterator();
		while (keys.hasNext())
		{
			sw.getBuffer().setLength(0);
			String key = keys.next().toString();
			Map root = SystemUtil.freemarker(null, msg);
			SystemUtil.freemarker(new Template("FilePath", new StringReader(fpath.get(key)
					.toString()), new Configuration()), root, sw);
			path.put(key, StringX.trim(sw.toString()));
		}
		return path;
	}

	protected String baseFilePath = StringX.EMPTY_STRING; // ����ļ��Ļ���·��
	protected Map filePath; // �ļ�·��, �ļ�·�������ò���freemarkerģ�壬���Զ�̬����һ���ļ�·��
	public final static String TARGET_FILES_KEY = ReportFileAFNode.class.getName()
			+ "$TARGET_FILES";

	public String getBaseFilePath()
	{
		return baseFilePath;
	}

	public void setBaseFilePath(String baseFilePath)
	{
		this.baseFilePath = baseFilePath;
	}

	public Map getFilePath()
	{
		return filePath;
	}

	public void setFilePath(Map filePath)
	{
		this.filePath = filePath;
	}
}
