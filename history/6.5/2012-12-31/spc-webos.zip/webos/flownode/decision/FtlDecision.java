package spc.webos.flownode.decision;

import java.util.Map;

import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

public class FtlDecision extends AbstractDecision
{
	private static final long serialVersionUID = 1L;

	public String decide(IMessage msg, IFlowContext cxt) throws Exception
	{
		Map root = SystemUtil.freemarker(null, msg);
		root.put(Common.MODEL_CXT_KEY, cxt);
		root.put(FTL_DECISION_KEY, this);
		String transition = StringX.trim(SystemUtil.freemarker(ftl, root));
		if (log.isInfoEnabled()) log.info("transition:" + transition + ", variables:"
				+ msg.getInLocal(MsgLocalKey.LOCAL_BPL_VARIABLES));
		return transition;
	}

	protected String ftl;
	public final static String FTL_DECISION_KEY = "_ftldecision";

	public String getFtl()
	{
		return ftl;
	}

	public void setFtl(String ftl)
	{
		this.ftl = StringX.trim(ftl);
	}
}
