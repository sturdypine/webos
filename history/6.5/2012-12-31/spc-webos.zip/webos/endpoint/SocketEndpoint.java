package spc.webos.endpoint;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.net.SocketFactory;

import spc.webos.constant.AppRetCode;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.Message;
import spc.webos.exception.AppException;
import spc.webos.log.Log;
import spc.webos.thread.IMessageReceiver;
import spc.webos.util.FileUtil;
import spc.webos.util.NumberX;
import spc.webos.util.StringX;
import spc.webos.util.charset.EBCDUtil;

public class SocketEndpoint implements Endpoint, IMessageReceiver
{
	/**
	 * ������߳�ͬʱ��Ҫ����ʱ��socket������Ҫͬ��ʹ�á�
	 */
	public void execute(Executable exe) throws Exception
	{
		if (longCnn) longCnn(exe);
		else shortCnn(exe);
	}

	protected synchronized void longCnn(Executable exe) throws Exception
	{
		int fail = 0;
		do
		{
			try
			{
				init();
				is = cnn(s, os, is, exe);
				return;
			}
			catch (IOException ioe)
			{
				destory(); // �������IO�쳣����ر�����
				log.error("net error: ip:" + ip + ", port:" + port + ", retryTimes: " + retryTimes
						+ ", fail: " + fail + ", reqbytes base64: "
						+ new String(StringX.encodeBase64(exe.request)), ioe);
				if (exe.cnnSnd || retryTimes <= fail) throw new AppException(AppRetCode
						.PROTOCOL_SOCKET(),
						new Object[] { String.valueOf(ip), String.valueOf(port) });
				fail++;
			}
		}
		while (!exe.cnnSnd);
	}

	protected void shortCnn(Executable exe) throws Exception
	{
		Socket s = null;
		OutputStream os = null;
		InputStream is = null;

		try
		{ // modified by chenjs 2011-06-23 ������ȡ������
			s = createSocket();
			// modified by chenjs 2011-10-15 ��socket���ʹ��BufferedOutputStream
			// os = new BufferedOutputStream(s.getOutputStream());
			os = s.getOutputStream();
			is = cnn(s, os, null, exe);
		}
		catch (IOException ioe)
		{
			log.error(toString() + ", reqbytes base64: "
					+ new String(StringX.encodeBase64(exe.request)), ioe);
			throw new AppException(AppRetCode.PROTOCOL_SOCKET(), new Object[] { String.valueOf(ip),
					String.valueOf(port) });
		}
		finally
		{
			release(s, os, is);
		}
	}

	protected Socket createSocket() throws IOException
	{
		if (log.isInfoEnabled()) log.info("createSocket:" + toString());
		Socket socket = null;
		if (timeout <= 0) socket = new Socket(ip, port);
		else
		{
			socket = SocketFactory.getDefault().createSocket();
			socket.connect(new InetSocketAddress(ip, port), timeout); // ����connect�r�Otimeout
		}
		// added by chenjs 2011-06-13 ���Ӷ���Ϣ��ʱ����
		if (soTimeout > 0) socket.setSoTimeout(soTimeout);
		// added 2012-06-27
		if (receiveBufferSize > 0) socket.setReceiveBufferSize(receiveBufferSize);
		socket.setTcpNoDelay(tcpNoDelay);
		socket.setPerformancePreferences(0, 1, 2);
		return socket;
	}

	protected InputStream cnn(Socket socket, OutputStream os, InputStream is, Executable exe)
			throws Exception
	{
		if (!longCnn && !simplex && exe.getTimeout() > 0) socket
				.setSoTimeout(exe.getTimeout() * 1000);
		long start = System.currentTimeMillis();
		if (log.isInfoEnabled()) log.info("TCP corId:" + exe.getCorrelationID() + ", timeout:"
				+ exe.getTimeout() + ", withoutReturn:" + exe.isWithoutReturn() + ", reqbytes:"
				+ exe.getRequest().length);
		send(socket, os, exe);
		// added by chenjs 2011-06-13 ����һ����ǰ�����ж����ԣ������ǰ���׵���ʱָ���޷����򲻽��շ���
		if (simplex || exe.isWithoutReturn())
		{ // �����������ָ���޷�����ֱ�ӷ���
			// ����Ƕ�����,���ǵ��������޷��������׵��������˳�̫��,������޷��յ��ֽڣ���Ҫ����˯��50ms��֤��������������
			// if (!longCnn)
			// {
			// try
			// {
			// Thread.sleep(200);
			// }
			// catch (Throwable t)
			// {
			// }
			// }
			return is;
		}

		if (socket.isInputShutdown() || socket.isClosed()) log.warn("isInputShutdown: "
				+ socket.isInputShutdown() + ", socket: " + socket.isClosed());
		if (is == null) is = socket.getInputStream();
		receive(socket, is, exe);
		if (log.isInfoEnabled()) log.info("cost:" + (System.currentTimeMillis() - start));
		return is;
	}

	protected void send(Socket socket, OutputStream os, Executable exe) throws Exception
	{
		byte[] buf = exe.getRequest();
		if (buf == null)
		{
			log.warn("send request is null, cannot send!!!");
			return;
		}
		send(socket, os, buf);
		os.flush();
		exe.cnnSnd = true; // �Ѿ����ͳɹ�
		log.debug("set cnnSnd is true!!!");
	}

	protected void send(Socket socket, OutputStream os, byte[] buf) throws Exception
	{
		if (!sndLenWithBuf || len <= 0)
		{
			write(os, buf);
			if (log.isInfoEnabled()) log.info("no sndLenWithBuf: " + buf.length);
		}
		else
		{
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			write(baos, buf);
			os.write(baos.toByteArray());
			if (log.isInfoEnabled()) log.info("sndLenWithBuf: " + buf.length);
		}
	}

	protected void write(OutputStream os, byte[] buf) throws Exception
	{
		if (len > 0)
		{
			byte[] lenBytes = lenBytes(buf);
			os.write(lenBytes); // ���ͱ����ܳ���
			if (log.isDebugEnabled()) log.debug("snd buf: " + buf.length + ", lenBytes:["
					+ new String(lenBytes) + "]");
		}
		if (log.isDebugEnabled()) log.debug("base64 req buf:["
				+ new String(StringX.encodeBase64(buf)) + "], buf:["
				+ (len2bcd ? EBCDUtil.bcd2gbk(buf) : new String(buf)) + "]");
		if (buf != null && buf.length > 0) os.write(buf);
	}

	protected byte[] lenBytes(byte[] buf)
	{
		int bufLen = buf.length + (containHdrLenSelf ? len : 0);
		if (hdrLenBinary) return NumberX.int2bytes(bufLen, len);
		String strlen = (len <= 0 ? String.valueOf(bufLen) : StringX.int2str(
				String.valueOf(bufLen), len)); // ���ȹ̶�Ϊ10���Ƶ�8���ֽڣ�����ǰ�油0
		return len2bcd ? EBCDUtil.gbk2bcd(strlen) : strlen.getBytes();
	}

	protected void receive(Socket socket, InputStream is, Executable exe) throws Exception
	{
		exe.setResponse(receive(socket, is)); // ��ȡ����
	}

	public byte[] receive(Socket socket, InputStream is) throws Exception
	{
		if (is == null) is = socket.getInputStream();
		int hdrlen = (len > 0 ? length(FileUtil.readMsgWithLen(is, len)) : 0); // ��ȡ����
		return FileUtil.readMsgWithLen(is, hdrlen); // ��ȡ����
	}

	protected int length(byte[] lenBytes)
	{
		if (hdrLenBinary) return NumberX.bytes2int(lenBytes) - (containHdrLenSelf ? len : 0);
		return new Integer(len2bcd ? EBCDUtil.bcd2gbk(lenBytes) : new String(lenBytes).trim())
				.intValue()
				- (containHdrLenSelf ? len : 0);
	}

	public Socket getSocket()
	{
		return s;
	}

	public void init() throws Exception
	{
		if (s != null && longCnn)
		{
			log.debug("it is long cnn!!!");
			return; // modified by spc 2011-03-11
		}
		release(s, os, is);
		try
		{
			s = createSocket();
			// modified by chenjs 2011-10-15 ��socket���ʹ��BufferedOutputStream
			// os = new BufferedOutputStream(s.getOutputStream());
			os = s.getOutputStream();
		}
		catch (Exception e)
		{
			log.warn("Err createSocket: " + toString() + ", e:" + e);
			throw e;
		}
	}

	public void destory()
	{
		release(s, os, is);
		is = null;
		os = null;
		s = null;
	}

	public void release(Socket s, OutputStream os, InputStream is)
	{
		try
		{
			if (s != null)
			{
				log.info("close socket: " + s.getInetAddress());
				s.close();
			}
		}
		catch (Exception e)
		{
			log.warn("err to close socket", e);
		}
	}

	public void setIp(String ip)
	{
		this.ip = ip;
	}

	public void setPort(int port)
	{
		this.port = port;
	}

	public Endpoint clone() throws CloneNotSupportedException
	{
		SocketEndpoint se = new SocketEndpoint();
		se.ip = ip;
		se.port = port;
		se.retryTimes = retryTimes;
		se.simplex = simplex;
		se.longCnn = longCnn;
		se.len = len;
		se.len2bcd = len2bcd;
		se.timeout = timeout;
		se.soTimeout = soTimeout;
		return se;
	}

	public String toString()
	{
		return "TCP://" + ip + ":" + port + ", simplex:" + simplex + ", longCnn:" + longCnn + ":"
				+ len + ":" + len2bcd + ":" + hdrLenBinary + ", loc:" + location;
	}

	// added by chenjs 2012-05-08, ���ڽ���첽˫��ģʽ�µ�tcpЭ��
	public IMessage receive() throws Exception
	{
		try
		{
			while (s == null)
			{ // �ȴ�����ʱ��������
				log.debug("socket is null, sleep 500 mills");
				Thread.sleep(500);
			}
			if (is == null) is = s.getInputStream();
			byte[] buf = receive(s, is);
			IMessage msg = new Message();
			msg.setInLocal(MsgLocalKey.ACCEPTOR_REMOTE_HOST, ip);
			msg.setInLocal(MsgLocalKey.ACCEPTOR_LOCAL_PORT, String.valueOf(port));
			msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, buf);
			msg.setInLocal(MsgLocalKey.LOCAL_MSGCVT_DELAY, Boolean.TRUE); // �ӳٽ���
			return msg;
		}
		catch (Exception e)
		{
			log.warn("receive", e);
			destory();
		}
		return null;
	}

	public IMessage receive(long timeout) throws Exception
	{
		return receive();
	}

	public SocketEndpoint()
	{
	}

	public SocketEndpoint(String location)
	{
		createEndpoint(location);
	}

	protected void createEndpoint(String location)
	{
		this.location = location; // format is:
		// tcp://192.168.0.1:8080?retryTimes=1&simplex=true&len=8&len2bcd=true&hdrLenBinary=false&timeout=30&sndLenWithBuf=false
		if (log.isDebugEnabled()) log.debug("location:" + location);
		StringTokenizer st = new StringTokenizer(location, ":?");
		List params = new ArrayList();
		while (st.hasMoreTokens())
			params.add(st.nextToken());
		ip = StringX.trim((String) params.get(1), "/");
		port = Integer.parseInt((String) params.get(2));
		String strExtParams = (params.size() > 3 ? (String) params.get(3) : null);
		if (StringX.nullity(strExtParams)) return;
		Map extParams = StringX.str2map(strExtParams, "&");
		String val = (String) extParams.get("retryTimes");
		if (!StringX.nullity(val)) retryTimes = Integer.parseInt(val);

		val = (String) extParams.get("len");
		if (!StringX.nullity(val)) len = Integer.parseInt(val);

		val = (String) extParams.get("containHdrLenSelf");
		if (!StringX.nullity(val)) containHdrLenSelf = TRUE.equalsIgnoreCase(val);

		val = (String) extParams.get("timeout");
		if (!StringX.nullity(val)) timeout = Integer.parseInt(val);

		val = (String) extParams.get("soTimeout");
		if (!StringX.nullity(val)) soTimeout = Integer.parseInt(val);

		val = (String) extParams.get("simplex");
		if (!StringX.nullity(val)) simplex = TRUE.equalsIgnoreCase(val);

		val = (String) extParams.get("longCnn");
		if (!StringX.nullity(val)) longCnn = TRUE.equalsIgnoreCase(val);

		val = (String) extParams.get("len2bcd");
		if (!StringX.nullity(val)) len2bcd = TRUE.equalsIgnoreCase(val);

		val = (String) extParams.get("tcpNoDelay");
		if (!StringX.nullity(val)) tcpNoDelay = TRUE.equalsIgnoreCase(val);

		val = (String) extParams.get("hdrLenBinary");
		if (!StringX.nullity(val)) hdrLenBinary = TRUE.equalsIgnoreCase(val);

		val = (String) extParams.get("sndLenWithBuf");
		if (!StringX.nullity(val)) sndLenWithBuf = TRUE.equalsIgnoreCase(val);
	}

	static String TRUE = "true";
	protected int receiveBufferSize = 4096;
	protected boolean tcpNoDelay = true;
	protected String location;
	protected String ip;
	protected int port;

	protected Socket s;
	protected OutputStream os;
	protected InputStream is;

	protected int retryTimes = 0; // ���Դ���Ĭ��Ϊ����һ��
	protected boolean simplex; // �Ƿ񵥹��� ���������ֻ�ܷ������ܽ���
	protected boolean longCnn; // �Ƿ�����
	protected int len = 8; // ÿ�η��͵�ͷ����, ���Ϊ<=0��ʾ����Ҫ���ͳ��ȱ�ʶ
	protected boolean containHdrLenSelf; // chenjs 2012-11-22 ����ͷ�����Ƿ����ͷ���ȱ���,
	// ���糤��ͷ8���ֽڣ�����200���ֽڣ�����ͷ��ϢΪ208�ֽ�
	protected boolean len2bcd; // ���͵ĳ����ֶ��Ƿ���ҪBCDת��
	protected boolean hdrLenBinary;
	protected int timeout; // ����socket���ӵĳ�ʱʱ��
	protected int soTimeout; // ��ȡ��Ϣ��ʱʱ��
	protected boolean sndLenWithBuf = true; // added by chenjs 2011-11-03
	// ���Ⱥ�����һ������ͨѶ���з��ͣ� true����ߺܶ�����
	protected static Log log = Log.getLogger(SocketEndpoint.class);

	public void setSimplex(boolean simplex)
	{
		this.simplex = simplex;
	}

	public void setLongCnn(boolean longCnn)
	{
		this.longCnn = longCnn;
	}

	public void setRetryTimes(int retryTimes)
	{
		this.retryTimes = retryTimes;
	}

	public void setLen2bcd(boolean len2bcd)
	{
		this.len2bcd = len2bcd;
	}

	public int getLen()
	{
		return len;
	}

	public void setLen(int len)
	{
		this.len = len;
	}

	public void setTimeout(int timeout)
	{
		this.timeout = timeout;
	}

	public void setSoTimeout(int soTimeout)
	{
		this.soTimeout = soTimeout;
	}

	public boolean isHdrLenBinary()
	{
		return hdrLenBinary;
	}

	public void setHdrLenBinary(boolean hdrLenBinary)
	{
		this.hdrLenBinary = hdrLenBinary;
	}

	public void setReceiveBufferSize(int receiveBufferSize)
	{
		this.receiveBufferSize = receiveBufferSize;
	}

	public void setSndLenWithBuf(boolean sndLenWithBuf)
	{
		this.sndLenWithBuf = sndLenWithBuf;
	}

	public void setTcpNoDelay(boolean tcpNoDelay)
	{
		this.tcpNoDelay = tcpNoDelay;
	}

	public boolean isContainHdrLenSelf()
	{
		return containHdrLenSelf;
	}

	public void setContainHdrLenSelf(boolean containHdrLenSelf)
	{
		this.containHdrLenSelf = containHdrLenSelf;
	}
}
