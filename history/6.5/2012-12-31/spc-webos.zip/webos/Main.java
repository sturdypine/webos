package spc.webos;

import java.io.File;

import org.apache.log4j.Logger;

import spc.webos.config.AppConfig;
import spc.webos.constant.Common;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

public class Main
{
	static boolean stop = false;
	static Logger log;
	static
	{
		String bootDir = new File(StringX.EMPTY_STRING).getAbsolutePath().replace('\\', '/') + '/';
		System.setProperty("boot.dir", bootDir);
		System.setProperty(Common.WEBAPP_ROOT_PATH_KEY, bootDir);
		AppConfig.getInstance().setProperty(Common.WEBAPP_ROOT_PATH_KEY, bootDir);
		// AppConfig.getInstance().getStaticCfg().set(Common.WEBAPP_ROOT_KEY,
		// bootDir);
	}

	public static void stop()
	{
		stop = true;
		log.warn("JVM receive stop command, JVM will stop in seconds...");
	}

	public static void wait4stop()
	{
		while (!stop)
		{
			try
			{
				Thread.sleep(2000);
			}
			catch (Throwable e)
			{
				e.printStackTrace(System.out);
			}
		}
	}

	public static void main(String[] args) throws Exception
	{
		log = Logger.getLogger(Main.class);
		long start = System.currentTimeMillis();
		System.setErr(System.out);
		if (args == null || args.length == 0)
		{
			String msg = "args is null, application stop!!!";
			log.fatal(msg);
			return;
		}
		SystemUtil.debugJvm();
		SystemUtil.load(args); // ����spring��������
		log.info("JVM starts to wait4stop, cost: " + (System.currentTimeMillis() - start));
		wait4stop();
		log.warn("JVM starts to stop after wait4stop...");
		SystemUtil.unload();
		log.info("JVM(" + SystemUtil.JVM + ") App(" + SystemUtil.APP
				+ ") has bean stopped, system will exit...");
		System.exit(0); // ǿ���˳�
	}
}
