package spc.webos.log;

import java.io.StringReader;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.log4j.Priority;

import spc.webos.buffer.CommonWaitWithTime;
import spc.webos.buffer.IBuffer;
import spc.webos.constant.Common;
import spc.webos.model.LogVO;
import spc.webos.thread.DaemonThread;
import spc.webos.thread.ThreadPool;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;
import spc.webos.web.common.ISessionUserInfo;
import freemarker.template.Configuration;
import freemarker.template.Template;

/**
 * ��־���������ģʽ�� 1. �߳���־�������������Ҫ����curlog, buf��Ϣ, 2. ���߳���־��������curlog,
 * Ҳ���ǵ�ǰ�߳�����ִ����������ĳһ�ض���־��. 3. ��ͳlog4jģʽ
 * 
 * @author chenjs
 * 
 */
public class Log
{
	Logger log;
	static Logger notice = Logger.getLogger("notice"); // ֪ͨ����־
	static final ThreadLocal TRACE_NO = new ThreadLocal();
	static final ThreadLocal NOTICE_BUF = new ThreadLocal();

	public static Logger DEF_LOG = Logger.getLogger(Log.class);
	public static int DEFAULT_MAX_ITEMS = 5000;
	static final ThreadLocal CUR_LEVEL = new ThreadLocal();
	static final ThreadLocal FTL_CONDITION = new ThreadLocal();
	public final static ThreadLocal BUF_MAX_ITEMS = new ThreadLocal(); // ��־����
	public final static ThreadLocal LOG_BUFFER = new ThreadLocal(); // ��־����
	public final static ThreadLocal CUR_LOG = new ThreadLocal(); // ��ǰ��־
	public final static ThreadLocal CUR_EXT = new ThreadLocal(); // ��ǰ��־

	public final static String TRACE = "TRC";
	public final static String DEBUG = "DEB";
	public final static String INFO = "INF";
	public final static String WARN = "WAR";
	public final static String ERROR = "ERR";
	public final static String FATAL = "FAT";

	private Log(Logger log)
	{
		this.log = log;
	}

	public static void setCurLevel(String level)
	{
		CUR_LEVEL.set(level);
	}

	public static boolean notice(String msg)
	{
		List buf = (List) NOTICE_BUF.get();
		if (buf == null) NOTICE_BUF.set(buf = new ArrayList());
		buf.add(msg);
		if (buf.size() > 100)
		{
			buf.add("notice buf is over 100, auto print...");
			printNotice();
		}
		return true;
	}

	public static boolean printNotice()
	{
		List buf = (List) NOTICE_BUF.get();
		if (buf == null) return false;
		try
		{
			StringBuffer strbuf = new StringBuffer();
			for (int i = 0; i < buf.size(); i++)
			{
				strbuf.append(buf.get(i));
				strbuf.append('\n');
			}
			NOTICE_BUF.set(null);
			notice.error(strbuf);
		}
		catch (Throwable t)
		{
			t.printStackTrace(System.out);
		}
		return true;
	}

	/*
	 * ��־��������Java�ű�, ��beenshell����
	 */
	public static void setFTLCondition(String script)
	{
		script = StringX.trim(script);
		if (StringX.nullity(script)) FTL_CONDITION.set(null);
		else
		{
			try
			{
				FTL_CONDITION
						.set(new Template("LOG", new StringReader(script), new Configuration()));
			}
			catch (Exception e)
			{
				DEF_LOG.error("Log.setFTLCondition::ftl:[[" + script + "]]", e);
			}
		}
	}

	public static String getTraceNo()
	{
		return (String) TRACE_NO.get();
	}

	public static void setTraceNo(String traceNo)
	{
		TRACE_NO.set(traceNo);
	}

	public static Template getFTLCondition()
	{
		return (Template) FTL_CONDITION.get();
	}

	public static boolean isThreadLog()
	{
		return LOG_BUFFER.get() != null;
	}

	public static void start(Logger log)
	{
		print();
		LOG_BUFFER.set(new LinkedList());
		CUR_LOG.set(log == null ? DEF_LOG : log);
	}

	public static void start(Logger log, boolean thread)
	{
		print();
		if (thread) LOG_BUFFER.set(new LinkedList());
		CUR_LOG.set(log == null ? DEF_LOG : log);
	}

	public static void change(String logName)
	{
		if (!StringX.nullity(logName)) CUR_LOG.set(Logger.getLogger(logName));
	}

	public static void start(Class clazz)
	{
		start(Logger.getLogger(clazz));
	}

	public static boolean startWithRequired(String logName)
	{
		if (StringX.nullity(logName) || isThreadLog()) return false;
		start(logName);
		return true;
	}

	public static boolean startWithRequired(String logName, boolean thread)
	{
		if (StringX.nullity(logName) || isThreadLog()) return false;
		start(logName, thread);
		return true;
	}

	public static void start(String logName)
	{
		start(logName, true);
	}

	public static void start(String logName, boolean thread)
	{
		if (StringX.nullity(logName))
		{
			print();
			LOG_BUFFER.set(null);
		}
		else start(Logger.getLogger(logName), thread);
	}

	public static void setMaxItems(int maxItems)
	{
		BUF_MAX_ITEMS.set(new Integer(maxItems));
	}

	public static List print()
	{
		List buf = (List) LOG_BUFFER.get();
		if (buf == null || buf.size() == 0) return buf;
		Logger l = (Logger) CUR_LOG.get();
		if (l == null)
		{
			l = DEF_LOG;
			System.out.println("ThreadLog, but curlog is null, using def log:" + DEF_LOG.getName());
		}
		Map ext = getLogExt();
		// System.out.println("log.print
		// "+Thread.currentThread().getName()+":"+(null==ext.get("msg")));
		ISessionUserInfo sui = (ISessionUserInfo) ISessionUserInfo.SUI.get();
		if (ext != null && sui != null) ext.put(Common.MODEL_SUI_KEY, sui);
		Object[] arr = new Object[] { buf, l, ext };
		try
		{
			IBuffer logBuf = LogManager.getInstance().getLogBuf(l.getName());
			if (logBuf != null) logBuf.put(arr, new CommonWaitWithTime(CommonWaitWithTime.WRITE,
					1000));
			else
			{
				System.out.println("LogBuf(" + l.getName() + ") is null !!!!");
				LogThread.print(arr, LogThread.TXT_ESB); // �������־�Ų���ȥ��ֱ�����
			}
		}
		catch (Throwable t)
		{
			t.printStackTrace(System.out);
			System.out.println("LogBuf(" + l.getName() + ") is full !!!!");
			LogThread.print(arr, LogThread.TXT_ESB); // �������־�Ų���ȥ��ֱ�����
		}
		finally
		{
			// ��ղ�����Ϣ, ����һ���̱߳�����ʹ��
			// buf.clear(); // ����������������־����ӡ��
			LOG_BUFFER.set(buf = new LinkedList());
			CUR_EXT.set(null); // chenjs 2012-12-31 ����߳̾�̬����ʹ�õ���־��չ����
		}
		return buf;
	}

	public static void setLogExt(Map ext)
	{
		Thread t = Thread.currentThread();
		if (t instanceof DaemonThread)
		{
			ThreadPool pool = ((DaemonThread) t).getPool();
			if (pool != null)
			{
				ext.put("POOLNAME", pool.getName());
				ext.put("POOLCLAZZ", pool.getClass().getName());
			}
		}
		ext.put("THREADNAME", Thread.currentThread().getName());
		CUR_EXT.set(ext);
	}

	public static Map getLogExt()
	{
		return (Map) CUR_EXT.get();
	}

	public boolean isDebugEnabled()
	{
		return condition(DEBUG);
	}

	public boolean isTraceEnabled()
	{
		return condition(TRACE);
	}

	public boolean isInfoEnabled()
	{
		return condition(INFO);
	}

	public boolean isWarnEnabled()
	{
		return condition(WARN);
	}

	public boolean condition(String level)
	{
		// 0. ftl �ű� �߳���־���ȼ���Ƿ�����������
		Template t = getFTLCondition();
		// System.out.println("ftl log level: " + (t != null) + " " +
		// (getLogExt() != null));
		if (t != null && getLogExt() != null)
		{
			Map root = new HashMap(getLogExt());
			try
			{
				String curLevel = StringX.trim(SystemUtil.freemarker(t, root));
				// System.out.println("ftl log level:[" + curLevel
				// +"]  "+level);
				if (!StringX.nullity(curLevel))
				{ // ����ű����ؿ��ַ��������Ĭ�����ù�����д���
					if (TRACE.equalsIgnoreCase(curLevel)) return true;
					if (DEBUG.equalsIgnoreCase(curLevel)) return !level.equalsIgnoreCase(TRACE);
					if (INFO.equalsIgnoreCase(curLevel)) return !level.equalsIgnoreCase(DEBUG)
							&& !TRACE.equalsIgnoreCase(level);
					return !TRACE.equalsIgnoreCase(level) && !DEBUG.equalsIgnoreCase(level)
							&& !INFO.equalsIgnoreCase(level);
				}
			}
			catch (Throwable e)
			{
				DEF_LOG.warn("ERR Log.FTL e:" + e + ", root:" + root.keySet());
			}
		}

		List buf = (List) LOG_BUFFER.get();
		if (buf == null || !LogManager.getInstance().isStarted())
		{ // 1. ��ͨ��־����û������ftl����, û�н����߳̿�����
			if (level.equalsIgnoreCase(TRACE)) return curLogger().isTraceEnabled();
			if (level.equalsIgnoreCase(DEBUG)) return curLogger().isDebugEnabled();
			if (level.equalsIgnoreCase(INFO)) return curLogger().isInfoEnabled();
			return true;
			// if (curLogger().isTraceEnabled()) return true;
			// if (curLogger().isDebugEnabled()) return
			// !level.equalsIgnoreCase(TRACE);
			// if (curLogger().isInfoEnabled()) return
			// !level.equalsIgnoreCase(DEBUG)
			// && !level.equalsIgnoreCase(TRACE);
			// return !level.equalsIgnoreCase(DEBUG) &&
			// !level.equalsIgnoreCase(INFO)
			// && !level.equalsIgnoreCase(TRACE);
		}
		// 2. ��ǰ�߳��Ƿ�̬�趨һ����־����
		String curLevel = (String) CUR_LEVEL.get();
		if (!StringX.nullity(curLevel))
		{
			if (curLevel.equalsIgnoreCase(TRACE)) return true;
			if (DEBUG.equalsIgnoreCase(curLevel)) return !level.equalsIgnoreCase(TRACE);
			if (INFO.equalsIgnoreCase(curLevel)) return !level.equalsIgnoreCase(DEBUG)
					&& !level.equalsIgnoreCase(TRACE);
			return !DEBUG.equalsIgnoreCase(level) && !INFO.equalsIgnoreCase(level)
					&& !level.equalsIgnoreCase(TRACE);
		}

		// 3. ���û���������ƣ��������־���õ�����
		// Logger l = (Logger) CUR_LOG.get(); // ����Ƿ��е�ǰ��־
		// if (l == null) l = DEF_LOG;
		Logger l = curLogger(); // modified by chenjs 2011-12-20
		if (l.isTraceEnabled()) return true;
		if (l.isDebugEnabled()) return !level.equalsIgnoreCase(TRACE);
		if (l.isInfoEnabled()) return !level.equalsIgnoreCase(DEBUG)
				&& !level.equalsIgnoreCase(TRACE);
		if (level.equalsIgnoreCase(WARN)) return l.isEnabledFor(Priority.WARN);
		return !level.equalsIgnoreCase(DEBUG) && !level.equalsIgnoreCase(INFO)
				&& !level.equalsIgnoreCase(TRACE);
	}

	public static Log getLogger(Class clazz)
	{
		return new Log(Logger.getLogger(clazz));
	}

	public static Log getLogger(String name)
	{
		return new Log(Logger.getLogger(name));
	}

	public void trace(Object msg)
	{
		if (!isTraceEnabled()) return;
		if (addLogVO(new LogVO(TRACE, msg, null))) return;
		curLogger().trace(TRACE(msg));
	}

	public void debug(String mf, Object[] msg)
	{
		if (!isDebugEnabled()) return;
		if (addLogVO(new LogVO(DEBUG, new MessageFormat(mf).format(msg), null))) return;
		curLogger().debug(TRACE(new MessageFormat(mf).format(msg)));
	}

	public void debug(Object msg)
	{
		if (!isDebugEnabled()) return;
		if (addLogVO(new LogVO(DEBUG, msg, null))) return;
		curLogger().debug(TRACE(msg));
	}

	public void debug(String mf, Object[] msg, Throwable t)
	{
		if (!isDebugEnabled()) return;
		if (addLogVO(new LogVO(DEBUG, new MessageFormat(mf).format(msg), t))) return;
		curLogger().debug(TRACE(new MessageFormat(mf).format(msg)), t);
	}

	public void debug(Object msg, Throwable t)
	{
		if (!isDebugEnabled()) return;
		if (addLogVO(new LogVO(DEBUG, msg, t))) return;
		curLogger().debug(TRACE(msg), t);
	}

	public void info(Object msg)
	{
		if (!isInfoEnabled()) return;
		if (addLogVO(new LogVO(INFO, msg, null))) return;
		curLogger().info(TRACE(msg));
	}

	public void info(String mf, Object[] msg)
	{
		if (!isInfoEnabled()) return;
		if (addLogVO(new LogVO(INFO, new MessageFormat(mf).format(msg), null))) return;
		curLogger().info(TRACE(new MessageFormat(mf).format(msg)));
	}

	public void info(String mf, Object[] msg, Throwable t)
	{
		if (!isInfoEnabled()) return;
		if (addLogVO(new LogVO(INFO, new MessageFormat(mf).format(msg), t))) return;
		curLogger().info(TRACE(new MessageFormat(mf).format(msg)), t);
	}

	public void info(Object msg, Throwable t)
	{
		if (!isInfoEnabled()) return;
		if (addLogVO(new LogVO(INFO, msg, t))) return;
		curLogger().info(TRACE(msg), t);
	}

	public void warn(String mf, Object[] msg)
	{
		if (!isWarnEnabled()) return;
		if (addLogVO(new LogVO(WARN, new MessageFormat(mf).format(msg), null))) return;
		curLogger().warn(TRACE(new MessageFormat(mf).format(msg)));
	}

	public void warn(Object msg)
	{
		if (!isWarnEnabled()) return;
		if (addLogVO(new LogVO(WARN, msg, null))) return;
		curLogger().warn(TRACE(msg));
	}

	public void warn(String mf, Object[] msg, Throwable t)
	{
		if (!isWarnEnabled()) return;
		if (addLogVO(new LogVO(WARN, new MessageFormat(mf).format(msg), t))) return;
		curLogger().warn(TRACE(new MessageFormat(mf).format(msg)), t);
	}

	public void warn(Object msg, Throwable t)
	{
		if (!isWarnEnabled()) return;
		if (addLogVO(new LogVO(WARN, msg, t))) return;
		curLogger().warn(TRACE(msg), t);
	}

	public void error(String mf, Object[] msg)
	{
		if (addLogVO(new LogVO(ERROR, new MessageFormat(mf).format(msg), null))) return;
		curLogger().error(TRACE(new MessageFormat(mf).format(msg)));
	}

	public void error(Object msg)
	{
		if (addLogVO(new LogVO(ERROR, msg, null))) return;
		curLogger().error(TRACE(msg));
	}

	public void error(String mf, Object[] msg, Throwable t)
	{
		if (addLogVO(new LogVO(ERROR, new MessageFormat(mf).format(msg), t))) return;
		curLogger().error(TRACE(new MessageFormat(mf).format(msg)), t);
	}

	public void error(Object msg, Throwable t)
	{
		if (addLogVO(new LogVO(ERROR, msg, t))) return;
		curLogger().error(TRACE(msg), t);
	}

	public void fatal(String mf, Object[] msg)
	{
		if (addLogVO(new LogVO(FATAL, new MessageFormat(mf).format(msg), null))) return;
		curLogger().fatal(TRACE(new MessageFormat(mf).format(msg)));
	}

	public void fatal(Object msg)
	{
		if (addLogVO(new LogVO(FATAL, msg, null))) return;
		curLogger().fatal(TRACE(msg));
	}

	public void fatal(String mf, Object[] msg, Throwable t)
	{
		if (addLogVO(new LogVO(FATAL, new MessageFormat(mf).format(msg), t))) return;
		curLogger().fatal(TRACE(new MessageFormat(mf).format(msg)), t);
	}

	public void fatal(Object msg, Throwable t)
	{
		if (addLogVO(new LogVO(FATAL, msg, t))) return;
		curLogger().fatal(TRACE(msg), t);
	}

	protected static String TRACE(Object msg)
	{
		return getStackTraceInfo()
				+ (StringX.nullity(getTraceNo()) ? StringX.null2emptystr(msg) : getTraceNo() + msg);
	}

	public static String getStackTraceInfo()
	{
		StackTraceElement[] stack = new Throwable().getStackTrace();
		if (stack == null || stack.length < 4) return "[] - ";
		String clazz = stack[3].getClassName();
		if (!clazz.startsWith("spc.webos.echain.log")) return "[" + stack[3].getClassName() + " "
				+ stack[3].getMethodName() + " " + stack[3].getLineNumber() + "] - ";
		return "[" + stack[6].getClassName() + " " + stack[6].getMethodName() + " "
				+ stack[6].getLineNumber() + "] - ";
	}

	public Logger curLogger()
	{
		// modified by chenjs 2012-01-15 �����ǰ���õ��ض���־��ʹ�õ�ǰ�ض���־������ʹ��ԭ��������־���
		Logger l = (Logger) CUR_LOG.get(); // ��ǰ��־
		return l == null ? log : l;

		// if (!LogManager.getInstance().isStarted()) return log;
		// Logger l = (Logger) CUR_LOG.get();
		// return l == null ? log : l;
		// added by chenjs 2011-12-18
		// �õ���ǰ��־�������������߳���־��ʹ�õ�ǰ�߳���־���󣬷������߳���־״̬�������ǰ����־
		// Logger l = (Logger) CUR_LOG.get(); // ����Ƿ��е�ǰ��־
		// if (l != null) return l;
		// return LOG_BUFFER.get() == null ? log : DEF_LOG;
	}

	private static boolean addLogVO(LogVO logVO)
	{
		if (!LogManager.getInstance().isStarted()) return false; // �����־�߳�û����������ó�����־ģʽ
		List buf = (List) LOG_BUFFER.get();
		if (buf == null) return false;
		int max = DEFAULT_MAX_ITEMS;
		Integer maxItems = (Integer) BUF_MAX_ITEMS.get();
		if (maxItems != null) max = maxItems.intValue();
		if (buf.size() >= max) buf = print(); // print��������µĿջ���buf, modify by
		// 2010-03-17
		buf.add(logVO);
		return true;
	}
}
