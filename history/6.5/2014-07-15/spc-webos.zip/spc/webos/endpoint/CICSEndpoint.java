package spc.webos.endpoint;

import java.io.IOException;

import spc.webos.log.Log;
import spc.webos.util.StringX;
import spc.webos.util.charset.EBCDUtil;

import com.ibm.ctg.client.ECIRequest;
import com.ibm.ctg.client.ECIReturnCodes;
import com.ibm.ctg.client.JavaGateway;

/**
 * CICS java client, ͨ��CTGģʽ����
 * 
 * @author chenjs
 * @version 2011-12-30
 */
public class CICSEndpoint implements Endpoint
{
	public ECIRequest initEciRequest(String cicsProgram, byte[] commAreaByte)
	{
		// 2. ����ECIRequest
		// orasync ECI_SYNC or ECI_SYNC_TPN
		ECIRequest eciRequest = new ECIRequest(ECIRequest.ECI_SYNC_TPN, // sync
				cicsServerName, // CICS region name
				cicsUser,// userid
				cicsPwd,// password
				cicsProgram == null ? defCicsProgram : cicsProgram, // program
																	// name
				cicsTransId, // Mirror transaction ID
				commAreaByte, commAreaByte.length, // commarea data & length
				ECIRequest.ECI_NO_EXTEND, // extended mode
				ECIRequest.ECI_LUW_NEW); // LUW token
		eciRequest.setECITimeout((short) timeout);
		return eciRequest;
	}

	public void execute(Executable exe) throws Exception
	{
		// 1. ����JavaGateway
		JavaGateway javaGateway = new JavaGateway(cicsUrl, cicsPort);
		try
		{
			byte[] commAreaByte = new byte[commAreaSize];
			if (exe.request.length > commAreaSize) throw new IOException("big data size "
					+ exe.request.length + ">" + commAreaSize);
			if (log.isDebugEnabled()) log.debug("request:" + new String(exe.request) + ", base64:"
					+ new String(StringX.encodeBase64(exe.request)));
			byte[] lenBytes = lenBytes(exe.request); // �õ������ֽڱ��ĵ�ͷ����
			if (lenBytes != null)
			{
				System.arraycopy(lenBytes, 0, commAreaByte, 0, lenBytes.length);
				if (log.isInfoEnabled()) log.info("hdrLen: " + new String(lenBytes));
			}
			System.arraycopy(exe.request, 0, commAreaByte, lenBytes == null ? 0 : lenBytes.length,
					exe.request.length); // copy request
			ECIRequest eciRequest = initEciRequest(getCicsProgram(exe), commAreaByte);
			int iRc = javaGateway.flow(eciRequest);
			if (eciRequest.getCicsRc() != ECIReturnCodes.ECI_NO_ERROR) throw new IOException(
					"CICS return code=[" + eciRequest.getCicsRc() + "], string=["
							+ eciRequest.getCicsRcString() + "]");
			exe.response = getResponse(eciRequest, commAreaByte);
			if (log.isDebugEnabled()) log.debug("response:" + new String(exe.response)
					+ ", base64:" + new String(StringX.encodeBase64(exe.response)));
		}
		finally
		{
			try
			{
				if (javaGateway != null && javaGateway.isOpen()) javaGateway.close();
			}
			catch (IOException e)
			{
				log.warn("CICS destory: ", e);
			}
		}
	}

	protected String getCicsProgram(Executable exe)
	{
		return exe.cicsProgram;
	}

	protected byte[] getResponse(ECIRequest eciRequest, byte[] commAreaByte)
	{
		byte[] hdr = new byte[len];
		System.arraycopy(commAreaByte, 0, hdr, 0, hdr.length);
		int length = length(hdr);
		if (log.isInfoEnabled()) log.info("response len: " + length + ", cicsHdrLen:" + cicsHdrLen);
		byte[] response = new byte[length];
		System.arraycopy(commAreaByte, len, response, 0, length);
		return response;
		// ByteArrayOutputStream baos = new ByteArrayOutputStream();
		// int count = -1;
		// for (int i = commAreaByte.length - 1; i > -1; i--)
		// {
		// if (commAreaByte[i] != 0x00)
		// {
		// count = i;
		// break;
		// }
		// }
		// ɽ�����˶��ƣ��ҵ�0x3E��Ϊ���� added by wxchc @ 20101222
		// for (int i = 0; i < count; i++) {
		// if (commAreaByte[i] == 0x3E) {
		// count = i;
		// break;
		// }
		// }

		// baos.write(commAreaByte, 0, count + 1);
		// return baos.toByteArray();
	}

	protected byte[] lenBytes(byte[] buf)
	{
		String strlen = (len <= 0 ? String.valueOf(buf.length) : StringX.int2str(
				String.valueOf(buf.length - cicsHdrLen), len)); // ���ȹ̶�Ϊ10���Ƶ�8���ֽڣ�����ǰ�油0
		return len2bcd ? EBCDUtil.gbk2bcd(strlen) : strlen.getBytes();
	}

	protected int length(byte[] lenBytes)
	{
		return new Integer(len2bcd ? EBCDUtil.bcd2gbk(lenBytes) : new String(lenBytes).trim())
				.intValue() + cicsHdrLen;
	}

	public void destory()
	{
	}

	public Endpoint clone() throws CloneNotSupportedException
	{
		return null;
	}

	public static void main(String[] args) throws Exception
	{
		// "tcp://130.1.9.39", 2006, "HRBRUN", "CICSUSER", null, null, 60
		CICSEndpoint cics = new CICSEndpoint();
		cics.setCicsUrl("tcp://130.1.9.39");
		cics.setCicsPort(2006);
		cics.setCicsServerName("HRBRUN");
		cics.setCicsUser("CICSUSER");
		cics.setTimeout(60);
		// String szValue1 =
		// "00000262990042RQ0VOST0001################        tp9900421<TellerLvl0>5</><TelPasswd>111111</><ChannelId>39</><BrcName0>��������Ӫҵ��</><TranName>���ֲ�ѯ</><Brc>00080000</><Teller>000317</><TellerType0>12</><TermIP>10.200.1.60</><TranDate>2006-08-16</><TermId>ttyp12</><AuthFlag>0</><TellerName>���Թ�Ա1</><Ccy1>01</>";
		String szValue = "990042RQ0VOST0001################        tp9900421<TellerLvl0>5</><TelPasswd>111111</><ChannelId>39</><BrcName0>��������Ӫҵ��</><TranName>���ֲ�ѯ</><Brc>00080000</><Teller>000317</><TellerType0>12</><TermIP>10.200.1.60</><TranDate>2006-08-16</><TermId>ttyp12</><AuthFlag>0</><TellerName>���Թ�Ա1</><Ccy1>01</>";
		Executable exe = new Executable();
		exe.request = szValue.getBytes("gbk"); // ȥ��ǰ8���ֽڳ���ͷ��
		exe.cicsProgram = "tp000000";
		cics.execute(exe);

	}

	protected int len = 8; // ÿ�η��͵�ͷ����, ���Ϊ<=0��ʾ����Ҫ���ͳ��ȱ�ʶ
	protected int cicsHdrLen = 0;
	protected boolean len2bcd; // ���͵ĳ����ֶ��Ƿ���ҪBCDת��

	protected Log log = Log.getLogger(getClass());
	protected int commAreaSize = 10240;
	protected String cicsUrl = "local:";
	protected int cicsPort = 2006;
	protected String mc_szCicsPassword = "";
	protected String defCicsProgram = "tp990042";
	// protected String mc_szCicsTransid = "CPMI";

	// protected JavaGateway javaGateway;
	protected String cicsServerName;
	protected String cicsUser;
	protected String cicsPwd;
	protected String cicsTransId;
	protected int timeout;

	public int getLen()
	{
		return len;
	}

	public void setLen(int len)
	{
		this.len = len;
	}

	public int getCicsHdrLen()
	{
		return cicsHdrLen;
	}

	public void setCicsHdrLen(int cicsHdrLen)
	{
		this.cicsHdrLen = cicsHdrLen;
	}

	public boolean isLen2bcd()
	{
		return len2bcd;
	}

	public void setLen2bcd(boolean len2bcd)
	{
		this.len2bcd = len2bcd;
	}

	public int getCommAreaSize()
	{
		return commAreaSize;
	}

	public void setCommAreaSize(int commAreaSize)
	{
		this.commAreaSize = commAreaSize;
	}

	public String getCicsUrl()
	{
		return cicsUrl;
	}

	public void setCicsUrl(String cicsUrl)
	{
		this.cicsUrl = cicsUrl;
	}

	public int getCicsPort()
	{
		return cicsPort;
	}

	public void setCicsPort(int cicsPort)
	{
		this.cicsPort = cicsPort;
	}

	public String getMc_szCicsPassword()
	{
		return mc_szCicsPassword;
	}

	public void setMc_szCicsPassword(String mc_szCicsPassword)
	{
		this.mc_szCicsPassword = mc_szCicsPassword;
	}

	public String getCicsServerName()
	{
		return cicsServerName;
	}

	public void setCicsServerName(String cicsServerName)
	{
		this.cicsServerName = cicsServerName;
	}

	public String getCicsUser()
	{
		return cicsUser;
	}

	public void setCicsUser(String cicsUser)
	{
		this.cicsUser = cicsUser;
	}

	public String getCicsPwd()
	{
		return cicsPwd;
	}

	public void setCicsPwd(String cicsPwd)
	{
		this.cicsPwd = cicsPwd;
	}

	public String getDefCicsProgram()
	{
		return defCicsProgram;
	}

	public void setDefCicsProgram(String defCicsProgram)
	{
		this.defCicsProgram = defCicsProgram;
	}

	public String getCicsTransId()
	{
		return cicsTransId;
	}

	public void setCicsTransId(String cicsTransId)
	{
		this.cicsTransId = cicsTransId;
	}

	public int getTimeout()
	{
		return timeout;
	}

	public void setTimeout(int timeout)
	{
		this.timeout = timeout;
	}

	public void init() throws Exception
	{
	}
}
