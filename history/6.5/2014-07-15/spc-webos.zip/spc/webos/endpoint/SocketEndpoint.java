package spc.webos.endpoint;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.net.SocketFactory;

import spc.webos.constant.AppRetCode;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.Message;
import spc.webos.exception.AppException;
import spc.webos.log.Log;
import spc.webos.thread.IMessageReceiver;
import spc.webos.util.FileUtil;
import spc.webos.util.NumberX;
import spc.webos.util.StringX;
import spc.webos.util.charset.EBCDUtil;

public class SocketEndpoint implements Endpoint, IMessageReceiver
{
	/**
	 * 当多个线程同时需要访问时，socket连接需要同步使用。
	 */
	public void execute(Executable exe) throws Exception
	{
		if (longCnn) longCnn(exe);
		else shortCnn(exe);
	}

	protected synchronized void longCnn(Executable exe) throws Exception
	{
		int fail = 0;
		do
		{
			try
			{
				init();
				is = cnn(s, os, is, exe);
				return;
			}
			catch (IOException ioe)
			{
				destory(); // 如果发生IO异常，则关闭连接
				log.error("net error: ip:" + ip + ", port:" + ports[0] + ", retryTimes: "
						+ retryTimes + ", fail: " + fail + ", reqbytes base64: "
						+ new String(StringX.encodeBase64(exe.request)), ioe);
				if (exe.cnnSnd || retryTimes <= fail) throw new AppException(
						AppRetCode.PROTOCOL_SOCKET(), new Object[] { String.valueOf(ip),
								String.valueOf(ports[0]) });
				fail++;
			}
		}
		while (!exe.cnnSnd);
	}

	protected String getCurrentIP(Executable exe)
	{
		return ip;
	}

	protected int getCurrentPort(Executable exe)
	{
		return getCurrentPort(ports, randomPort, cursor);
	}

	protected static int getCurrentPort(int[] ports, boolean randomPort, int cursor)
	{
		if (ports.length == 1) return ports[0];
		if (randomPort)
		{ // 使用随机端口
			int idx = ((int) (Math.random() * 10000000)) % ports.length;
			return ports[idx];
		}
		// 使用顺序轮训端口
		if (cursor >= ports.length) cursor = 0;
		return ports[cursor++];
	}

	protected void shortCnn(Executable exe) throws Exception
	{
		shortCnn(exe, getCurrentPort(exe));
	}

	protected void shortCnn(Executable exe, int port) throws Exception
	{
		Socket s = null;
		OutputStream os = null;
		InputStream is = null;
		String ip = getCurrentIP(exe);

		try
		{ // modified by chenjs 2011-06-23 短链接取消重试
			s = createSocket(ip, port);
			// modified by chenjs 2011-10-15 对socket输出使用BufferedOutputStream
			// os = new BufferedOutputStream(s.getOutputStream());
			os = s.getOutputStream();
			is = cnn(s, os, null, exe);
		}
		catch (IOException ioe)
		{
			log.error(
					toString(ip, port) + ", reqbytes base64: "
							+ new String(StringX.encodeBase64(exe.request)), ioe);
			throw new AppException(AppRetCode.PROTOCOL_SOCKET(), new Object[] { String.valueOf(ip),
					String.valueOf(port) });
		}
		finally
		{
			release(s, os, is);
		}
	}

	protected Socket createSocket() throws IOException
	{
		return createSocket(ip, ports[0]);
	}

	protected Socket createSocket(String ip, int port) throws IOException
	{
		if (log.isInfoEnabled()) log.info("createSocket:" + toString(ip, port));
		Socket socket = null;
		if (timeout <= 0) socket = new Socket(ip, port);
		else
		{
			socket = SocketFactory.getDefault().createSocket();
			socket.connect(new InetSocketAddress(ip, port), timeout); // 就在connect��timeout
		}
		// added by chenjs 2011-06-13 增加读消息超时属性
		if (soTimeout > 0) socket.setSoTimeout(soTimeout);
		// added 2012-06-27
		if (receiveBufferSize > 0) socket.setReceiveBufferSize(receiveBufferSize);
		socket.setTcpNoDelay(tcpNoDelay);
		socket.setPerformancePreferences(0, 1, 2);
		return socket;
	}

	protected InputStream cnn(Socket socket, OutputStream os, InputStream is, Executable exe)
			throws Exception
	{
		if (!longCnn && !simplex && exe.getTimeout() > 0) socket
				.setSoTimeout(exe.getTimeout() * 1000);
		long start = System.currentTimeMillis();
		if (log.isInfoEnabled()) log.info("TCP corId:" + exe.getCorrelationID() + ", timeout:"
				+ exe.getTimeout() + ", withoutReturn:" + exe.isWithoutReturn() + ", reqbytes:"
				+ exe.getRequest().length);
		send(socket, os, exe);
		// added by chenjs 2011-06-13 增加一个当前报文判断属性，如果当前交易调用时指定无返回则不接收返回
		if (simplex || exe.isWithoutReturn())
		{ // 如果单工或者指定无返回则直接返回
			// 如果是短连接,又是单工或者无返回则容易导致连接退出太快,服务端无法收到字节，需要程序睡眠50ms保证服务器收完请求
			// if (!longCnn)
			// {
			// try
			// {
			// Thread.sleep(200);
			// }
			// catch (Throwable t)
			// {
			// }
			// }
			return is;
		}

		if (socket.isInputShutdown() || socket.isClosed()) log.warn("isInputShutdown: "
				+ socket.isInputShutdown() + ", socket: " + socket.isClosed());
		if (is == null) is = socket.getInputStream();
		receive(socket, is, exe);
		if (log.isInfoEnabled()) log.info("cost:" + (System.currentTimeMillis() - start));
		return is;
	}

	protected void send(Socket socket, OutputStream os, Executable exe) throws Exception
	{
		byte[] buf = exe.getRequest();
		if (buf == null)
		{
			log.warn("send request is null, cannot send!!!");
			return;
		}
		send(socket, os, buf);
		os.flush();
		exe.cnnSnd = true; // 已经发送成功
		log.debug("set cnnSnd is true!!!");
	}

	protected void send(Socket socket, OutputStream os, byte[] buf) throws Exception
	{
		if (!sndLenWithBuf || len <= 0)
		{
			write(os, buf);
			if (log.isInfoEnabled()) log.info("no sndLenWithBuf: " + buf.length);
		}
		else
		{
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			write(baos, buf);
			os.write(baos.toByteArray());
			if (log.isInfoEnabled()) log.info("sndLenWithBuf: " + buf.length);
		}
	}

	protected void write(OutputStream os, byte[] buf) throws Exception
	{
		if (len > 0)
		{
			byte[] lenBytes = lenBytes(buf);
			os.write(lenBytes); // 发送报文总长度
			if (log.isDebugEnabled()) log.debug("snd buf: " + buf.length + ", lenBytes:["
					+ new String(lenBytes) + "]");
		}
		if (log.isDebugEnabled()) log.debug("base64 req buf:["
				+ new String(StringX.encodeBase64(buf)) + "], buf:["
				+ (len2bcd ? EBCDUtil.bcd2gbk(buf) : new String(buf)) + "]");
		if (buf != null && buf.length > 0) os.write(buf);
	}

	protected byte[] lenBytes(byte[] buf)
	{
		int bufLen = buf.length + (containHdrLenSelf ? len : 0);
		if (hdrLenBinary) return NumberX.int2bytes(bufLen, len);
		String strlen = (len <= 0 ? String.valueOf(bufLen) : StringX.int2str(
				String.valueOf(bufLen), len)); // 长度固定为10进制的8个字节，不足前面补0
		return len2bcd ? EBCDUtil.gbk2bcd(strlen) : strlen.getBytes();
	}

	protected void receive(Socket socket, InputStream is, Executable exe) throws Exception
	{
		exe.setResponse(receive(socket, is)); // 读取报文
	}

	public byte[] receive(Socket socket, InputStream is) throws Exception
	{
		if (is == null) is = socket.getInputStream();
		int hdrlen = (len > 0 ? length(FileUtil.readMsgWithLen(is, len)) : 0); // 读取长度
		return FileUtil.readMsgWithLen(is, hdrlen); // 读取报文
	}

	protected int length(byte[] lenBytes)
	{
		if (hdrLenBinary) return NumberX.bytes2int(lenBytes) - (containHdrLenSelf ? len : 0);
		return new Integer(len2bcd ? EBCDUtil.bcd2gbk(lenBytes) : new String(lenBytes).trim())
				.intValue() - (containHdrLenSelf ? len : 0);
	}

	public Socket getSocket()
	{
		return s;
	}

	public void init() throws Exception
	{
		if (s != null && longCnn)
		{
			log.debug("it is long cnn!!!");
			return; // modified by spc 2011-03-11
		}
		release(s, os, is);
		try
		{
			s = createSocket();
			// modified by chenjs 2011-10-15 对socket输出使用BufferedOutputStream
			// os = new BufferedOutputStream(s.getOutputStream());
			os = s.getOutputStream();
		}
		catch (Exception e)
		{
			log.warn("Err createSocket: " + toString() + ", e:" + e);
			throw e;
		}
	}

	public void destory()
	{
		release(s, os, is);
		is = null;
		os = null;
		s = null;
	}

	public void release(Socket s, OutputStream os, InputStream is)
	{
		try
		{
			if (s != null)
			{
				log.info("close socket: " + s.getInetAddress());
				s.close();
			}
		}
		catch (Exception e)
		{
			log.warn("err to close socket", e);
		}
	}

	public void setIp(String ip)
	{
		this.ip = ip;
	}

	public void setPort(int port)
	{
		this.ports = new int[] { port };
	}

	public void setPorts(int[] ports)
	{
		this.ports = ports;
	}

	public void setPortRange(String portRange)
	{
		this.ports = createPorts(portRange);
	}

	public Endpoint clone() throws CloneNotSupportedException
	{
		SocketEndpoint se = new SocketEndpoint();
		se.ip = ip;
		se.ports = ports;
		se.retryTimes = retryTimes;
		se.simplex = simplex;
		se.longCnn = longCnn;
		se.len = len;
		se.len2bcd = len2bcd;
		se.timeout = timeout;
		se.soTimeout = soTimeout;
		return se;
	}

	public String toString()
	{
		return toString(ip, ports[0]);
	}

	public String toString(String ip, int port)
	{
		return "TCP://" + ip + ":" + port + ", simplex:" + simplex + ", longCnn:" + longCnn + ":"
				+ len + ":" + len2bcd + ":" + hdrLenBinary;
	}

	// added by chenjs 2012-05-08, 用于解决异步双工模式下的tcp协议
	public IMessage receive() throws Exception
	{
		try
		{
			while (s == null)
			{ // 等待请求时建立连接
				log.debug("socket is null, sleep 500 mills");
				Thread.sleep(500);
			}
			if (is == null) is = s.getInputStream();
			byte[] buf = receive(s, is);
			IMessage msg = new Message();
			msg.setInLocal(MsgLocalKey.ACCEPTOR_REMOTE_HOST, ip);
			msg.setInLocal(MsgLocalKey.ACCEPTOR_LOCAL_PORT, String.valueOf(ports[0]));
			msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, buf);
			msg.setInLocal(MsgLocalKey.LOCAL_MSGCVT_DELAY, Boolean.TRUE); // 延迟解析
			return msg;
		}
		catch (Exception e)
		{
			log.warn("receive", e);
			destory();
		}
		return null;
	}

	public IMessage receive(long timeout) throws Exception
	{
		return receive();
	}

	public SocketEndpoint()
	{
	}

	public SocketEndpoint(String location)
	{
		createEndpoint(location);
	}

	protected int[] createPorts(String strPort)
	{
		if (strPort.indexOf('-') > 0)
		{ // port range
			String[] ps = StringX.split(strPort, "-");
			int startPort = Integer.parseInt(ps[0]);
			int endPort = Integer.parseInt(ps[1]);
			int[] ports = new int[endPort - startPort + 1];
			for (int i = 0; i < ports.length; i++)
				ports[i] = startPort + i;
			return ports;
		}
		// only one port
		if (strPort.indexOf(',') < 0) return new int[] { Integer.parseInt(strPort) };
		// port enumation
		String[] ps = StringX.split(strPort, StringX.COMMA);
		int[] ports = new int[ps.length];
		for (int i = 0; i < ports.length; i++)
			ports[i] = Integer.parseInt(ps[i]);
		return ports;
	}

	protected void createEndpoint(String location)
	{
		this.location = location; // format is:
		// tcp://192.168.0.1:8080?retryTimes=1&simplex=true&len=8&len2bcd=true&hdrLenBinary=false&timeout=30&sndLenWithBuf=false
		if (log.isDebugEnabled()) log.debug("location:" + location);
		StringTokenizer st = new StringTokenizer(location, ":?");
		List params = new ArrayList();
		while (st.hasMoreTokens())
			params.add(st.nextToken());
		ip = StringX.trim((String) params.get(1), "/");
		ports = createPorts((String) params.get(2));
		String strExtParams = (params.size() > 3 ? (String) params.get(3) : null);
		if (StringX.nullity(strExtParams)) return;
		Map extParams = StringX.str2map(strExtParams, "&");
		String val = (String) extParams.get("retryTimes");
		if (!StringX.nullity(val)) retryTimes = Integer.parseInt(val);

		val = (String) extParams.get("len");
		if (!StringX.nullity(val)) len = Integer.parseInt(val);

		val = (String) extParams.get("containHdrLenSelf");
		if (!StringX.nullity(val)) containHdrLenSelf = TRUE.equalsIgnoreCase(val);

		val = (String) extParams.get("timeout");
		if (!StringX.nullity(val)) timeout = Integer.parseInt(val);

		val = (String) extParams.get("soTimeout");
		if (!StringX.nullity(val)) soTimeout = Integer.parseInt(val);

		val = (String) extParams.get("simplex");
		if (!StringX.nullity(val)) simplex = TRUE.equalsIgnoreCase(val);

		val = (String) extParams.get("longCnn");
		if (!StringX.nullity(val)) longCnn = TRUE.equalsIgnoreCase(val);

		val = (String) extParams.get("len2bcd");
		if (!StringX.nullity(val)) len2bcd = TRUE.equalsIgnoreCase(val);

		val = (String) extParams.get("tcpNoDelay");
		if (!StringX.nullity(val)) tcpNoDelay = TRUE.equalsIgnoreCase(val);

		val = (String) extParams.get("hdrLenBinary");
		if (!StringX.nullity(val)) hdrLenBinary = TRUE.equalsIgnoreCase(val);

		val = (String) extParams.get("sndLenWithBuf");
		if (!StringX.nullity(val)) sndLenWithBuf = TRUE.equalsIgnoreCase(val);
	}

	static String TRUE = "true";
	protected int receiveBufferSize = 4096;
	protected boolean tcpNoDelay = true;
	protected String location;
	protected String ip;
	protected int[] ports;
	protected int cursor; // 多端口情况下，当前端口， chenjs 2013-03-28
	protected boolean randomPort; // 随机端口

	protected Socket s;
	protected OutputStream os;
	protected InputStream is;

	protected int retryTimes = 0; // 重试次数默认为重试一次
	protected boolean simplex; // 是否单工， 如果单工则只能发，不能接受
	protected boolean longCnn; // 是否长连接
	protected int len = 8; // 每次发送的头长度, 如果为<=0表示不需要发送长度标识
	protected boolean containHdrLenSelf; // chenjs 2012-11-22 报文头长度是否包含头长度本身,
	// 比如长度头8个字节，内容200个字节，长度头信息为208字节
	protected boolean len2bcd; // 发送的长度字段是否需要BCD转码
	protected boolean hdrLenBinary;
	protected int timeout; // 建立socket连接的超时时间
	protected int soTimeout; // 读取消息超时时间
	protected boolean sndLenWithBuf = true; // added by chenjs 2011-11-03
	// 长度和内容一次网络通讯进行发送， true会提高很多性能
	protected static Log log = Log.getLogger(SocketEndpoint.class);

	public void setSimplex(boolean simplex)
	{
		this.simplex = simplex;
	}

	public void setLongCnn(boolean longCnn)
	{
		this.longCnn = longCnn;
	}

	public void setRetryTimes(int retryTimes)
	{
		this.retryTimes = retryTimes;
	}

	public void setLen2bcd(boolean len2bcd)
	{
		this.len2bcd = len2bcd;
	}

	public int getLen()
	{
		return len;
	}

	public void setLen(int len)
	{
		this.len = len;
	}

	public void setTimeout(int timeout)
	{
		this.timeout = timeout;
	}

	public void setSoTimeout(int soTimeout)
	{
		this.soTimeout = soTimeout;
	}

	public boolean isHdrLenBinary()
	{
		return hdrLenBinary;
	}

	public void setHdrLenBinary(boolean hdrLenBinary)
	{
		this.hdrLenBinary = hdrLenBinary;
	}

	public void setReceiveBufferSize(int receiveBufferSize)
	{
		this.receiveBufferSize = receiveBufferSize;
	}

	public void setSndLenWithBuf(boolean sndLenWithBuf)
	{
		this.sndLenWithBuf = sndLenWithBuf;
	}

	public void setTcpNoDelay(boolean tcpNoDelay)
	{
		this.tcpNoDelay = tcpNoDelay;
	}

	public boolean isContainHdrLenSelf()
	{
		return containHdrLenSelf;
	}

	public void setContainHdrLenSelf(boolean containHdrLenSelf)
	{
		this.containHdrLenSelf = containHdrLenSelf;
	}

	public void setRandomPort(boolean randomPort)
	{
		this.randomPort = randomPort;
	}

}
