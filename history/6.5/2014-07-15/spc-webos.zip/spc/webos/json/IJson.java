package spc.webos.json;

public interface IJson
{
	StringBuffer toJson();
}
