package spc.webos.acceptor;

import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Map;

import spc.webos.buffer.IBuffer;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.flownode.MessageFlow;
import spc.webos.thread.DaemonThread;
import spc.webos.util.NumberX;
import spc.webos.util.StringX;
import spc.webos.util.charset.EBCDUtil;

public abstract class Acceptor extends DaemonThread
{
	protected IMessageConverter converter;
	protected int port;
	protected boolean simplex; // �첽����ʱ�Ƿ���Ҫ����Ӧ���ģ���Ϊ���������ǵ���ģʽ,simplex
	protected boolean len2bcd;
	protected String logScript; // �߳���־�ű�, ���ڱ���ʽ�ж�
	protected String logName; // ��־��
	protected LinkedList handlers = new LinkedList(); // ������ǰ���ӵ��߳�
	protected int hdrLen = 8;
	protected boolean containHdrLenSelf; // 2012-11-26 chenjs ��Щģʽ����ͷ��Ϣ�������ȱ���
	protected boolean hdrLenBinary = false; // ���ȱ�ʾΪ������, Ĭ����ASC��
	protected IBuffer reqbuf; // ����buffer
	protected IBuffer repbuf; // Ӧ��buffer
	protected MessageFlow msgFlow; // ָ���������ĵ���Ϣ��
	protected boolean endFlag;
	protected ISecurity security;
	protected int maxbytes;
	protected byte endFlagChar = '\0';

	public static final Map ACCEPTORS = new Hashtable(); // ������HashMap����Ϊ�����ӣ�Ҳ��ɾ��

	// 2012-12-12 chenjs ������ͷ���ȵĴ������뵽Acceptor��
	public int length(byte[] lenBytes)
	{
		// added by chenjs 2011-06-25 ֧�����붨��ͷ�ĳ�����ϢΪ������ģʽ
		// modified by chenjs 2012-11-25 ����containHdrLenSelf�����ж�
		if (isHdrLenBinary()) return NumberX.bytes2int(lenBytes)
				- (isContainHdrLenSelf() ? getHdrLen() : 0);
		return new Integer(isLen2bcd() ? EBCDUtil.bcd2gbk(lenBytes) : new String(lenBytes).trim())
				.intValue() - (isContainHdrLenSelf() ? getHdrLen() : 0);
	}

	public synchronized void addHandler(DaemonThread handler)
	{
		handlers.add(handler);
	}

	public synchronized void removeHandler(DaemonThread handler)
	{
		handlers.remove(handler);
	}

	// ǿ����ֹ��ص����д����߳�
	public void interruptAll()
	{
		if (handlers == null || handlers.size() == 0) return;
		for (int i = 0; i < handlers.size(); i++)
		{
			try
			{
				DaemonThread t = (DaemonThread) handlers.get(i);
				log.warn("start to interrupt thread " + t.getName());
				t.interrupt();
			}
			catch (Exception e)
			{
			}
		}
	}

	public void init() throws Exception
	{
		super.init();
		if (!StringX.nullity(getName()))
		{
			if (ACCEPTORS.containsKey(getName())) log.warn("ACCEPTOR(" + getName()
					+ ") has been exist!!!" + ACCEPTORS.keySet());
			ACCEPTORS.put(getName(), this);
		}
	}

	public int getPort()
	{
		return port;
	}

	public void setPort(int port)
	{
		this.port = port;
	}

	public boolean simplex()
	{
		return simplex;
	}

	public IMessageConverter getConverter()
	{
		return converter;
	}

	public void setConverter(IMessageConverter converter)
	{
		this.converter = converter;
	}

	public void setSimplex(boolean simplex)
	{
		this.simplex = simplex;
	}

	public String getLogScript()
	{
		return logScript;
	}

	public void setLogScript(String logScript)
	{
		this.logScript = logScript;
	}

	public String getLogName()
	{
		return logName;
	}

	public void setLogName(String logName)
	{
		this.logName = logName;
	}

	public LinkedList getHandlers()
	{
		return handlers;
	}

	public ISecurity getSecurity()
	{
		return security;
	}

	public void setSecurity(ISecurity security)
	{
		this.security = security;
	}

	public int getHdrLen()
	{
		return hdrLen;
	}

	public void setHdrLen(int hdrLen)
	{
		this.hdrLen = hdrLen;
	}

	public IBuffer getReqbuf()
	{
		return reqbuf;
	}

	public void setReqbuf(IBuffer reqbuf)
	{
		this.reqbuf = reqbuf;
	}

	public IBuffer getRepbuf()
	{
		return repbuf;
	}

	public void setRepbuf(IBuffer repbuf)
	{
		this.repbuf = repbuf;
	}

	public MessageFlow getMsgFlow()
	{
		return msgFlow;
	}

	public void setMsgFlow(MessageFlow msgFlow)
	{
		this.msgFlow = msgFlow;
	}

	public boolean isEndFlag()
	{
		return endFlag;
	}

	public void setEndFlag(boolean endFlag)
	{
		this.endFlag = endFlag;
	}

	public boolean isSimplex()
	{
		return simplex;
	}

	public boolean isLen2bcd()
	{
		return len2bcd;
	}

	public void setLen2bcd(boolean len2bcd)
	{
		this.len2bcd = len2bcd;
	}

	public boolean isHdrLenBinary()
	{
		return hdrLenBinary;
	}

	public void setHdrLenBinary(boolean hdrLenBinary)
	{
		this.hdrLenBinary = hdrLenBinary;
	}

	public void setMaxbytes(int maxbytes)
	{
		this.maxbytes = maxbytes;
	}

	public byte getEndFlagChar()
	{
		return endFlagChar;
	}

	public void setEndFlagChar(byte endFlagChar)
	{
		this.endFlagChar = endFlagChar;
	}

	public int getMaxbytes()
	{
		return maxbytes;
	}

	public boolean isContainHdrLenSelf()
	{
		return containHdrLenSelf;
	}

	public void setContainHdrLenSelf(boolean containHdrLenSelf)
	{
		this.containHdrLenSelf = containHdrLenSelf;
	}
}
