package spc.webos.acceptor.fnode;

import java.io.ByteArrayOutputStream;

import spc.webos.acceptor.SocketMessage;
import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.flownode.impl.SendResponseAFNode;
import spc.webos.util.NumberX;
import spc.webos.util.StringX;
import spc.webos.util.charset.EBCDUtil;

/**
 * ����TCPӦ��ڵ�
 * 
 * @author spc
 * 
 */
public class TCPResponseAFNode extends SendResponseAFNode
{
	protected void send(IMessage msg) throws Exception
	{
		SocketMessage smsg = (SocketMessage) msg2sndobj(msg);
		if (smsg == null)
		{
			log.warn("smsg is null!!!");
			return;
		}
		try
		{
			if (smsg.nbc != null)
			{
				synchronized (smsg.nbc)
				{
					send(msg, smsg);
					msg.setInLocal(MsgLocalKey.SND_BUF, Boolean.TRUE);
				}
			}
			else if (smsg.os != null)
			{
				synchronized (smsg.os)
				{
					send(msg, smsg);
					msg.setInLocal(MsgLocalKey.SND_BUF, Boolean.TRUE);
				}
			}
		}
		catch (Exception e)
		{
			if (logex) log.warn("err to sndrep:", e);
			else throw e;
		}
	}

	protected void send(IMessage msg, SocketMessage smsg) throws Exception
	{
		if (smsg.repmsg == null || smsg.repmsg.length == 0)
		{
			log.warn("smsg.repmsg is null or len is 0!!!");
			return;
		}
		if (log.isInfoEnabled()) log.info("snd len: " + smsg.repmsg.length + ", " + sndLenWithBuf);
		if (sndLenWithBuf)
		{
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			if (autoSndLenHdr && smsg.hdrLen > 0) baos.write(lenBytes(smsg));
			baos.write(smsg.repmsg);
			if (smsg.endFlag) baos.write('\0');
			send(smsg, baos.toByteArray(), false);
		}
		else
		{
			if (autoSndLenHdr && smsg.hdrLen > 0) send(smsg, lenBytes(smsg), false);
			send(smsg, smsg.repmsg, false);
			// added by spc 2011-05-03 ����н�����־���ͽ�����־
			if (smsg.endFlag) send(smsg, new byte[] { '\0' }, false);
		}
		flush(smsg);
		if (smsg.hdrLen <= 0) close(smsg);

		// added by chenjs 2012-12-12
		if (smsg.socket != null)
		{
			log.debug("close socket!!!");
			smsg.socket.close();
		}
	}

	protected byte[] lenBytes(SocketMessage smsg)
	{
		// modified by chenjs 2012-11-25 ����containHdrLenSelf���Կ���
		int hdrlen = smsg.repmsg.length + (smsg.containHdrLenSelf ? smsg.hdrLen : 0);
		if (smsg.hdrLenBinary) return NumberX.int2bytes(hdrlen, smsg.hdrLen);
		String strLen = StringX.int2str(String.valueOf(hdrlen), smsg.hdrLen);
		// added by chenjs 2011-06-25
		// Ϊ�˼�����ǰTCPResponse���ܣ�ֻҪһ���ط�����len2bcd����Ϊ��Ҫlen2bcd
		return (len2bcd || smsg.len2bcd) ? EBCDUtil.gbk2bcd(strLen) : strLen.getBytes();
	}

	protected void send(SocketMessage smsg, byte[] buf, boolean autoFlush) throws Exception
	{
		if (log.isDebugEnabled()) log.debug("snd bytes base64: "
				+ new String(StringX.encodeBase64(buf)) + "\n\t\tstr: " + new String(buf));
		if (smsg.nbc != null)
		{
			smsg.nbc.write(buf);
			if (autoFlush) smsg.nbc.flush();
			if (log.isInfoEnabled()) log.info("suc to snd nbc: " + buf.length + ", flush:"
					+ autoFlush + ", remote:" + smsg.nbc.getRemoteAddress());
		}
		else if (smsg.os != null)
		{
			smsg.os.write(buf);
			if (autoFlush) smsg.os.flush();
			if (log.isInfoEnabled()) log.info("suc to snd os: " + buf.length + ", flush:"
					+ autoFlush);
		}
		else log.warn("nbc and os in SocketMessage are null!!!");
	}

	protected void flush(SocketMessage smsg) throws Exception
	{
		if (smsg.nbc != null) smsg.nbc.flush();
		else if (smsg.os != null) smsg.os.flush();
		else log.warn("nbc and os in SocketMessage are null in flush!!!");
	}

	protected void close(SocketMessage smsg) throws Exception
	{
		log.debug("close os or nbc!!!");
		if (smsg.nbc != null)
		{
			synchronized (smsg.nbc)
			{
				smsg.nbc.close();
			}
			return;
		}
		else if (smsg.os != null)
		{
			synchronized (smsg.os)
			{
				smsg.os.close();
			}
			return;
		}
		else log.warn("nbc and os in SocketMessage are null in close!!!");
	}

	protected Object msg2sndobj(IMessage msg) throws Exception
	{
		byte[] response = repbytes(msg);
		if (((String) msg.getInLocal(MsgLocalKey.ACCEPTOR_PROTOCOL))
				.startsWith(Common.ACCEPTOR_PROTOCOL_TCPIP))
		{ // tcp���뷽ʽ
			SocketMessage smsg = (SocketMessage) msg
					.getInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_SOCKETMSG);
			smsg.repmsg = response;
			return smsg;
		}
		log.warn("it is not a SocketMessage!!!");
		return null;
	}

	protected byte[] repbytes(IMessage msg) throws Exception
	{
		IMessageConverter converter = getMsgConverter(msg);
		return converter.serialize(msg);
	}

	protected boolean isSend(IMessage msg)
	{
		if (msg.getLocal().containsKey(MsgLocalKey.NO_RETURN))
		{
			log.info("no return flag has been set!!!");
			return false;
		}
		if (msg.getLocal().containsKey(MsgLocalKey.LOCAL_ACCESS4LOCAL))
		{
			log.info("LOCAL_ACCESS4LOCAL flag has been set!!!");
			return false;
		}
		return true;
	}

	protected boolean logex = true; // �����־�쳣��˵������ʧ�ܣ������̲����׳��쳣, Ĭ��Ϊtrue
	protected boolean len2bcd; // ������Ϣbcd
	protected boolean autoSndLenHdr = true;
	protected boolean sndLenWithBuf = true; // added by chenjs 2011-11-03,
											// true����ߺܶ�����

	public void setLogex(boolean logex)
	{
		this.logex = logex;
	}

	public void setLen2bcd(boolean len2bcd)
	{
		this.len2bcd = len2bcd;
	}

	public void setAutoSndLenHdr(boolean autoSndLenHdr)
	{
		this.autoSndLenHdr = autoSndLenHdr;
	}

	public boolean isSndLenWithBuf()
	{
		return sndLenWithBuf;
	}

	public void setSndLenWithBuf(boolean sndLenWithBuf)
	{
		this.sndLenWithBuf = sndLenWithBuf;
	}
}