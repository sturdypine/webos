package spc.webos.acceptor.xsocket;

import java.util.concurrent.Executors;

import org.xsocket.connection.IServer;
import org.xsocket.connection.Server;

import spc.webos.acceptor.Acceptor;
import spc.webos.log.Log;
import spc.webos.util.StringX;

public class XSocketAcceptor extends Acceptor
{
	protected DefaultServerHandler handler;
	protected Server server;
	protected int maxReadBufferThreshold;
	protected int maxConcurrentConnections = 0;
	protected int workThreadPool = 0;
	protected int idleTimeoutMillis = 60 * 1000;
	protected int cnnTimeoutMillis = 60 * 1000;

	public void execute() throws Exception
	{
		try
		{
			log.info("xsocket(" + getName() + ") start to listen: " + port);
			if (server == null)
			{
				log.warn("server need init, cause server is null!!!");
				init();
			}
			Log.print();
			server.run();
			log.info("xsocket(" + getName() + ") stop to listen: " + port);
		}
		catch (Exception e)
		{
			log.warn("XSocketAcceptor.exe(" + port + ")", e);
		}
		finally
		{
			release();
			Log.print(); // added by chenjs 2011-06-20 �ͷ���־�ռ�
			Log.printNotice();
		}
	}

	public void init() throws Exception
	{
		setName("XSocket-" + port);
		if (!StringX.nullity(getLogName())) Log.start(getLogName());
		if (handler == null)
		{
			handler = new DefaultServerHandler();
			log.debug("using DefaultServerHandler!!!");
		}
		handler.setAcceptor(this);
		handler.init(); // modified by chenjs 2011-06-23 ��ʼ���ӳ�
		if (server == null) server = new Server(port, handler);
		server.setIdleTimeoutMillis(idleTimeoutMillis);
		server.setConnectionTimeoutMillis(cnnTimeoutMillis);
		if (maxConcurrentConnections > 0) server
				.setMaxConcurrentConnections(maxConcurrentConnections);
		if (workThreadPool > 0) server.setWorkerpool(Executors.newFixedThreadPool(workThreadPool));
		super.init();
	}

	public void interruptAll()
	{
		release();
		super.interruptAll();
	}

	public void release()
	{
		log.warn("xsocket(" + getName() + ") stop to listen to port: " + port);
		super.release();
		try
		{
			if (server != null) server.close();
		}
		catch (Exception e)
		{
			log.error("XSocketAcceptor.close", e);
		}
		server = null;
	}

	public DefaultServerHandler getHandler()
	{
		return handler;
	}

	public void setHandler(DefaultServerHandler handler)
	{
		this.handler = handler;
	}

	public IServer getServer()
	{
		return server;
	}

	public void setServer(Server server)
	{
		this.server = server;
	}

	public void setMaxReadBufferThreshold(int maxReadBufferThreshold)
	{
		this.maxReadBufferThreshold = maxReadBufferThreshold;
	}

	public void setMaxConcurrentConnections(int maxConcurrentConnections)
	{
		this.maxConcurrentConnections = maxConcurrentConnections;
	}

	public int getWorkThreadPool()
	{
		return workThreadPool;
	}

	public void setWorkThreadPool(int workThreadPool)
	{
		this.workThreadPool = workThreadPool;
	}

	public int getMaxReadBufferThreshold()
	{
		return maxReadBufferThreshold;
	}

	public int getMaxConcurrentConnections()
	{
		return maxConcurrentConnections;
	}

	public void setIdleTimeoutMillis(int idleTimeoutMillis)
	{
		this.idleTimeoutMillis = idleTimeoutMillis;
	}

	public void setCnnTimeoutMillis(int cnnTimeoutMillis)
	{
		this.cnnTimeoutMillis = cnnTimeoutMillis;
	}
}
