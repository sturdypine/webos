package spc.webos.jsrmi;

import java.io.IOException;
import java.util.Locale;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import spc.webos.jsrmi.request.RequestContext;
import spc.webos.jsrmi.request.RequestContextUtil;
import spc.webos.jsrmi.request.RequestWorker;
import spc.webos.jsrmi.service.DefaultServiceRepository;
import spc.webos.jsrmi.service.JsrmiWorker;
import spc.webos.jsrmi.service.ServiceRepository;
import spc.webos.jsrmi.web.RequestUtils;
import spc.webos.log.Log;

public class JsrmiServlet extends HttpServlet
{
	private static final long serialVersionUID = 7531914733078063390L;
	private static final Log log = Log.getLogger(JsrmiServlet.class);
	private static final String LOCALE_COOKIE_NAME = "spc.webos.jsrmi.web.locale";

	public String getServletInfo()
	{
		return "Jsrmi Application Gateway Servlet";
	}

	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		initServiceRepository();
	}

	private void initServiceRepository()
	{
		if (getServletContext().getAttribute(ServiceRepository.WEB_CONTEXT_KEY) == null)
		{
			log.info("initialize the service repository");
			ServiceRepository repository = new DefaultServiceRepository(getServletContext());
			getServletContext().setAttribute(ServiceRepository.WEB_CONTEXT_KEY, repository);
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		doRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		doRequest(request, response);
	}

	protected void doRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		try
		{
			RequestContextUtil.createRequestContext(getServletContext(), request, response);
			RequestWorker worker = new JsrmiWorker();

			// try
			// {
			// worker.validate(request, response);
			// }
			// catch (ValidationException ex)
			// {
			// throw new ServletException("Service validation error", ex);
			// }

			worker.processRequest(request, response);
			RequestContextUtil.updateRequestContext(getServletContext(), request, response);
		}
		catch (Exception e)
		{
			log.debug("jsrmi request", e);
			throw new RuntimeException(e);
		}
	}

	protected Locale getLocaleFromRequest() throws ServletException
	{
		Cookie cookie = (Cookie) RequestContext.getContext().getCookie().get(LOCALE_COOKIE_NAME);

		if (cookie != null) return RequestUtils.getLocale(cookie.getValue());

		return RequestContext.getContext().getHttpRequest().getLocale();
	}
}
