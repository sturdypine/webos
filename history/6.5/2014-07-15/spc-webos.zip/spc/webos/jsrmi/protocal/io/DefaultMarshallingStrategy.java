
package spc.webos.jsrmi.protocal.io;

import java.util.ArrayList;
import java.util.List;

import spc.webos.jsrmi.protocal.JsrmiCall;
import spc.webos.jsrmi.protocal.ProtocalTag;
import spc.webos.jsrmi.protocal.converters.ConverterLookup;

public class DefaultMarshallingStrategy implements MarshallingStrategy {
	
	public void marshal(Object obj, ConverterLookup converterLookup, StreamWriter streamWriter) {
		streamWriter.startNode(ProtocalTag.TAG_REPLY);
		MarshallingContext marshallingContext = new DefaultMarshallingContext(converterLookup, streamWriter);
		marshallingContext.convertAnother(obj);
		streamWriter.endNode();
		streamWriter.flush();
		streamWriter.close();
	}

	public JsrmiCall unmarshal(StreamReader in, ConverterLookup converterLookup) {
		in.moveDown();
		String methodName = in.getValue();
		in.moveUp();
		
		UnmarshallingContext unmarshallingContext = new DefaultUnmarshallingContext(converterLookup, in);
		List arguments = new ArrayList();
		while(in.hasMoreChildren()) {
			arguments.add(unmarshallingContext.convertAnother());
		}
		in.close();
		return new JsrmiCall(methodName, arguments.toArray());
	}

}
