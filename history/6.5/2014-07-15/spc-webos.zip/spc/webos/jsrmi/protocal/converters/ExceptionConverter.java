package spc.webos.jsrmi.protocal.converters;

import spc.webos.data.Status;
import spc.webos.data.validator.MessageErrors;
import spc.webos.exception.AppException;
import spc.webos.jsrmi.protocal.ProtocalTag;
import spc.webos.jsrmi.protocal.io.MarshallingContext;
import spc.webos.jsrmi.protocal.io.StreamReader;
import spc.webos.jsrmi.protocal.io.StreamWriter;
import spc.webos.jsrmi.protocal.io.UnmarshallingContext;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

public class ExceptionConverter implements Converter
{
	public boolean canConvert(Class type)
	{
		return Throwable.class.isAssignableFrom(type);
	}

	public void marshal(Object source, MarshallingContext marshallingContext,
			StreamWriter streamWriter)
	{
		Throwable ex = (Throwable) source;
		streamWriter.startNode(ProtocalTag.TAG_FAULT);
		if (source instanceof AppException)
		{
			AppException ae = (AppException) source;
			node(streamWriter, ProtocalTag.TAG_STRING, "code");
			node(streamWriter, ProtocalTag.TAG_STRING, ae.getCode());
			Status status = SystemUtil.ex2status(StringX.EMPTY_STRING, (AppException) source);
			node(streamWriter, ProtocalTag.TAG_STRING, "message");
			node(streamWriter, ProtocalTag.TAG_STRING, status.getDesc());
			node(streamWriter, ProtocalTag.TAG_STRING, "exception");
			node(streamWriter, ProtocalTag.TAG_STRING, source.getClass().getName());
			node(streamWriter, ProtocalTag.TAG_STRING, "autopop");
			node(streamWriter, ProtocalTag.TAG_STRING, "false");

			// node(streamWriter, ProtocalTag.TAG_STRING, "detail");
			// node(streamWriter, ProtocalTag.TAG_STRING, ae.getDetail());
			marshallingContext.convertAnother("detail");
			Object detail = ae.getDetail();
			if (detail == null) marshallingContext.convertAnother(StringX.EMPTY_STRING);
			else if (detail instanceof MessageErrors) marshallingContext
					.convertAnother(((MessageErrors) detail).toCNode());
			else marshallingContext.convertAnother(detail);
			node(streamWriter, ProtocalTag.TAG_STRING, "location");
			node(streamWriter, ProtocalTag.TAG_STRING, ae.getLocation());
			// Converter converter = DefaultConverterLookup.getInstance()
			// .lookupConverterForType(ae.getDetail().getClass());
			// converter.marshal(ae.getDetail(), marshallingContext,
			// streamWriter);
		}
		else
		{
			String detail = StringX.EMPTY_STRING;
			if (ex.getCause() != null) detail = "caused by: " + ex.getCause().getMessage();
			node(streamWriter, ProtocalTag.TAG_STRING, "code");
			node(streamWriter, ProtocalTag.TAG_STRING, StringX.EMPTY_STRING);
			node(streamWriter, ProtocalTag.TAG_STRING, "message");
			node(streamWriter, ProtocalTag.TAG_STRING, ex.getMessage());
			node(streamWriter, ProtocalTag.TAG_STRING, "exception");
			node(streamWriter, ProtocalTag.TAG_STRING, source.getClass().getName());
			node(streamWriter, ProtocalTag.TAG_STRING, "autopop");
			node(streamWriter, ProtocalTag.TAG_STRING, "true");
			// detail is at the tail
			node(streamWriter, ProtocalTag.TAG_STRING, "detail");
			node(streamWriter, ProtocalTag.TAG_STRING, detail);
			node(streamWriter, ProtocalTag.TAG_STRING, "location");
			StackTraceElement[] stack = ex.getCause() != null ? ex.getCause().getStackTrace() : ex
					.getStackTrace();
			String loc = stack[0].getClassName() + '.' + stack[0].getMethodName() + ':'
					+ stack[0].getLineNumber();
			node(streamWriter, ProtocalTag.TAG_STRING, loc);
		}

		streamWriter.endNode();
	}

	private void node(StreamWriter streamWriter, String tagName, String value)
	{
		streamWriter.startNode(tagName);
		streamWriter.setValue(value);
		streamWriter.endNode();
	}

	public Object unmarshal(StreamReader reader, UnmarshallingContext unmarshallingContext)
	{
		throw new UnsupportedOperationException();
	}

}
