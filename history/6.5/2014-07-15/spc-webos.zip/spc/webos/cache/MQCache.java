package spc.webos.cache;

import java.util.Collection;
import java.util.Map;

import spc.webos.constant.AppRetCode;
import spc.webos.exception.AppException;
import spc.webos.log.Log;
import spc.webos.queue.Queue;
import spc.webos.queue.QueueMessage;
import spc.webos.queue.ibmmq.Accessor;
import spc.webos.queue.ibmmq.MQCnnPool;
import spc.webos.queue.ibmmq.MQMessageUtil;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;

/**
 * ʹ��MQCache����MQ��ʱ��Ϣ���� message.clearMessage(); message.write(msg);
 * message.expiry = transMsg.getMsgExprity(); // �趨��Ϣ�ĳ�ʱʱ�� message.correlationId
 * = transMsg.getCorrelationIDBaseOnMessageAsbytes(); // �趨��Ϣ��corrId
 * message.messageId = transMsg.getMsgIDBaseOnMessageAsbytes(); // �趨��Ϣ��msgId
 * message.replyToQueueManagerName = getQMName(); //
 * �趨��Ϣ��ʱ�������صĶ��й����������ֵ�������ã�ֵΪ��BROKER��ʹ�õĶ��й����� //
 * �趨��ʱ����Ϣ�����صĶ��У���ֵ����ΪMB.TIMEOUT
 * ������Ϣ��TIMEOUT_ERROR_RETURN.msgflow�Ӵ˶����л�ȡ��ʱ���ģ����д��� message.replyToQueueName =
 * MbConfig.MB_DEFAULT_TIMEOUTQ; message.report =
 * MQC.MQRO_EXPIRATION_WITH_FULL_DATA; //
 * �趨report�����ͣ��������÷���ָ����Ϣ�ڳ�ʱ�󣬷��ص�replyQ�У�����ȫ������ send(message, new
 * MQPutMessageOptions()); // ������Ϣ
 * 
 * @author spc
 * 
 */
public class MQCache implements ICache
{
	public Object get(Object key)
	{
		return readMQ(key.toString(), browse, 0);
	}

	public Object poll(Object key)
	{
		return readMQ(key.toString(), false, 0);
	}

	public Object poll(Object key, long timeout)
	{
		return readMQ(key.toString(), false, timeout);
	}

	public int browseAll() throws Exception
	{
		return Accessor.browseAll(cnnpool, qname, cap);
		// modified by chenjs ʹ��һ��ָ������ϢId����ɨ���������� 2010-10-28
		// log.info("browseAll queue message!!!");
		// try
		// {
		// MQGetMessageOptions gmo = new MQGetMessageOptions();
		// // ƥ��������corrid msgid������
		// gmo.matchOptions = MQC.MQMO_MATCH_CORREL_ID | MQC.MQMO_MATCH_MSG_ID;
		// // ���û�з��������ı��ģ����ȴ����̷���
		// gmo.options = MQC.MQGMO_NO_WAIT;
		// MQMessage qmsg = new MQMessage();
		// qmsg.correlationId = StringX.ZEROS.substring(0, 24).getBytes(); //
		// �ṩһ�������ڵ���Ϣid
		// qmsg.messageId = StringX.ZEROS.substring(0, 24).getBytes();
		// Accessor.receive(cnnpool, qname, gmo, qmsg);
		// }
		// catch (Exception e)
		// {
		// }
		// return 0;
	}

	protected MQMessage readMQ(String key, boolean browse, long timeout)
	{
		if (key.length() > 48) throw new RuntimeException("key len: " + key.length() + " > 48");
		String strkey = key + BLANKS;
		String messageId = strkey.substring(0, 24);
		String corId = strkey.substring(24, 48);
		MQMessage mqmsg = new MQMessage();
		MQGetMessageOptions gmo = new MQGetMessageOptions();
		// ƥ��������corrid msgid������
		gmo.matchOptions = MQC.MQMO_MATCH_CORREL_ID | MQC.MQMO_MATCH_MSG_ID;
		// ���û�з��������ı��ģ����ȴ����̷���
		if (timeout <= 0) gmo.options = MQC.MQGMO_NO_WAIT;
		else
		{
			gmo.options = MQC.MQGMO_WAIT;
			gmo.waitInterval = (int) timeout;
		}
		mqmsg.correlationId = corId.getBytes();
		mqmsg.messageId = messageId.getBytes();

		try
		{
			if (browse) Accessor.browse(cnnpool, qname, gmo, mqmsg);
			else Accessor.receive(cnnpool, qname, gmo, mqmsg);
		}
		catch (MQException e)
		{
			if (e.reasonCode == 2033) return null;
			throw new AppException(AppRetCode.PROTOCOL_MQ(), new Object[] { qname,
					String.valueOf(e.reasonCode), String.valueOf(e.completionCode) });
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}

		return mqmsg;
	}

	public Object put(Object key, Object o)
	{
		if (key.toString().length() > 48) throw new RuntimeException("key len: "
				+ key.toString().length() + " > 48");
		if (readBeforeWrite && get(key) != null) throw new AppException(AppRetCode.CMM_BIZ_ERR(),
				"MQCache(" + name + ") has contain key: " + key);
		String strkey = key + BLANKS;
		String messageId = strkey.substring(0, 24);
		String corId = strkey.substring(24, 48);
		try
		{
			MQMessage mqmsg = null;
			if (o instanceof MQMessage) mqmsg = (MQMessage) o;
			else if (o instanceof QueueMessage)
			{
				// mqmsg = ((QueueMessage) o).toMQMessage(new MQMessage());
				// modified by chenjs 2012-11-29
				// ֧��TLQ���Ƴ�QueueMessage�����MQMessage����
				mqmsg = MQMessageUtil.toMQMessage((QueueMessage) o, new MQMessage());
			}
			else
			{
				mqmsg = new MQMessage();
				mqmsg.write((byte[]) o);
			}
			mqmsg.correlationId = corId.getBytes();
			mqmsg.messageId = messageId.getBytes();
			if (mqmsg.expiry > 0) mqmsg.report = MQC.MQRO_EXPIRATION_WITH_FULL_DATA;
			Accessor.send(cnnpool, qname, new MQPutMessageOptions(), mqmsg, 0, 0);
		}
		catch (Exception ee)
		{
			throw new RuntimeException(ee);
		}
		return o;
	}

	public int size()
	{
		try
		{
			Queue qinfo = Accessor.browse(cnnpool, qmname, qname);
			return qinfo.getCurDepth();
		}
		catch (MQException e)
		{
			// e.printStackTrace();
			throw new AppException(AppRetCode.PROTOCOL_MQ(), new Object[] { qname,
					String.valueOf(e.reasonCode), String.valueOf(e.completionCode) });
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
	}

	public void removeAll()
	{
		try
		{
			Accessor.clearAll(cnnpool, qname, cap);
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
	}

	public Object poll(Object key, WaitWithTime wwt)
	{
		return poll(key, wwt.timeout);
	}

	public Collection getKeys()
	{
		throw new UnsupportedOperationException("getKeys()");
	}

	public Object getMessage(String key)
	{
		throw new UnsupportedOperationException("getMessage(String key)");
	}

	public Object remove(Object o)
	{
		throw new UnsupportedOperationException("remove (Object o)");
	}

	public boolean changeStatus(Map param)
	{
		return false;
	}

	public Map checkStatus(Map param)
	{
		return null;
	}

	public void refresh() throws Exception
	{
	}

	protected boolean browse;
	protected boolean readBeforeWrite = true; // put MQ֮ǰ�Ƿ���read���
	protected String name;
	protected String qname;
	protected String qmname;
	protected MQCnnPool cnnpool;
	protected int cap = 100000;
	protected Log log = Log.getLogger(getClass());
	public static final String BLANKS = "                                                ";

	public boolean isReadBeforeWrite()
	{
		return readBeforeWrite;
	}

	public void setReadBeforeWrite(boolean readBeforeWrite)
	{
		this.readBeforeWrite = readBeforeWrite;
	}

	public int getCap()
	{
		return cap;
	}

	public void setCap(int cap)
	{
		this.cap = cap;
	}

	public boolean isBrowse()
	{
		return browse;
	}

	public void setBrowse(boolean browse)
	{
		this.browse = browse;
	}

	public String getQmname()
	{
		return qmname;
	}

	public void setQmname(String qmname)
	{
		this.qmname = qmname;
	}

	public String getQname()
	{
		return qname;
	}

	public void setQname(String qname)
	{
		this.qname = qname;
	}

	public MQCnnPool getCnnpool()
	{
		return cnnpool;
	}

	public void setCnnpool(MQCnnPool cnnpool)
	{
		this.cnnpool = cnnpool;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getName()
	{
		return name;
	}

	public void init() throws Exception
	{
		if (name == null) name = qname;
		if (getName() != null) CACHE.put(getName(), this);
	}

	public void put(String key, byte[] buf, long expireSeconds) throws Exception
	{
		// TODO Auto-generated method stub
		
	}

	public byte[] get(String key, boolean browse)
	{
		// TODO Auto-generated method stub
		return null;
	}
}
