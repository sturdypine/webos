package spc.webos.cache;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.jms.JMSException;

import spc.webos.log.Log;
import spc.webos.queue.QueueMessage;
import spc.webos.queue.jms.JMSAccessor;
import spc.webos.queue.jms.JMSCnnPool;

public class ClusterTLQCache implements ICache
{
	protected String name;
	protected String qname;
	protected List cnnpools;
	protected Log log = Log.getLogger(getClass());
	public static final String BLANKS = "                                                ";

	public Object get(Object key)
	{
		return get(key.toString(), true, 0);
	}

	public Object poll(Object key)
	{
		return get(key.toString(), false, 0);
	}

	public Object poll(Object key, long timeout)
	{
		return get(key.toString(), false, timeout);
	}

	public byte[] get(String key, boolean browse)
	{
		return get(key, browse, 0);
	}

	public byte[] get(String key, boolean browse, long timeout)
	{
		if (key.length() > 48) throw new RuntimeException("key len: " + key.length() + " > 48");
		String strkey = key + BLANKS;
		String messageId = strkey.substring(0, 24);
		String corId = strkey.substring(24, 48);
		QueueMessage qmsg = null;

		int index = ((int) (Math.random() * 1000000) % cnnpools.size());
		for (int i = 0; i < cnnpools.size(); i++)
		{
			if (index >= cnnpools.size()) index = 0;
			JMSCnnPool cnnpool = (JMSCnnPool) cnnpools.get(index++);
			try
			{
				if (browse) qmsg = JMSAccessor.browse(cnnpool, qname, corId.getBytes(),
						messageId.getBytes());
				else qmsg = JMSAccessor.receive(cnnpool, qname, corId.getBytes(),
						new Long(timeout).intValue());
			}
			catch (JMSException jmse)
			{
				log.warn("fail to read:" + cnnpool.getProps() + ", qname:" + qname, jmse);
				continue;
			}
			catch (Exception e)
			{
				log.warn("fail to read:" + cnnpool.getProps() + ", qname:" + qname, e);
			}
		}
		return qmsg.buf;
	}

	public Object put(Object key, Object o) throws Exception
	{
		QueueMessage qmsg = null;

		if (o instanceof QueueMessage)
		{
			qmsg = (QueueMessage) o;
		}
		else
		{
			qmsg = new QueueMessage();
			qmsg.buf = (byte[]) o;
		}
		put(key.toString(), qmsg, -1);

		return o;
	}

	public void put(String key, byte[] buf, long expireSeconds) throws Exception
	{
		QueueMessage qmsg = new QueueMessage();
		qmsg.buf = buf;
		put(key.toString(), qmsg, expireSeconds);
	}

	public void put(String key, QueueMessage qmsg, long expireSeconds) throws Exception
	{
		if (key.toString().length() > 48) throw new RuntimeException("key len: "
				+ key.toString().length() + " > 48");
		String strkey = key + BLANKS;
		String messageId = strkey.substring(0, 24);
		String corId = strkey.substring(24, 48);

		qmsg.correlationId = corId.getBytes();
		qmsg.messageId = messageId.getBytes();

		if (expireSeconds > 0) qmsg.expirySeconds = (int) expireSeconds * 10;

		JMSAccessor.sendCluster(false, cnnpools, qname, qmsg, 1, 0);
	}

	public int size()
	{
		return 0;
	}

	public void removeAll()
	{
		try
		{
			for (int i = 0; i < cnnpools.size(); i++)
				JMSAccessor.clearAll((JMSCnnPool) cnnpools.get(i), qname);

		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
	}

	public Object poll(Object key, WaitWithTime wwt)
	{
		return poll(key, wwt.timeout);
	}

	public Collection getKeys()
	{
		throw new UnsupportedOperationException("getKeys()");
	}

	public Object getMessage(String key)
	{
		throw new UnsupportedOperationException("getMessage(String key)");
	}

	public Object remove(Object o)
	{
		throw new UnsupportedOperationException("remove (Object o)");
	}

	public boolean changeStatus(Map param)
	{
		return false;
	}

	public Map checkStatus(Map param)
	{
		return null;
	}

	public void refresh() throws Exception
	{
	}

	public String getQname()
	{
		return qname;
	}

	public void setQname(String qname)
	{
		this.qname = qname;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getName()
	{
		return name;
	}

	public void setCnnpools(List cnnpools)
	{
		this.cnnpools = cnnpools;
	}

	public void init() throws Exception
	{
		if (name == null) name = qname;
		if (getName() != null) CACHE.put(getName(), this);
	}
}
