package spc.webos.cache;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class MapCache extends HashMap implements ICache
{
	private static final long serialVersionUID = 1L;
	String name;

	public void init() throws Exception
	{
		if (getName() != null) CACHE.put(getName(), this);
	}

	public void evictExpiredElements()
	{
	}

	public Collection getKeys()
	{
		return this.keySet();
	}

	public String getName()
	{
		return name;
	}

	public int getSize()
	{
		return this.size();
	}

	public Object poll(Object key, WaitWithTime wwt)
	{
		return null;
	}

	public Object poll(Object key)
	{
		return null;
	}

	public void removeAll()
	{
		this.clear();
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public Object poll(Object key, long timeout)
	{
		return null;
	}

	public Object getMessage(String key)
	{
		return get(key);
	}

	public boolean changeStatus(Map param)
	{
		return false;
	}

	public Map checkStatus(Map param)
	{
		return new HashMap();
	}

	public void refresh() throws Exception
	{
	}

	public void put(String key, byte[] buf, long expireSeconds) throws Exception
	{
		// TODO Auto-generated method stub
		
	}

	public byte[] get(String key, boolean browse)
	{
		// TODO Auto-generated method stub
		return null;
	}
}
