package spc.webos.resallocate.fnode;

import spc.webos.constant.MsgKey;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.AtomNode;
import spc.webos.data.IMessage;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.resallocate.service.IResourcePoolService;
import spc.webos.util.StringX;

public class ReleaseAFNode extends AbstractFNode
{
	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		String sn = StringX.null2emptystr(msg.findAtomInRequest(MsgKey.RES_ALLOCATE_SN, null));
		if (!StringX.nullity(sn)) msg.setInResponse("release",
				resourcePoolService.release(sn) ? Boolean.TRUE : Boolean.FALSE);
		else msg.setInResponse("recycle", resourcePoolService.recycle());
		// ���������ָ������ҪӦ���򲻷���Ӧ��
		if (msg.findAtomInRequest(MsgKey.RES_WITHOUTRETURN, new AtomNode(Boolean.TRUE))
				.booleanValue()) msg.setInLocal(MsgLocalKey.NO_RETURN, Boolean.TRUE);
		return null;
	}

	protected IResourcePoolService resourcePoolService;

	public void setResourcePoolService(IResourcePoolService resourcePoolService)
	{
		this.resourcePoolService = resourcePoolService;
	}
}
