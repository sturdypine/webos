package spc.webos.io;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class ByteArray
{
	// int pageSize = DEFAULT_PAGE_SIZE;
	public static final int DEFAULT_PAGE_SIZE = 1024;
	List pages = new ArrayList();
	int count = 0;

	public ByteArray()
	{
	}

	public void allocat(int size)
	{
		int pageNum = size / DEFAULT_PAGE_SIZE;
		if (size % DEFAULT_PAGE_SIZE > 0) pageNum++;
		addPages(pageNum - pages.size());
		count = size;
	}

	public void read(InputStream is) throws IOException
	{
		while (true)
		{
			byte[] page = getLastBlankPage();
			int pageRemain = getLastBlankPageRemain();
			int size = is.read(page, page.length - pageRemain, pageRemain);
			if (size > 0) count += size;
			if (size == -1 || size < pageRemain) break;
		}
	}

	public int getCount()
	{
		return count;
	}

	public void addCount(int increment)
	{
		count += increment;
	}

	public byte[] getPage(int i)
	{
		return (byte[]) pages.get(i);
	}

	public int getNumOfPage()
	{
		return pages.size();
	}

	// ��ȡ���һ������ҳ�� �����ǰû�п���ҳ������һҳ
	public byte[] getLastBlankPage()
	{
		if (pages.size() * DEFAULT_PAGE_SIZE <= count) addPages(1);
		return (byte[]) pages.get(pages.size() - 1);
	}

	// ��ȡ���һҳ�Ŀ��ô�С
	public int getLastBlankPageRemain()
	{
		return pages.size() * DEFAULT_PAGE_SIZE - count;
	}

	public byte get(int index)
	{
		if (index >= count) throw new IndexOutOfBoundsException();
		byte[] page = getPageByOffset(index);
		int s = index % DEFAULT_PAGE_SIZE;
		return page[s];
	}

	public void set(int index, byte b)
	{
		if (index >= count) throw new IndexOutOfBoundsException();
		byte[] page = getPageByOffset(index);
		int s = index % DEFAULT_PAGE_SIZE;
		page[s] = b;
	}

	public int read(int offset)
	{
		if (offset >= count) return -1;
		byte[] page = getPageByOffset(offset);
		int start = offset % DEFAULT_PAGE_SIZE;
		return page[start];
	}

	public int read(byte[] arr, int offset, int length, int pos)
	{
		int len = 0;
		int b = read(pos);
		if (b == -1) return -1;
		while (b != -1 && offset < length)
		{
			arr[offset++] = (byte) b;
			len++;
			b = read(++pos);
		}
		return len;
	}

	int read(byte[] arr, int s, int offset)
	{
		if (offset >= count) return -1;
		byte[] page = getPageByOffset(offset);
		int start = offset % DEFAULT_PAGE_SIZE;
		if (arr.length - s > count - offset)
		{ // �����������
			System.arraycopy(page, start, arr, s, count - offset);
			return count - offset;
		}
		int left = (arr.length - s) - (page.length - start);
		int size = left > 0 ? (page.length - start) : (arr.length - s);
		System.arraycopy(page, start, arr, s, size);
		if (left > 0) { return read(arr, s + size, offset + size); }
		return arr.length;
	}

	public void write(byte b)
	{
		byte[] page = getPageByOffset(count);
		int start = count % DEFAULT_PAGE_SIZE;
		page[start] = b;
		count++;
	}

	public void write(byte[] b, int offset, int len)
	{
		byte[] page = getPageByOffset(count);
		int start = count % DEFAULT_PAGE_SIZE;
		int left = len - (page.length - start);
		int size = left > 0 ? page.length - start : len;
		System.arraycopy(b, offset, page, start, size);
		count += size;
		if (left > 0) write(b, offset + size, len - size);
	}

	byte[] getPageByOffset(int offset)
	{
		int index = offset / DEFAULT_PAGE_SIZE;
		if ((offset % DEFAULT_PAGE_SIZE) > 0) index++;
		if (index >= pages.size()) return addPages(1);
		return (byte[]) pages.get(index);
	}

	// �������һҳ
	byte[] addPages(int pageNum)
	{
		byte[] page = null;
		while (pageNum > 0)
		{
			page = new byte[DEFAULT_PAGE_SIZE];
			pages.add(page);
			pageNum--;
		}
		return page;
	}

	public String toString()
	{
		byte[] arr = new byte[count];
		for (int i = 0; i < count; i++)
			arr[i] = get(i);
		return new String(arr);
	}
}
