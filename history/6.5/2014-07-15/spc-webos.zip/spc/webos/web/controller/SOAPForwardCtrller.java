package spc.webos.web.controller;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import spc.webos.constant.Common;
import spc.webos.endpoint.Endpoint;
import spc.webos.endpoint.EndpointFactory;
import spc.webos.endpoint.Executable;
import spc.webos.log.Log;
import spc.webos.util.FileUtil;
import spc.webos.util.StringX;

/**
 * webserviceת��������������¼��webservice���õ�soap����http����ͷ��Ϣ��
 * 
 * @author chenjs
 * 
 */
public class SOAPForwardCtrller implements Controller
{
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response)
			throws Exception
	{
		String queryString = request.getQueryString();
		StringBuffer httpHeaderInfo = new StringBuffer();
		java.util.Enumeration<String> keys = request.getHeaderNames();
		while (keys.hasMoreElements())
		{
			String key = keys.nextElement();
			httpHeaderInfo.append("\n" + key + "::" + request.getHeader(key));
		}
		if (log.isInfoEnabled()) log.info("WS request queryStringt: " + queryString
				+ ", http header info:" + httpHeaderInfo);

		Executable exe = new Executable();
		exe.reqHttpHeaders = new HashMap<String, String>();
		for (int i = 0; forwardHttpHeader != null && i < forwardHttpHeader.length; i++)
			exe.reqHttpHeaders.put(forwardHttpHeader[i], request.getHeader(forwardHttpHeader[i]));
		exe.request = FileUtil.is2bytes(request.getInputStream(), true);
		if (log.isInfoEnabled()) log.info("soap request info:\n"
				+ new String(exe.request, Common.CHARSET_UTF8));

		Endpoint endpoint = EndpointFactory.getInstance().getEndpoint(
				StringX.nullity(queryString) ? forwardUrl : (forwardUrl + "?" + queryString));
		endpoint.execute(exe);

		if (log.isInfoEnabled()) log.info("soap response info:\n"
				+ new String(exe.response, Common.CHARSET_UTF8));

		response.getOutputStream().write(exe.response);
		return null;
	}

	protected String forwardUrl;
	protected String[] forwardHttpHeader;
	protected Log log = Log.getLogger(getClass());

	public void setForwardUrl(String forwardUrl)
	{
		this.forwardUrl = forwardUrl;
	}

	public void setForwardHttpHeader(String[] forwardHttpHeader)
	{
		this.forwardHttpHeader = forwardHttpHeader;
	}
}
