package spc.webos.web.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;

import spc.webos.json.IJson;
import spc.webos.util.StringX;
import spc.webos.util.tree.TreeNode;
import spc.webos.web.util.WebUtil;

public class ServiceCtrller extends PageCtrller
{
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws Exception
	{
		Map params = WebUtil.request2map(request, null);
		addCommonObj(params, request);
		// 1. ִ�з���
		Object data = WebUtil.invokeService(request, null, params);
		// c. ��ȡext��ʽ��json������, ֻ��Ҫ���ظ��ĺ�����Ϣ������Ҫ���ظ�����
		if (data instanceof TreeNode) response.getWriter().print(
				StringX.treeNode2ExtJson((TreeNode) data));
		else if (data instanceof IJson) response.getWriter().print(
				((IJson) data).toJson());
		else if (data instanceof List)
		{
			String v = StringX.table2extgrid((List) data, null, null);
			response.getWriter().print(v);
		}
		else response.getWriter().print(data); // d. δ֪ģʽ��ֱ����Ϊ���ص����ַ���
		return null;
	}
}
