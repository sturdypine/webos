package spc.webos.pool;

import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Map;

import spc.webos.log.Log;

public abstract class ObjectPool
{
	public void init() throws Exception
	{
		if (name != null)
		{
			if (POOLS.containsKey(name)) log.warn("POOL(" + name + ") has been exists!!!");
			POOLS.put(name, this);
		}
		// added by chenjs. 2011-05-16, ��ֹ�����down�ˡ�
		// ��jvm�쳣������ֹͣʱ���ͷŶ����
		Runtime.getRuntime().addShutdownHook(new Thread()
		{
			public void run()
			{
				System.err.println("JVM will stop in " + getClass() + ", Pool name: " + name);
				destory();
			}
		});

		if (borrowOnInit)
		{
			for (int i = 0; i < max; i++)
			{
				if (log.isDebugEnabled()) log.debug("start to borrow object : " + i);
				pool.add(newIntance());
			}
		}
	}

	public void destory()
	{
	}

	public void destroy()
	{
		destory();
	}

	public int getAvailable()
	{
		return pool.size();
	}

	public abstract Object newIntance() throws Exception;

	public synchronized Object borrow() throws Exception
	{
		if (pool.size() == 0 && autoIncrease)
		{
			if (log.isInfoEnabled()) log.info("pool is empty, borrow a new object:"
					+ getClass().getName() + ", name:" + name + ", max:" + max);
			return newIntance();
		}
		long startTm = System.currentTimeMillis();
		while (pool.size() == 0 && waitTime != 0)
		{
			log.info("pool object wait " + waitTime);
			try
			{
				if (waitTime < 0) wait();
				else
				{
					if (System.currentTimeMillis() - startTm > waitTime) break;
					wait(waitTime);
				}
			}
			catch (InterruptedException e)
			{
			}
		}
		if (pool.size() <= 0)
		{
			String msg = "pool exhausted, name:" + name + ", waitTime:" + waitTime
					+ ",autoIncrease:" + autoIncrease + ",max:" + max;
			log.warn(msg);
			throw new Exception(msg);
		}
		Object obj = pool.removeFirst();
		return obj;
	}

	public synchronized boolean release(Object obj)
	{
		if (obj == null) return true;
		if (pool.size() >= max)
		{
			log.info("objectpool current size: " + pool.size() + ", max: " + max);
			return false; // ���������Ƶķ��룬���ܵ������Ӷ�����Դй©����Ϊ������Ҫclose
		}
		pool.add(obj);
		log.debug("success to recycle one object!!!");
		notifyAll();
		return true;
	}

	// ���ָ���ȴ�ʱ�䣬����ָ��ʱ��û����Դ�����쳣
	protected boolean borrowOnInit = true; // ����س�ʼ��ʱ�͹������ж���
	protected long waitTime;
	protected boolean autoIncrease = false;
	protected String name;
	protected int max = DEFAULT_MAX;
	protected LinkedList pool = new LinkedList();
	public static final int DEFAULT_MAX = 50;
	protected Log log = Log.getLogger(getClass());
	public final static Map POOLS = new Hashtable();

	public long getWaitTime()
	{
		return waitTime;
	}

	public void setWaitTime(long waitTime)
	{
		this.waitTime = waitTime;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getName()
	{
		return name;
	}

	public int getMax()
	{
		return max;
	}

	public void setMax(int max)
	{
		this.max = max;
	}

	public void setAutoIncrease(boolean autoIncrease)
	{
		this.autoIncrease = autoIncrease;
	}

	public boolean isBorrowOnInit()
	{
		return borrowOnInit;
	}

	public void setBorrowOnInit(boolean borrowOnInit)
	{
		this.borrowOnInit = borrowOnInit;
	}
}
