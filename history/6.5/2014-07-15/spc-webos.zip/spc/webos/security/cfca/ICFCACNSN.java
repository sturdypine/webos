package spc.webos.security.cfca;

public interface ICFCACNSN
{
	boolean validate(String accSvr, String sn, String cn);
}
