package spc.webos.queue;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import spc.webos.buffer.IBuffer;
import spc.webos.cache.ICache;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.flownode.MessageFlow;
import spc.webos.thread.ThreadPool;

public abstract class AccessTPool extends ThreadPool
{
	// ���������ȡ�߳�ʹ��
	protected ICache msgIdCache;
	protected IBuffer msgBuf;
	protected IMessageConverter converter;
	protected MessageFlow msgFlow;
	protected IAsynSenderListener asynSenderListener = DefaultAsynSenderListener.getInstance();
	protected int cnnHoldTime = -1; // ���ӱ��ֵ����ʱ�䣬 -1��ʾ���޳�

	protected IBlobMessageCreator creator;
	protected int waitInterval = -1;
	protected int rw = AccessThread.RW_READ;
	protected List bufferNames;
	protected List bufs = new ArrayList();
	protected Map buf2queueMapping; // ����buffer���Ͷ�������ͬ����Ҫӳ��
	protected Hashtable props;
	protected boolean correlation = false; // ���Ϊtrue��ʾ�Ӷ����л�õ���Ϣ����Ҫ��messageId��Ϊ������
	protected boolean expiry = false; // �Ƿ��͵���Ϣ������Ϣ��ʱ����
	public final static int DEFAULT_EXPIRY = 120; // Ĭ����Ϣ��ʱʱ��Ϊ120��
	public static final int DEFAULT_WAIT_INTERVAL = 1000; // һ���߳�Ϊһ�����з����Ĭ�ϵȴ�ʱ��Ϊ1.5��
	public static final int DEFAULT_MUL_WAIT_INTERVAL = 200; // �����߳���Ϊһ��buf����ʱ���ȴ�ʱ��Ϊ200����

	public boolean isExpiry()
	{
		return expiry;
	}

	public void setExpiry(boolean expiry)
	{
		this.expiry = expiry;
	}

	public void init() throws Exception
	{
		if (bufs.size() <= 0)
		{
			for (int i = 0; bufferNames != null && i < bufferNames.size(); i++)
			{
				String name = (String) bufferNames.get(i);
				IBuffer buf = (IBuffer) IBuffer.BUFFERS.get(name);
				if (buf == null) continue;
				bufs.add(buf);
			}
			if (bufs.size() == 0 && msgBuf == null) { throw new RuntimeException("AccessTPool("
					+ getName() + ") has no bufs or msgBuf is null!!!"); }
		}
		super.init();
	}

	public boolean isCorrelation()
	{
		return correlation;
	}

	public void setCorrelation(boolean correlation)
	{
		this.correlation = correlation;
	}

	public int getRw()
	{
		return rw;
	}

	public void setRw(int rw)
	{
		this.rw = rw;
	}

	public List getBufferNames()
	{
		return bufferNames;
	}

	public void setBufferNames(List bufferNames)
	{
		this.bufferNames = bufferNames;
	}

	public Hashtable getProps()
	{
		return props;
	}

	public Map getBuf2queueMapping()
	{
		return buf2queueMapping;
	}

	public void setBuf2queueMapping(Map buf2queueMapping)
	{
		this.buf2queueMapping = buf2queueMapping;
	}

	public void setProps(Hashtable props)
	{
		this.props = props;
	}

	public void setBufs(List bufs)
	{
		this.bufs = bufs;
	}

	public void setMsgIdCache(ICache msgIdCache)
	{
		this.msgIdCache = msgIdCache;
	}

	public void setMsgBuf(IBuffer msgBuf)
	{
		this.msgBuf = msgBuf;
	}

	public void setConverter(IMessageConverter converter)
	{
		this.converter = converter;
	}

	public IAsynSenderListener getAsynSenderListener()
	{
		return asynSenderListener;
	}

	public void setAsynSenderListener(IAsynSenderListener asynSenderListener)
	{
		this.asynSenderListener = asynSenderListener;
	}

	public IMessageConverter getConverter()
	{
		return converter;
	}

	public int getCnnHoldTime()
	{
		return cnnHoldTime;
	}

	public void setCnnHoldTime(int cnnHoldTime)
	{
		this.cnnHoldTime = cnnHoldTime;
	}

	public MessageFlow getMsgFlow()
	{
		return msgFlow;
	}

	public void setMsgFlow(MessageFlow msgFlow)
	{
		this.msgFlow = msgFlow;
	}

	public IBlobMessageCreator getCreator()
	{
		return creator;
	}

	public void setCreator(IBlobMessageCreator creator)
	{
		this.creator = creator;
	}

	public int getWaitInterval()
	{
		return waitInterval;
	}

	public void setWaitInterval(int waitInterval)
	{
		this.waitInterval = waitInterval;
	}
}
