package spc.webos.queue.ibmmq;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.Message;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.data.util.MessageUtil;
import spc.webos.queue.AbstractReceiverThread;
import spc.webos.queue.AccessTPool;
import spc.webos.queue.QueueMessage;
import spc.webos.thread.ThreadPool;
import spc.webos.util.SystemUtil;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;

public class ReceiverThread extends AbstractReceiverThread
{
	protected MQGetMessageOptions gmo = new MQGetMessageOptions();
	protected MQManager mqm;

	public ReceiverThread()
	{
		super();
	}

	public ReceiverThread(ThreadPool pool, Hashtable props, List bufs, Map buf2queueMapping)
	{
		super();
		this.pool = pool;
		this.props = props;
		this.bufs = bufs;
		this.buf2queueMapping = buf2queueMapping;
	}

	public void release()
	{
		super.release();
		mqm.disconnect();
	}

	public void init() throws Exception
	{
		super.init();
		Object ccsid = props.get(MQC.CCSID_PROPERTY);
		if (ccsid instanceof String) props.put(MQC.CCSID_PROPERTY, new Integer((String) ccsid));
		Object port = props.get(MQC.PORT_PROPERTY);
		if (port instanceof String) props.put(MQC.PORT_PROPERTY, new Integer((String) port));

		// ����timeout��ʱ�䣬��λ����
		gmo.options = MQC.MQGMO_WAIT;
		if (((MQAccessTPool) pool).getWaitInterval() > 0) gmo.waitInterval = ((MQAccessTPool) pool)
				.getWaitInterval();
		else if (bufs.size() == 1) gmo.waitInterval = MQAccessTPool.DEFAULT_WAIT_INTERVAL;
		else gmo.waitInterval = MQAccessTPool.DEFAULT_MUL_WAIT_INTERVAL;

		if (mqm == null) mqm = new MQManager(props, ((AccessTPool) pool).getCnnHoldTime());
		// modified by 2011-07-30 chenjs Ϊ�˸��õĸ��أ�������֣����ܺ��������ӵõ�����Ϣ��
		// modified by spc 2010-12-16 Ϊ��������ܣ����رն��ж���
		// modified by chenjs 2012-07-27 Ϊ���Ա��ֶԶ��е�OPEN״̬
		mqm.keepQueue = KEEP_QUEUE_OPEN;
		refresh();
	}

	public void refresh() throws Exception
	{
		super.refresh();
		mqm.reconnect(-1);
	}

	public Object receive(String qname) throws Exception
	{
		QueueMessage qmsg = receiveMQMessage(qname);
		if (qmsg == null) return null;
		IMessageConverter converter = ((MQAccessTPool) getPool()).getConverter();
		if (converter == null) return qmsg;
		// IMessage msg = converter.deserialize(qmsg.buf);
		// 2012-07-29 chenjs ��ʱ����
		IMessage msg = new Message();
		msg.setInLocal(MsgLocalKey.LOCAL_MSG_CONVERTER, converter);
		msg.setInLocal(MsgLocalKey.LOCAL_MSGCVT_DELAY, Boolean.TRUE);

		msg.setCorrelationID(qmsg.correlationId);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_QMSG, qmsg); // ���������Ϣ��ԭʼ��Ϣ
		msg.setInLocal(MsgLocalKey.ACCEPTOR_PROTOCOL, Common.ACCEPTOR_PROTOCOL_QUEUE_MQ);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, qmsg.buf);
		msg.setInLocal(MsgLocalKey.MQGET_QMSG_KEY, qmsg);
		if (((MQAccessTPool) getPool()).getMsgFlow() != null) msg.setInLocal(
				MsgLocalKey.LOCAL_MSG_MSGFLOW, ((MQAccessTPool) getPool()).getMsgFlow());
		return msg;
	}

	public QueueMessage receiveMQMessage(String qname)
	{
		MQMessage mqmsg = new MQMessage();
		QueueMessage qmsg = null;
		try
		{
			mqm.connect(-1);
			Accessor.receive(mqm, qname, gmo, mqmsg);
			// qmsg = new QueueMessage(mqmsg, qname);
			// modified by chenjs 2012-11-29 ֧��TLQ���Ƴ�QueueMessage�����MQMessage����
			qmsg = MQMessageUtil.createQMsg(mqmsg, qname);
			qmsg.qmprops = mqm.props; // 2012-07-31 ������Ϣ��Դ�Ķ��й�������Ϣ
			if (log.isDebugEnabled())
			{
				byte[] header = MessageUtil.getHeader(qmsg.buf);
				log.debug("read buf size: " + qmsg.buf.length + ", header: "
						+ (header != null ? new String(header) : "null") + "\nbuf in utf-8:"
						+ new String(qmsg.buf, Common.CHARSET_UTF8));
			}
		}
		catch (MQException mqe)
		{
			if (Accessor.handleMQException(mqe) == Accessor.MQ_TIME_OUT)
			{
				// if (log.isDebugEnabled()) log.debug("qName:" + qname +
				// " has no msg");
			}
			else
			{
				log.error("mqe.ret==-1...wait to reconnect..." + qname + ", thread will sleep:"
						+ Accessor.CNN_EXCEPTION_SLEEP + " seconds!!!", mqe);
				mqm.disconnect();
				try
				{ // ����Ϣʧ�ܿ����Ƕ��й���������ʧ�ܣ� Ҳ�����Ƕ��й�������û�ж���(���������һ��ֻ�ڿ���ʱ�ڣ�����û���ö�)
					Thread.sleep(Accessor.CNN_EXCEPTION_SLEEP * 1000);
				}
				catch (Exception e)
				{
				}
			}
			return null;
		}
		catch (Exception e)
		{
			log.error("read qName:" + qname + " mq message", e);
			return null;
		}

		try
		{
			if (((MQAccessTPool) pool).isCorrelation()) qmsg.correlationId = mqmsg.messageId; // ���ù�����
			else qmsg.correlationId = mqmsg.correlationId; // ���ù�����
			if (log.isInfoEnabled()) log
					.info("inQTm:"
							+ new SimpleDateFormat(SystemUtil.DF_SALL17).format(mqmsg.putDateTime
									.getTime()) + ",corId:\n" + new String(mqmsg.correlationId)
							+ ", t: " + getName());
			return qmsg;
		}
		catch (Exception e)
		{
			try
			{
				log.error("in utf-8:" + new String(qmsg.buf, Common.CHARSET_UTF8), e);
			}
			catch (UnsupportedEncodingException e1)
			{
				log.warn("UnsupportedEncodingException for utf-8", e1);
			}
		}
		return null;
	}
}
