package spc.webos.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
* genarated by sturdypine.chen
* Email: sturdypine@gmail.com
* description: 
*/
public class JPDLVO implements ValueObject
{
	public static final long serialVersionUID = 20100317L;
	// ����������Ӧ�ֶε�����
	String name; //  ����
	Integer ver; //  ����
	String jpdl; // 
	String jpdlVer; // 
	String exeModel; // 
	String status; // 
	String remark; // 

	// �ʹ�VO�����������VO����
	
	// �ʹ�VO�������������Sql����
	// Note: ���������Sql����ΪString, Inegter...��Java final classʱ�� ֻ��ʹ��Object���� ����ʱ��ֻ��ͨ��
	// Object��toString()������ʹ�á�
	public static final String TABLE = "esb_jpdl";
	public static final String[] BLOB_FIELD = null;
	public static final String SEQ_NAME = "version";

	
	public JPDLVO()
	{
	}
	
	public void setPrimary(String name ,Integer version)
	{
		this.name = name;
		this.ver = version;
	}
	
	public String getPrimary(String delim)
	{
		StringBuffer buf = new StringBuffer();
		buf.append(this.name);
		buf.append(delim + this.ver);
		return buf.toString();
	}
	
	public Map getPrimary()
	{
		Map m = new HashMap();
		m.put("name", name);
		m.put("version", ver);
		return m;
	}
	
	public String getTable()
	{
		return TABLE;
	}
	
	public String[] getBlobField()
	{
		return BLOB_FIELD;
	}
	
	public String getKeyName()
	{
		return SEQ_NAME;
	}
	
	public Serializable getKey()
	{
		return ver;
	}
	
	// set all properties to NULL
	public void setNULL()
	{
    	this.name = null;
    	this.ver = null;
    	this.jpdl = null;
    	this.jpdlVer = null;
    	this.exeModel = null;
    	this.status = null;
    	this.remark = null;
	}
	
	public boolean equals(Object o)
	{
		if (this == o) return true;
		if (!(o instanceof JPDLVO)) return false;
		JPDLVO obj = (JPDLVO) o;
		if (!name.equals(obj.name)) return false;
		if (!ver.equals(obj.ver)) return false;
		if (!jpdl.equals(obj.jpdl)) return false;
		if (!jpdlVer.equals(obj.jpdlVer)) return false;
		if (!exeModel.equals(obj.exeModel)) return false;
		if (!status.equals(obj.status)) return false;
		if (!remark.equals(obj.remark)) return false;
		return true;
	}
	
	// ֻ����������ɢ��
	public int hashCode()
	{
		long hashCode = getClass().hashCode();
		if (name != null) hashCode += name.hashCode();
		if (ver != null) hashCode += ver.hashCode();
		return (int)hashCode;
	}
	
	public int compareTo(Object o)
	{
		return -1;
	}

	// set all properties to default value...
	public void init()
	{
	}
	
    public String getName()
    {
        return name;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public Integer getVer()
    {
        return ver;
    }
    
    public void setVer(Integer ver)
    {
        this.ver = ver;
    }
    
    public String getJpdl()
    {
        return jpdl;
    }
    
    public void setJpdl(String jpdl)
    {
        this.jpdl = jpdl;
    }
    
    public String getJpdlVer()
    {
        return jpdlVer;
    }
    
    public void setJpdlVer(String jpdlVer)
    {
        this.jpdlVer = jpdlVer;
    }
    
    public String getExeModel()
    {
        return exeModel;
    }
    
    public void setExeModel(String exeModel)
    {
        this.exeModel = exeModel;
    }
    
    public String getStatus()
    {
        return status;
    }
    
    public void setStatus(String status)
    {
        this.status = status;
    }
    
    public String getRemark()
    {
        return remark;
    }
    
    public void setRemark(String remark)
    {
        this.remark = remark;
    }
    
	
	public void set(JPDLVO vo)
	{
    	this.name = vo.name;
    	this.ver = vo.ver;
    	this.jpdl = vo.jpdl;
    	this.jpdlVer = vo.jpdlVer;
    	this.exeModel = vo.exeModel;
    	this.status = vo.status;
    	this.remark = vo.remark;
	}
	
	public static long getSerialVersionUID()
	{
		return serialVersionUID;
	}
	
	public StringBuffer toJson()
	{
		StringBuffer buf = new StringBuffer();
		buf.append('{');
		if (name != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("name:'");
			buf.append(name);
			buf.append('\'');
		}
		if (ver != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("version:'");
			buf.append(ver);
			buf.append('\'');
		}
		if (jpdl != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("jpdl:'");
			buf.append(jpdl);
			buf.append('\'');
		}
		if (jpdlVer != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("jpdlVer:'");
			buf.append(jpdlVer);
			buf.append('\'');
		}
		if (exeModel != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("exeModel:'");
			buf.append(exeModel);
			buf.append('\'');
		}
		if (status != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("status:'");
			buf.append(status);
			buf.append('\'');
		}
		if (remark != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("remark:'");
			buf.append(remark);
			buf.append('\'');
		}
		buf.append('}');
		return buf;
	}
	
	public void afterLoad()
	{
		// TODO Auto-generated method stub

	}

	public void beforeLoad()
	{
		// TODO Auto-generated method stub

	}

	public void setManualSeq(Long seq)
	{
		
	}
	
	public void destory()
	{

	}
	
	public String toString()
	{
		StringBuffer buf = new StringBuffer(128);
		buf.append(getClass().getName() + "(serialVersionUID=" + serialVersionUID + "):");
		buf.append(toJson());
		return buf.toString();
	}
}
