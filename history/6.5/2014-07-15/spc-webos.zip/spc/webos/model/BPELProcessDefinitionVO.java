package spc.webos.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import spc.webos.jdbc.blob.ByteArrayBlob;
import spc.webos.util.JsonUtil;

/**
* genarated by sturdypine.chen
* Email: sturdypine@gmail.com
* description: 
*/
public class BPELProcessDefinitionVO implements ValueObject
{
	public static final long serialVersionUID = 20110131L;
	// ����������Ӧ�ֶε�����
	String id; //  ����
	String name; // 
	String ver; // 
	String proccessType; // 
	String publishDt; // 
	ByteArrayBlob gpd; // 
	ByteArrayBlob definition; // 
	ByteArrayBlob processImage; // 

	// �ʹ�VO�����������VO����
	
	// �ʹ�VO�������������Sql����
	// Note: ���������Sql����ΪString, Inegter...��Java final classʱ�� ֻ��ʹ��Object���� ����ʱ��ֻ��ͨ��
	// Object��toString()������ʹ�á�
	public static final String TABLE = "BPL_PROCESSDEFINITION";
	public static final String[] BLOB_FIELD = null;
	public static final String SEQ_NAME = "id";

	
	public BPELProcessDefinitionVO()
	{
	}
	
	public void setPrimary(String id)
	{
		this.id = id;
	}
	
	public String getPrimary(String delim)
	{
		StringBuffer buf = new StringBuffer();
		buf.append(this.id);
		return buf.toString();
	}
	
	public Map getPrimary()
	{
		Map m = new HashMap();
		m.put("id", id);
		return m;
	}
	
	public String getTable()
	{
		return TABLE;
	}
	
	public String[] getBlobField()
	{
		return BLOB_FIELD;
	}
	
	public String getKeyName()
	{
		return SEQ_NAME;
	}
	
	public Serializable getKey()
	{
		return id;
	}
	
	// set all properties to NULL
	public void setNULL()
	{
    	this.id = null;
    	this.name = null;
    	this.ver = null;
    	this.proccessType = null;
    	this.publishDt = null;
    	this.gpd = null;
    	this.definition = null;
    	this.processImage = null;
	}
	
	public boolean equals(Object o)
	{
		if (this == o) return true;
		if (!(o instanceof BPELProcessDefinitionVO)) return false;
		BPELProcessDefinitionVO obj = (BPELProcessDefinitionVO) o;
		if (!id.equals(obj.id)) return false;
		if (!name.equals(obj.name)) return false;
		if (!ver.equals(obj.ver)) return false;
		if (!proccessType.equals(obj.proccessType)) return false;
		if (!publishDt.equals(obj.publishDt)) return false;
		if (!gpd.equals(obj.gpd)) return false;
		if (!definition.equals(obj.definition)) return false;
		if (!processImage.equals(obj.processImage)) return false;
		return true;
	}
	
	// ֻ����������ɢ��
	public int hashCode()
	{
		long hashCode = getClass().hashCode();
		if (id != null) hashCode += id.hashCode();
		return (int)hashCode;
	}
	
	public int compareTo(Object o)
	{
		return -1;
	}

	// set all properties to default value...
	public void init()
	{
		this.proccessType = "JBPM3";
	}
	
    public String getId()
    {
        return id;
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public String getName()
    {
        return name;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getVer()
    {
        return ver;
    }
    
    public void setVer(String ver)
    {
        this.ver = ver;
    }
    
    public String getProccessType()
    {
        return proccessType;
    }
    
    public void setProccessType(String proccessType)
    {
        this.proccessType = proccessType;
    }
    
    public String getPublishDt()
    {
        return publishDt;
    }
    
    public void setPublishDt(String publishDt)
    {
        this.publishDt = publishDt;
    }
    
    public ByteArrayBlob getGpd()
    {
        return gpd;
    }
    
    public void setGpd(ByteArrayBlob gpd)
    {
        this.gpd = gpd;
    }
    
    public ByteArrayBlob getDefinition()
    {
        return definition;
    }
    
    public void setDefinition(ByteArrayBlob definition)
    {
        this.definition = definition;
    }
    
    public ByteArrayBlob getProcessImage()
    {
        return processImage;
    }
    
    public void setProcessImage(ByteArrayBlob processImage)
    {
        this.processImage = processImage;
    }
    
	
	public void set(BPELProcessDefinitionVO vo)
	{
    	this.id = vo.id;
    	this.name = vo.name;
    	this.ver = vo.ver;
    	this.proccessType = vo.proccessType;
    	this.publishDt = vo.publishDt;
    	this.gpd = vo.gpd;
    	this.definition = vo.definition;
    	this.processImage = vo.processImage;
	}
	
	public static long getSerialVersionUID()
	{
		return serialVersionUID;
	}
	
	public StringBuffer toJson()
	{
		StringBuffer buf = new StringBuffer();
		buf.append(JsonUtil.obj2json(this));
		return buf;
	}
	
	public void afterLoad()
	{
		// TODO Auto-generated method stub

	}

	public void beforeLoad()
	{
		// TODO Auto-generated method stub

	}

	public void setManualSeq(Long seq)
	{
		
	}
	
	public void destory()
	{

	}
	
	public String toString()
	{
		StringBuffer buf = new StringBuffer(128);
		buf.append(getClass().getName() + "(serialVersionUID=" + serialVersionUID + "):");
		buf.append(toJson());
		return buf.toString();
	}
}
