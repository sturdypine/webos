package spc.webos.flownode.action;

import java.util.List;
import java.util.Map;

import spc.webos.constant.Common;
import spc.webos.constant.MsgKey;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.CompositeNode;
import spc.webos.data.DefaultNode2XML;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.data.INode;
import spc.webos.data.Message;
import spc.webos.data.converter.XMLConverter;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

/**
 * �첽ִ��һ�νڵ����
 * 
 * @author spc
 * 
 */
public class CreateMsgCallAction extends TargetFNodeAction implements IAfterAsynCall
{
	private static final long serialVersionUID = 1L;

	public void execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		IMessage nsubmsg = createSubRequestMsg(msg, cxt);
		msg.setInLocal(MsgLocalKey.LOCAL_NSUB_MSG, nsubmsg); // 2012-05-12�����´������ӱ���
		before(msg, nsubmsg, cxt);
		super.execute(nsubmsg, cxt);
		after(msg, nsubmsg, cxt);
	}

	protected void before(IMessage parent, IMessage submsg, IFlowContext cxt) throws Exception
	{
	}

	protected IMessage createSubRequestMsg(IMessage parent, IFlowContext cxt) throws Exception
	{
		IMessage nsubmsg = newMessage(parent);
		if (StringX.nullity(reqMsgFtl))
		{ // ���û������reqmsgftl�� ��ֱ��ʹ��parent��request, 2012-05-12
			log.debug("reqMsgFtl is null!!!");
			nsubmsg.setRequest(parent.getRequest());
		}
		else
		{ // msg info from config and merge info..
			nsubmsg.getTransaction().apply(
					genMsg(parent, cxt, genMsgByFtl(reqMsgFtl, parent, cxt), type));
		}
		nsubmsg.setInLocal(MsgLocalKey.LOCAL_PARENT_MSG, parent);
		if (log.isDebugEnabled()) log.debug("create new submsg:" + nsubmsg.toXml(true));
		return nsubmsg;
	}

	protected IMessage newMessage(IMessage parent)
	{ // default new msg info...
		IMessage nsubmsg = new Message();
		nsubmsg.init();
		String dt = SystemUtil.getInstance().getCurrentDate(SystemUtil.DF_SALL17);
		String sn = (SystemUtil.JVM + SystemUtil.getTimeSN(8) + SystemUtil.random(7)).substring(0,
				15);
		nsubmsg.setVersion(IMessage.HEADER_VERSION_1_0);
		nsubmsg.setSndAppCd(appCd);
		nsubmsg.setSndDt(dt.substring(0, 8));
		nsubmsg.setSndTm(dt.substring(8, 17));
		nsubmsg.setSeqNb(sn);
		nsubmsg.setCallType(IMessage.CALLTYP_ASYN);
		nsubmsg.setMsgCd(StringX.nullity(msgCd) ? name : msgCd);
		if (!StringX.nullity(SystemUtil.NODE)) nsubmsg.setSndNode(SystemUtil.NODE);

		// 2012-06-12 ����������Ϣ�����ӽ���ext/bpl��
		ICompositeNode bpl = new CompositeNode();
		bpl.set(MsgKey.BPL_PMSGSN, parent.getMsgSn());
		bpl.set(MsgKey.BPL_NODE_NAME, name);
		bpl.set(MsgKey.BPL_FAIL_ABORT, failAbort);
		bpl.set(MsgKey.BPL_PSNDAPPCD, parent.getSndApp());
		bpl.set(MsgKey.BPL_PSNDMBRCD, parent.getSndNode());
		nsubmsg.setInHeaderExt(MsgKey.EXT_BPL, bpl);

		return nsubmsg;
	}

	protected ICompositeNode genMsg(IMessage parent, IFlowContext cxt, String text, String type)
			throws Exception
	{
		ICompositeNode transaction = null;
		// FTL is xml or json
		if (FTL_XML.equalsIgnoreCase(type)) transaction = XMLConverter.getInstance()
				.deserialize(text.getBytes(Common.CHARSET_UTF8)).getTransaction();
		else transaction = new CompositeNode((Map) JsonUtil.json2obj(text));
		if (log.isDebugEnabled()) log.debug("from msg ftl, type:" + type + ", transaction:"
				+ transaction.toXml("transaction", true) + ", text:" + text);
		return transaction;
	}

	public void after(IMessage parent, IMessage submsg, IFlowContext cxt) throws Exception
	{
		after(type, repMapping, repMsgFtl, apply, parent, submsg, cxt);
	}

	public void after(String type, String repMapping, String repMsgFtl, String apply,
			IMessage parent, IMessage submsg, IFlowContext cxt) throws Exception
	{
		if (!StringX.nullity(repMapping))
		{
			List mappings = (List) JsonUtil.json2obj(repMapping);
			for (int i = 0; i < mappings.size(); i++)
			{
				List mapping = (List) mappings.get(i);
				INode value = submsg.getTransaction().find(mapping.get(0).toString());
				if (value != null) parent.getTransaction().set(mapping.get(1).toString(), value);
			}
		}
		else if (!StringX.nullity(repMsgFtl))
		{
			if ("1".equals(apply)) parent.getTransaction().apply(
					genMsg(parent, cxt, genMsgByFtl(repMsgFtl, submsg, cxt), type));
			else parent.getTransaction().applyIf(
					genMsg(parent, cxt, genMsgByFtl(repMsgFtl, submsg, cxt), type));
		}
		else if (!"0".equals(apply))
		{ //
			log.info("repMsgFtl is null && apply: " + apply);
			if ("1".equals(apply))
			{
				parent.getResponse().apply(submsg.getResponse());
				parent.getRequest().apply(submsg.getResponse());
			}
			else
			{
				parent.getResponse().applyIf(submsg.getResponse());
				parent.getRequest().applyIf(submsg.getResponse());
			}
		}
	}

	public String genMsgByFtl(String ftl, IMessage msg, IFlowContext cxt) throws Exception
	{
		Map root = SystemUtil.freemarker(null, msg);
		root.put(Common.MODEL_CXT_KEY, cxt);
		try
		{
			String nmsg = StringX.trim(SystemUtil.freemarker(ftl, root));
			if (log.isDebugEnabled()) log.debug("nmsg: " + nmsg);
			return nmsg;
		}
		catch (Exception e)
		{
			log.warn("FTL:[["
					+ ftl
					+ "\nXML:"
					+ msg.getTransaction().toXml(IMessage.TAG_ROOT, true,
							DefaultNode2XML.getInstance()));
			throw e;
		}
	}

	public static final String FTL_JSON = "json";
	public static final String FTL_XML = "xml";
	protected String type = FTL_JSON; // ģ������ı�����json��ʽ
	protected String reqMsgFtl; // �����±���ģ��
	protected String repMsgFtl; // Ӧ����ģ��
	protected String failAbort = "0"; // �첽�ڵ�ʧ������ֹ����ִ��, chenjs
										// 2012-09-09���̽���Ĭ�ϲ��Զ����ƽڵ�ʧ��״̬
	protected String repMapping; // Ӧ����Ϣӳ��
	protected String apply = "1"; // 0:no, 1: apply, 2:applyIf
	protected String appCd = "JBPM3";
	protected String msgCd;

	public String getReqMsgFtl()
	{
		return reqMsgFtl;
	}

	public void setReqMsgFtl(String reqMsgFtl)
	{
		this.reqMsgFtl = StringX.trim(reqMsgFtl);
	}

	public String getRepMsgFtl()
	{
		return repMsgFtl;
	}

	public void setRepMsgFtl(String repMsgFtl)
	{
		this.repMsgFtl = StringX.trim(repMsgFtl);
	}

	public String getFailAbort()
	{
		return failAbort;
	}

	public void setFailAbort(String failAbort)
	{
		this.failAbort = StringX.trim(failAbort);
	}

	public String getJson()
	{
		return FTL_JSON.equalsIgnoreCase(type) ? Common.YES : Common.NO;
	}

	public void setJson(String json)
	{
		if (Common.YES.equals(json)) type = FTL_JSON;
	}

	public String getRepMapping()
	{
		return repMapping;
	}

	public void setRepMapping(String repMapping)
	{
		this.repMapping = repMapping;
	}

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public String getApply()
	{
		return apply;
	}

	public void setApply(String apply)
	{
		this.apply = apply;
	}

	public String getAppCd()
	{
		return appCd;
	}

	public void setAppCd(String appCd)
	{
		this.appCd = appCd;
	}

	public String getMsgCd()
	{
		return msgCd;
	}

	public void setMsgCd(String msgCd)
	{
		this.msgCd = msgCd;
	}
}
