package spc.webos.jdbc;

import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import spc.webos.jdbc.converter.XmlColumnConverter;
import spc.webos.jdbc.rowmapper.ClazzRowMapper;
import spc.webos.jdbc.rowmapper.JsonRowMapper;
import spc.webos.jdbc.rowmapper.ListRowMapper;
import spc.webos.jdbc.rowmapper.MapRowMapper;
import spc.webos.jdbc.rowmapper.XMapRowMapper;
import spc.webos.log.Log;

public class XJdbcTemplate extends JdbcTemplate
{
	String dbType = "DB2"; // ���ݿ�����SQLServer,DB2,oracle
	String dbName = "default"; // ����Դ����
	Log log = Log.getLogger(XJdbcTemplate.class);

	public void setDbName(String dbName)
	{
		this.dbName = dbName;
	}

	public void setDbType(String dbType)
	{
		this.dbType = dbType.toUpperCase();
	}
	
	public Connection createConnectionProxy(Connection con)
	{
		return super.createConnectionProxy(con);
	}
	
//	public Connection getConnection()
//	{
//		Connection con = DataSourceUtils.getConnection(getDataSource());
//		// Create close-suppressing Connection proxy, also preparing
//		// returned Statements.
//		return createConnectionProxy(con);
//		// }
//		// catch (SQLException ex)
//		// {
//		// // Release Connection early, to avoid potential connection pool
//		// // deadlock
//		// // in the case when the exception translator hasn't been initialized
//		// // yet.
//		// DataSourceUtils.releaseConnection(con, getDataSource());
//		// con = null;
//		//
//		// throw getExceptionTranslator().translate("ConnectionCallback",
//		// getSql(action), ex);
//		// }
//		// finally
//		// {
//		// DataSourceUtils.releaseConnection(con, getDataSource());
//		// }
//	}

	/**
	 * �ø�����Sql���, ���д�����, �����ؽ��
	 * 
	 * @param sql
	 * @param rowClazzName
	 * @return
	 * @throws DataAccessException
	 */
	public List query(String sql, String rowClazzName) throws DataAccessException
	{
		if (log.isDebugEnabled())
		{
			logger.debug("XJdbcTemplate.query sql = " + sql + ", rowClazzName = " + rowClazzName);
		}

		try
		{
			if (charsetSQL != null) sql = new String(sql.getBytes(charsetSQL));
		}
		catch (Exception e)
		{
			throw new RuntimeException("Error in coverting to Charset(" + charsetSQL + "), sql="
					+ sql, e);
		}
		long s = 0;
		if (log.isInfoEnabled()) s = System.currentTimeMillis();
		List result = null;
		Class rowClazz = null;
		// ������չ��Map��ʽ��������, �˷�ʽ��һ���hashmap��ʡKey�ռ�
		if ("xmap".equalsIgnoreCase(rowClazzName)) result = query(sql, new XMapRowMapper(charsetDB));
		else if ("list".equalsIgnoreCase(rowClazzName)) // ����List��ʽ��������
		result = query(sql, new ListRowMapper(charsetDB));
		else if ("map".equals(rowClazzName)) // ����һ���HashMap��������
		result = query(sql, new MapRowMapper(charsetDB));
		else if ("json".equals(rowClazzName)) // ����һ���HashMap��������
		result = query(sql, new JsonRowMapper(charsetDB));
		else if ("XML".equals(rowClazzName))
		{ // return xml
			List list = super.queryForList(sql, String.class);
			if (list == null || list.size() == 0) return list;
			for (int i = 0; i < list.size(); i++)
				list.set(i, XmlColumnConverter.getInstance().convert(null, (String) list.get(i)));
			result = list;
		}
		// ���õ��ǵ�һ����, ����Integer, String, Short....
		else if ((rowClazz = (Class) innerClazzMap.get(rowClazzName)) != null) result = super
				.queryForList(sql, rowClazz);
		else
		{ // ���õ����Զ�����д�����
			try
			{
				rowClazz = Class.forName(rowClazzName);
			}
			catch (Exception e)
			{
				throw new RuntimeException("cannot find class:" + rowClazzName);
			}
			result = query(sql, new ClazzRowMapper(rowClazz, charsetDB));
		}
		if (log.isDebugEnabled())
		{
			String msg = "JdbcTemplate.query cost:" + (System.currentTimeMillis() - s) + ", size:"
					+ (result == null ? 0 : result.size());
			log.debug(msg);
		}
		return result;
	}

	String charsetSQL; // SQL�����ַ�������
	String charsetDB; // ��������ȡ�������ַ�������
	public final static Map innerClazzMap; // ��Ƕ��

	static
	{
		innerClazzMap = new HashMap();
		innerClazzMap.put("string", String.class);
		innerClazzMap.put("float", Float.class);
		innerClazzMap.put("double", Double.class);
		innerClazzMap.put("int", Integer.class);
		innerClazzMap.put("short", Short.class);
		innerClazzMap.put("boolean", Boolean.class);
		innerClazzMap.put("byte", Byte.class);
		innerClazzMap.put("long", Long.class);
		innerClazzMap.put("number", Number.class);
		innerClazzMap.put("Date", java.sql.Date.class);
		innerClazzMap.put("date", java.util.Date.class);
		innerClazzMap.put("time", java.sql.Time.class);
		innerClazzMap.put("timestamp", java.sql.Timestamp.class);
	}

	public void setCharsetDB(String charsetDB)
	{
		this.charsetDB = charsetDB;
	}

	public void setCharsetSQL(String charsetSQL)
	{
		this.charsetSQL = charsetSQL;
	}

	public String getDbType()
	{
		return dbType;
	}
}