package spc.webos.util.scheduling;

import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import org.quartz.Scheduler;
import org.springframework.scheduling.quartz.CronTriggerBean;

import spc.webos.config.AppConfig;
import spc.webos.service.Service;
import spc.webos.util.StringX;

public class DynamicCronTriggerService extends Service implements IDynamicCronTriggerService
{
	protected Scheduler scheduler;
	protected String cronTriggerCfgKey = "CronTriggers";

	public int updateAll() throws Exception
	{
		Map cronTriggers = AppConfig.getInstance().getModule(cronTriggerCfgKey);
		if (cronTriggers == null || cronTriggers.size() == 0)
		{
			log.warn("cronTriggers is null in appconfig by " + cronTriggerCfgKey);
			return 0;
		}
		Iterator keys = cronTriggers.keySet().iterator();
		while (keys.hasNext())
		{
			String triggerId = (String) keys.next();
			String cronExp = (String) cronTriggers.get(triggerId);
			updateCronTrigger(triggerId, null, cronExp);
			if (log.isInfoEnabled()) log.info("triggerId: " + triggerId + ", cronExp: [" + cronExp
					+ "]");
		}
		return cronTriggers.size();
	}

	public String getCronExpression(String triggerId, String group) throws Exception
	{
		if (StringX.nullity(group)) group = Scheduler.DEFAULT_GROUP;
		CronTriggerBean trigger = (CronTriggerBean) scheduler.getTrigger(triggerId, group);
		return trigger.getCronExpression();
	}

	public Date updateCronTrigger(String triggerId, String group, String cronExp) throws Exception
	{
		if (StringX.nullity(group)) group = Scheduler.DEFAULT_GROUP;
		CronTriggerBean trigger = (CronTriggerBean) scheduler.getTrigger(triggerId, group);
		trigger.setCronExpression(cronExp);
//		trigger.isVolatile()
		Date nextFireTime = scheduler.rescheduleJob(triggerId, group, trigger);
//		scheduler.start();
		return nextFireTime;
	}

	public void init() throws Exception
	{
		
	}

	public void setCronTriggerCfgKey(String cronTriggerCfgKey)
	{
		this.cronTriggerCfgKey = cronTriggerCfgKey;
	}

	public void setScheduler(Scheduler scheduler)
	{
		this.scheduler = scheduler;
	}
}
