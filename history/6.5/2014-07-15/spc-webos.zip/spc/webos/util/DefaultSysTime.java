package spc.webos.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import spc.webos.config.AppConfig;

public class DefaultSysTime implements ISystemTime
{
	String current; // yyyyMMdd
	String sysdtCfgKey = "app/sysdt";

	public Date current()
	{
		Date dt = new Date();
		String strDt = (String) AppConfig.getInstance().getProperty(sysdtCfgKey, current);
		if (strDt != null)
		{
			SimpleDateFormat df = new SimpleDateFormat(SystemUtil.DF_SALL17);
			try
			{
				return df.parse(strDt + df.format(dt).substring(8));
			}
			catch (ParseException e)
			{
				e.printStackTrace();
				return null;
			}
		}
		return dt;
	}

	public void setSysdtCfgKey(String sysdtCfgKey)
	{
		this.sysdtCfgKey = sysdtCfgKey;
	}

	public void setCurrent(String current)
	{
		this.current = current;
	}
}
