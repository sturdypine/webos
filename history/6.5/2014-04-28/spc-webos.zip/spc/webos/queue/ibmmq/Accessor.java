package spc.webos.queue.ibmmq;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipInputStream;

import spc.webos.constant.AppRetCode;
import spc.webos.data.BlobMsgHeader;
import spc.webos.data.BlobMsgHeader0;
import spc.webos.data.IBlobMsgHeader;
import spc.webos.data.IMessage;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.exception.AppException;
import spc.webos.log.Log;
import spc.webos.queue.IBlobMessageCreator;
import spc.webos.queue.Queue;
import spc.webos.util.FileUtil;
import spc.webos.util.StringX;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;

public class Accessor
{
	public static final int MQ_OK = 0;
	public static final int MQ_CONNECTION_BROKER = -1;
	public static final int MQ_TIME_OUT = 1;
	public static final int MQ_UNKNOW_EXCEPTION = 2;
	public static final int CNN_EXCEPTION_SLEEP = 1; // �쳣����˯��
	public static final String QM_NAME = "qmName";
	public static int CCSID = 1208;
	static final Log log = Log.getLogger(Accessor.class);
	// static final String DEF_MULTI_FILE_NAME = "data.zip";
	public static String DEF_FILE_NAME = "data";

	static
	{
		MQException.log = null; // ��MQ���ӡ�쳣��־
	}

	/**
	 * ����һ��Blob��Ϣ�����Ѵ���Ϣ���뵽�ļ�ϵͳ��
	 * 
	 * @param qm
	 * @param qname
	 *            ������Ϣ�Ķ�����
	 * @param blob
	 *            ������Ϣ�ӿ�
	 * @param segment
	 *            true��ʾ����MQ��Ƭ���ƣ�false��ʾ����MQ�������
	 * @param timeout
	 *            �ȴ����еĳ�ʱʱ��
	 * @return
	 * @throws Exception
	 */
	// public static IMessage receive2(MQQueueManager qm, String qname,
	// IBlobMessageCreator blob,
	// boolean segment, byte[] correlationId, int timeout) throws Exception
	// {
	// IMessage msg = null;
	// BlobMsgHeader0 header = null;
	// File parent = null;
	// List targetFiles = new ArrayList();
	// OutputStream os = null;
	// int backoutCount = 0;
	// MQQueue queue = null;
	// try
	// {
	// int opnOptn = (MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQOO_FAIL_IF_QUIESCING);
	// MQMessage qmsg = null;
	// MQGetMessageOptions gmo = new MQGetMessageOptions();
	// gmo.options = (MQC.MQGMO_FAIL_IF_QUIESCING + MQC.MQGMO_SYNCPOINT
	// + MQC.MQGMO_ALL_MSGS_AVAILABLE + MQC.MQGMO_LOGICAL_ORDER);
	// if (!segment) gmo.matchOptions = MQC.MQMO_MATCH_GROUP_ID;
	// if (correlationId != null) gmo.matchOptions += MQC.MQMO_MATCH_CORREL_ID;
	// if (timeout > 0)
	// {
	// gmo.waitInterval = timeout;
	// gmo.options += MQC.MQGMO_WAIT;
	// }
	//
	// boolean isLast = false;
	// queue = qm.accessQueue(qname, opnOptn);
	// while (!isLast)
	// {
	// qmsg = new MQMessage();
	// if (correlationId != null) qmsg.correlationId = correlationId;
	// queue.get(qmsg, gmo);
	// backoutCount = qmsg.backoutCount;
	// isLast = (gmo.groupStatus == MQC.MQGS_LAST_MSG_IN_GROUP);
	//
	// // byte[] buf = parseMQRFH2(qmsg, header, os);
	// byte[] buf = new byte[qmsg.getMessageLength()];
	// qmsg.readFully(buf);
	// header = new BlobMsgHeader0(buf);
	// if (header.containBlob())
	// {
	// if (parent == null)
	// {
	// // parent = blob.create(header);
	// File target = new File(parent, BlobMsgHeader.NO.equals(header
	// .getMultiFiles()) ? "data" : "data.zip");
	// if (target.exists()) target.delete();
	// os = new FileOutputStream(target);
	// targetFiles.add(target);
	// }
	// buf2os0(buf, os);
	// }
	// }
	//
	// if (header.containBlob() &&
	// BlobMsgHeader0.YES.equals(header.getMultiFiles()))
	// { // �����ǰ������Ϣ�д����� �ҷ��������Ƕ��ļ�
	// File zipFile = new File(parent, "data.zip");
	// targetFiles = FileUtil.unzip(new ZipInputStream(new
	// FileInputStream(zipFile)),
	// parent);
	// zipFile.delete();
	// }
	// // msg = blob.create(header, targetFiles);
	//
	// qm.commit(); // �ύMQ����
	// }
	// catch (Exception e)
	// {
	// try
	// {
	// if (qm != null)
	// {
	// if (backoutCount < 5) qm.backout();
	// else log.warn("msg backoutCount over 5");
	// }
	// }
	// catch (Exception ee)
	// {
	// log.warn("fail to backout QM", ee);
	// }
	// throw e;
	// }
	// finally
	// {
	// try
	// {
	// if (queue != null) queue.close();
	// }
	// catch (Exception e)
	// {
	// log.warn("fail to close queue", e);
	// }
	// try
	// {
	// if (os != null) os.close();
	// }
	// catch (Exception e)
	// {
	// log.warn("fail to close OS", e);
	// }
	// }
	//
	// return msg;
	// }

	/**
	 * ��һ��MQ��Ϣ�����ݷŵ�һ�����������
	 * 
	 * @param buf
	 * @param os
	 * @throws Exception
	 */
	// public static BlobMsgHeader0 buf2os0(byte[] buf, OutputStream os) throws
	// Exception
	// {
	// BlobMsgHeader0 header = new BlobMsgHeader0(buf);
	// int headLen = Integer.parseInt(header.getHeadLen());
	//
	// ByteArrayInputStream bais = new ByteArrayInputStream(buf, headLen,
	// buf.length - headLen);
	// InputStream is = bais;
	// if (BlobMsgHeader.YES.equals(header.getGzip())) is = new
	// GZIPInputStream(bais);
	// FileUtil.is2os(is, os, true, false);
	// return header;
	// }

	/**
	 * ����һ��Blob��Ϣ�����Ѵ���Ϣ���뵽�ļ�ϵͳ��
	 * 
	 * @param qm
	 * @param qname
	 *            ������Ϣ�Ķ�����
	 * @param blob
	 *            ������Ϣ�ӿ�
	 * @param segment
	 *            true��ʾ����MQ��Ƭ���ƣ�false��ʾ����MQ�������
	 * @param timeout
	 *            �ȴ����еĳ�ʱʱ��
	 * @return
	 * @throws Exception
	 */
	public static IMessage receive(MQManager mqm, String qname, IBlobMessageCreator blob,
			boolean segment, byte[] correlationId, int timeout) throws Exception
	{
		if (log.isInfoEnabled()) log.info("receive blob:" + qname + ", timeout:" + timeout
				+ ", corId:"
				+ (correlationId == null ? StringX.EMPTY_STRING : new String(correlationId)));
		// seg always is false;
//		mqm.disconnect(); // ��ȡ����Ϣÿ�ζ���������
		mqm.connect(1);
		IMessage msg = null;
		BlobMsgHeader fbmh = null; // ��һƬ��Ϣ
		File parent = null;
		File target = null; // ���ļ�ģʽ�µ�ǰд���ļ�
		String targetFileNm = StringX.EMPTY_STRING;
		List targetFiles = new ArrayList();
		OutputStream os = null;
		int backoutCount = 0;
		MQQueue queue = null;
		try
		{
			// int opnOptn = segment ? (MQC.MQOO_INPUT_SHARED |
			// MQC.MQOO_FAIL_IF_QUIESCING)
			// : (MQC.MQOO_INPUT_SHARED | MQC.MQOO_FAIL_IF_QUIESCING);
			int opnOptn = (MQC.MQOO_INPUT_SHARED | MQC.MQOO_FAIL_IF_QUIESCING);
			// : (MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQOO_FAIL_IF_QUIESCING);
			MQGetMessageOptions gmo = new MQGetMessageOptions();
			// gmo.options = segment ? (MQC.MQGMO_LOGICAL_ORDER |
			// MQC.MQGMO_SYNCPOINT | MQC.MQGMO_ALL_SEGMENTS_AVAILABLE)
			// : (MQC.MQGMO_LOGICAL_ORDER | MQC.MQGMO_SYNCPOINT |
			// MQC.MQGMO_ALL_MSGS_AVAILABLE);
			gmo.options = (MQC.MQGMO_LOGICAL_ORDER | MQC.MQGMO_SYNCPOINT | MQC.MQGMO_ALL_MSGS_AVAILABLE);
			// if (!segment) gmo.matchOptions = MQC.MQMO_MATCH_GROUP_ID;
			// if (correlationId != null) gmo.matchOptions =
			// MQC.MQMO_MATCH_CORREL_ID
			// | MQC.MQMO_MATCH_GROUP_ID;
			// 655_20140425 ֻƥ�����
			if (correlationId != null) gmo.matchOptions = MQC.MQMO_MATCH_GROUP_ID;
			if (timeout <= 0) timeout = 2;
			// chenjs 2011-06-01����MQ����1000���ܣ���timeout��Ϊ��,
			// 2012-04-27ȡ������1000������ͨMQ��ȡ�̳߳����ñ���һ��
			gmo.waitInterval = timeout * 1000;
			gmo.options += MQC.MQGMO_WAIT;

			boolean isLast = false;
			// mqm.keepQueue = false; // 2012-04-17 �������ò��ܱ���queue��ģʽ
			queue = mqm.accessQueue(qname, opnOptn);
			while (!isLast)
			{
				MQMessage qmsg = new MQMessage();
				if (correlationId != null) qmsg.groupId = correlationId;
				log.info("read:" + qname);
				queue.get(qmsg, gmo);
				backoutCount = qmsg.backoutCount;
				// if (segment) isLast = (qmsg.messageFlags == MQC.MQMF_SEGMENT
				// + MQC.MQMF_LAST_SEGMENT);
				// else
				isLast = (qmsg.messageFlags == MQC.MQMF_MSG_IN_GROUP + MQC.MQMF_LAST_MSG_IN_GROUP);
				// 2012-04-27 ����Ϣ��β��־����
				// isLast = (gmo.groupStatus == MQC.MQGS_LAST_MSG_IN_GROUP);
				gmo.options = (MQC.MQGMO_LOGICAL_ORDER | MQC.MQGMO_SYNCPOINT | MQC.MQGMO_ALL_MSGS_AVAILABLE);
				gmo.waitInterval = 0;

				byte[] buf = new byte[qmsg.getMessageLength()];
				qmsg.readFully(buf);
				if (log.isInfoEnabled()) log
						.info("MQ:("
								+ qname
								+ "), size: "
								+ buf.length
								+ ", group:"
								+ new String(qmsg.groupId)
								+ ","
								+ (correlationId == null ? StringX.EMPTY_STRING : new String(
										correlationId)) + ", mqSN:" + qmsg.messageSequenceNumber
								+ ", last:" + isLast);
				if (log.isDebugEnabled()) log.debug("fixhdr: len:" + buf.length + ", [["
						+ new String(buf, 0, BlobMsgHeader.FIXLEN) + "]]");
				BlobMsgHeader bmh = new BlobMsgHeader(buf);
				if (fbmh == null)
				{
					fbmh = bmh;
					msg = fbmh.toMessage();
				}

				if (bmh.containBlob())
				{
					if (parent == null)
					{
						parent = blob.create(bmh, msg);// ������Ŀ¼
						if (log.isInfoEnabled()) log
								.info("parent dir: " + parent.getAbsolutePath());
					}
					if (!parent.exists()) parent.mkdirs();
					String fileNm = bmh.getFileId().trim();
					if (StringX.nullity(fileNm)) fileNm = DEF_FILE_NAME + '.' + bmh.getFileNo();
					if (!targetFileNm.equalsIgnoreCase(fileNm))
					{ // ��ǰ�����ļ������ǵڶ����ļ������ǵ�һ���ļ���֮��Ҫ����һ���µ�target file
						if (os != null) os.close(); // ����ϴ��Ѿ�����һ���ļ���ر�
						target = new File(parent, fileNm);
						if (target.exists()) target.delete();
						os = new FileOutputStream(target);
						targetFiles.add(target);
					}
					targetFileNm = fileNm;
					blobbuf2os(buf, os);
					log.info("slice over...");
				}
			}
			mqm.commit(); // �ύMQ����
			msg = blob.create(fbmh, targetFiles);
		}
		catch (Exception e)
		{
			// ����쳣�Ƕ��й������ϵ�, ��ϵ�����
			try
			{
				if (!(e instanceof MQException) || ((MQException) e).reasonCode != 2033)
				{ // ����û����Ϣ2033�쳣
					if (backoutCount < 2)
					{
						log.debug("backoutCount:" + backoutCount, e);
						mqm.backout();
					}
					else log.warn("msg backoutCount over 2!!!", e);
				}
			}
			catch (Exception ee)
			{
				log.warn("fail to backout QM", ee);
			}
			if ((e instanceof MQException)
					&& MQ_CONNECTION_BROKER == handleMQException((MQException) e)) mqm.disconnect();
			throw e;
		}
		finally
		{
			mqm.closeQueue();
//			mqm.disconnect(); // ����Ϣ��ȡ���ر�����
			try
			{
				if (os != null) os.close(); // �ر����һ�����ļ�
			}
			catch (Exception e)
			{
				log.warn("fail to close OS", e);
			}
		}

		return msg;
	}

	/**
	 * ��һ��MQ��Ϣ�����ݷŵ�һ�����������
	 * 
	 * @param buf
	 * @param os
	 * @throws Exception
	 */
	public static BlobMsgHeader blobbuf2os(byte[] buf, OutputStream os) throws Exception
	{
		BlobMsgHeader bhdr = new BlobMsgHeader(buf);
		int headLen = bhdr.getHeadLen();
		if (log.isInfoEnabled()) log
				.info("blob slice: hlen: " + headLen + ", total: " + buf.length);
		os.write(buf, headLen, buf.length - headLen);

		// ByteArrayInputStream bais = new ByteArrayInputStream(buf, headLen,
		// buf.length - headLen);
		// InputStream is = bais;
		// // modified by chenjs 2011-06-04 �ڲ�������gzip�ֶ�
		// // if (BlobMsgHeader.YES.equals(bhdr.getGzip())) is = new
		// // GZIPInputStream(bais);
		// FileUtil.is2os(is, os, true, false);
		return bhdr;
	}

	public static void send(MQManager mqm, String qname, InputStream is, IMessage msg,
			IMessageConverter messageConverter, int sliceSize) throws Exception
	{
		BlobMsgHeader bhdr = new BlobMsgHeader();
		bhdr.setMessage(msg, messageConverter);
		String sn = msg.isRequestMsg() ? msg.getMsgSn() : msg.getRefMsgSn();
		sn = sn.substring(sn.length() - 24);
		send(mqm, qname, is, bhdr, false, sliceSize, sn.getBytes());
	}

	/**
	 * ����MQ���ʹ�ĸ�����Ϣ��Ӧ�ó�����Ϣ���з�Ƭ����
	 * 
	 * @param qname
	 *            ���͵Ķ�����
	 * @param is
	 *            ������
	 * @param len
	 *            ���͵��ܳ���
	 * @param sliceBuf
	 *            ÿƬ��С һ��Ϊ1M
	 * @param header
	 *            mq��Ϣ����
	 * @throws Exception
	 */
	public static void send(MQManager mqm, String qname, InputStream is, IBlobMsgHeader header,
			boolean segment, int sliceSize, byte[] correlationId) throws Exception
	{
		log.warn("not recommended call!!!");
		mqm.connect(1);
		// MQQueueManager qm = mqm.qm;
		ByteArrayOutputStream baos = new ByteArrayOutputStream(); // һ��mq����Ƭ��
		OutputStream os = baos;
		byte[] buf = new byte[1024]; // ÿ�δ��������ж�ȡ��buf��С
		int opnOptn = segment ? (MQC.MQOO_OUTPUT | MQC.MQOO_FAIL_IF_QUIESCING)
				: (MQC.MQOO_OUTPUT | MQC.MQOO_FAIL_IF_QUIESCING);
		// 2011-07-05 ȡ�����Ż�, ������2085����
		// opnOptn += MQC.MQBND_BIND_NOT_FIXED; // added by chenjs 2011-07-01.
		// ��Լ�Ⱥ�����Ż�
		MQQueue queue = null;
		try
		{
			MQPutMessageOptions pmo = new MQPutMessageOptions();
			if (segment) pmo.options = MQC.MQPMO_LOGICAL_ORDER + MQC.MQPMO_SYNCPOINT; // ����MQ���߼���Ƭ
			else pmo.options = MQC.MQPMO_LOGICAL_ORDER | MQC.MQPMRF_GROUP_ID;
			// | MQC.MQPMO_SYNCPOINT |

			queue = mqm.accessQueue(qname, opnOptn);

			int sliceNo = 0;
			if (header.containXML())
			{ // ����xml, �ڵ�һƬʱ����xml, �����Ƭ��Ϣֻ������
				byte[] hdrWithXML = header.toMsg(true);
				sendSlice(mqm, queue, pmo, hdrWithXML, sliceNo, is == null || is.available() <= 0,
						correlationId, segment);
				if (log.isInfoEnabled()) log.info("succ to snd hdrWithXML: " + hdrWithXML.length);
				sliceNo++;
			}
			byte[] blobHdrWithoutXML = header.toMsg(false);
			while (is != null && is.available() > 0)
			{
				int size = is.read(buf); // ��ȡ�����С
				if (baos.size() == 0)
				{ // ÿ�η���MQ��Ϣ, д��ͷ
					baos.write(blobHdrWithoutXML);
					baos.flush();
					// modified by chenjs 2011-06-04 �ڲ�������gzip�ֶ�
					// if (BlobMsgHeader.YES.equals(header.getGzip())) os = new
					// GZIPOutputStream(baos); // ��Ҫѹ������
					// else
					os = baos;
				}
				os.write(buf, 0, size);
				os.flush();
				if (is.available() > 0 && baos.size() < sliceSize) continue; // ����������һƬ��Ϣ���ߴ����͵Ļ��滹û�ﵽ��ֵ�����
				os.close(); // ����close, ����Gzip�޷�������ʽ��β��
				// System.out.println("available: " + is.available() + ", size:"
				// + baos.size());
				sendSlice(mqm, queue, pmo, baos.toByteArray(), sliceNo, is.available() <= 0,
						correlationId, segment);
				baos.reset();
				sliceNo++;
			}
			mqm.commit();
		}
		catch (Exception e)
		{
			try
			{
				mqm.backout();
			}
			catch (Exception ee)
			{
				log.warn("fail to backout QM", ee);
			}
			if ((e instanceof MQException)
					&& MQ_CONNECTION_BROKER == handleMQException((MQException) e)) mqm.disconnect();
			throw e;
		}
		finally
		{
			mqm.closeQueue();
			try
			{
				is.close();
			}
			catch (Exception e)
			{
				log.warn("fail to close IS", e);
			}
		}
	}

	public static void send(MQManager mqm, String qname, File[] files, boolean[] gzip,
			IMessage msg, IMessageConverter messageConverter, int sliceSize) throws Exception
	{
		BlobMsgHeader bhdr = new BlobMsgHeader();
		bhdr.setMessage(msg, messageConverter);
		String sn = msg.isRequestMsg() ? msg.getMsgSn() : msg.getRefMsgSn();
		sn = sn.substring(sn.length() - 24);
		send(mqm, qname, files, gzip, bhdr, false, sliceSize, sn.getBytes());
	}

	// ���Ͷ��ļ�
	public static void send(MQManager mqm, String qname, File[] files, boolean[] gzip,
			IBlobMsgHeader header, boolean segment, int sliceSize, byte[] correlationId)
			throws Exception
	{
		mqm.connect(1);
		MQQueueManager qm = mqm.qm;
		int opnOptn = segment ? (MQC.MQOO_OUTPUT | MQC.MQOO_FAIL_IF_QUIESCING)
				: (MQC.MQOO_OUTPUT | MQC.MQOO_FAIL_IF_QUIESCING);
		// 2011-07-05 ȡ�����Ż�, ������2085����
		// opnOptn += MQC.MQBND_BIND_NOT_FIXED; // added by chenjs 2011-07-01.
		// // ��Լ�Ⱥ�����Ż�
		MQQueue queue = null;
		try
		{
			MQPutMessageOptions pmo = new MQPutMessageOptions();
			if (segment) pmo.options = MQC.MQPMO_LOGICAL_ORDER + MQC.MQPMO_SYNCPOINT; // ����MQ���߼���Ƭ
			else pmo.options = MQC.MQPMO_LOGICAL_ORDER | MQC.MQPMRF_GROUP_ID;
			// | MQC.MQPMO_SYNCPOINT |

			queue = qm.accessQueue(qname, opnOptn);
			int sliceNo = 0;
			if (header.containXML())
			{ // ����xml, �ڵ�һƬʱ����xml, �����Ƭ��Ϣֻ������
				byte[] hdrWithXML = header.toMsg(true);
				sendSlice(mqm, queue, pmo, hdrWithXML, sliceNo, files == null, correlationId,
						segment);
				if (log.isInfoEnabled()) log.info("succ to snd hdrWithXML: " + hdrWithXML.length);
				sliceNo++;
			}
			if (files != null && files.length > 0)
			{
				byte[] blobHdrWithoutXML = header.toMsg(false);
				// �����ļ�
				for (int i = 0; i < files.length; i++)
				{
					if (log.isInfoEnabled()) log.info("start to snd file: "
							+ files[i].getAbsolutePath());
					sliceNo += sendFile(mqm, queue, pmo, new FileInputStream(files[i]),
							gzip == null ? false : gzip[i], i, sliceNo, sliceSize,
							blobHdrWithoutXML, files[i].getName(), i == files.length - 1,
							correlationId, segment);
				}
			}
			else if (log.isInfoEnabled()) log.info("no files send!!!");
			qm.commit();
		}
		catch (Exception e)
		{
			try
			{
				if (qm != null) qm.backout();
			}
			catch (Exception ee)
			{
				log.warn("fail to backout QM", ee);
			}
			if ((e instanceof MQException)
					&& MQ_CONNECTION_BROKER == handleMQException((MQException) e)) mqm.disconnect();
			throw e;
		}
		finally
		{
			mqm.closeQueue();
		}
	}

	// ����һ���ļ�������������ļ���Ƭ��
	static int sendFile(MQManager mqm, MQQueue queue, MQPutMessageOptions pmo, InputStream is,
			boolean gzip, int fileNo, int startSliceNo, int sliceSize, byte[] blobHdrWithoutXML,
			String fileId, boolean lastFile, byte[] correlationId, boolean segment)
			throws IOException, MQException
	{
		BlobMsgHeader h = new BlobMsgHeader(blobHdrWithoutXML);
		h.setFileId(fileId); // ���õ�ǰ�ļ�ID
		h.setFileNo(fileNo);
		h.setGzip(gzip ? BlobMsgHeader.YES : BlobMsgHeader.NO);
		int sliceNo = 0;
		ByteArrayOutputStream baos = new ByteArrayOutputStream(); // һ��mq����Ƭ��
		byte[] buf = new byte[1024]; // ÿ�δ��������ж�ȡ��buf��С
		try
		{
			while (is != null && is.available() > 0)
			{
				int size = is.read(buf); // ��ȡ�����С
				if (baos.size() == 0)
				{ // ÿ�η���MQ��Ϣ, д��ͷ
					baos.write(blobHdrWithoutXML);
					baos.flush();
				}
				baos.write(buf, 0, size);
				baos.flush();
				if (is.available() > 0 && baos.size() < sliceSize) continue; // ����������һƬ��Ϣ���ߴ����͵Ļ��滹û�ﵽ��ֵ�����
				baos.close();
				sendSlice(mqm, queue, pmo, baos.toByteArray(), startSliceNo + sliceNo, lastFile
						&& is.available() <= 0, correlationId, segment);
				baos.reset();
				sliceNo++;
			}
		}
		finally
		{
			if (is != null) is.close();
		}
		return sliceNo;
	}

	// ����һƬ��Ϣ
	static void sendSlice(MQManager mqm, MQQueue queue, MQPutMessageOptions pmo, byte[] content,
			int sliceNo, boolean last, byte[] correlationId, boolean segment) throws IOException,
			MQException
	{
		if (log.isDebugEnabled()) log.debug("sendSlice.. sliceNo:" + sliceNo + ", last:" + last
				+ ",content:" + (content == null ? 0 : content.length));
		MQMessage qmsg = new MQMessage();
		// added by chenjs 2011-06-11 ����Ĭ���ַ���
		if (qmsg.characterSet == 0)
		{
			Integer ccsid = ((Integer) mqm.props.get(MQC.CCSID_PROPERTY));
			if (ccsid == null) ccsid = CCSID;
			qmsg.characterSet = ccsid;
		}
		if (correlationId != null) qmsg.correlationId = correlationId;

		// added by chenjs 2011-07-07 Ϊ������Ϣ���ӳ�ʱʱ��1Сʱ��mq expiry��λΪ100ms
		if (qmsg.expiry <= 0) qmsg.expiry = 36000;

		// �ж��Ƿ����һ����Ϣ
		if (segment) qmsg.messageFlags = (last ? MQC.MQMF_LAST_SEGMENT : MQC.MQMF_SEGMENT);
		else qmsg.messageFlags = (last ? MQC.MQMF_LAST_MSG_IN_GROUP : MQC.MQMF_MSG_IN_GROUP);
		BlobMsgHeader h = new BlobMsgHeader(content);
		h.setSliceNo(sliceNo);
		h.setLast(last ? BlobMsgHeader.YES : BlobMsgHeader.NO); // �Ƿ����һ����Ϣ
		qmsg.write(content);
		queue.put(qmsg, pmo);
		if (log.isInfoEnabled()) log.info("sliceNo:" + sliceNo + ", len:" + content.length);
	}

	/**
	 * ����MQ���ʹ�ĸ�����Ϣ��Ӧ�ó�����Ϣ���з�Ƭ���� �˷���Ϊ�˼���ũ������Ʊ�����ĸ������ͳ��� added by chenjs
	 * 2012-06-10
	 * 
	 * @param qname
	 *            ���͵Ķ�����
	 * @param is
	 *            ������
	 * @param len
	 *            ���͵��ܳ���
	 * @param sliceBuf
	 *            ÿƬ��С һ��Ϊ1M
	 * @param header
	 *            mq��Ϣ����
	 * @throws Exception
	 */
	public static void send0(MQManager mqm, String qname, InputStream is, BlobMsgHeader0 header,
			int sliceSize, byte[] correlationId) throws Exception
	{
		log.info("send blob msg by NCC-1 mode, qname:" + qname + ", qm: " + mqm.props);
		mqm.connect(1);
		MQQueueManager qm = mqm.qm;
		byte[] blobHdr = header.toMsg();
		ByteArrayOutputStream baos = new ByteArrayOutputStream(); // һ��mq����Ƭ��
		OutputStream os = baos;
		byte[] buf = new byte[1024]; // ÿ�δ��������ж�ȡ��buf��С
		int opnOptn = (MQC.MQOO_OUTPUT | MQC.MQOO_FAIL_IF_QUIESCING);
		MQQueue queue = null;
		try
		{
			MQPutMessageOptions pmo = new MQPutMessageOptions();
			pmo.options = MQC.MQPMO_LOGICAL_ORDER | MQC.MQPMRF_GROUP_ID; // +
			// MQC.MQPMRF_GROUP_ID;

			queue = qm.accessQueue(qname, opnOptn);

			int sliceNo = 0;
			while (is.available() > 0)
			{
				int size = is.read(buf); // ��ȡ�����С
				if (baos.size() == 0)
				{ // ÿ�η���MQ��Ϣ, д��ͷ
					baos.write(blobHdr);
					baos.flush();
					if (BlobMsgHeader0.YES.equals(header.getGzip())) os = new GZIPOutputStream(baos); // ��Ҫѹ������
					else os = baos;
				}
				os.write(buf, 0, size);
				os.flush();
				if (is.available() > 0 && baos.size() < sliceSize) continue; // ����������һƬ��Ϣ���ߴ����͵Ļ��滹û�ﵽ��ֵ�����
				os.close(); // ����close, ����Gzip�޷�������ʽ��β��
				// System.out.println("available: " + is.available() + ", size:"
				// + baos.size());
				MQMessage qmsg = new MQMessage();
				if (correlationId != null) qmsg.correlationId = correlationId;
				// �ж��Ƿ����һ����Ϣ
				qmsg.messageFlags = (is.available() > 0 ? MQC.MQMF_MSG_IN_GROUP
						: MQC.MQMF_LAST_MSG_IN_GROUP);

				byte[] content = baos.toByteArray();
				BlobMsgHeader0 h = new BlobMsgHeader0(content);
				h.setSliceNo(sliceNo);
				if (is.available() <= 0) h.setIsLast(BlobMsgHeader0.YES); // �Ƿ����һ����Ϣ
				else h.setIsLast(BlobMsgHeader0.NO);
				// buf2os(content, fos); // for test
				baos.reset(); // ����ÿƬ���͵Ļ���
				qmsg.write(content);
				queue.put(qmsg, pmo);
				if (log.isInfoEnabled()) log.info("sliceNo:" + sliceNo + ", len:" + content.length);
				sliceNo++;
			}
			qm.commit();
		}
		catch (Exception e)
		{
			try
			{
				if (qm != null) qm.backout();
			}
			catch (Exception ee)
			{
				log.warn("fail to backout QM", ee);
			}
			throw e;
		}
		finally
		{
			mqm.closeQueue();
			try
			{
				is.close();
			}
			catch (Exception e)
			{
				log.warn("fail to close IS", e);
			}
		}
	}

	// 2012-05-16 ͨ����ͨ����ĳ�����л�ȡ��Ϣ������ͨ��QM_GW_IN, QM_GW_OUT��ȡrep.nbs��Ϣ
	public static void receive(List<MQCnnPool> cnnpools, String qname, MQGetMessageOptions gmo,
			MQMessage qmsg) throws Exception
	{
		for (int i = 0; i < cnnpools.size(); i++)
		{
			MQCnnPool cnnpool = cnnpools.get(i);
			try
			{
				receive(cnnpool, qname, gmo, qmsg);
				return; // ����ɹ�ȡ����Ϣ�򷵻�
			}
			catch (Exception e)
			{
				// ���MQ�쳣��2033û����Ϣ�򷵻�
				if ((e instanceof MQException) && (((MQException) e).reasonCode == 2033)) throw e;
				log.warn("cnnpool:" + cnnpool.getProps(), e);
				if (i == cnnpools.size() - 1) throw e; // �������û��ͨ���ˣ���ֱ���쳣����
			}
		}
		throw new Exception("fail to read msg from Multi channel, qname: " + qname);
	}

	public static void receive(MQManager mqm, String qname, MQGetMessageOptions gmo, MQMessage qmsg)
			throws MQException
	{
		long start = System.currentTimeMillis();
		int failTimes = 0;
		while (failTimes < 2)
		{ // ����Ƿ�2033����Ϣ�쳣�� ��Ĭ�Ͽ��Զ�ȡ���Σ��������½�������
			try
			{
				if (log.isDebugEnabled()) log.debug("start to read MQ(" + qname + ")" + mqm.props
						+ "(keepQueue:" + mqm.keepQueue);
				mqm.connect(1);
				// 2012-06-18 ����MQC.MQOO_FAIL_IF_QUIESCING, ����MQ serverֹͣ
				MQQueue queue = mqm.accessQueue(qname, MQC.MQOO_INPUT_AS_Q_DEF
						| MQC.MQOO_FAIL_IF_QUIESCING);
				queue.get(qmsg, gmo);
				long end = System.currentTimeMillis();
				long cost = end - qmsg.putDateTime.getTimeInMillis();
				if (log.isInfoEnabled()) log.info("read MQ(" + qname + ")" + mqm.props
						+ "(keepQueue:" + mqm.keepQueue + "), cost:" + (end - start) + ", in mq:"
						+ cost + ", size: " + qmsg.getMessageLength()); // �����Ϣ��MQ�����д���ʱ�䳬��200ms�򾯸���־
				return;
			}
			catch (MQException mqex)
			{
				failTimes++;
				if (mqex.reasonCode != 2033) log.warn("receive qn: " + qname, mqex);
				if (Accessor.handleMQException(mqex) == Accessor.MQ_CONNECTION_BROKER)
				{
					log.error("mqe.ret==-1...wait to reconnect...", mqex);
					mqm.reconnect(1);
					// modified by spc 2011-03-16 ���������Ϣ����ΪMQ�����쳣������һ��
					continue;
				}
				throw mqex;
			}
			catch (Exception ex)
			{
				throw new RuntimeException(ex);
			}
			finally
			{
				mqm.closeQueue();
			}
		}
	}

	public static void receive(MQCnnPool cnnpool, String qname, MQGetMessageOptions gmo,
			MQMessage qmsg) throws Exception
	{
		if (log.isDebugEnabled()) log.debug("cnn: " + cnnpool.getProps());
		MQManager mqm = (MQManager) cnnpool.borrow();
		try
		{
			receive(mqm, qname, gmo, qmsg);
		}
		finally
		{
			cnnpool.release(mqm);
		}
	}

	public static void sendCluster(List<MQCnnPool> cnnpools, String qname, MQPutMessageOptions pmo,
			MQMessage mqmsg, int retryTimes, int retryInterval) throws Exception
	{
		sendCluster(false, cnnpools, qname, pmo, mqmsg, retryTimes, retryInterval);
	}

	// added 2012-05-12 ʹ�ö�ͨѸ��·���ͣ�
	// ��ʾֻҪ��һ��ͨ�����ͳɹ���OK��
	public static void sendCluster(boolean randomStart, List<MQCnnPool> cnnpools, String qname,
			MQPutMessageOptions pmo, MQMessage mqmsg, int retryTimes, int retryInterval)
			throws Exception
	{
		Exception ee = null;
		// �������Ϊ��㣬ѭ��һ�鷢��
		int index = (randomStart ? ((int) (Math.random() * 1000) % cnnpools.size()) : 0);
		if (log.isDebugEnabled()) log.debug("start: " + index);
		for (int i = 0; i < cnnpools.size(); i++)
		{
			if (index >= cnnpools.size()) index = 0;
			MQCnnPool cnnpool = cnnpools.get(index++);
			try
			{
				Accessor.send(cnnpool, qname, pmo, mqmsg, retryTimes, retryInterval);
				return;
			}
			catch (Exception e)
			{
				ee = e;
				log.warn("fail to put:" + cnnpool.getProps() + ", qname:" + qname + ", keepQueue:"
						+ cnnpool.isKeepQueue(), e);
			}
		}
		throw ee;
	}

	// all=true��ʾÿ��ͨ��������һ�Σ���һ�����ͳɹ�����ɹ�
	public static void sendAll(List<MQCnnPool> cnnpools, String qname, MQPutMessageOptions pmo,
			MQMessage mqmsg, int retryTimes, int retryInterval) throws Exception
	{
		// �������Ϊ��㣬ѭ��һ�鷢��
		int index = ((int) (Math.random() * 1000000) % cnnpools.size());
		boolean fail = true;
		for (int i = 0; i < cnnpools.size(); i++)
		{
			if (index >= cnnpools.size()) index = 0;
			MQCnnPool cnnpool = cnnpools.get(index++);
			try
			{
				Accessor.send(cnnpool, qname, pmo, mqmsg, retryTimes, retryInterval);
				fail = false;
			}
			catch (Exception e)
			{
				log.warn("fail to put:" + cnnpool.getProps() + ", qname:" + qname, e);
			}
		}
		if (fail) throw new Exception("Fail to sendAll ClusterMQPut: qname:" + qname);
	}

	public static void send(MQCnnPool cnnpool, String qname, MQPutMessageOptions pmo,
			MQMessage mqmsg, int retryTimes, int retryInterval) throws Exception
	{
		MQManager mqm = (MQManager) cnnpool.borrow();
		try
		{
			Accessor.send(mqm, qname, pmo, mqmsg, retryTimes, retryInterval);
		}
		finally
		{
			cnnpool.release(mqm);
		}
	}

	public static void send(MQManager mqm, String qname, MQPutMessageOptions pmo, MQMessage mqMsg,
			int retryTimes, int retryInterval) throws MQException
	{
		// if (retryInterval <= 0) retryInterval = 10;
		// �������MQ�����У�pmo����������MQPMO_SET_IDENTITY_CONTEXT( for
		// applicationIdData )
		int opt = MQC.MQOO_OUTPUT;
		if ((pmo.options & MQC.MQPMO_SET_IDENTITY_CONTEXT) > 0) opt = MQC.MQOO_OUTPUT
				+ MQC.MQOO_SET_IDENTITY_CONTEXT;
		else if ((pmo.options & MQC.MQPMO_SET_ALL_CONTEXT) > 0) opt = MQC.MQOO_OUTPUT
				+ MQC.MQPMO_SET_ALL_CONTEXT;
		// added by chenjs 2011-06-11 ����Ĭ���ַ���
		Integer ccsid = ((Integer) mqm.props.get(MQC.CCSID_PROPERTY));
		if (ccsid == null) ccsid = CCSID;
		long start = System.currentTimeMillis(), failTimes = 0;
		while (true)
		{
			try
			{
				mqm.connect(1);

				// 2011-07-05 ȡ�����Ż�, ������2085����
				// added by chenjs 2011-07-01. ��Լ�Ⱥ�����Ż�
				// opt += MQC.MQBND_BIND_NOT_FIXED;
				MQQueue queue = mqm.accessQueue(qname, opt);
				// added by chenjs 2011-06-11 ����Ĭ���ַ���
				if (mqMsg.characterSet == 0) mqMsg.characterSet = ccsid.intValue();
				queue.put(mqMsg, pmo);
				if (log.isInfoEnabled()) log.info("put MQ(" + qname + ")" + mqm.props
						+ "(keepQueue:" + mqm.keepQueue + "), cost:"
						+ (System.currentTimeMillis() - start) + ", len:"
						+ mqMsg.getTotalMessageLength() + ", retry(" + retryTimes + ","
						+ retryInterval + "," + failTimes + ")");
				return; // ��������
			}
			catch (MQException mqex)
			{
				failTimes++;
				int ret = Accessor.handleMQException(mqex);
				log.warn("err to snd MQ: " + qname + ", reason: " + mqex.reasonCode + ", qm: "
						+ mqm.props + ", retryTms:" + retryTimes + ", failTms:" + failTimes
						+ ", ret: " + ret);
				// added by spc 2010-12-15 �����Ӳ�����ʱ���ͷ�����
				if (ret == Accessor.MQ_CONNECTION_BROKER)
				{
					log.error("mqe.ret==-1...wait to reconnect...");
					mqm.disconnect();
				}
				if (failTimes > retryTimes) throw mqex;
				try
				{
					if (retryInterval > 0) Thread.sleep(retryInterval);
				}
				catch (Exception ee)
				{
				}
			}
			finally
			{
				mqm.closeQueue();
			}
		}
	}

	public static boolean clearAll(MQCnnPool cnnpool, String qname, int maxDepth) throws Exception
	{
		MQManager mqm = (MQManager) cnnpool.borrow();
		MQQueue queue = null;
		try
		{
			mqm.connect(1);
			MQMessage qmsg = new MQMessage();
			MQGetMessageOptions gmo = new MQGetMessageOptions();
			gmo.matchOptions = MQC.MQMO_NONE;
			gmo.options = MQC.MQGMO_NO_WAIT;
			queue = mqm.accessQueue(qname, MQC.MQOO_INPUT_AS_Q_DEF);
			for (int i = 1; i < maxDepth; i++)
			{
				try
				{
					qmsg.clearMessage();
				}
				catch (IOException e)
				{
					qmsg = new MQMessage();
				}
				queue.get(qmsg, gmo);
			}
		}
		catch (MQException mqe)
		{
			if (Accessor.handleMQException(mqe) == Accessor.MQ_CONNECTION_BROKER) mqm.disconnect();
			if (mqe.reasonCode == 2033) return true; // û����Ϣ��
		}
		finally
		{
			cnnpool.release(mqm);
			mqm.closeQueue();
		}
		return false;
	}

	public static int browseAll(MQCnnPool cnnpool, String qname, int maxDepth) throws Exception
	{
		int msgnum = 0;
		MQManager mqm = (MQManager) cnnpool.borrow();
		MQQueue queue = null;
		MQMessage qmsg = new MQMessage();
		MQGetMessageOptions gmo = new MQGetMessageOptions();
		gmo.matchOptions = MQC.MQMO_NONE;
		gmo.options = MQC.MQGMO_BROWSE_FIRST | MQC.MQGMO_NO_WAIT;
		// MQC.MQGMO_NO_WAIT | MQC.MQGMO_BROWSE_NEXT;
		try
		{
			mqm.connect(1);
			queue = mqm.accessQueue(qname, MQC.MQOO_BROWSE | MQC.MQOO_INPUT_SHARED
					| MQC.MQOO_INQUIRE);
			// MQC.MQOO_BROWSE | MQC.MQOO_INQUIRE);
			int curDepth = queue.getCurrentDepth();
			if (log.isInfoEnabled()) log.info("Queue: " + qname + ", curDepth: " + curDepth);
			if (curDepth <= 0) return 0;
			int depth = (maxDepth <= 0 || curDepth <= maxDepth) ? curDepth : maxDepth;
			for (int i = 0; i < depth; i++)
			{
				try
				{
					qmsg.clearMessage();
				}
				catch (IOException e)
				{
					qmsg = new MQMessage();
				}
				queue.get(qmsg, gmo);
				gmo.options = MQC.MQGMO_BROWSE_NEXT; // added by chenjs,
				// 2011-02-01
				msgnum++;
			}
		}
		catch (MQException mqe)
		{
			if (Accessor.handleMQException(mqe) == Accessor.MQ_CONNECTION_BROKER) mqm.disconnect();
			if (mqe.reasonCode != 2033)
			{
				log.warn("browseAll:" + qname + ":" + mqe.reasonCode);
				throw new AppException(AppRetCode.PROTOCOL_MQ(), new Object[] { qname,
						String.valueOf(mqe.reasonCode), String.valueOf(mqe.completionCode) });
			}
			else if (log.isInfoEnabled()) log.info("After browse Queue: " + qname);
		}
		finally
		{
			cnnpool.release(mqm);
			mqm.closeQueue();
		}
		return msgnum;
	}

	public static void browse(MQCnnPool cnnpool, String qname, MQGetMessageOptions gmo,
			MQMessage qmsg) throws Exception
	{
		MQManager mqm = (MQManager) cnnpool.borrow();
		try
		{
			browse(mqm, qname, gmo, qmsg);
		}
		finally
		{
			cnnpool.release(mqm);
		}
	}

	public static void browse(MQManager mqm, String qname, MQGetMessageOptions gmo, MQMessage qmsg)
			throws MQException
	{
		MQQueue queue = null;
		try
		{
			mqm.connect(1);
			gmo.options += MQC.MQGMO_BROWSE_FIRST;
			if (log.isInfoEnabled()) log.info("start to read MQ:" + qname);
			queue = mqm.accessQueue(qname, MQC.MQOO_BROWSE);
			queue.get(qmsg, gmo);
			if (log.isInfoEnabled()) log.info("end to read MQ");
		}
		catch (MQException mqex)
		{
			if (Accessor.handleMQException(mqex) == Accessor.MQ_CONNECTION_BROKER) mqm.disconnect();
			throw mqex;
		}
		finally
		{
			mqm.closeQueue();
		}
	}

	public static Queue browse(MQCnnPool cnnpool, String qmname, String qName) throws Exception
	{
		MQManager mqm = (MQManager) cnnpool.borrow();
		try
		{
			return Accessor.browse(mqm, qmname, qName);
		}
		finally
		{
			cnnpool.release(mqm);
		}
	}

	public static Queue browse(MQManager mqm, String qmname, String qname) throws MQException
	{
		try
		{
			mqm.connect(1);
			MQQueue q = mqm.accessQueue(qname, MQC.MQOO_INPUT_AS_Q_DEF + MQC.MQOO_INQUIRE);
			Queue qinfo = new Queue(qmname, qname, q);
			return qinfo;
		}
		catch (MQException mqe)
		{
			if (Accessor.handleMQException(mqe) == Accessor.MQ_CONNECTION_BROKER) mqm.disconnect();
			throw mqe;
		}
		finally
		{
			mqm.closeQueue();
		}
	}

	/**
	 * props.put(MQC.HOST_NAME_PROPERTY,host); hostname
	 * props.put(MQC.PORT_PROPERTY, new Integer(port)); port
	 * props.put(MQC.CHANNEL_PROPERTY, channel); channel
	 * props.put(MQC.CCSID_PROPERTY, new Integer(ccsid)); CCSID
	 * 
	 * @param qm
	 * @param props
	 * @param count
	 * @return
	 */
	public static MQQueueManager connect(MQQueueManager qm, Hashtable props, int retryTimes)
	{
		long i = 0;
		String qnname = (String) props.get(QM_NAME);
		while (true)
		{
			try
			{
				disconnect(qm);
				qm = new MQQueueManager(qnname, props);
				return qm;
			}
			catch (Exception e)
			{
				// e.printStackTrace();
				log.warn("MQ access error:" + props + ", failtimes:" + i + ", sleep:"
						+ CNN_EXCEPTION_SLEEP + " seconds, retryTimes:" + retryTimes, e);
				Log.print();
				i++;
				if (retryTimes >= 0 && i >= retryTimes)
				{
					if (e instanceof MQException)
					{
						MQException mqex = (MQException) e;
						throw new AppException(AppRetCode.PROTOCOL_MQ(), new Object[] { qnname,
								String.valueOf(mqex.reasonCode),
								String.valueOf(mqex.completionCode), e.toString() });
					}
					throw new RuntimeException(e);
				}
				try
				{
					log.debug("thread will sleep:" + CNN_EXCEPTION_SLEEP);
					Thread.sleep(CNN_EXCEPTION_SLEEP * 1000);
				}
				catch (Exception ee)
				{
				}
				if (retryTimes < 0) continue;
			}
		}
	}

	public static MQQueueManager disconnect(MQQueueManager qm)
	{
		if (qm == null) return null;
		try
		{
			qm.close();
		}
		catch (Throwable t)
		{
		}
		try
		{
			qm.disconnect();
		}
		catch (Throwable t)
		{
		}
		return null;
	}

	public static int handleMQException(MQException e)
	{
		int ret = MQ_UNKNOW_EXCEPTION;
		if (e.completionCode == MQException.MQCC_OK && e.reasonCode == MQException.MQRC_NONE) ret = MQ_OK;
		else if (e.completionCode == MQException.MQCC_FAILED)
		{
			switch (e.reasonCode)
			{
				case MQException.MQRC_NO_MSG_AVAILABLE:
					ret = MQ_TIME_OUT;
					break;
				case MQException.MQRC_CONNECTION_BROKEN:
				case MQException.MQRC_Q_MGR_NAME_ERROR:
				case MQException.MQRC_Q_MGR_NOT_AVAILABLE:
				case MQException.MQRC_SECURITY_ERROR:
					// modified by spc 2010-12-21 ���ϲ���Ԥ֪����,�������й�����
				case MQException.MQRC_UNEXPECTED_ERROR:
				case MQException.MQRC_CONNECTION_STOPPING:
					ret = MQ_CONNECTION_BROKER;
					break;
				default:
					ret = MQ_UNKNOW_EXCEPTION;
			}
		}
		return ret;
	}

}
