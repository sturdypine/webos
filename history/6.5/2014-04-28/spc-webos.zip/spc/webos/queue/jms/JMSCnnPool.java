package spc.webos.queue.jms;

import java.util.Hashtable;

import spc.webos.queue.AbstractCnnPool;

public class JMSCnnPool extends AbstractCnnPool
{
	public JMSCnnPool()
	{
		this.autoIncrease = true;
	}

	public JMSCnnPool(int max, Hashtable props)
	{
		this.max = max;
		this.props = props;
		this.autoIncrease = true;
	}

	public JMSCnnPool(int max, Hashtable props, int cnnHoldTime)
	{
		this.max = max;
		this.props = props;
		this.cnnHoldTime = cnnHoldTime;
		this.autoIncrease = true;
	}

	public JMSCnnPool(int max, Hashtable props, int cnnHoldTime, int cnnIdleTime)
	{
		this.max = max;
		this.props = props;
		this.cnnHoldTime = cnnHoldTime;
		this.cnnIdleTime = cnnIdleTime;
		this.autoIncrease = true;
	}

	public JMSCnnPool(int max, Hashtable props, int cnnHoldTime, int cnnIdleTime,
			boolean autoIncrease)
	{
		this.max = max;
		this.props = props;
		this.cnnHoldTime = cnnHoldTime;
		this.cnnIdleTime = cnnIdleTime;
		this.autoIncrease = autoIncrease;
	}

	public JMSCnnPool(int max, Hashtable props, int cnnHoldTime, int cnnIdleTime,
			boolean autoIncrease, long waitTime)
	{
		this.max = max;
		this.props = props;
		this.cnnHoldTime = cnnHoldTime;
		this.cnnIdleTime = cnnIdleTime;
		this.autoIncrease = autoIncrease;
		this.waitTime = waitTime;
	}

	public Object newIntance()
	{
		return new JMSManager(props, cnnHoldTime, cnnIdleTime, keepQueue);
	}

	public boolean release(Object obj)
	{
		JMSManager jmsm = (JMSManager) obj;
		if (!super.release(jmsm)) jmsm.disconnect();
		return true;
	}

	public synchronized void destory()
	{
		log.warn("start to destory JMS pool(" + name + ") : " + pool.size());
		for (int i = 0; i < pool.size(); i++)
			((JMSManager) pool.get(i)).disconnect();
		pool.clear();
	}
}
