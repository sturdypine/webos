package spc.webos.resallocate.fnode;

import java.util.List;

import spc.webos.constant.AppRetCode;
import spc.webos.constant.MsgKey;
import spc.webos.data.AtomNode;
import spc.webos.data.IMessage;
import spc.webos.exception.AppException;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.resallocate.service.IResourcePoolService;

/**
 * �Ե�ǰ���ĵķ�����������������飬�������򵲻�
 * 
 * @author chenjs at 2010-07-06
 */

public class ApplyAFNode extends AbstractFNode
{
	protected IResourcePoolService resourcePoolService;
	protected int defHoldTm = 10000; // Ĭ��holdʱ�䣬��λ����
	protected int defTimeout = 0; // Ĭ�Ͽɵȴ�����ʱ��, ��λ����
	protected int defMatchType = 0;

	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		String key = msg.findAtomInRequest(MsgKey.RES_ALLOCATE_KEY, null).stringValue();
		String sn = msg.findAtomInRequest(MsgKey.RES_ALLOCATE_SN, null).stringValue();
		int holdTm = msg.findAtomInRequest(MsgKey.RES_ALLOCATE_HOLD_TIME, new AtomNode(defHoldTm))
				.intValue();
		int timeout = msg.findAtomInRequest(MsgKey.RES_ALLOCATE_TIMEOUT, new AtomNode(defTimeout))
				.intValue();
		int matchType = msg.findAtomInRequest(MsgKey.RES_ALLOCATE_MATCH_TYPE,
				new AtomNode(defMatchType)).intValue();
		List pres = resourcePoolService.apply(sn, key, holdTm, timeout, matchType);
		if (pres == null || pres.size() == 0) throw new AppException(
				AppRetCode.RES_ALLOCATE_APPLY_FAIL());
		msg.setInResponse("pres", pres);
		return null;
	}

	public void setResourcePoolService(IResourcePoolService resourcePoolService)
	{
		this.resourcePoolService = resourcePoolService;
	}

	public void setDefHoldTm(int defHoldTm)
	{
		this.defHoldTm = defHoldTm;
	}

	public void setDefTimeout(int defTimeout)
	{
		this.defTimeout = defTimeout;
	}

	public void setDefMatchType(int defMatchType)
	{
		this.defMatchType = defMatchType;
	}
}
