package spc.webos.jsrmi.protocal.converters.basic;

import spc.webos.jsrmi.protocal.ProtocalTag;
import spc.webos.jsrmi.protocal.converters.Converter;
import spc.webos.util.StringX;

public class StringConverter extends AbstractBasicConverter implements
		Converter
{
	protected String getType()
	{
		return ProtocalTag.TAG_STRING;
	}

	public boolean canConvert(Class value)
	{
		if (value == null) return false;
		return value.equals(String.class) || value.equals(char.class)
				|| value.equals(Character.class);
	}

	public Object fromString(String str)
	{ // ���jsmri����������,ͳһתΪģʽ, ǰ̨����������ַ�ͳһ��utfת���ʽ
		return StringX.utf82str(str);
	}
}
