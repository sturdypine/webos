package spc.webos.jsrmi.protocal.converters.basic;

import java.math.BigDecimal;

import spc.webos.jsrmi.protocal.ProtocalTag;
import spc.webos.jsrmi.protocal.converters.Converter;

public class DoubleConverter extends AbstractBasicConverter implements Converter
{
	public boolean canConvert(Class clazz)
	{
		if (clazz == null) return false;
		return clazz.equals(double.class) || clazz.equals(Double.class)
				|| clazz.equals(float.class) || clazz.equals(Float.class)
				|| clazz == BigDecimal.class;
	}

	protected String getType()
	{
		return ProtocalTag.TAG_DOUBLE;
	}

	public Object fromString(String string)
	{
		return Double.valueOf(string);
	}
}
