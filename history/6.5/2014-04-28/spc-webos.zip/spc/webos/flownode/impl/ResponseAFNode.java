package spc.webos.flownode.impl;

import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.data.Status;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

/**
 * ��esbҪ����Ӧ����
 * 
 * @author spc
 * 
 */
public class ResponseAFNode extends AbstractFNode
{
	public ResponseAFNode()
	{
	}

	public ResponseAFNode(String exMsgCd)
	{
		this.exMsgCd = exMsgCd;
	}

	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		if (!msg.isRequestMsg())
		{
			log.info("msg is a response msg!!!");
			return null;
		}
		// ���ܱ�����Ϣ�������е������ǩ�ı���
		if (msg.getLocal().containsKey(MsgLocalKey.LOCAL_ORIGINAL_REQUEST)) msg
				.setRequest((ICompositeNode) msg.getInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQUEST));
		// ��ű��Ĳο���Ϣ
		ICompositeNode mesg = msg.getMsg(); // ��ñ�����Ϣ
		if (mesg.getNode(IMessage.TAG_HEADER_MSG_CD) == null)
		{
			log.warn("msgCd is null...");
			return null;
		}
		boolean refInfo = StringX.nullity(msg.getRefMsgCd());
		if (refInfo) req2rep(msg);
		genSndInfo(msg);
		if (refInfo) msg.setMsgCd(getRepMsgCd(msg, msg.getMsgCd()));
		// added by chenjs 2011-06-10 ��ȡ���ĵ�ԭʼ��������Ϣ
		if (removeOriginalBytes) msg.setOriginalBytesPlainStr(null);
		if (removeMsgLocal) msg.setMsgLocal(null); // 2012-05-12
		return null;
	}

	public void genSndInfo(IMessage msg)
	{
		String dt = SystemUtil.getInstance().getCurrentDate(SystemUtil.DF_SALL17);
		// �����µı�����ˮ�ͱ��ı��
		// 8λ����ʱ���Ѿ��ܱ�֤����Ψһ
		msg.setSeqNb(SystemUtil.getInstance().genSN(15));

		// if (!StringX.nullity(node)) msg.setSndNode(node);
		msg.setSndNode(node); // modified by chenjs 2011-06-02 ���û�нڵ���ɾ��
		msg.setSndAppCd(sndAppCd);
		msg.setSndDt(dt.substring(0, 8));
		// modified by spc 2010-12-03, ���ӷ���ʱ��λ��
		msg.setSndTm(dt.substring(8, 17));
	}

	public static void req2rep(IMessage msg)
	{
		if (!StringX.nullity(msg.getRefMsgCd())) return;
		String sndNode = msg.getSndNode();
		if (StringX.nullity(msg.getRefSndNode()) && !StringX.nullity(sndNode))
		{
			msg.setRcvNode(sndNode);
			msg.setRefSndNode(msg.getSndNode());
		}
		if (StringX.nullity(msg.getRefMsgCd())) msg.setRefMsgCd(msg.getMsgCd());
		if (StringX.nullity(msg.getRefSndApp())) msg.setRefSndApp(msg.getSndApp());
		if (StringX.nullity(msg.getRefSndDt())) msg.setRefSndDt(msg.getSndDt());
		if (StringX.nullity(msg.getRefSeqNb())) msg.setRefSeqNb(msg.getSeqNb());
		if (StringX.nullity(msg.getRefCallType())) msg.setRefCallType(msg.getCallType());
		// msg.setCallType(StringX.EMPTY_STRING);
		msg.setCallType(null);
		// msg.getMsg().remove(IMessage.TAG_HEADER_CALLTYPE);
		// String rcvAppCd = msg.getRcvApp();
		// if (StringX.nullity(rcvAppCd))
		msg.setRcvAppCd(msg.getSndApp());
	}

	public String getRepMsgCd(IMessage msg, String msgCd)
	{ // �̶�����Ӧ���ı�ŵ����һλ��Ϊ1
		ICompositeNode msgLocal = msg.getMsgLocal();
		String curRepMsgCd = (msgLocal == null ? null : StringX.null2emptystr(msgLocal
				.get(CUR_REP_MSG_CD)));
		if (!StringX.nullity(curRepMsgCd))
		{
			if (log.isDebugEnabled()) log.debug("curRepMsgCd: " + curRepMsgCd);
			return curRepMsgCd;
		}
		
		// chenjs 2012-09-09 ����ʹ��curRepMsgCd��������ʹ��ϵͳ������
		if (!StringX.nullity(exMsgCd))
		{
			Status s = msg.getStatus();
			if (s != null && s.isFail()) return exMsgCd;
		}
		
		
		// modified by chenjs 2012-01-01������ı�Ž�β����0�򲻱�Ϊ1
		return msgCd.endsWith(Common.ESB_REQMSG_END) ? (msgCd.substring(0, msgCd.length() - 1) + '1')
				: msgCd;
	}

	public static final String CUR_REP_MSG_CD = "CurRepMsgCd"; // msg��ָ���ĵ�ǰӦ���ı��
	protected String exMsgCd; // �쳣ʱ�ı��ı��
	protected String sndAppCd = SystemUtil.APP;
	protected String node = SystemUtil.NODE;
	// modified by chenjs 2011-07-20 �޸�Ϊfalse, Ĭ�ϲ�ɾ��ԭʼ�ֽ�
	protected boolean removeOriginalBytes;// = true;
	protected boolean removeMsgLocal = true; // ����Ƿ�ɾ��local��ǩ

	public String getExMsgCd()
	{
		return exMsgCd;
	}

	public void setExMsgCd(String exMsgCd)
	{
		this.exMsgCd = exMsgCd;
	}

	public void setSndAppCd(String sndAppCd)
	{
		this.sndAppCd = sndAppCd;
	}

	public void setNode(String node)
	{
		this.node = node;
	}

	public void setRemoveOriginalBytes(boolean removeOriginalBytes)
	{
		this.removeOriginalBytes = removeOriginalBytes;
	}

	public void setRemoveMsgLocal(boolean removeMsgLocal)
	{
		this.removeMsgLocal = removeMsgLocal;
	}
}
