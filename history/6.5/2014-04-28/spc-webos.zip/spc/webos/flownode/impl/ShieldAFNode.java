package spc.webos.flownode.impl;

import java.io.StringWriter;
import java.util.HashMap;

import spc.webos.constant.AppRetCode;
import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.Array2Node2XML;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.data.Status;
import spc.webos.data.converter.HeaderXMLConverter;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.data.util.MessageUtil;
import spc.webos.endpoint.Executable;
import spc.webos.flownode.IFlowContext;
import spc.webos.queue.QueueMessage;

/**
 * �Խ�����Ϊģ��������һ�����屨�ġ�
 * 
 * @author chenjs
 * 
 */
public class ShieldAFNode extends ReportAFNode
{
	protected int defaultDelay = -1;
	protected boolean withRequest = true;
	// 2012-07-07 ��ȫ����xml�ṩ����
	protected IMessageConverter converter = HeaderXMLConverter.getInstance();

	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		long s = System.currentTimeMillis();
		if (defaultDelay > 0)
		{
			log.info("start to sleep " + defaultDelay + " ms!!!");
			Thread.sleep(defaultDelay);
		}
		before(msg, cxt);
		StringWriter sw = new StringWriter();
		freemarker(msg, cxt, getTemplate(msg), getSqls(msg), sw, null);
		String xml = sw.toString();
		Executable executable = new Executable();
		executable.setResponse(xml.getBytes(Common.CHARSET_UTF8));
		executable.setStatus(new Status(AppRetCode.SUCCESS()));

		// 2012-09-01 ֱ��ʹ��shield����
		byte[] repxml = executable.response;
		// IMessage repMsg = converter.deserialize(executable.getResponse());
		// // modified 2012-02-20 ʹ�������ĵ��屨��, ���뵲��ı���ͷ��Ϣ
		// msg.getTransaction().apply(repMsg.getTransaction());
		// msg.setBody(null);

		byte[] body = null;
		// 2012-08-15 ��ԭrequest��ǩ��Ϣ���ӵ�body��
		ICompositeNode request = msg.getRequest();
		if (withRequest && request.size() > 0)
		{
			byte[] req = request.toXml((String) null, IMessage.TAG_REQUEST, false,
					Array2Node2XML.getInstance(), new HashMap());
			body = MessageUtil.getBody(repxml);
			if (body == null) body = ("<body>" + new String(req, Common.CHARSET_UTF8) + "</body>")
					.getBytes(Common.CHARSET_UTF8);
			else
			{
				byte[] nbody = new byte[body.length + req.length];
				System.arraycopy(body, 0, nbody, 0, 6); // copy <body>
				System.arraycopy(req, 0, nbody, 6, req.length);
				System.arraycopy(body, 6, nbody, 6 + req.length, body.length - 6);
				body = nbody;
			}
		}

		QueueMessage qmsg = new QueueMessage();
		if (body == null) qmsg.buf = repxml;
		else qmsg.buf = MessageUtil.addBody(MessageUtil.removeBody(repxml), body);
		// if (log.isDebugEnabled()) log.debug("shield buf:"
		// + new String(qmsg.buf, Common.CHARSET_UTF8));
		msg.setInLocal(MsgLocalKey.MQPUT_QMSG_KEY, qmsg);

		// qmsg.buf = (body == null ? XMLConverter2.getInstance().serialize(msg)
		// : MessageUtil
		// .addBody(XMLConverter2.getInstance().serialize(msg), body));

		// if (log.isDebugEnabled()) log.debug("shield qmsg.buf: "
		// + new String(qmsg.buf, Common.CHARSET_UTF8));
		after(msg, cxt);
		if (log.isInfoEnabled()) log.info("cost: " + (System.currentTimeMillis() - s)
				+ ", xml len: " + qmsg.buf.length);
		return null;
	}

	public void setDefaultDelay(int defaultDelay)
	{
		this.defaultDelay = defaultDelay;
	}

	public void setConverter(IMessageConverter converter)
	{
		this.converter = converter;
	}

	public void setWithRequest(boolean withRequest)
	{
		this.withRequest = withRequest;
	}
}
