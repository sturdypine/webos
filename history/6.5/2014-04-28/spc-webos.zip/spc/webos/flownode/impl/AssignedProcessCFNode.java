package spc.webos.flownode.impl;

import java.util.Map;

import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.flownode.IFlowContext;
import spc.webos.flownode.IFlowNode;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

public class AssignedProcessCFNode extends AbstractCFNode
{
	public void flow(IMessage msg, IFlowContext cxt) throws Exception
	{
		msg.setInLocal(MsgLocalKey.LOCAL_JBPM_PROCESS_NAME, getProcessName(msg, cxt));
		bplFNode.execute(msg, cxt);
	}

	protected String getProcessName(IMessage msg, IFlowContext cxt) throws Exception
	{
		if (!StringX.nullity(processName)) return processName;
		if (!StringX.nullity(processNameTemplate))
		{
			Map root = SystemUtil.freemarker(null, msg);
			root.put(Common.MODEL_CXT_KEY, cxt);
			return StringX.trim(SystemUtil.freemarker(processNameTemplate, root));
		}
		return null;
	}

	protected IFlowNode bplFNode;
	protected String processName;
	protected String processNameTemplate;

	public void setBplFNode(IFlowNode bplFNode)
	{
		this.bplFNode = bplFNode;
	}

	public String getProcessName()
	{
		return processName;
	}

	public void setProcessName(String processName)
	{
		this.processName = processName;
	}

	public String getProcessNameTemplate()
	{
		return processNameTemplate;
	}

	public void setProcessNameTemplate(String processNameTemplate)
	{
		this.processNameTemplate = processNameTemplate;
	}
}
