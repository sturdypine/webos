package spc.webos.jsrmi.protocal.converters.basic;

import java.math.BigInteger;

import spc.webos.jsrmi.protocal.ProtocalTag;
import spc.webos.jsrmi.protocal.converters.Converter;

public class LongConverter extends AbstractBasicConverter implements Converter
{
	protected String getType()
	{
		return ProtocalTag.TAG_LONG;
	}

	public boolean canConvert(Class clazz)
	{
		if (clazz == null) return false;
		return clazz.equals(long.class) || clazz == BigInteger.class || clazz.equals(Long.class);
	}

	public Object fromString(String string)
	{
		return new Long(string);
	}
}
