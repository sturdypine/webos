package spc.webos.flownode.action;

import spc.webos.constant.AppRetCode;
import spc.webos.data.IMessage;
import spc.webos.exception.AppException;
import spc.webos.flownode.IFlowContext;
import spc.webos.flownode.IFlowNode;
import spc.webos.util.StringX;

public class TargetFNodeAction extends AbstractAction
{
	private static final long serialVersionUID = 1L;

	public void execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		executeTargetFNode(msg, cxt);
	}

	protected void executeTargetFNode(IMessage msg, IFlowContext cxt) throws Exception
	{
		String[] fnodes = StringX.split(this.fnodes, StringX.COMMA);
		for (int i = 0; i < fnodes.length; i++)
		{
			IFlowNode fnode = getFlowNode(fnodes[i]);
			if (fnode == null)
			{
				log.warn("canot find beanId for " + fnodes[i]);
				throw new AppException(AppRetCode.MSGCD_UNDEFINDED(), new Object[] { fnodes[i] });
			}
			fnode.execute(msg, cxt);
		}
	}

	protected String fnodes;

	public void setFnodes(String fnodes)
	{
		this.fnodes = StringX.trim(fnodes);
	}
}
