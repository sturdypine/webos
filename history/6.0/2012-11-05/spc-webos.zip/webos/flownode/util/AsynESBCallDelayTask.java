package spc.webos.flownode.util;

import spc.webos.data.IMessage;
import spc.webos.flownode.IDelayTask;
import spc.webos.flownode.IFlowContext;
import spc.webos.flownode.impl.MQPutAFNode;
import spc.webos.log.Log;

public class AsynESBCallDelayTask implements IDelayTask
{
	MQPutAFNode mqPut;
	IMessage msg;
	IFlowContext cxt;
	boolean done;
	protected Log log = Log.getLogger(getClass());

	public AsynESBCallDelayTask(IMessage msg, IFlowContext cxt, MQPutAFNode mqPut)
	{
		this.cxt = cxt;
		this.mqPut = mqPut;
		this.msg = msg;
	}

	public Object execute() throws Exception
	{
		if (isDone())
		{
			log.warn("DelayTask has been done!!!");
			return null;
		}
		mqPut.execute(msg, cxt);
		done = true;
		return null;
	}

	public String getName()
	{
		return "AsynESBCall(" + msg.getMsgSn() + ")";
	}

	public boolean isDone()
	{
		return done;
	}

	public void setDone(boolean done)
	{
		this.done = done;
	}
}
