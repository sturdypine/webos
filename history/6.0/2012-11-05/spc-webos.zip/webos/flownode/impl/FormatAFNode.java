package spc.webos.flownode.impl;

import spc.webos.constant.MsgLocalKey;
import spc.webos.data.CompositeNode;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.data.IMessageSchema;
import spc.webos.data.util.MessageTranslator;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.tree.TreeNode;

public class FormatAFNode extends AbstractFNode
{
	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		ICompositeNode cnode = request ? msg.getRequest() : msg.getResponse();
		TreeNode struct = validatorSource.getMsgSchema(msg.getMsgCd());
		if (struct == null) return null;
		ICompositeNode target = new CompositeNode();
		translator.processMap(struct, msg, cnode, target, esb2rcv, rcvIgnore, alterStruct);
		if (replace)
		{
			if (request)
			{
				msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQUEST, cnode);
				msg.setRequest(target);
			}
			else msg.setResponse(target);
		}
		return null;
	}

	protected boolean esb2rcv = true;
	protected boolean request = true;
	protected boolean rcvIgnore;
	protected boolean alterStruct;
	protected boolean replace;
	protected IMessageSchema validatorSource;
	protected MessageTranslator translator = new MessageTranslator();

	public void setTranslator(MessageTranslator translator)
	{
		this.translator = translator;
	}

	public void setValidatorSource(IMessageSchema validatorSource)
	{
		this.validatorSource = validatorSource;
	}

	public void setEsb2rcv(boolean esb2rcv)
	{
		this.esb2rcv = esb2rcv;
	}

	public void setRcvIgnore(boolean rcvIgnore)
	{
		this.rcvIgnore = rcvIgnore;
	}

	public void setAlterStruct(boolean alterStruct)
	{
		this.alterStruct = alterStruct;
	}

	public void setReplace(boolean replace)
	{
		this.replace = replace;
	}

	public void setRequest(boolean request)
	{
		this.request = request;
	}
}
