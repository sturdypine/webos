package spc.webos.flownode.impl;

import spc.webos.constant.AppRetCode;
import spc.webos.data.IMessage;
import spc.webos.data.Status;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

/**
 * ���óɹ���Ϣ
 * 
 * @author spc
 * 
 */
public class SuccessAFNode extends AbstractFNode
{
	static final SuccessAFNode node = new SuccessAFNode();
	protected String appCd;

	public Object execute(IMessage msg, IFlowContext cxt)
	{
		Status status = msg.getStatus();
		// System.out.println("success:"+msg.getStatus());
		if (status == null || status.isUnderWay())
		{
			if (log.isInfoEnabled()) log.info("set success flag: " + AppRetCode.SUCCESS());
			status = new Status(AppRetCode.SUCCESS());
			// if (!StringX.nullity(SystemUtil.NODE))
			status.setMbrCd(SystemUtil.NODE); // modified by chenjs 2011-06-02
												// ���û�нڵ���ɾ��
			status.setAppCd(StringX.nullity(appCd) ? SystemUtil.APP : appCd);
			status.setIp(SystemUtil.LOCAL_HOST_IP);
			status.setLocation("SuccessAFNode");
			msg.setStatus(status);
		}
		else if (log.isInfoEnabled()) log.info("retCd : " + status.getRetCd());
		return null;
	}

	public void setAppCd(String appCd)
	{
		this.appCd = appCd;
	}

	public SuccessAFNode()
	{
	}

	public static SuccessAFNode getInstance()
	{
		return node;
	}
}
