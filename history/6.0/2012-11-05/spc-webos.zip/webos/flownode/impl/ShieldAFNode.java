package spc.webos.flownode.impl;

import java.io.StringWriter;

import spc.webos.constant.AppRetCode;
import spc.webos.constant.Common;
import spc.webos.data.IMessage;
import spc.webos.data.Status;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.endpoint.Executable;
import spc.webos.flownode.IFlowContext;

/**
 * �Խ�����Ϊģ��������һ�����屨�ġ�
 * 
 * @author spc
 * 
 */
public class ShieldAFNode extends ReportAFNode
{
	protected int defaultDelay = -1;
	protected IMessageConverter converter;

	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		if (defaultDelay > 0) Thread.sleep(defaultDelay);
		before(msg, cxt);
		StringWriter sw = new StringWriter();
		freemarker(msg, cxt, getTemplate(msg), getSqls(msg), sw, null);
		String xml = sw.toString();
		if (log.isDebugEnabled()) log.debug("shield msg:" + xml.toString());
		Executable executable = new Executable();
		executable.setResponse(xml.getBytes(Common.CHARSET_UTF8));
		executable.setStatus(new Status(AppRetCode.SUCCESS()));
		if (converter != null)
		{
			IMessage repMsg = converter.deserialize(executable.getResponse());
			// modified 2012-02-20 ʹ�������ĵ��屨��, ���뵲��ı���ͷ��Ϣ
			msg.getTransaction().apply(repMsg.getTransaction());
//			msg.getResponse().set(resMsg.getResponse());
			Status status = msg.getStatus();
			if (status != null) msg.setStatus(status); // ������ģ�������ñ���״̬
		}
		after(msg, cxt);
		return null;
	}

	public void setDefaultDelay(int defaultDelay)
	{
		this.defaultDelay = defaultDelay;
	}

	public void setConverter(IMessageConverter converter)
	{
		this.converter = converter;
	}
}
