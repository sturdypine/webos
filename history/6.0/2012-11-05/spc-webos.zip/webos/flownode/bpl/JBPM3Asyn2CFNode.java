package spc.webos.flownode.bpl;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jbpm.graph.def.Action;
import org.jbpm.graph.def.DelegationException;
import org.jbpm.graph.def.Event;
import org.jbpm.graph.def.Node;
import org.jbpm.graph.def.ProcessDefinition;
import org.jbpm.graph.exe.ProcessInstance;
import org.jbpm.graph.exe.Token;
import org.springframework.core.io.Resource;

import spc.webos.cache.ClusterMQCache;
import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.Status;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.data.converter.XMLConverter2;
import spc.webos.exception.AppException;
import spc.webos.flownode.IFlowContext;
import spc.webos.flownode.IFlowNode;
import spc.webos.flownode.action.IAfterAsynCall;
import spc.webos.flownode.impl.AbstractCFNode;
import spc.webos.jdbc.blob.ByteArrayBlob;
import spc.webos.model.BPELInstanceVO;
import spc.webos.model.BPELNodeVO;
import spc.webos.model.BPELProcessDefinitionVO;
import spc.webos.persistence.IPersistence;
import spc.webos.util.FileUtil;
import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

/**
 * ��ʹ�����ݿ���Ϊ�첽�洢���ʣ���ʹ��cluster cache
 * 
 * @author chenjs
 * 
 */
public class JBPM3Asyn2CFNode extends AbstractCFNode
{
	public void flow(IMessage msg, IFlowContext cxt) throws Exception
	{
		ProcessInstance instance = null;
		IMessage parent = null;
		Status status = null;
		Map variables = new HashMap();
		BPELNodeVO nodeVO = null;
		BPELInstanceVO instanceVO = null;
		try
		{
			if (msg.isRequestMsg())
			{ // is a request message...
				parent = msg; // first create BPL. parent is current msg.
				instanceVO = new BPELInstanceVO();
				instance = createProcessInstance(msg, cxt, instanceVO);
			}
			else
			{ // is a response message...
				status = msg.getStatus();
				if (log.isInfoEnabled()) log.info("sub rep msg status: " + status);
				instance = resumeProcessInstance(msg.getRefMsgSn(), cxt); // ʹ�õ�ǰ�ӱ��ĵ���ˮ�Ż�ȡ������Ϣ

				nodeVO = (BPELNodeVO) instance.getContextInstance().getVariable(
						INSTANCE_VAR_KEY_nodeVO); // ������ʵ�������л�ȡnodeVO
				instanceVO = (BPELInstanceVO) instance.getContextInstance().getVariable(
						INSTANCE_VAR_KEY_instanceVO); // ������ʵ�������л�ȡinstanceVO
				if (log.isDebugEnabled()) log
						.debug("instance vars: " + instanceVO + ",  " + nodeVO);

				// handle response msg to parent msg
				parent = converter.deserialize(instanceVO.getParentXml().bytes()); // �ָ�������״̬
				msg.setInLocal(MsgLocalKey.LOCAL_PARENT_MSG, parent);
				parent.setInLocal(MsgLocalKey.LOCAL_SUB_MSG, msg);

				ProcessDefinition processDefinition = getProcessDefinition(instanceVO.getMsgCd());
				Node lastNode = processDefinition.getNode(nodeVO.getNode()); // ���һ��ִ�еĽڵ�
				if (lastNode == null) log.warn("lastNode(" + nodeVO.getNode() + ") is null!!!");
				else
				{ // �������첽���ã��õ����һ��ִ�еĽڵ㣬Ȼ��������һ�νڵ��Ӧ��ӳ���ϵ
					Event evt = lastNode.getEvent("node-enter");
					List actions = evt == null ? null : evt.getActions();
					if (actions != null && actions.size() > 0)
					{
						Action action = (Action) actions.get(0);
						Object delegation = action.getActionDelegation().instantiate();
						if (delegation instanceof IAfterAsynCall) ((IAfterAsynCall) delegation)
								.after(parent, msg, cxt);
						else log.warn("delegation" + delegation.getClass()
								+ " is not IAfterAsynCall!!!");
					}
				}
				instanceVO.setParentXml(new ByteArrayBlob(converter.serialize(parent)));
				if (log.isDebugEnabled()) log.debug("after response msg, parent msg is: "
						+ instanceVO.getParentXml());
				// read instance history variables
				if (!StringX.nullity(instanceVO.getVariables())) variables = (Map) JsonUtil
						.json2obj(instanceVO.getVariables());

				// update node
				BPELNodeVO nnodeVO = new BPELNodeVO();
				nnodeVO.setMsgSn(nodeVO.getMsgSn());
				nnodeVO.setStatus(status.isSuccess() ? Status.STATUS_SUCCESS : Status.STATUS_FAIL);
				if (!status.isSuccess())
				{
					nnodeVO.setRetCd(status.getRetCd());
					nnodeVO.setAppCd(status.getAppCd());
					nnodeVO.setLocation(status.getLocation());
					nnodeVO.setRetDesc(status.getDesc());
					nnodeVO.setIp(status.getIp());
				}
				if (bplPersistence != null) bplPersistence.update(nnodeVO);
				if (Common.YES.equals(nodeVO.getFailAbort()) && status.isFail())
				{ // sub service is fail and bpl node's failabort flag is
					// abort when fail
					throw new AppException(status);
				}
			}

			// to execute next node
			instance.getContextInstance().setTransientVariable(IFlowContext.JBPM_FLOW_CXT_KEY, cxt);
			instance.getContextInstance().setTransientVariable(IFlowContext.JBPM_MSG_KEY, parent);
			if (!parent.getLocal().containsKey(MsgLocalKey.LOCAL_BPL_VARIABLES)) parent.setInLocal(
					MsgLocalKey.LOCAL_BPL_VARIABLES, variables);
			instance.getContextInstance().setVariables(variables);

			instance.getContextInstance().setTransientVariable(Common.MODEL_MSG, parent); // ����ǰ������Ϊ���̵���ʱ����
			Token token = instance.getRootToken();
			token.signal();

			if (parent != msg) msg.addDelayTasks(parent.getDelayTask()); // �������е�δ��ʱ������������뵽��ǰ���Ļ�����
			variables = (Map) parent.getInLocal(MsgLocalKey.LOCAL_BPL_VARIABLES);
			if (instance.hasEnded())
			{ // jpdl has normal end...
				if (log.isInfoEnabled()) log.info("id: " + instance.getId() + ", parent msgcd:"
						+ parent.getMsgCd() + ", parent sn: " + parent.getMsgSn() + " will end...");
				if (log.isDebugEnabled()) log.debug("parent: " + parent.toXml(true));
				instanceVO.setStatus(Status.STATUS_SUCCESS);
				// response to request msg.
				// parent.setMsgLocal(null); // 2012-01-25 chenjs ɾ�����ĵ�local��Ϣ
				if (endFNode != null) endFNode.execute(parent, cxt);
				else log.warn("endFNode is null!!!");
				// set success to reponse requester flag
				// msg.setInLocal(REP_SUCCESS_KEY, Boolean.TRUE);
				// delete jbpm instance
				deleteProcessInstance(parent.getMsgSn()); // ʹ�ø�������ˮ��ɾ������ʵ��
			}
			else
			{
				// ��������ִ���м��instanceVO & nodeVO
				instance.getContextInstance().setVariable(INSTANCE_VAR_KEY_instanceVO, instanceVO);
				BPELNodeVO bnvo = (BPELNodeVO) parent.getInLocal(MsgLocalKey.LOCAL_LAST_NODE);
				instance.getContextInstance().setVariable(INSTANCE_VAR_KEY_nodeVO, bnvo);
				if (bplPersistence != null) bplPersistence.insert(bnvo);
				IMessage nsubmsg = (IMessage) parent.getInLocal(MsgLocalKey.LOCAL_NSUB_MSG);
				saveProcessInstance(instance, nsubmsg.getMsgSn()); // ��������ʵ��
			}
		}
		catch (Exception e)
		{ // �κ��쳣��ɾ��������Ϣ
			if (e instanceof DelegationException) e = (Exception) ((DelegationException) e)
					.getCause();
			if (instanceVO != null) instanceVO.setStatus(Status.STATUS_FAIL);
			try
			{
				if (instance != null)
				{
					log.warn("force to end process instance: " + instance.getId());
					instance.end();
					deleteProcessInstance(parent.getMsgSn()); // ʹ�ø�������ˮ��ɾ������ʵ��
				}
			}
			catch (Exception ex)
			{
				log.warn("handle ex and end instance", ex);
			}
			failAbort(msg, parent, e, cxt);
		}
		finally
		{
			try
			{
				if (instanceVO != null)
				{
					BPELInstanceVO ninstanceVO = new BPELInstanceVO();
					ninstanceVO.setMsgSn(instanceVO.getMsgSn());
					ninstanceVO.setVariables(instanceVO.getVariables());
					if (variables != null && variables.size() > 0) ninstanceVO
							.setVariables(JsonUtil.obj2json(variables));
					ninstanceVO.setParentXml(instanceVO.getParentXml());
					ninstanceVO.setStatus(instanceVO.getStatus());
					if (bplPersistence != null) bplPersistence.update(ninstanceVO);
				}
			}
			catch (Exception ex)
			{
				log.warn("finally handle instanceVO", ex);
			}
		}
	}

	public JBPM3Asyn2CFNode()
	{
		name = "jbpm3Asyn2";
	}

	public boolean support(IMessage msg)
	{
		if (!msg.isRequestMsg())
		{ // Ӧ����Ϣ
			return Common.APP_CD_BPL.equals(msg.getRefSndApp());
		}
		return true;
	}

	protected void failAbort(IMessage msg, IMessage parent, Exception ex, IFlowContext cxt)
			throws Exception
	{
		if (log.isInfoEnabled()) log.info("failAbort for sn:" + msg.getMsgSn(), ex);
		if (parent == null)
		{
			log.error("failAbort: cannot find parent msg for msg:" + msg.toXml(true), ex);
			return;
		}
		parent.setStatus(SystemUtil.ex2status(parent.getFixedErrDesc(), ex));
		// parent.setMsgLocal(null); // 2012-01-25 chenjs ɾ�����ĵ�local��Ϣ
		if (endFNode != null) endFNode.execute(parent, cxt);
	}

	/**
	 * ������һ������ı��ġ��������Ϊ
	 * 
	 * @param msg
	 * @param cxt
	 * @throws Exception
	 */
	protected ProcessInstance createProcessInstance(IMessage msg, IFlowContext cxt,
			BPELInstanceVO instanceVO) throws Exception
	{
		String msgCd = msg.getMsgCd();
		ProcessDefinition pdefinition = getProcessDefinition(msgCd);
		ProcessInstance instance = new ProcessInstance(pdefinition);

		// insert a row to BPELInstance for a start
		msg.getMsg().toObject(instanceVO);

		instanceVO.setMsgSn(msg.getMsgSn());
		instanceVO.setMsgCd(msgCd);
		instanceVO.setProccessName(msgCd);
		instanceVO.setVer(String.valueOf(pdefinition.getVersion()));
		instanceVO.setInstanceId(String.valueOf(instance.getId()));
		instanceVO.setStatus(Status.STATUS_UNDERWAY);
		instanceVO.setParentXml(new ByteArrayBlob(converter.serialize(msg)));
		instanceVO.setTmStamp(SystemUtil.getInstance().getCurrentDate(SystemUtil.DF_SALL17));
		if (bplPersistence != null) bplPersistence.insert(instanceVO);
		return instance;
	}

	/**
	 * Ӧ������ʱ�ָ�����ʵ��
	 * 
	 * @param msg
	 * @param cxt
	 * @return
	 */
	protected ProcessInstance resumeProcessInstance(String msgSn, IFlowContext cxt)
			throws Exception
	{
		if (log.isInfoEnabled()) log.info("resumeProcessInstance: msgSn:" + msgSn);
		byte[] buf = clusterCache.get(msgSn, false);
		return (ProcessInstance) FileUtil.deserialize(buf, true);
	}

	protected void saveProcessInstance(ProcessInstance instance, String msgSn) throws Exception
	{
		if (log.isInfoEnabled()) log.info("saveProcessInstance:" + msgSn);
		clusterCache.put(msgSn, FileUtil.serialize(instance, true), 60);
	}

	/**
	 * ���̽���ִ����ϣ�ɾ������ʵ��
	 * 
	 * @param msgSn
	 */
	protected void deleteProcessInstance(String msgSn)
	{
		if (log.isInfoEnabled()) log.info("deleteProcessInstance: msgsn: " + msgSn);
	}

	protected ProcessDefinition getProcessDefinition(String msgCd)
	{
		return (ProcessDefinition) processDefinitions.get(msgCd);
	}

	public void init() throws Exception
	{
		super.init();
		refresh();
	}

	public void refresh() throws Exception
	{
		log.info("JBPM3Asyn2CFNode refresh... ");
		Map pDefinitions = new HashMap();
		loadFromDisk(pDefinitions);
		loadFromDB(pDefinitions);
		processDefinitions = pDefinitions;
		if (log.isInfoEnabled()) log.info("load processdefinitins:" + processDefinitions.keySet());
	}

	protected void loadFromDB(Map processDefinitions) throws Exception
	{
		if (!persistence.contain(BPELProcessDefinitionVO.class)) return;
		log.info("loadFromDB..");
		List pdefs = persistence.get(new BPELProcessDefinitionVO());
		for (int i = 0; pdefs != null && i < pdefs.size(); i++)
		{
			BPELProcessDefinitionVO pdvo = (BPELProcessDefinitionVO) pdefs.get(i);
			if (log.isInfoEnabled()) log.info("loading process definition from DB:"
					+ pdvo.getName());
			ProcessDefinition definition = ProcessDefinition.parseXmlString(new String(pdvo
					.getDefinition().bytes(), jpdlCharset));
			definition.setVersion(Integer.parseInt(pdvo.getVer()));
			processDefinitions.put(definition.getName(), definition);
		}
	}

	protected void loadFromDisk(Map processDefinitions) throws Exception
	{
		if (jpdlDir == null) return;
		File dir = jpdlDir.getFile();
		if (!dir.exists())
		{
			log.error("jpdl dir is no exist:" + dir.getAbsolutePath());
			return;
		}
		readDir(dir, processDefinitions);
	}

	protected void readDir(File dir, Map processDefinitions) throws Exception
	{
		log.info("loadFromDisk..." + dir.getAbsolutePath());
		File[] subfile = dir.listFiles();
		for (int i = 0; i < subfile.length; i++)
		{
			if (subfile[i].isDirectory())
			{
				readDir(subfile[i], processDefinitions);
				continue;
			}
			if (subfile[i].getName().equalsIgnoreCase(PROCESS_DEF_FILE_NAME))
			{
				ProcessDefinition definition = ProcessDefinition.parseXmlString(new String(FileUtil
						.file2bytes(subfile[i]), jpdlCharset));
				if (log.isInfoEnabled()) log.info("loading process definition from disk:"
						+ definition.getName());
				processDefinitions.put(definition.getName(), definition);
			}
		}
	}

	protected IPersistence bplPersistence;
	protected ClusterMQCache clusterCache; // ���ڼ�Ⱥ�洢���̻���
	protected String jpdlCharset = Common.CHARSET_UTF8;
	protected IFlowNode endFNode; // ��Ϸ����Ӧ������
	protected Resource jpdlDir;
	protected Map processDefinitions = new HashMap(); // ���̶���
	public final static String PROCESS_DEF_FILE_NAME = "processdefinition.xml";
	public final static String BPEL_KEY = "BPL";
	public final static String INSTANCE_VAR_KEY_instanceVO = "_instanceVO";
	public final static String INSTANCE_VAR_KEY_nodeVO = "_nodeVO";
	protected IMessageConverter converter = new XMLConverter2(false); // bpl�洢ʱ��ɾ��transaction/local��ǩ

	public void setBplPersistence(IPersistence bplPersistence)
	{
		this.bplPersistence = bplPersistence;
	}

	public void setConverter(IMessageConverter converter)
	{
		this.converter = converter;
	}

	public void setJpdlCharset(String jpdlCharset)
	{
		this.jpdlCharset = jpdlCharset;
	}

	public void setEndFNode(IFlowNode endFNode)
	{
		this.endFNode = endFNode;
	}

	public void setJpdlDir(Resource jpdlDir)
	{
		this.jpdlDir = jpdlDir;
	}

	public void setClusterCache(ClusterMQCache clusterCache)
	{
		this.clusterCache = clusterCache;
	}
}
