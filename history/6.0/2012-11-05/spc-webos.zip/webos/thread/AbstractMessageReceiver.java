package spc.webos.thread;

import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.data.converter.XMLConverter2;
import spc.webos.flownode.MessageFlow;
import spc.webos.log.Log;
import spc.webos.util.StringX;

public abstract class AbstractMessageReceiver implements IMessageReceiver
{
	protected boolean setOriginalBytes = true;
	protected IMessageConverter converter = XMLConverter2.getInstance(); // Ĭ���ñ�׼xml������
	protected Log log = Log.getLogger(getClass());

	protected IMessage obj2msg(Object obj) throws Exception
	{
		IMessage msg = null;
		if (obj instanceof IBufferMessage) msg = ((IBufferMessage) obj).toMessage(converter);
		else if (obj instanceof byte[])
		{
			msg = converter.deserialize(((byte[]) obj));
			msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, ((byte[]) obj));
		}
		else if (obj instanceof IMessage)
		{
			msg = (IMessage) obj;
			if (msg.getLocal().containsKey(MsgLocalKey.LOCAL_MSGCVT_DELAY))
			{
				// change log modified by chenjs 2010-11-17
				MessageFlow mf = (MessageFlow) msg.getInLocal(MsgLocalKey.LOCAL_MSG_MSGFLOW);
				if (mf != null && !StringX.nullity(mf.getLogName())) Log.change(mf.getLogName());
				// end change log end 2010-11-17

				byte[] original = (byte[]) msg.getInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES);
				try
				{
					IMessage reqmsg = ((IMessageConverter) msg
							.getInLocal(MsgLocalKey.LOCAL_MSG_CONVERTER))
							.deserialize(original, msg); // modified by chenjs,
															// ��Ҫ��ת��������ײ�������Ϣ
					msg.setTransaction(reqmsg.getTransaction());
					msg.getLocal().putAll(reqmsg.getLocal());
					if (setOriginalBytes && StringX.nullity(msg.getOriginalBytesPlainStr())) msg
							.setOriginalBytes(original);
				}
				catch (Exception e)
				{
					log.warn("buf, base64: " + new String(StringX.encodeBase64(original))
							+ "\n buf:[" + new String(original) + "]");
					throw e;
				}
			}
		}
		else if (obj != null)
		{
			log.warn("obj is undefined class: " + obj.getClass().getName() + "\n" + obj.toString());
		}
		if (msg == null) log.debug("msg is null!!!");
		return msg;
	}

	public void setSetOriginalBytes(boolean setOriginalBytes)
	{
		this.setOriginalBytes = setOriginalBytes;
	}

	public void setConverter(IMessageConverter converter)
	{
		this.converter = converter;
	}
}
