package spc.webos.thread;

import spc.webos.buffer.IBuffer;
import spc.webos.data.IMessage;

public class BufferMsgReceiver extends AbstractMessageReceiver
{
	protected IBuffer inBuf;
	// added by chenjs 2011-06-10 ���ӱ��������Ƿ�����ԭʼ��������Ϣ

	public IMessage receive() throws Exception
	{
		return receive(-1);
	}

	public IMessage receive(long timeout) throws Exception
	{
		Object obj = timeout <= 0 ? inBuf.remove() : inBuf.remove(timeout);
		return obj2msg(obj);
//		IMessage msg = null;
//		if (obj instanceof IBufferMessage)
//		{
//			msg = ((IBufferMessage) obj).toMessage(converter);
//		}
//		// modified by spc 2011-04-14 ����һ���ӿڣ������н���buffer����Ϣ�����Դ���
//		// if (obj instanceof QueueMessage)
//		// { // �����buf�л�õ��Ƕ�����Ϣ, ����Ҫת��ΪIMessage����
//		// msg = converter.deserialize(((QueueMessage) obj).buf);
//		// msg.setCorrelationID(((QueueMessage) obj).correlationId);
//		// msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_QMSG, obj); //
//		// ���������Ϣ��ԭʼ��Ϣ
//		// msg.setInLocal(MsgLocalKey.ACCEPTOR_PROTOCOL,
//		// Common.ACCEPTOR_PROTOCOL_QUEUE_MQ);
//		// msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, ((QueueMessage)
//		// obj).buf);
//		// }
//		// else if (obj instanceof SocketMessage)
//		// {
//		// msg = converter.deserialize(((SocketMessage) obj).reqmsg);
//		// msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_SOCKETMSG, obj); //
//		// ���������Ϣ��ԭʼ��Ϣ
//		// msg.setInLocal(MsgLocalKey.ACCEPTOR_PROTOCOL, ((SocketMessage)
//		// obj).protocol);
//		// msg.setInLocal(MsgLocalKey.LOCAL_REP_BUFFER, ((SocketMessage)
//		// obj).repbuf);
//		// msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, ((SocketMessage)
//		// obj).reqmsg);
//		// }
//		else if (obj instanceof byte[])
//		{
//			msg = converter.deserialize(((byte[]) obj));
//			msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, ((byte[]) obj));
//		}
//		else if (obj instanceof IMessage)
//		{
//			msg = (IMessage) obj;
//			if (msg.getLocal().containsKey(MsgLocalKey.LOCAL_MSGCVT_DELAY))
//			{
//				// change log modified by chenjs 2010-11-17
//				MessageFlow mf = (MessageFlow) msg.getInLocal(MsgLocalKey.LOCAL_MSG_MSGFLOW);
//				if (mf != null && !StringX.nullity(mf.getLogName())) Log.change(mf.getLogName());
//				// end change log end 2010-11-17
//
//				byte[] original = (byte[]) msg.getInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES);
//				try
//				{
//					IMessage reqmsg = ((IMessageConverter) msg
//							.getInLocal(MsgLocalKey.LOCAL_MSG_CONVERTER))
//							.deserialize(original, msg); // modified by chenjs,
//															// ��Ҫ��ת��������ײ�������Ϣ
//					msg.setTransaction(reqmsg.getTransaction());
//					msg.getLocal().putAll(reqmsg.getLocal());
//					if (setOriginalBytes && StringX.nullity(msg.getOriginalBytesPlainStr())) msg
//							.setOriginalBytes(original);
//				}
//				catch (Exception e)
//				{
//					log.warn("buf, base64: " + new String(StringX.encodeBase64(original))
//							+ "\n buf:[" + new String(original) + "]");
//					throw e;
//				}
//			}
//		}
//		else if (obj != null)
//		{
//			log.warn("obj is undefined class: " + obj.getClass().getName() + "\n" + obj.toString());
//		}
//		if (msg == null && log.isInfoEnabled()) log
//				.info("BufferMsgReceiver receive a null msg, timeout:" + timeout + ", inBuf:"
//						+ inBuf.getName());
//		// if (build && msg != null) msg.init(); //
//		// ���esb�����й̶��ַ�ͷ�������ں���ʱ�Ͳ���Ҫ��������xml,
//		// modified by spc 2010-07-15 �Ƿ�buildȡ����Converter
//
//		return msg;
	}

	public void setInBuf(IBuffer inBuf)
	{
		this.inBuf = inBuf;
	}

	public void setBuild(boolean build)
	{
		// this.build = build;
	}
}
