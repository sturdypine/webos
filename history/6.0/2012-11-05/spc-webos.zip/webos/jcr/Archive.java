package spc.webos.jcr;

import java.io.File;

import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

/**
 * �洢����Դ����ĵ��ڵ�����
 * 
 * @author spc
 * 
 */
public class Archive implements java.io.Serializable
{
	private static final long serialVersionUID = 1L;
	String uuid = StringX.EMPTY_STRING;
	String id = StringX.EMPTY_STRING;
	String path = StringX.EMPTY_STRING;
	String author = StringX.EMPTY_STRING;
	String title = StringX.EMPTY_STRING;
	String summary = StringX.EMPTY_STRING;
	String content = StringX.EMPTY_STRING;
	String createDt = SystemUtil.getInstance().getCurrentDate(SystemUtil.DF_APP8);
	String createTm = SystemUtil.getInstance().getCurrentDate(SystemUtil.DF_HMS6);
	String ext1 = StringX.EMPTY_STRING;
	String ext2 = StringX.EMPTY_STRING;
	String ext3 = StringX.EMPTY_STRING;
	String excerpt = StringX.EMPTY_STRING;
	String fileName = StringX.EMPTY_STRING;
	File[] files;

	public String getUuid()
	{
		return uuid;
	}

	public void setUuid(String uuid)
	{
		this.uuid = uuid;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getPath()
	{
		return path;
	}

	public void setPath(String path)
	{
		this.path = path;
	}

	public String getAuthor()
	{
		return author;
	}

	public void setAuthor(String author)
	{
		this.author = author;
	}

	public String getTitle()
	{
		return title;
	}

	public void setTitle(String title)
	{
		this.title = title;
	}

	public String getSummary()
	{
		return summary;
	}

	public void setSummary(String summary)
	{
		this.summary = summary;
	}

	public String getContent()
	{
		return content;
	}

	public void setContent(String content)
	{
		this.content = content;
	}

	public String getExt1()
	{
		return ext1;
	}

	public void setExt1(String ext1)
	{
		this.ext1 = ext1;
	}

	public String getExt2()
	{
		return ext2;
	}

	public void setExt2(String ext2)
	{
		this.ext2 = ext2;
	}

	public String getExt3()
	{
		return ext3;
	}

	public void setExt3(String ext3)
	{
		this.ext3 = ext3;
	}

	public File[] getFiles()
	{
		return files;
	}

	public void setFiles(File[] files)
	{
		this.files = files;
	}

	public String getCreateDt()
	{
		return createDt;
	}

	public void setCreateDt(String createDt)
	{
		this.createDt = createDt;
	}

	public String getCreateTm()
	{
		return createTm;
	}

	public void setCreateTm(String createTm)
	{
		this.createTm = createTm;
	}

	public String getExcerpt()
	{
		return excerpt;
	}

	public void setExcerpt(String excerpt)
	{
		this.excerpt = excerpt;
	}

	public String getFileName()
	{
		return fileName;
	}

	public void setFileName(String fileName)
	{
		this.fileName = fileName;
	}

	public String toString()
	{
		return "uuid:" + uuid + ", id:" + id + ", path:" + path + ", author:" + author + ", title:"
				+ title + ", sum:" + summary + ", content:" + content + ", Dt:" + createDt
				+ ", Tm:" + createTm + ", ext1:" + ext1 + ", ext2:" + ext2 + ", ext3" + ext3
				+ ", files:" + (files == null ? 0 : files.length) + ", file:" + fileName
				+ ", excerpt:" + excerpt;
	}
}
