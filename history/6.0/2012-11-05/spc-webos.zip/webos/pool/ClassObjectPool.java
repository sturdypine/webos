package spc.webos.pool;

public class ClassObjectPool extends ObjectPool
{
	public ClassObjectPool(Class clazz)
	{
		this(clazz, DEFAULT_MAX);
	}

	public ClassObjectPool(Class clazz, int max)
	{
		this.clazz = clazz;
		this.max = max;
	}

	public int getAvailable()
	{
		return pool.size();
	}

	public Object newIntance()
	{
		try
		{
			return clazz.newInstance();
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
	}

	Class clazz;
}
