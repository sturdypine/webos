package spc.webos.web.listener;

import java.util.Hashtable;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import spc.webos.endpoint.ESB;
import spc.webos.log.Log;
import spc.webos.queue.DefaultBlobMessageCreator;
import spc.webos.util.StringX;

public class ESBServletCxtListener implements ServletContextListener
{
	public final static String APPCD_KEY = "appCd";
	public final static String NODE_KEY = "node";
	public final static String MAXCNN_KEY = "maxCnnNum";
	public final static String REQQNM_KEY = "reqQName";
	public final static String TIMEOUT_KEY = "timeout";
	public final static String CNNHOLDTIME_KEY = "cnnHoldTime";
	public final static String CNNIDLETIME_KEY = "cnnIdleTime";
	public final static String JVM_KEY = "jvm";
	public final static String JVM_BLOB_BASEDIR = "blobDir";
	public final static String JVM_BLOB_PATH = "blobPath";

	static Log log = Log.getLogger(ESBServletCxtListener.class);

	public void contextDestroyed(ServletContextEvent evt)
	{
		ESB.getInstance().destory();
	}

	/**
	 * <context-param> <param-name>ESBConfig</param-name>
	 * <param-value>hostname=172.16
	 * .1.227&port=651000&cnnHoldTime=300&CCSID=1208&channel=SVRCONN_GWIN
	 * &qmName=QM_GW_IN&appCd=NNS&maxCnnNum=20</param-value> </context-param>
	 * <listener> <listener-class> spc.esb.ESBServletCxtListener
	 * </listener-class> </listener>
	 */
	public void contextInitialized(ServletContextEvent evt)
	{
		log.info("servlet context init...");
		String esbParam = StringX.trim(evt.getServletContext().getInitParameter("ESBConfig"));
		if (StringX.nullity(esbParam))
		{
			log.warn("ESBConfig is null...");
			return;
		}
		else log.info("ESBConfig is " + esbParam);

		Hashtable params = (Hashtable) StringX.str2map(esbParam, esbParam.indexOf('&') >= 0 ? "&"
				: "#", new Hashtable());
		String appCd = (String) params.get(APPCD_KEY);
		String node = (String) params.get(NODE_KEY);
		String maxCnnNum = (String) params.get(MAXCNN_KEY);
		String reqQName = (String) params.get(REQQNM_KEY);
		String timeout = (String) params.get(TIMEOUT_KEY);
		String cnnHoldTime = (String) params.get(CNNHOLDTIME_KEY);
		String cnnIdleTime = (String) params.get(CNNIDLETIME_KEY);
		String jvm = (String) params.get(JVM_KEY);
		String blobDir = (String) params.get(JVM_BLOB_BASEDIR);
		String blobPath = (String) params.get(JVM_BLOB_PATH);
		if (!StringX.nullity(jvm)) ESB.getInstance().setJvm(jvm);
		if (!StringX.nullity(appCd)) ESB.getInstance().setAppCd(appCd);
		if (!StringX.nullity(node)) ESB.getInstance().setNode(node);
		if (!StringX.nullity(reqQName)) ESB.getInstance().setReqQName(reqQName);
		if (!StringX.nullity(maxCnnNum)) ESB.getInstance()
				.setMaxCnnNum(Integer.parseInt(maxCnnNum));
		if (!StringX.nullity(timeout)) ESB.getInstance().setDefTimeout(Integer.parseInt(timeout));
		if (!StringX.nullity(cnnHoldTime)) ESB.getInstance().setCnnHoldTime(
				Integer.parseInt(cnnHoldTime));
		if (!StringX.nullity(cnnIdleTime)) ESB.getInstance().setCnnIdleTime(
				Integer.parseInt(cnnIdleTime));
		if (!StringX.nullity(blobDir)
				&& (ESB.getInstance().getCreator() instanceof DefaultBlobMessageCreator)) ((DefaultBlobMessageCreator) ESB
				.getInstance().getCreator()).setBaseDir(blobDir);
		if (!StringX.nullity(blobPath)
				&& (ESB.getInstance().getCreator() instanceof DefaultBlobMessageCreator)) ((DefaultBlobMessageCreator) ESB
				.getInstance().getCreator()).setPathTemplate(blobPath);

		Hashtable qmProps = new Hashtable(params);
		qmProps.remove(APPCD_KEY);
		qmProps.remove(NODE_KEY);
		qmProps.remove(MAXCNN_KEY);
		qmProps.remove(TIMEOUT_KEY);
		qmProps.remove(CNNHOLDTIME_KEY);
		qmProps.remove(CNNIDLETIME_KEY);
		qmProps.remove(REQQNM_KEY);
		qmProps.remove(JVM_KEY);
		qmProps.remove(JVM_BLOB_BASEDIR);
		qmProps.remove(JVM_BLOB_PATH);
		ESB.getInstance().setProps(qmProps);
		try
		{
			ESB.getInstance().init();
		}
		catch (Exception e)
		{
			log.warn("ESB.init", e);
			throw new RuntimeException(e);
		}
		log.info("ESB endpoint init successfully...");
	}
}
