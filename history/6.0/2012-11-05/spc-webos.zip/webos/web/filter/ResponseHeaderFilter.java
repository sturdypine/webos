package spc.webos.web.filter;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import spc.webos.config.AppConfig;
import spc.webos.constant.Web;

public class ResponseHeaderFilter extends AbstractURLFilter
{
	Map defaultResponseParam;

	public void filter(ServletRequest req, ServletResponse res,
			FilterChain chain, String patternURL) throws IOException,
			ServletException
	{
		chain.doFilter(req, res);
		if (!AppConfig.isProductMode()) return; // ϵͳ����ģʽ�²�ʹ�ÿͻ��˻���
		HttpServletResponse response = (HttpServletResponse) res;
		HttpServletRequest request = (HttpServletRequest) req;
		// �������������ڲ����󣬴˽����Ӧ�ñ��ͻ��˻��档
		Boolean err = (Boolean) request.getAttribute(Web.RESP_ATTR_ERROR_KEY);
		String unCache = request.getParameter(Web.REQ_KEY_UN_CLIENT_CACHE);
		if ((err != null && err.booleanValue())
				|| (unCache != null && unCache.length() > 0))
		{
			// System.out.println("client cache false...");
			response.setHeader("Pragma", "No-cache");
			response.setHeader("Cache-Control", "no-cache");
			response.setDateHeader("Expires", 0);
			return;
		}

		// set the provided HTTP response parameters
		// System.out.println(patternURL+" responseParam = " + responseParam);
		Iterator keySet = defaultResponseParam.keySet().iterator();
		while (keySet.hasNext())
		{ // �ȼ���Ĭ����Ϣ
			String key = (String) keySet.next();
			response.addHeader(key, ((String) defaultResponseParam.get(key))
					.replace('?', '='));
		}
		// �����ض�URI��������Ϣ
		Map paramMap = queryStringToMap(patternURL);
		if (paramMap != null)
		{
			keySet = paramMap.keySet().iterator();
			while (keySet.hasNext())
			{ // �ڼ�������������Ϣ
				String key = (String) keySet.next();
				response.addHeader(key, ((String) paramMap.get(key)).replace(
						'?', '='));
			}
		}
	}

	public void setDefaultResponseParam(Map defaultResponseParam)
	{
		this.defaultResponseParam = defaultResponseParam;
	}
}
