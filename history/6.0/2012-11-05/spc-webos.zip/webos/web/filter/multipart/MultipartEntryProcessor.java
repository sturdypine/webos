package spc.webos.web.filter.multipart;

public interface MultipartEntryProcessor
{
	public void beginEntry(MultipartEntry entry);

	public void addByte(int data);

	public void addBytes(byte[] bytes, int start, int length);

	public void endEntry();

	public void dispose();
}
