package spc.webos.queue.ibmmq;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.queue.IBlobMessageCreator;
import spc.webos.thread.ThreadPool;

import com.ibm.mq.MQException;

public class BlobReceiverThread extends ReceiverThread
{
	protected IBlobMessageCreator creator;

	public BlobReceiverThread()
	{
		super();
	}

	public BlobReceiverThread(ThreadPool pool, Hashtable props, List bufs, Map buf2queueMapping,
			IBlobMessageCreator creator)
	{
		super();
		this.pool = pool;
		this.props = props;
		this.bufs = bufs;
		this.creator = creator;
		this.buf2queueMapping = buf2queueMapping;
	}

	public Object receive(String qname)
	{
		IMessage msg = null;
		try
		{
			mqm.connect(-1);
			// chenjs 2012-05-01 ���ָ���������Ϣ��ȡʱ����ʹ��pmo��MQC.MQGMO_WAIT���ԣ���������ȡ����
			msg = Accessor.receive(mqm, qname, creator, false, null, 0); // gmo.waitInterval
			// added by chenjs 2011-11-17
			msg.setInLocal(MsgLocalKey.ACCEPTOR_PROTOCOL, Common.ACCEPTOR_PROTOCOL_QUEUE_MQ);
			if (((MQAccessTPool) getPool()).getMsgFlow() != null) msg.setInLocal(
					MsgLocalKey.LOCAL_MSG_MSGFLOW, ((MQAccessTPool) getPool()).getMsgFlow());
			if (log.isDebugEnabled()) log.debug("blobmsg:" + msg);
		}
		catch (MQException mqe)
		{
			int ret = Accessor.handleMQException(mqe);
			if (ret == Accessor.MQ_TIME_OUT)
			{
				if (log.isDebugEnabled()) log.debug("qName:" + qname
						+ " has no msg, sleep 1 second...");
				try
				{
					Thread.sleep(1000);
				}
				catch (InterruptedException e)
				{
				}
			}
			else
			{
				log.error("mqe.ret==-1...wait to reconnect..." + qname + ", thread will sleep:"
						+ Accessor.CNN_EXCEPTION_SLEEP + " seconds!!!");
				mqm.disconnect();
				try
				{ // ����Ϣʧ�ܿ����Ƕ��й���������ʧ�ܣ� Ҳ�����Ƕ��й�������û�ж���(���������һ��ֻ�ڿ���ʱ�ڣ�����û���ö�)
					Thread.sleep(Accessor.CNN_EXCEPTION_SLEEP * 1000);
				}
				catch (Exception e)
				{
				}
			}
			return null;
		}
		catch (Exception e)
		{
			log.error("read qName:" + qname + " mq message", e);
			return null;
		}
		return msg;
	}
}
