package spc.webos.queue.ibmmq;

import java.io.IOException;

import spc.webos.constant.AppRetCode;
import spc.webos.constant.Common;
import spc.webos.exception.AppException;
import spc.webos.log.Log;
import spc.webos.queue.IQueueAccess;
import spc.webos.queue.QueueMessage;
import spc.webos.util.StringX;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;

public class QueueAccess implements IQueueAccess
{
	protected MQCnnPool cnnPool;
	protected Log log = Log.getLogger(getClass());
	protected int retryTimes = 0;
	protected int retryInterval = 20;

	public QueueAccess()
	{
	}

	public QueueAccess(MQCnnPool cnnPool)
	{
		this.cnnPool = cnnPool;
	}

	public void destroy()
	{
		cnnPool.destory();
	}

	public void send(String qname, QueueMessage qmsg) throws Exception
	{
		MQManager mqm = (MQManager) cnnPool.borrow();
		try
		{
			if (log.isInfoEnabled()) log.info("sn:" + qmsg.sn + ", corId:"
					+ (qmsg.correlationId != null ? new String(qmsg.correlationId) : ""));
			if (log.isDebugEnabled()) log.debug("req:" + new String(qmsg.buf, Common.CHARSET_UTF8));
			// modifed by chenjs 2011-10-02 ʹ��QueueMessage����toMQMessage����
			// MQMessage reqMQMsg = new MQMessage();
			// reqMQMsg.write(qmsg.buf);
			// // ����ˮ����Ϊmq��Ϣ������
			// if (qmsg.correlationId != null) reqMQMsg.correlationId =
			// qmsg.correlationId;

			Accessor.send(mqm, qname, new MQPutMessageOptions(), qmsg.toMQMessage(new MQMessage()),
					0, 0);
		}
		catch (MQException mqex)
		{
			log.warn("send", mqex);
			if (Accessor.handleMQException(mqex) == Accessor.MQ_CONNECTION_BROKER) mqm.disconnect(); // �����ǰ�쳣�������쳣��ر�����
			throw new AppException(AppRetCode.PROTOCOL_MQ(), new Object[] { qname,
					String.valueOf(mqex.reasonCode), String.valueOf(mqex.completionCode) });
		}
		finally
		{
			cnnPool.release(mqm);
		}
	}

	public QueueMessage receive(String qname, byte[] correlationId, int timeout) throws Exception
	{
		MQManager mqm = (MQManager) cnnPool.borrow();
		try
		{
			MQMessage resMQMsg = new MQMessage();
			MQGetMessageOptions gmo = new MQGetMessageOptions();
			gmo.options = MQC.MQGMO_WAIT;
			if (timeout > 0) gmo.waitInterval = timeout * 1000;
			if (correlationId != null)
			{
				gmo.matchOptions = MQC.MQMO_MATCH_CORREL_ID;
				resMQMsg.correlationId = correlationId;
			}
			Accessor.receive(mqm, qname, gmo, resMQMsg);
			byte[] buf = new byte[resMQMsg.getDataLength()];
			resMQMsg.readFully(buf);
			if (log.isDebugEnabled()) log.debug("res:" + new String(buf));
			return new QueueMessage(buf, resMQMsg.correlationId, resMQMsg.messageId);
		}
		catch (MQException mqex)
		{
			log.warn("send", mqex);
			if (Accessor.handleMQException(mqex) == Accessor.MQ_CONNECTION_BROKER) mqm.disconnect(); // �����ǰ�쳣�������쳣��ر�����
			throw new AppException(AppRetCode.PROTOCOL_MQ(), new Object[] { qname,
					String.valueOf(mqex.reasonCode), String.valueOf(mqex.completionCode) });
		}
		catch (IOException ioe)
		{
			throw new AppException(AppRetCode.NET_COMMON(), ioe);
		}
		finally
		{
			cnnPool.release(mqm);
		}
	}

	public QueueMessage execute(String reqQName, String repQName, QueueMessage qmsg, int timeout)
			throws Exception
	{
		MQManager mqm = (MQManager) cnnPool.borrow();
		try
		{
			byte[] corId = qmsg.correlationId; // ����ˮ����Ϊmq��Ϣ������
			if (log.isInfoEnabled()) log.info("start to send sn:" + qmsg.sn + ", timeout:"
					+ timeout);
			MQMessage reqMQMsg = new MQMessage();
			reqMQMsg.write(qmsg.buf);
			// ��������˳�ʱʱ�䡣����Ϣ����ȡ��ʱ��Ӧ���г�ʱʱ�䣬MQ����Ϣ��Чʱ��Ϊ100����
			// if (qmsg.expirySeconds > 0) reqMQMsg.expiry = qmsg.expirySeconds
			// * 10;

			if (log.isDebugEnabled()) log.debug("req:" + new String(qmsg.buf));
			if (corId != null) reqMQMsg.correlationId = corId;
			if (qmsg.expirySeconds > 0) reqMQMsg.expiry = qmsg.expirySeconds * 10; // 2012-11-01
																					// ������Ϣ�ĳ�ʱʱ��
			long start = 0;
			Accessor.send(mqm, reqQName, new MQPutMessageOptions(), reqMQMsg, retryTimes,
					retryInterval); // ������Ϣ
			if (StringX.nullity(repQName)) // added by spc 2011-03-11
											// ���Ӧ�����Ϊ�գ����ʾ����Ҫ����
			{
				log.info("repQName is null!!!");
				return null;
			}
			if (log.isInfoEnabled())
			{
				start = System.currentTimeMillis();
				log.info("success send sn:" + qmsg.sn);
			}

			// ���ݹ������ù�������Ϣ
			MQMessage repMQMsg = new MQMessage();
			MQGetMessageOptions gmo = new MQGetMessageOptions();
			gmo.options = MQC.MQGMO_WAIT;
			gmo.waitInterval = timeout * 1000;
			gmo.matchOptions = MQC.MQMO_MATCH_CORREL_ID;
			repMQMsg.correlationId = corId;
			Accessor.receive(mqm, repQName, gmo, repMQMsg);
			if (log.isInfoEnabled())
			{
				long end = System.currentTimeMillis();
				log.info("corId:" + new String(corId) + ", cost:" + (end - start) + ","
						+ (end - repMQMsg.putDateTime.getTimeInMillis()));
			}
			byte[] buf = new byte[repMQMsg.getDataLength()];
			repMQMsg.readFully(buf);
			if (log.isDebugEnabled()) log.debug("rep buf:" + new String(buf));
			return new QueueMessage(buf, repMQMsg.correlationId, repMQMsg.messageId);
		}
		catch (MQException mqex)
		{
			log.warn("QueueAccess: reqQName:" + reqQName + ", repQName:" + repQName, mqex);
			if (Accessor.handleMQException(mqex) == Accessor.MQ_CONNECTION_BROKER) mqm.disconnect(); // �����ǰ�쳣�������쳣��ر�����
			throw new AppException(AppRetCode.PROTOCOL_MQ(), new Object[] { repQName,
					String.valueOf(mqex.reasonCode), String.valueOf(mqex.completionCode) });
		}
		catch (Throwable t)
		{
			throw new AppException(AppRetCode.NET_COMMON(), t);
		}
		finally
		{
			cnnPool.release(mqm);
		}
	}

	/**
	 * ���ĳ�����У�����������������Ϣ��һЩ�Զ����ƣ����糬ʱת���ȵ�
	 * 
	 * @param qname
	 * @param gmo
	 * @throws Exception
	 */
	public void browse(String qname, MQGetMessageOptions gmo) throws Exception
	{
		MQManager mqm = (MQManager) cnnPool.borrow();
		MQQueue queue = null;
		try
		{
			queue = mqm.accessQueue(qname, MQC.MQOO_BROWSE);
			queue.get(new MQMessage(), gmo);
		}
		finally
		{
			cnnPool.release(mqm);
			mqm.closeQueue();
		}
	}

	public void setCnnPool(MQCnnPool cnnPool)
	{
		this.cnnPool = cnnPool;
	}

	public int getRetryTimes()
	{
		return retryTimes;
	}

	public void setRetryTimes(int retryTimes)
	{
		this.retryTimes = retryTimes;
	}

	public int getRetryInterval()
	{
		return retryInterval;
	}

	public void setRetryInterval(int retryInterval)
	{
		this.retryInterval = retryInterval;
	}
}
