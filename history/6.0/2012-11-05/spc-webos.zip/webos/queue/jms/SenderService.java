package spc.webos.queue.jms;

import java.util.HashMap;
import java.util.Map;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.springframework.jms.connection.SingleConnectionFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import spc.webos.cluster.IClusterService;
import spc.webos.cluster.ServiceException;
import spc.webos.data.IMessage;

public class SenderService implements IClusterService
{
	String name;
	String destination;
	JmsTemplate jms;
	boolean available = true;
	public static final ThreadLocal EAI_MSG = new ThreadLocal(); // ��ǰ�߳�Ҫ���͵�eaimsg

	public String getDestination()
	{
		return destination;
	}

	public String getName()
	{
		return destination;
	}

	public void setDestination(String destination)
	{
		this.destination = destination;
	}

	public JmsTemplate getJms()
	{
		return jms;
	}

	public void setJms(JmsTemplate jms)
	{
		this.jms = jms;
	}

	public boolean available()
	{
		return available;
	}

	// ���½�������
	public void refresh()
	{
		SingleConnectionFactory factory = (SingleConnectionFactory) jms
				.getConnectionFactory();
		factory.resetConnection();
		available = true;
	}

	public Object execute(Object req)
	{
		EAI_MSG.set(req);
		try
		{
			jms.send(destination, new MessageCreator()
			{
				public Message createMessage(Session session)
						throws JMSException
				{
					BytesMessage msg = session.createBytesMessage();
					try
					{
						IMessage esbmsg = (IMessage) EAI_MSG.get();
						msg.writeBytes(esbmsg.toByteArray(false));
						// ����ˮ����Ϊ������
						msg.setJMSCorrelationID(esbmsg.getMsgSn());
					}
					catch (Exception e)
					{
						throw new JMSException("Fail:eaiMsg.toByteArray");
					}
					return msg;
				}
			});
			return req;
		}
		catch (Exception e)
		{
			available = false;
			throw new ServiceException(e);
		}
		finally
		{
			EAI_MSG.set(null); // ��������
		}
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public void init() throws Exception
	{
	}

	public boolean changeStatus(Map param)
	{
		return false;
	}

	public Map checkStatus(Map param)
	{
		return new HashMap();
	}
}
