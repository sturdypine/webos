package spc.webos.data.util;

import java.util.HashMap;
import java.util.Map;

import spc.webos.data.IArrayNode;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.data.INode;
import spc.webos.model.MsgSchemaVO;

/**
 * ����ڵ�͸��ӽڵ�ת��
 * 
 * @author chenjs
 * 
 */
public interface INodeConverter
{
	/**
	 * ����������ڵ�ת��Ϊ����ڵ����ͷ���
	 * 
	 * @param msg
	 * @param src
	 * @param schema
	 * @param esb2rcv
	 * @param pnode
	 * @param path
	 * @param tpnode
	 * @return
	 * @throws Exception
	 */
	INode converter(IMessage msg, INode src, MsgSchemaVO schema, boolean esb2rcv,
			ICompositeNode pnode, String path, ICompositeNode tpnode) throws Exception;

	final static Map CONVERTERS = new HashMap();
}
