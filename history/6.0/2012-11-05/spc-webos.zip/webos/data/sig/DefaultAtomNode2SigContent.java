package spc.webos.data.sig;

import spc.webos.data.IAtomNode;
import spc.webos.data.IMessage;
import spc.webos.data.INode;
import spc.webos.log.Log;
import spc.webos.model.MsgSchemaVO;
import spc.webos.util.StringX;

public class DefaultAtomNode2SigContent implements INode2SigContent
{
	protected Log log = Log.getLogger(getClass());

	public String sigCnt(IMessage msg, String nodeCd, INode value, MsgSchemaVO schema)
	{
		return value == null ? StringX.EMPTY_STRING : StringX.trim(((IAtomNode) value)
				.stringValue());
	}

	public void init() throws Exception
	{
		if (INode2SigContent.SIGS.containsKey(name)) log.warn("IAtomNodeSigContent(" + name
				+ ") repeated!!!");
		INode2SigContent.SIGS.put(name, this);
	}

	protected String name = "Y";

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}
}
