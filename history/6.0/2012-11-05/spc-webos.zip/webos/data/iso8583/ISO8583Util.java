package spc.webos.data.iso8583;

import java.util.List;

import spc.webos.data.CompositeNode;
import spc.webos.data.FixedMessage;
import spc.webos.data.IAtomNode;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.log.Log;
import spc.webos.model.MsgSchemaVO;
import spc.webos.util.StringX;
import spc.webos.util.tree.TreeNode;

public class ISO8583Util
{
	protected static Log log = Log.getLogger(ISO8583Util.class);

	// ��ñ�׼iso8583�Ľ�����, field 3: ����Ϊ6
	public static byte[] getTranCode(byte[] buf, int offset)
	{
		return getTranCode(buf, offset, 22, 6);
	}

	public static byte[] getTranCode(byte[] buf, int offset, int offLen, int tranCdLen)
	{
		BitMap bitmap = new BitMap(buf);
		if (offset > 0)
		{ // �����ƫ���������¹���bitmapλͼ��Ϣ
			byte[] hdr = new byte[8];
			System.arraycopy(buf, offset, hdr, 0, 8);
			bitmap = new BitMap(hdr);
		}
		int start = bitmap.isValid(0) ? 16 : 8; // ��64λͼ����128λͼ
		start += offLen; // ��׼�ڶ�����Ϊ22�ֽڳ������ʺ�PRIMARY ACCOUNT NUMBER
		return FixedMessage.read(buf, offset, start, tranCdLen); // �ʺ�Ϊ6���ֽ�
	}

	/**
	 * �������Ʊ��İ�תΪ�м��ISO8583Message���İ�
	 * 
	 * @param buf
	 * @param offset
	 * @param len
	 * @param msg
	 * @return
	 * @throws Exception
	 */
	public static ISO8583Message deserialize2iso8583(IISO8583MessageConverter iso8583MsgConverter,
			byte[] buf, int offset, int len, IMessage msg, TreeNode schema) throws Exception
	{
		ISO8583Message iso8583msg = new ISO8583Message();
		List child = schema.getChildren();
		for (int i = 0; i < child.size(); i++)
		{
			TreeNode tnode = (TreeNode) child.get(i);
			MsgSchemaVO schemaVO = (MsgSchemaVO) tnode.getTreeNodeValue();
			Field f = new Field(schemaVO);
			iso8583msg.setField(f);
		}
		iso8583MsgConverter.deserialize(iso8583msg, buf, offset);
		if (log.isDebugEnabled()) log.debug("deserialize2iso8583: " + iso8583msg);
		return iso8583msg;
	}

	public static ICompositeNode deserialize(ISO8583Message iso8583msg, TreeNode schema)
			throws Exception
	{
		CompositeNode cnode = new CompositeNode();
		List child = schema.getChildren();
		for (int i = 0; i < child.size(); i++)
		{
			TreeNode tnode = (TreeNode) child.get(i);
			MsgSchemaVO schemaVO = (MsgSchemaVO) tnode.getTreeNodeValue();
			int[] iso8583 = StringX.split2ints(schemaVO.getIso8583(), "|");
			// modified by chenjs 2011-11-10
			int no = iso8583[0]; // Integer.parseInt(schemaVO.getRcvName());
			Field f = iso8583msg.getField(no);
			if (f != null && f.enabled) cnode.set(schemaVO.getEsbName(), f.value);
		}
		return cnode;
	}

	/**
	 * ��һ��8583���ĸ�����Ԥ�ڵı��Ľṹת��Ϊһ��cnode�ڵ�
	 * 
	 * @param iso8583
	 * @param offset
	 * @param len
	 * @param reqmsg
	 * @param schema
	 * @return
	 * @throws Exception
	 */
	public static ICompositeNode deserialize(IISO8583MessageConverter iso8583MsgConverter,
			byte[] iso8583, int offset, int len, IMessage msg, TreeNode schema) throws Exception
	{
		return deserialize(
				deserialize2iso8583(iso8583MsgConverter, iso8583, offset, len, msg, schema), schema);
	}

	public static ICompositeNode deserialize(IISO8583MessageConverter iso8583MsgConverter,
			byte[] iso8583, TreeNode schema) throws Exception
	{
		return deserialize(
				deserialize2iso8583(iso8583MsgConverter, iso8583, 0, iso8583.length, null, schema),
				schema);
	}

	/**
	 * ��һ�����ӽڵ�����䱨�Ľṹת��Ϊһ��8583�ṹ
	 * 
	 * @param cnode
	 * @param schema
	 * @return
	 * @throws Exception
	 */
	public static ISO8583Message serialize2iso8583(ICompositeNode cnode, TreeNode schema)
			throws Exception
	{
		ISO8583Message iso8583msg = new ISO8583Message();
		List child = schema.getChildren();
		for (int i = 0; i < child.size(); i++)
		{
			TreeNode tnode = (TreeNode) child.get(i);
			MsgSchemaVO schemaVO = (MsgSchemaVO) tnode.getTreeNodeValue();
			IAtomNode anode = (IAtomNode) cnode.getNode(schemaVO.getEsbName());
			if (anode == null || StringX.nullity(anode.stringValue()))
			{
				if (log.isDebugEnabled()) log.debug("esbNm:" + schemaVO.getEsbName()
						+ " is null...");
				continue;
			}
			Field f = new Field(schemaVO);
			f.setValue(anode.stringValue());
			iso8583msg.setField(f);
		}
		return iso8583msg;
	}

	public static byte[] serialize(IISO8583MessageConverter iso8583MsgConverter,
			ICompositeNode cnode, TreeNode schema) throws Exception
	{
		ISO8583Message iso8583msg = serialize2iso8583(cnode, schema);
		return iso8583MsgConverter.serialize(iso8583msg);
	}
}
