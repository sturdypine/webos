package spc.webos.timeout.service.impl;

import java.util.List;

import spc.webos.service.Service;
import spc.webos.timeout.service.ITimeoutService;
import spc.webos.timeout.service.ITimeoutHandlerService;
import spc.webos.timeout.service.ITimeoutJobService;
import spc.webos.timeout.service.Timeout;

public class TimeoutJobService extends Service implements ITimeoutJobService
{
	public void timeout() throws Exception
	{
		List timeouts = timeoutFinderService.find();
		while (timeouts != null && timeouts.size() > 0)
		{
			for (int i = 0; i < timeouts.size(); i++)
			{
				Timeout timeout = (Timeout) timeouts.get(i);
				if (timeoutFinderService.remove(timeout))
				{
					if (log.isInfoEnabled()) log
							.info("start to handle timeout: " + timeout.getSn());
					try
					{
						timeoutHandlerService.doTimeout(timeout);
					}
					catch (Throwable t)
					{
						log.warn("handler err for " + timeout, t);
					}
				}
				else if (log.isInfoEnabled()) log
						.info("fail to remove timeout: " + timeout.getSn());
			}
			// ѭ��������ֱ��û�г�ʱ��Ϣ�����
			timeouts = timeoutFinderService.find();
		}
	}

	protected ITimeoutService timeoutFinderService;
	protected ITimeoutHandlerService timeoutHandlerService;

	public void setTimeoutFinderService(ITimeoutService timeoutFinderService)
	{
		this.timeoutFinderService = timeoutFinderService;
	}

	public void setTimeoutHandlerService(ITimeoutHandlerService timeoutHandlerService)
	{
		this.timeoutHandlerService = timeoutHandlerService;
	}
}
