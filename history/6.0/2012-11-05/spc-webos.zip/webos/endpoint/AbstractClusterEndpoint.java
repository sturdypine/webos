package spc.webos.endpoint;

import spc.webos.log.Log;

/**
 * ��Ⱥcluster
 * 
 * @author spc
 * 
 */
public abstract class AbstractClusterEndpoint implements Endpoint
{
	public void init() throws Exception
	{
	}

	protected boolean execute(Endpoint endpoint, Executable exe, int failCount) throws Exception
	{
		try
		{
			endpoint.execute(exe);
			return true;
		}
		catch (Exception e)
		{
			if (log.isInfoEnabled()) log.info("exExit:" + exExit + ", cnnSnd: " + exe.cnnSnd
					+ ", failCount:" + failCount + ", retryTimes:" + retryTimes + ", e:" + e);
			if (exExit || !isClusterRetry(exe, e) || failCount >= retryTimes) throw e;
			if (retryInterval > 0) Thread.sleep(retryInterval);
		}
		return false;
	}

	protected boolean isClusterRetry(Executable exe, Exception e)
	{ // ����Ѿ����ͳɹ���ʹ�ü�Ⱥ�������·���
		return !exe.cnnSnd;
	}

	public Endpoint clone() throws CloneNotSupportedException
	{
		throw new CloneNotSupportedException();
	}

	protected boolean exExit; // �쳣ֱ���˳�
	protected int retryInterval;
	protected int retryTimes;
	protected Log log = Log.getLogger(getClass());

	public int getRetryInterval()
	{
		return retryInterval;
	}

	public void setRetryInterval(int retryInterval)
	{
		this.retryInterval = retryInterval;
	}

	public void setRetryTimes(int retryTimes)
	{
		this.retryTimes = retryTimes;
	}

	public boolean isExExit()
	{
		return exExit;
	}

	public void setExExit(boolean exExit)
	{
		this.exExit = exExit;
	}

	public int getRetryTimes()
	{
		return retryTimes;
	}
}
