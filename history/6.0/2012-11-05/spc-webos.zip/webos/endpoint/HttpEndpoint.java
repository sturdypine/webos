package spc.webos.endpoint;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.InputStreamRequestEntity;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;

import spc.webos.constant.AppRetCode;
import spc.webos.exception.AppException;
import spc.webos.log.Log;
import spc.webos.util.FileUtil;
import spc.webos.util.StringX;

public class HttpEndpoint implements Endpoint
{
	public synchronized void execute(Executable exe) throws Exception
	{
		int count = 0;
		long start = 0;
		if (log.isInfoEnabled())
		{
			log.info("http start corId:" + exe.getCorrelationID() + ", timeout:" + exe.getTimeout()
					+ ",url:" + url + ", buf:" + exe.getRequest().length);
			start = System.currentTimeMillis();
		}
		int statusCode = -1;
		do
		{
			try
			{
				init();
				RequestEntity entity = new InputStreamRequestEntity(new ByteArrayInputStream(
						exe.getRequest()));
				pm.setRequestEntity(entity);
				statusCode = client.executeMethod(pm);
				if (statusCode != HttpStatus.SC_OK)
				{ // net fail...
					log.error("net error:" + url + ", code:" + statusCode);
					throw new AppException(AppRetCode.PROTOCOL_HTTP(), new Object[] { new Integer(
							statusCode) });
				}
				// ������Ӧ��Ϣ
				InputStream is = pm.getResponseBodyAsStream();
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				FileUtil.is2os(is, baos, false, false);
				byte[] repbuf = baos.toByteArray();
				if (log.isInfoEnabled()) log.info("res from server:len=" + repbuf.length
						+ ", cost:" + (System.currentTimeMillis() - start));
				if (log.isDebugEnabled()) log.debug("rep buf:" + new String(repbuf));
				exe.setResponse(repbuf);
			}
			catch (IOException ioe)
			{
				destory();
				log.error("net error:" + url + ", code:" + statusCode + ", reqbytes base64: "
						+ new String(StringX.encodeBase64(exe.request)), ioe);
				if (retryTimes <= count) throw new AppException(AppRetCode.PROTOCOL_HTTP(),
						new Object[] { url, new Integer(statusCode) });
			}
			finally
			{
				count++;
				destory();
			}
		}
		while (retryTimes > count);
	}

	public void init() throws Exception
	{
		refresh();
	}

	public void refresh()
	{
		destory();
		pm = new PostMethod(url);
		pm.setRequestHeader("Connection", "Keep-Alive");
		client.getHttpConnectionManager().getParams().setConnectionTimeout(5000);
	}

	public void setUrl(String url)
	{
		this.url = url;
	}

	public void destory()
	{
		try
		{
			if (pm != null) pm.releaseConnection();
			pm = null;
		}
		catch (Exception e)
		{
		}
	}

	public Endpoint clone() throws CloneNotSupportedException
	{
		HttpEndpoint he = new HttpEndpoint();
		he.url = url;
		he.retryTimes = retryTimes;
		return he;
	}

	public void setRetryTimes(int retryTimes)
	{
		this.retryTimes = retryTimes;
	}

	protected String url; // ��̨url��ַ
	protected HttpClient client = new HttpClient();
	protected PostMethod pm;
	protected int retryTimes = 1; // ���Դ���Ĭ��Ϊ����һ��
	protected Log log = Log.getLogger(getClass());
}
