package spc.webos.service.common.impl;

import spc.webos.constant.Common;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.data.Message;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.data.converter.XMLConverter2;
import spc.webos.endpoint.ESB;
import spc.webos.service.Service;
import spc.webos.service.common.IESBService;
import spc.webos.util.StringX;

public class ESBService extends Service implements IESBService
{
	protected int timeout = 30;
	protected String charset = Common.CHARSET_UTF8;
	protected ESB esb = ESB.getInstance();
	protected IMessageConverter messageConverter = XMLConverter2.getInstance();

	public ICompositeNode execute(ICompositeNode transaction) throws Exception
	{
		transaction.applyIf(esb.newMessage().getTransaction());
		Message reqmsg = new Message(transaction);
		String callType = reqmsg.getCallType();
		if (StringX.nullity(callType)) reqmsg.setCallType(IMessage.CALLTYP_SYN);
		IMessage repmsg = esb.execute(reqmsg, timeout);
		return repmsg.getTransaction();
	}

	public String esb(String reqXml) throws Exception
	{
		IMessage reqmsg = messageConverter.deserialize(reqXml.getBytes(charset));
		reqmsg.getTransaction().applyIf(esb.newMessage().getTransaction());
		String callType = reqmsg.getCallType();
		if (StringX.nullity(callType)) reqmsg.setCallType(IMessage.CALLTYP_SYN);
		IMessage repmsg = esb.execute(reqmsg, timeout);
		return new String(messageConverter.serialize(repmsg), charset);
	}

	public void setTimeout(int timeout)
	{
		this.timeout = timeout;
	}

	public void setEsb(ESB esb)
	{
		this.esb = esb;
	}

	public void setMessageConverter(IMessageConverter messageConverter)
	{
		this.messageConverter = messageConverter;
	}

	public void setCharset(String charset)
	{
		this.charset = charset;
	}
}
