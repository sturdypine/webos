package spc.webos.service.common.impl;

import java.util.Map;

import spc.webos.cache.Ehcache;
import spc.webos.data.IMessage;
import spc.webos.service.Service;
import spc.webos.service.common.ISeqNoService;
import spc.webos.util.StringX;

/**
 * ͨ��Ecache�ĳ־û����ܴ���ϴ���ˮ����Ϣ
 * 
 * @author spc
 * 
 */
public class EhcacheSeqNoService extends Service implements ISeqNoService
{
	public synchronized String rndoGenSN(String key, IMessage msg, Map params) throws Exception
	{
		SequenceInfo seqInfo = (SequenceInfo) cache.get(key);
		if (seqInfo == null)
		{
			log.warn("cannot find seqinfo in cache for " + key);
			seqInfo = (SequenceInfo) seqInfos.get(key);
			if (seqInfo == null) return null;
		}
		String sn = String.valueOf(seqInfo.current);
		next(seqInfo);
		cache.put(key, seqInfo);
		cache.get(DUMB_KEY);
		return sn;
	}

	protected void next(SequenceInfo seqInfo)
	{
		seqInfo.current += seqInfo.step;
		if (seqInfo.current > seqInfo.max) seqInfo.current = seqInfo.min;
	}

	public void init() throws Exception
	{
		super.init();
		cache.put(DUMB_KEY, StringX.EMPTY_STRING);
	}

	Ehcache cache;
	Map seqInfos;
	public final static String DUMB_KEY = "_DUMB_";

	public void setCache(Ehcache cache)
	{
		this.cache = cache;
	}

	public Map getSeqInfos()
	{
		return seqInfos;
	}

	public void setSeqInfos(Map seqInfos)
	{
		this.seqInfos = seqInfos;
	}
}
