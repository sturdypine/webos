package spc.webos.jdbc.converter;

import spc.webos.data.converter.XMLConverter;

/**
 * �����ݿ��xml���ͱ�Ϊcompositenode����
 * 
 * @author spc
 * 
 */
public class XmlColumnConverter extends AbstractColumnConverter
{
	public Object convert(String column, Object value)
	{
		if (value == null) return null;
		try
		{
			String xml = value.toString();
			if (xml.length() == 0) return null;
			return XMLConverter.getInstance().deserialize2composite(
					xml.getBytes());
		}
		catch (Exception e)
		{
			return new RuntimeException(e);
		}
	}

	private XmlColumnConverter()
	{
		name = "XML";
		init();
	}

	public static XmlColumnConverter getInstance()
	{
		return XCC;
	}

	static XmlColumnConverter XCC = new XmlColumnConverter();
}
