package spc.webos.constant;

/**
 * Message ����key
 * 
 * @author spc
 * 
 */
public class MsgKey
{
	public final static String RES_RESULT = "result";
	public final static String RES_ALLOCATE_SN = "sn";
	public final static String RES_ALLOCATE_KEY = "key";
	public final static String RES_ALLOCATE_HOLD_TIME = "holdTm";
	public final static String RES_ALLOCATE_TIMEOUT = "timeout";
	public final static String RES_ALLOCATE_MATCH_TYPE = "matchType";
	public final static String RES_WITHOUTRETURN = "withoutReturn";
}
