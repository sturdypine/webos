package spc.webos.queue.ibmmq;

import java.io.UnsupportedEncodingException;
import java.util.Hashtable;

import spc.webos.buffer.IBuffer;
import spc.webos.constant.Common;
import spc.webos.queue.AbstractReceiverThread;
import spc.webos.queue.AccessTPool;
import spc.webos.queue.IOnMessage;
import spc.webos.queue.QueueMessage;
import spc.webos.thread.ThreadPool;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;

public class ReceiverThread extends AbstractReceiverThread
{
	protected MQGetMessageOptions gmo = new MQGetMessageOptions();
	protected MQManager mqm;

	public ReceiverThread()
	{
		super();
	}

	public ReceiverThread(ThreadPool pool, Hashtable props, String bufferName, IBuffer buf,
			String qname)
	{
		super();
		this.pool = pool;
		this.props = props;
		this.bufferName = bufferName;
		this.buf = buf;
		this.qname = qname;
	}

	public ReceiverThread(ThreadPool pool, Hashtable props, String bufferName, IBuffer buf,
			String qname, IOnMessage onMessage, byte[] messageId)
	{
		super();
		this.pool = pool;
		this.props = props;
		this.bufferName = bufferName;
		this.buf = buf;
		this.qname = qname;
		this.onMessage = onMessage;
		this.messageId = messageId;
	}

	public void release()
	{
		super.release();
		mqm.disconnect();
	}

	public void init() throws Exception
	{
		super.init();
		Object ccsid = props.get(MQC.CCSID_PROPERTY);
		if (ccsid instanceof String) props.put(MQC.CCSID_PROPERTY, new Integer((String) ccsid));
		Object port = props.get(MQC.PORT_PROPERTY);
		if (port instanceof String) props.put(MQC.PORT_PROPERTY, new Integer((String) port));

		// ����timeout��ʱ�䣬��λ����
		gmo.options = MQC.MQGMO_WAIT;
		if (((MQAccessTPool) pool).getWaitInterval() > 0) gmo.waitInterval = ((MQAccessTPool) pool)
				.getWaitInterval();
		else gmo.waitInterval = MQAccessTPool.DEFAULT_WAIT_INTERVAL;
		// if(bufs.size()== 1)
		// else gmo.waitInterval = MQAccessTPool.DEFAULT_MUL_WAIT_INTERVAL;
		// 701 2013-09-12 ���Ի���msgIdƥ��
		if (messageId != null) gmo.matchOptions = MQC.MQMO_MATCH_MSG_ID;

		if (mqm == null) mqm = new MQManager(props, ((AccessTPool) pool).getCnnHoldTime());
		// modified by 2011-07-30 chenjs Ϊ�˸��õĸ��أ�������֣����ܺ��������ӵõ�����Ϣ��
		// modified by spc 2010-12-16 Ϊ��������ܣ����رն��ж���
		// modified by chenjs 2012-07-27 Ϊ���Ա��ֶԶ��е�OPEN״̬
		mqm.keepQueue = ((AccessTPool) pool).isKeepQueue();
		refresh();
	}

	public void refresh() throws Exception
	{
		super.refresh();
		mqm.reconnect(-1);
	}

	public Object receive(String qname)
	{
		MQMessage mqmsg = new MQMessage();
		// 701 2013-09-12 ��������msgIdƥ���ȡ��Ϣ
		if (messageId != null) mqmsg.messageId = messageId;
		QueueMessage qmsg = null;
		try
		{
			mqm.connect(-1);
			Accessor.receive(mqm, qname, gmo, mqmsg);
			// qmsg = new QueueMessage(mqmsg, qname);
			// modified by chenjs 2012-11-29 ֧��TLQ���Ƴ�QueueMessage�����MQMessage����
			qmsg = MQMessageUtil.createQMsg(mqmsg, qname);
			qmsg.qmprops = mqm.getCurrentProps(); // 2012-07-31 ������Ϣ��Դ�Ķ��й�������Ϣ
		}
		catch (MQException mqe)
		{
			if (Accessor.handleMQException(mqe) == Accessor.MQ_TIME_OUT)
			{
				// if (log.isDebugEnabled()) log.debug("qName:" + qname +
				// " has no msg");
			}
			else
			{
				log.error("mqe.ret==-1...wait to reconnect..." + qname + ", thread will sleep:"
						+ Accessor.CNN_EXCEPTION_SLEEP + " seconds!!!", mqe);
				mqm.disconnect();
				try
				{ // ����Ϣʧ�ܿ����Ƕ��й���������ʧ�ܣ� Ҳ�����Ƕ��й�������û�ж���(���������һ��ֻ�ڿ���ʱ�ڣ�����û���ö�)
					Thread.sleep(Accessor.CNN_EXCEPTION_SLEEP * 1000);
				}
				catch (Exception e)
				{
				}
			}
			return null;
		}
		catch (Exception e)
		{
			log.error("read qName:" + qname + " mq message", e);
			return null;
		}

		try
		{
			if (((MQAccessTPool) pool).isCorrelation()) qmsg.correlationId = mqmsg.messageId; // ���ù�����
			else qmsg.correlationId = mqmsg.correlationId; // ���ù�����
			return qmsg;
		}
		catch (Exception e)
		{
			try
			{
				log.error("in utf-8:" + new String(qmsg.buf, Common.CHARSET_UTF8), e);
			}
			catch (UnsupportedEncodingException e1)
			{
				log.warn("UnsupportedEncodingException for utf-8", e1);
			}
		}
		return null;
	}
}
