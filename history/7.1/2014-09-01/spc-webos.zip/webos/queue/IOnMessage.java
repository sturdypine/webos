package spc.webos.queue;

public interface IOnMessage
{
	void onMessage(Object obj, AccessTPool pool, AbstractReceiverThread thread) throws Exception;
}
