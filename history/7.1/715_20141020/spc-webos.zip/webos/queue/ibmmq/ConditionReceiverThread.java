package spc.webos.queue.ibmmq;

import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;

import spc.webos.buffer.IBuffer;
import spc.webos.cache.ICache;
import spc.webos.log.Log;
import spc.webos.queue.AccessThread;
import spc.webos.queue.MessageID;
import spc.webos.queue.QueueMessage;
import spc.webos.thread.ThreadPool;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;

/**
 * ������ȡ��������ȡָ������Ϣ��һ��������ȡ������Ϣ����Ӧ��Ϣ��������Ϣ����������Ϣ��messageId��
 * 
 * @author spc
 * 
 */
public class ConditionReceiverThread extends AccessThread
{
	protected ICache msgIdCache;
	protected IBuffer msgBuf;
	protected MQGetMessageOptions gmo = new MQGetMessageOptions();
	protected Hashtable props;
	protected MQQueueManager qm;
	protected MQQueue queue;

	public ConditionReceiverThread(ThreadPool pool, Hashtable props, IBuffer msgBuf,
			ICache msgIdCache)
	{
		super();
		this.pool = pool;
		this.props = props;
		this.msgBuf = msgBuf;
		this.msgIdCache = msgIdCache;
	}

	public void execute() throws Exception
	{
		startThreadLog();
		int receiveNum = 0; // ����������������ִ��û�з��͵���Ϣ��˯�ߣ������������
		Collection c = msgIdCache.getKeys();
		Iterator keys = c.iterator();
		if (log.isDebugEnabled()) log.debug("keys:" + c);
		while (keys != null && keys.hasNext())
		{
			Object key = keys.next();
			MessageID msgID = (MessageID) msgIdCache.get(key);
			if (receive(msgID)) receiveNum++;
		}
		if (receiveNum == 0) Thread.sleep(100);
		Log.print();
	}

	public boolean receive(MessageID msgID)
	{
		if (msgID == null) return false;
		int read = msgID.read(getPoolName());
		if (log.isInfoEnabled()) log.info("read flag=" + read + ",ID=" + msgID.toString());
		if (read != 0) return false;
		MQMessage mqMsg = new MQMessage();
		mqMsg.correlationId = msgID.getMessageId(); // ���ù�����Ϣ
		try
		{
			if (qm == null) qm = Accessor.connect(qm, props, -1);
			if (queue == null) queue = qm.accessQueue(msgBuf.getName(), MQC.MQOO_INPUT_AS_Q_DEF);
			queue.get(mqMsg, gmo);
			byte[] buf = new byte[mqMsg.getMessageLength()];
			mqMsg.readFully(buf);
			if (log.isDebugEnabled()) log.debug("buf:" + new String(buf));
			// msg = ((MQAccessTPool) pool).getConverter().deserialize(buf);
			msgID.markRead();
			msgBuf.put(new QueueMessage(buf, msgID.getMessageId(), null));
			msgIdCache.remove(msgID.getTransSN());
			if (log.isInfoEnabled()) log.info("success read:" + msgID.toString());
			return true;
		}
		catch (MQException mqe)
		{
			int ret = Accessor.handleMQException(mqe);
			if (ret == Accessor.MQ_CONNECTION_BROKER)
			{
				log.error("mqe.ret==-1...wait to reconnect...");
				qm = Accessor.connect(qm, props, -1);
			}
		}
		catch (Exception e)
		{
			log.error("receive", e);
		}
		finally
		{
			msgID.release(getPoolName());
		}
		return false;
	}

	public void release()
	{
		super.release();
		try
		{
			if (queue != null) queue.close();
		}
		catch (Exception e)
		{
		}
		try
		{
			if (qm != null) qm.close();
		}
		catch (Exception e)
		{
			log.warn("thread release", e);
		}
		queue = null;
		qm = null;
	}

	public void init() throws Exception
	{
		gmo.matchOptions = MQC.MQMO_MATCH_CORREL_ID;
		gmo.options = MQC.MQGMO_WAIT;
		refresh();
	}

	public void refresh() throws Exception
	{
		super.refresh();
		Object ccsid = props.get(MQC.CCSID_PROPERTY);
		if (ccsid instanceof String) props.put(MQC.CCSID_PROPERTY, new Integer((String) ccsid));
		Object port = props.get(MQC.PORT_PROPERTY);
		if (port instanceof String) props.put(MQC.PORT_PROPERTY, new Integer((String) port));

		// ����timeout��ʱ�䣬��λ����
		gmo.waitInterval = ((MQAccessTPool) pool).getWaitInterval();
	}

	public void setMsgIdCache(ICache msgIdCache)
	{
		this.msgIdCache = msgIdCache;
	}

	public Hashtable getProps()
	{
		return props;
	}

	public void setMsgBuf(IBuffer msgBuf)
	{
		this.msgBuf = msgBuf;
	}

	public void setProps(Hashtable props)
	{
		this.props = props;
	}
}