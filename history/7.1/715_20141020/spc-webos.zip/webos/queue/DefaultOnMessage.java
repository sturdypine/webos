package spc.webos.queue;

import spc.webos.buffer.IBuffer;
import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.Message;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.log.Log;

public class DefaultOnMessage implements IOnMessage
{
	protected Log log = Log.getLogger(getClass());
	protected boolean delay = false; // �ӳٽ���

	public void onMessage(Object obj, AccessTPool pool, AbstractReceiverThread thread)
			throws Exception
	{
		if (pool.getBuf() != null && pool.getConverter() == null)
		{ // û�����ý����������������buffer����, 711_20140710 ���ҵ�ǰ������buffer
			put2buf(obj, pool.getBuf());
			return;
		}

		handle((obj instanceof IMessage) ? (IMessage) obj : createMessage((QueueMessage) obj, pool,
				thread), pool, thread);
	}

	protected IMessage createMessage(QueueMessage qmsg, AccessTPool pool,
			AbstractReceiverThread thread) throws Exception
	{
		IMessageConverter converter = pool.getConverter();
		// 2012-07-29 chenjs ��ʱ����
		IMessage msg = !delay ? converter.deserialize(qmsg.buf) : new Message();
		msg.setInLocal(MsgLocalKey.LOCAL_MSG_CONVERTER, converter);
		if (delay) msg.setInLocal(MsgLocalKey.LOCAL_MSGCVT_DELAY, Boolean.TRUE);

		msg.setCorrelationID(qmsg.correlationId);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_QMSG, qmsg); // ���������Ϣ��ԭʼ��Ϣ
		msg.setInLocal(MsgLocalKey.ACCEPTOR_PROTOCOL, Common.ACCEPTOR_PROTOCOL_QUEUE_MQ);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, qmsg.buf);
		msg.setInLocal(MsgLocalKey.MQGET_QMSG_KEY, qmsg);
		if (pool.getMsgFlow() != null) msg.setInLocal(MsgLocalKey.LOCAL_MSG_MSGFLOW,
				pool.getMsgFlow());
		return msg;
	}

	protected void put2buf(Object obj, IBuffer buf)
	{
		buf.put(obj);
		log.info("put2buf(" + buf.getName() + "), size: " + buf.size());
	}

	protected void handle(IMessage msg, AccessTPool pool, AbstractReceiverThread thread)
	{
		IBuffer buf = pool.getBuf();
		if (buf != null)
		{ // �����buffer����뵽buffer���д���
			put2buf(msg, pool.getBuf());
			return;
		}
		log.debug("handle msg...");
		try
		{
			pool.getMsgFlow().execute(msg);
		}
		catch (Throwable e)
		{
			log.warn("fail to handle", e);
		}
	}

	public boolean isDelay()
	{
		return delay;
	}

	public void setDelay(boolean delay)
	{
		this.delay = delay;
	}
}
