package spc.webos.queue;

import java.util.Hashtable;

import spc.webos.constant.Common;
import spc.webos.pool.ObjectPool;

public abstract class AbstractCnnPool extends ObjectPool
{
	protected Hashtable props;
	protected int cnnHoldTime = -1; // ���ӱ��ֵ����ʱ�䣬 -1��ʾ���޳�
	protected int cnnIdleTime = -1;
	// added by chenjs 2012-07-27, Ϊ�˷���ESB���ص���������Ϊһ��������д򿪣��ṩ���ܣ����緢�͸�REP����
	protected boolean keepQueue = Common.KEEP_QUEUE;

	public AbstractCnnPool()
	{
		this.autoIncrease = true;
	}

	public AbstractCnnPool(int max, Hashtable props)
	{
		this.max = max;
		this.props = props;
		this.autoIncrease = true;
	}

	public AbstractCnnPool(int max, Hashtable props, int cnnHoldTime)
	{
		this.max = max;
		this.props = props;
		this.cnnHoldTime = cnnHoldTime;
		this.autoIncrease = true;
	}

	public AbstractCnnPool(int max, Hashtable props, int cnnHoldTime, int cnnIdleTime)
	{
		this.max = max;
		this.props = props;
		this.cnnHoldTime = cnnHoldTime;
		this.cnnIdleTime = cnnIdleTime;
		this.autoIncrease = true;
	}

	public AbstractCnnPool(int max, Hashtable props, int cnnHoldTime, int cnnIdleTime,
			boolean autoIncrease)
	{
		this.max = max;
		this.props = props;
		this.cnnHoldTime = cnnHoldTime;
		this.cnnIdleTime = cnnIdleTime;
		this.autoIncrease = autoIncrease;
	}

	public AbstractCnnPool(int max, Hashtable props, int cnnHoldTime, int cnnIdleTime,
			boolean autoIncrease, long waitTime)
	{
		this.max = max;
		this.props = props;
		this.cnnHoldTime = cnnHoldTime;
		this.cnnIdleTime = cnnIdleTime;
		this.autoIncrease = autoIncrease;
		this.waitTime = waitTime;
	}

	public int getCnnHoldTime()
	{
		return cnnHoldTime;
	}

	public void setCnnHoldTime(int cnnHoldTime)
	{
		this.cnnHoldTime = cnnHoldTime;
	}

	public void setProps(Hashtable props)
	{
		this.props = props;
	}

	public Hashtable getProps()
	{
		return props;
	}

	public int getCnnIdleTime()
	{
		return cnnIdleTime;
	}

	public void setCnnIdleTime(int cnnIdleTime)
	{
		this.cnnIdleTime = cnnIdleTime;
	}

	public void setKeepQueue(boolean keepQueue)
	{
		this.keepQueue = keepQueue;
	}

	public boolean isKeepQueue()
	{
		return keepQueue;
	}
}