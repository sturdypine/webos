package spc.webos.jsrmi.service;

public class ServiceInvocationException extends RuntimeException {

	private static final long serialVersionUID = 4265698432215818206L;

	public ServiceInvocationException() {
		super();
	}

	public ServiceInvocationException(String message, Throwable cause) {
		super(message, cause);
	}

	public ServiceInvocationException(String message) {
		super(message);
	}

	public ServiceInvocationException(Throwable cause) {
		super(cause);
	}
	
}
