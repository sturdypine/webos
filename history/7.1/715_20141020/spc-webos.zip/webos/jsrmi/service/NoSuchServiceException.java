package spc.webos.jsrmi.service;

public class NoSuchServiceException extends RuntimeException {

	private static final long serialVersionUID = 664802552465490277L;

	public NoSuchServiceException() {
		super();
	}

	public NoSuchServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	public NoSuchServiceException(String message) {
		super(message);
	}

	public NoSuchServiceException(Throwable cause) {
		super(cause);
	}
	
}
