package spc.webos.flownode.action;

import java.util.Map;

import spc.webos.constant.Common;
import spc.webos.data.IMessage;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

public class FtlAction extends AbstractAction
{
	private static final long serialVersionUID = 1L;

	void execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		Map root = SystemUtil.freemarker(null, msg);
		root.put(Common.MODEL_CXT_KEY, cxt);
		root.put(FTL_ACTION_KEY, this);
		SystemUtil.freemarker(ftl, root);
	}

	protected String ftl;
	public final static String FTL_ACTION_KEY = "_ftlaction";

	public String getFtl()
	{
		return ftl;
	}

	public void setFtl(String ftl)
	{
		this.ftl = StringX.trim(ftl);
	}
}
