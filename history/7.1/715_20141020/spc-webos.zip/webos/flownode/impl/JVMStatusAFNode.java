package spc.webos.flownode.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import spc.webos.buffer.IBuffer;
import spc.webos.data.AtomNode;
import spc.webos.data.CompositeNode;
import spc.webos.data.IArrayNode;
import spc.webos.data.IAtomNode;
import spc.webos.data.IMessage;
import spc.webos.data.INode;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.flownode.IFlowNode;
import spc.webos.persistence.stat.SqlPerformanceStat;
import spc.webos.service.IStatus;
import spc.webos.statistics.IStat;
import spc.webos.thread.DaemonThread;
import spc.webos.util.SystemUtil;

/**
 * ��õ�ǰjvm�Ļ�����Ϣ, �߳�״̬, buf״̬
 * 
 * @author spc
 * 
 */
public class JVMStatusAFNode extends AbstractFNode
{
	public static final String DEFAULT_NAME = "JVMStatus";
	static JVMStatusAFNode node = new JVMStatusAFNode();

	public static final String STATUS_TYPE = "types"; // ״̬��������
	public static final String TAG_BUFFER = "buffers"; // jvm����������ע��buffer��״̬���
	public static final String TAG_STAT = "stat";
	public static final String TAG_FNODE = "fnodes"; // jvm����������ע��fnode��״̬���
	public static final String TAG_THREAD = "threads"; // jvm����������ע��threads��״̬���
	public static final String TAG_SPS = "SPS"; // JVMִ��SQL������

	public Object execute(IMessage msg, IFlowContext cxt)
	{
		IArrayNode types = msg.findArrayInRequest(STATUS_TYPE, null);
		// System.out.println("flg: " + types.contains(new AtomNode(TAG_STAT)));
		if (types.contains(TAG_BUFFER)) process(TAG_BUFFER, IBuffer.BUFFERS, msg, cxt,
				(CompositeNode) msg.findInRequest(TAG_BUFFER));
		if (types.contains(TAG_STAT)) process(TAG_STAT, IStat.STATISTICS, msg, cxt,
				(CompositeNode) msg.findInRequest(TAG_STAT));
		if (types.contains(TAG_FNODE)) process(TAG_FNODE, IFlowNode.FLOW_NODES, msg, cxt,
				(CompositeNode) msg.findInRequest(TAG_FNODE));
		if (types.contains(TAG_THREAD)) process(TAG_THREAD, DaemonThread.THREADS, msg, cxt,
				(CompositeNode) msg.findInRequest(TAG_THREAD));
		if (types.contains(TAG_SPS)) msg.setInResponse(TAG_SPS, SqlPerformanceStat.getInstance()
				.getSqls());

		// jvm ����״̬��Ϣ
		CompositeNode jvm = new CompositeNode();
		if (((IAtomNode) msg.getRequest().find(IMessage.PATH_REQUEST, "env", INode.TYPE_BOOL,
				AtomNode.FALSE)).booleanValue()) jvm.set("env", System.getenv());
		// ÿ�α��뷵���ڴ�ʹ��״̬
		Runtime rt = Runtime.getRuntime();
		jvm.set("max", new AtomNode(new Long(rt.maxMemory())));
		jvm.set("total", new AtomNode(new Long(rt.totalMemory())));
		jvm.set("free", new AtomNode(new Long(rt.freeMemory())));
		jvm.set("ip", SystemUtil.LOCAL_HOST_IP);
		jvm.set("app", SystemUtil.APP);
		jvm.set("jvmId", SystemUtil.JVM);
		jvm.set("jvmDesc", SystemUtil.JVMDESC);
		jvm.set("checkTime", new SimpleDateFormat(SystemUtil.DF_ALL23).format(new Date()));
		jvm.set("startTime",
				new SimpleDateFormat(SystemUtil.DF_ALL23).format(SystemUtil.JVM_START_TIME));
		msg.setInResponse("jvm", jvm);
		return null;
	}

	protected void process(String tag, Map status, IMessage msg, IFlowContext cxt,
			CompositeNode param)
	{
		if (status == null || status.size() == 0) return;
		List statuses = new ArrayList();

		Iterator ss = status.values().iterator();
		while (ss.hasNext())
		{
			Map st = ((IStatus) ss.next()).checkStatus(param);
			if (st != null && st.size() > 0) statuses.add(st);
		}
		msg.setInResponse(tag, statuses);
		// System.out.println(tag+","+statuses);
	}

	public static JVMStatusAFNode getInstance()
	{
		return node;
	}

	private JVMStatusAFNode()
	{
		name = DEFAULT_NAME;
	}
}
