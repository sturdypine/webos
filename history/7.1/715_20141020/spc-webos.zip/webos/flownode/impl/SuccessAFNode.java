package spc.webos.flownode.impl;

import spc.webos.constant.AppRetCode;
import spc.webos.data.IMessage;
import spc.webos.data.Status;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

/**
 * ���óɹ���Ϣ
 * 
 * @author spc
 * 
 */
public class SuccessAFNode extends AbstractFNode
{
	static final SuccessAFNode node = new SuccessAFNode();
	protected String appCd;
	protected String mbrCd;

	public Object execute(IMessage msg, IFlowContext cxt)
	{
		Status status = msg.getStatus();
		// System.out.println("success:"+msg.getStatus());
		if (status == null || status.isUnderWay())
		{
			if (log.isDebugEnabled()) log.debug("set success flag: " + AppRetCode.SUCCESS());
			status = new Status(AppRetCode.SUCCESS());
			// if (!StringX.nullity(SystemUtil.NODE))
			status.setMbrCd(StringX.nullity(mbrCd) ? SystemUtil.NODE : mbrCd);
			status.setAppCd(StringX.nullity(appCd) ? SystemUtil.APP : appCd);
			status.setIp(SystemUtil.LOCAL_HOST_IP);
			status.setLocation("SuccessAFNode");
			msg.setStatus(status);
		}
		else if (log.isDebugEnabled()) log.debug("retCd : " + status.getRetCd());
		return null;
	}

	public void setAppCd(String appCd)
	{
		this.appCd = appCd;
	}

	public void setMbrCd(String mbrCd)
	{
		this.mbrCd = mbrCd;
	}

	public SuccessAFNode()
	{
	}

	public static SuccessAFNode getInstance()
	{
		return node;
	}
}
