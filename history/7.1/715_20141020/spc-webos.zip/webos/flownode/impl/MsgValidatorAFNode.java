package spc.webos.flownode.impl;

import spc.webos.data.IMessage;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;

public class MsgValidatorAFNode extends AbstractFNode
{
	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		super.validate(msg);
		return null;
	}
}
