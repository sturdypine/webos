package spc.webos.advice;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

import spc.webos.log.Log;

public class MethodCallAdvice implements MethodInterceptor
{
	protected Log log = Log.getLogger(getClass());

	public Object invoke(MethodInvocation mi) throws Throwable
	{
		if (log.isDebugEnabled()) log.debug("start " + mi.getThis().getClass() + ":"
				+ mi.getMethod());
		Object result = mi.proceed();
		if (log.isDebugEnabled()) log
				.debug("end " + mi.getThis().getClass() + ":" + mi.getMethod());
		return result;
	}
}
