package spc.webos.web.common;

import java.io.Serializable;

public class TransientInSession
{
	long lastVisitTimeMillis;
	Serializable obj;
	int cacheSeconds = -1;

	public TransientInSession(Serializable obj)
	{
		this.obj = obj;
	}

	public TransientInSession(Serializable obj, int cacheSeconds)
	{
		this.obj = obj;
		this.cacheSeconds = cacheSeconds;
		lastVisitTimeMillis = System.currentTimeMillis();
	}

	public Object getObj()
	{
		if (cacheSeconds > 0) lastVisitTimeMillis = System.currentTimeMillis();
		return obj;
	}

	public void setObj(Serializable obj)
	{
		if (cacheSeconds > 0) lastVisitTimeMillis = System.currentTimeMillis();
		this.obj = obj;
	}

	public boolean isExpired(long currentTimeMillis)
	{
		return cacheSeconds >= 0
				&& currentTimeMillis > lastVisitTimeMillis + cacheSeconds
						* 1000;
	}
}
