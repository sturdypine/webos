package spc.webos.statistics;

import java.util.HashMap;
import java.util.Map;

import spc.webos.data.IMessage;
import spc.webos.service.IStatus;

public interface IStat extends IStatus
{
	void trigger(IMessage msg, long cur);
	
	Map STATISTICS = new HashMap();
}
