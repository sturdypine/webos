package spc.webos.cache;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import spc.webos.persistence.IPersistence;
import spc.webos.persistence.Persistence;
import spc.webos.util.tree.ExtTreeNode;
import spc.webos.util.tree.TreeNode;

/**
 * ΪExt�ͻ���, �ṩExt��ʽ��tree. ���������, ���ܲ˵���...
 * 
 * @author sturdypine.chen
 * 
 */
public class ExtTreeCache extends EternalCache
{
	private static final long serialVersionUID = 1L;

	public void init() throws Exception
	{
		super.init();
		Iterator keys = treesSql.keySet().iterator();
		while (keys.hasNext())
			get(keys.next().toString());
	}

	public Object getMessage(String code) // for ���ʻ�
	{
		int index = code.indexOf('/');
		if (index < 0) index = code.indexOf('.');
		if (index < 0) index = code.indexOf('_');
		String prefix = index > 0 ? code.substring(0, index) : code;

		return ((TreeNode) get(prefix)).getMessage(code.substring(index + 1),
				null, null);
	}

	public Object get(Object treeId)
	{
		ExtTreeNode node = (ExtTreeNode) super.get(treeId);
		// System.out.println(treeId);
		if (node != null) return node;
		node = new ExtTreeNode();
		// System.out.println(treeId + "," + (String) treesSql.get(treeId));
		List list = (List) persistence.execute((String) treesSql.get(treeId),
				null);
		node.createTree(list);
		super.put(treeId, node);
		return node;
	}

	Map treesSql;
	IPersistence persistence = Persistence.getInstance();

	public void setTreesSql(Map treesSql)
	{
		this.treesSql = treesSql;
	}

	public Map getTreesSql()
	{
		return treesSql;
	}

	public void setPersistence(IPersistence persistence)
	{
		this.persistence = persistence;
	}
}
