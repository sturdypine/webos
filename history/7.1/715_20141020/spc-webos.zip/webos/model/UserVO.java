package spc.webos.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * genarated by sturdypine.chen Email: sturdypine@gmail.com description:
 */
public class UserVO implements ValueObject
{
	public static final long serialVersionUID = 20100608L;
	// ����������Ӧ�ֶε�����
	String code; // ����
	String name; //
	String pwd; //
	String roleId; //
	String orgId;
	String depId;
	String groupId;
	String login; //
	String ipAddress; //
	String email; //
	String lookAndFeel; //
	String abolishFlag; //
	String wallpaper; //
	String shortcuts; //
	String quickStarts; //
	String autoruns; //
	String mobilePhone;
	String phone;
	String certType;
	String certNo;
	String lastLoginDt;
	String creater;
	String creatDt;
	String admin;
	String startDt;

	// �ʹ�VO�����������VO����

	// �ʹ�VO�������������Sql����
	// Note: ���������Sql����ΪString, Inegter...��Java final classʱ�� ֻ��ʹ��Object����
	// ����ʱ��ֻ��ͨ��
	// Object��toString()������ʹ�á�
	public static final String TABLE = "sys_user";
	public static final String[] BLOB_FIELD = null;
	public static final String SEQ_NAME = "code";

	public UserVO()
	{
	}

	public UserVO(String code)
	{
		this.code = code;
	}

	public void setPrimary(String code)
	{
		this.code = code;
	}

	public String getPrimary(String delim)
	{
		StringBuffer buf = new StringBuffer();
		buf.append(this.code);
		return buf.toString();
	}

	public Map getPrimary()
	{
		Map m = new HashMap();
		m.put("code", code);
		return m;
	}

	public String getTable()
	{
		return TABLE;
	}

	public String[] getBlobField()
	{
		return BLOB_FIELD;
	}

	public String getKeyName()
	{
		return SEQ_NAME;
	}

	public Serializable getKey()
	{
		return code;
	}

	// set all properties to NULL
	public void setNULL()
	{
		this.code = null;
		this.name = null;
		this.pwd = null;
		this.roleId = null;
		this.login = null;
		this.ipAddress = null;
		this.email = null;
		this.lookAndFeel = null;
		this.abolishFlag = null;
		this.wallpaper = null;
		this.shortcuts = null;
		this.quickStarts = null;
		this.autoruns = null;
	}

	public boolean equals(Object o)
	{
		if (this == o) return true;
		if (!(o instanceof UserVO)) return false;
		UserVO obj = (UserVO) o;
		if (!code.equals(obj.code)) return false;
		if (!name.equals(obj.name)) return false;
		if (!pwd.equals(obj.pwd)) return false;
		if (!roleId.equals(obj.roleId)) return false;
		if (!login.equals(obj.login)) return false;
		if (!ipAddress.equals(obj.ipAddress)) return false;
		if (!email.equals(obj.email)) return false;
		if (!lookAndFeel.equals(obj.lookAndFeel)) return false;
		if (!abolishFlag.equals(obj.abolishFlag)) return false;
		if (!wallpaper.equals(obj.wallpaper)) return false;
		if (!shortcuts.equals(obj.shortcuts)) return false;
		if (!quickStarts.equals(obj.quickStarts)) return false;
		if (!autoruns.equals(obj.autoruns)) return false;
		return true;
	}

	// ֻ����������ɢ��
	public int hashCode()
	{
		long hashCode = getClass().hashCode();
		if (code != null) hashCode += code.hashCode();
		return (int) hashCode;
	}

	public int compareTo(Object o)
	{
		return -1;
	}

	// set all properties to default value...
	public void init()
	{
	}

	public String getCode()
	{
		return code;
	}

	public void setCode(String code)
	{
		this.code = code;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getMobilePhone()
	{
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone)
	{
		this.mobilePhone = mobilePhone;
	}

	public String getPhone()
	{
		return phone;
	}

	public void setPhone(String phone)
	{
		this.phone = phone;
	}

	public String getCertType()
	{
		return certType;
	}

	public void setCertType(String certType)
	{
		this.certType = certType;
	}

	public String getCertNo()
	{
		return certNo;
	}

	public void setCertNo(String certNo)
	{
		this.certNo = certNo;
	}

	public String getLastLoginDt()
	{
		return lastLoginDt;
	}

	public void setLastLoginDt(String lastLoginDt)
	{
		this.lastLoginDt = lastLoginDt;
	}

	public String getCreater()
	{
		return creater;
	}

	public void setCreater(String creater)
	{
		this.creater = creater;
	}

	public String getCreatDt()
	{
		return creatDt;
	}

	public void setCreatDt(String creatDt)
	{
		this.creatDt = creatDt;
	}

	public String getAdmin()
	{
		return admin;
	}

	public void setAdmin(String admin)
	{
		this.admin = admin;
	}

	public String getStartDt()
	{
		return startDt;
	}

	public void setStartDt(String startDt)
	{
		this.startDt = startDt;
	}

	public String getPwd()
	{
		return pwd;
	}

	public void setPwd(String pwd)
	{
		this.pwd = pwd;
	}

	public String getRoleId()
	{
		return roleId;
	}

	public void setRoleId(String roleId)
	{
		this.roleId = roleId;
	}

	public String getLogin()
	{
		return login;
	}

	public void setLogin(String login)
	{
		this.login = login;
	}

	public String getIpAddress()
	{
		return ipAddress;
	}

	public void setIpAddress(String ipAddress)
	{
		this.ipAddress = ipAddress;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public String getLookAndFeel()
	{
		return lookAndFeel;
	}

	public void setLookAndFeel(String lookAndFeel)
	{
		this.lookAndFeel = lookAndFeel;
	}

	public String getAbolishFlag()
	{
		return abolishFlag;
	}

	public void setAbolishFlag(String abolishFlag)
	{
		this.abolishFlag = abolishFlag;
	}

	public String getWallpaper()
	{
		return wallpaper;
	}

	public void setWallpaper(String wallpaper)
	{
		this.wallpaper = wallpaper;
	}

	public String getShortcuts()
	{
		return shortcuts;
	}

	public void setShortcuts(String shortcuts)
	{
		this.shortcuts = shortcuts;
	}

	public String getQuickStarts()
	{
		return quickStarts;
	}

	public void setQuickStarts(String quickStarts)
	{
		this.quickStarts = quickStarts;
	}

	public String getAutoruns()
	{
		return autoruns;
	}

	public void setAutoruns(String autoruns)
	{
		this.autoruns = autoruns;
	}

	public void set(UserVO vo)
	{
		this.code = vo.code;
		this.name = vo.name;
		this.pwd = vo.pwd;
		this.roleId = vo.roleId;
		this.login = vo.login;
		this.ipAddress = vo.ipAddress;
		this.email = vo.email;
		this.lookAndFeel = vo.lookAndFeel;
		this.abolishFlag = vo.abolishFlag;
		this.wallpaper = vo.wallpaper;
		this.shortcuts = vo.shortcuts;
		this.quickStarts = vo.quickStarts;
		this.autoruns = vo.autoruns;
	}

	public String getDepId()
	{
		return depId;
	}

	public void setDepId(String depId)
	{
		this.depId = depId;
	}

	// public String getPostId()
	// {
	// return postId;
	// }
	//
	// public void setPostId(String postId)
	// {
	// this.postId = postId;
	// }

	public static long getSerialVersionUID()
	{
		return serialVersionUID;
	}

	public StringBuffer toJson()
	{
		StringBuffer buf = new StringBuffer();
		buf.append('{');
		if (code != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("code:'");
			buf.append(code);
			buf.append('\'');
		}
		if (name != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("name:'");
			buf.append(name);
			buf.append('\'');
		}
		if (pwd != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("pwd:'");
			buf.append(pwd);
			buf.append('\'');
		}
		if (roleId != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("roleId:'");
			buf.append(roleId);
			buf.append('\'');
		}
		if (login != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("login:'");
			buf.append(login);
			buf.append('\'');
		}
		if (ipAddress != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("ipAddress:'");
			buf.append(ipAddress);
			buf.append('\'');
		}
		if (email != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("email:'");
			buf.append(email);
			buf.append('\'');
		}
		if (lookAndFeel != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("lookAndFeel:'");
			buf.append(lookAndFeel);
			buf.append('\'');
		}
		if (abolishFlag != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("abolishFlag:'");
			buf.append(abolishFlag);
			buf.append('\'');
		}
		if (wallpaper != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("wallpaper:'");
			buf.append(wallpaper);
			buf.append('\'');
		}
		if (shortcuts != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("shortcuts:'");
			buf.append(shortcuts);
			buf.append('\'');
		}
		if (quickStarts != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("quickStarts:'");
			buf.append(quickStarts);
			buf.append('\'');
		}
		if (autoruns != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("autoruns:'");
			buf.append(autoruns);
			buf.append('\'');
		}
		buf.append('}');
		return buf;
	}

	public void afterLoad()
	{
		// TODO Auto-generated method stub

	}

	public void beforeLoad()
	{
		// TODO Auto-generated method stub

	}

	public void setManualSeq(Long seq)
	{

	}

	public void destory()
	{

	}

	public String toString()
	{
		StringBuffer buf = new StringBuffer(128);
		buf.append(getClass().getName() + "(serialVersionUID=" + serialVersionUID + "):");
		buf.append(toJson());
		return buf.toString();
	}

	public String getOrgId()
	{
		return orgId;
	}

	public void setOrgId(String orgId)
	{
		this.orgId = orgId;
	}

	public String getGroupId()
	{
		return groupId;
	}

	public void setGroupId(String groupId)
	{
		this.groupId = groupId;
	}
}
