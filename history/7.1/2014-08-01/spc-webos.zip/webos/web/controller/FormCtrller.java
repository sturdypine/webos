package spc.webos.web.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.core.io.ResourceLoader;
import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import spc.webos.constant.Common;
import spc.webos.constant.Web;
import spc.webos.jdbc.blob.FileBlob;
import spc.webos.model.ValueObject;
import spc.webos.persistence.IPersistence;
import spc.webos.persistence.Persistence;
import spc.webos.util.StringX;
import spc.webos.web.filter.multipart.MultipartEntry;
import spc.webos.web.filter.multipart.MultipartFilter;
import spc.webos.web.filter.multipart.MultipartRequestHandler;
import spc.webos.web.form.CommonForm;
import spc.webos.web.util.WebUtil;

public class FormCtrller extends SimpleFormController implements ResourceLoaderAware
{
	public FormCtrller()
	{
		setCommandName("form");
	}

	protected Map referenceData(HttpServletRequest request, Object command, Errors errors)
			throws Exception
	{
		Map model = WebUtil.request2map(request, null);
		model.put(getCommandName(), command);
		// ��ȡ��ѯ��Ϣ
		String batchSql = request.getParameter(Web.REQ_KEY_BATCH_SQL);
		if (!StringX.nullity(batchSql)) persistence.execute(batchSql.split(StringX.COMMA), model,
				model);
		return model;
	}

	// protected ModelAndView showForm(HttpServletRequest request,
	// HttpServletResponse response, BindException errors, Map controlModel)
	// throws Exception
	// {
	// return showForm(request, errors, getFormView(), controlModel);
	// }

	protected Object formBackingObject(HttpServletRequest request) throws Exception
	{
		CommonForm form = new CommonForm();
		String voClazz = this.voClazz;
		// System.out.println(this.voClazz);
		if (voClazz == null) voClazz = (String) request.getParameter(Web.REQ_KEY_VO);

		form.setVo((ValueObject) Class.forName(voClazz).newInstance());
		if (Web.POST_METHOD.equalsIgnoreCase(request.getMethod())) { return form; }
		// GET...
		super.bindAndValidate(request, form);
		String action = (String) request.getParameter(ACTION_PARAM_NAME);
		if (Common.ACTION_UPDATE.equalsIgnoreCase(action))
		{ // update...�����ݿ�����ϸ��Ϣ
			request.setAttribute(Web.REQ_KEY_UN_CLIENT_CACHE, Boolean.TRUE); // ��ֹʹ�ÿͻ��˻���
			form.setVo(persistence.find(form.getVo()));
			form.setAct(Common.ACTION_UPDATE);
		}
		else form.setAct(Common.ACTION_INSERT);
		return form;
	}

	protected ModelAndView onSubmit(HttpServletRequest request, HttpServletResponse response,
			Object command, BindException errors) throws Exception
	{
		List attach = null;
		if (MultipartRequestHandler.isMultipartRequest(request)) attach = handleUploadFiles(
				request, command);
		CommonForm form = (CommonForm) command;
		if (Common.ACTION_UPDATE.equalsIgnoreCase(form.getAct())) persistence.update(form.getVo());
		else persistence.insert(form.getVo());
		// ��������, ���������ļ�
		String searchIndex = request.getParameter(Web.REQ_KEY_SEARCH_INDEX);
		if (searchIndex != null && searchIndex.length() > 0 && attach != null && attach.size() > 0)
		{ // ���û������������־���򲻽�������
			List search = StringX.split2list(searchIndex, StringX.COMMA);
			ValueObject vo = persistence.find(form.getVo());
			for (int i = 0; i < attach.size(); i++)
			{
				Object[] arr = (Object[]) attach.get(i);
				if (search.contains((String) arr[1])) // ���ǰ��ָ����Ҫ�����������ļ�
				makeSearchIndex(request, (File) arr[0], vo, (String) arr[1], (String) arr[2]);
			}
		}
		return handleResult(request, response, command, errors);
	}

	/**
	 * �����ϴ��ļ��Ľӿ�
	 * 
	 * @param request
	 * @param command
	 * @throws Exception
	 */
	protected List handleUploadFiles(HttpServletRequest request, Object command) throws Exception
	{
		List attach = new ArrayList();
		try
		{
			List uploadFileNames = WebUtil.getUploadFileNames(request);
			if (uploadFileNames.size() == 0) return attach;
			ValueObject vo = ((CommonForm) command).getVo();

			for (int i = 0; i < uploadFileNames.size(); i++)
			{
				String uploadFileName = (String) uploadFileNames.get(i);
				MultipartEntry entry = getEntry(request, uploadFileName);
				if (entry == null || entry.getTempFile() == null
						|| entry.getTempFile().length() == 0 || entry.getFileName() == null
						|| entry.getFileName().length() == 0) continue;
				String fieldName = uploadFileName.substring(uploadFileName.lastIndexOf('.') + 1);
				File file = entry.getTempFile();

				String fileName = entry.getFileName();
				int index1 = fileName.lastIndexOf('\\');
				if (index1 < 0) index1 = fileName.lastIndexOf('/');
				if (index1 >= 0) fileName = fileName.substring(index1 + 1);

				FileBlob blob = new FileBlob(file, vo, fieldName);
				BeanUtils.setProperty(vo, fieldName, blob);
				BeanUtils.setProperty(vo, fieldName + "Name", fileName);
				// System.out.println("save: " +
				// fieldName+","+fileName+","+file.length());
				attach.add(new Object[] { file, fieldName, fileName });
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return attach;
	}

	protected void makeSearchIndex(HttpServletRequest request, File file, ValueObject vo,
			String fieldName, String fileName) throws Exception
	{
//		String fileType = fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase();
//		if (!Global.VALID_SUFFIX.contains(fileType.toLowerCase())) { return; }
//		String fileId = JdbcUtil.genFileNameByVO(vo, fieldName);
//		DocumentEntity de = new DocumentEntity(fileId);
//		de.setSrc(file);
//		de.setSuffix(fileType);
//		de.setName(fileName);
//		de.setAuthor(((SessionUserInfo) (ISessionUserInfo.SUI.get())).getUser().getName());
//		StringBuffer ext1 = new StringBuffer();
//		// System.out.println(vo);
//		ext1.append(vo.getKeyName());
//		ext1.append('=');
//		ext1.append(vo.getKey());
//		ext1.append('&');
//		ext1.append(Web.REQ_KEY_FN);
//		ext1.append('=');
//		ext1.append(fieldName);
//		ext1.append('&');
//		ext1.append(Web.REQ_KEY_VO);
//		ext1.append('=');
//		ext1.append(vo.getClass().getName());
//		de.setExt1(ext1.toString());
//
//		SearchService.getInstance().add(de);
	}

	protected ModelAndView handleResult(HttpServletRequest request, HttpServletResponse response,
			Object command, BindException errors) throws Exception
	{
		String successMode = request.getParameter(Web.REQ_KEY_FORM_SUCCESS_MODE);
		if (successMode == null || successMode.length() == 0) successMode = Web.FORM_SUCCESS_MODE_JSON;

		if (Web.FORM_SUCCESS_MODE_JSON == successMode)
		{
			// System.out.println("form save OK....");
			response.getWriter().print(successJson);
			response.getWriter().close();
			return null;
		}
		CommonForm form = (CommonForm) command;
		ModelAndView mv = new ModelAndView(request.getParameter(Web.REQ_KEY_VIEW_NAME_SKEY));
		Map params = WebUtil.request2map(request, mv.getModel());

		params.put(getCommandName(), form);
		String batchSql = request.getParameter(Web.REQ_KEY_BATCH_SQL);
		if (!StringX.nullity(batchSql)) persistence.execute(batchSql.split(StringX.COMMA), params,
				params);
		return mv;
	}

	/**
	 * �������г�ȡһ���ϴ����ļ�
	 * 
	 * @param request
	 * @param paramName
	 * @return
	 */
	public MultipartEntry getEntry(HttpServletRequest request, String paramName)
	{
		Map entries = (Map) request.getAttribute(MultipartFilter.REQ_ATTR_ENTRIES_KEY);
		return entries == null ? null : (MultipartEntry) entries.get(paramName);
	}

	protected String successJson = "{success:true,code:'000000',msg:'save successfully!!!'}";
	protected String voClazz;
	protected IPersistence persistence = Persistence.getInstance();
	protected Object contextParam;
	protected ResourceLoader resourceLoader;
	protected String uploadFilePathPrefix = "uploadfiles";
	// public static final String FORM_SUCCESS_FLAG = "FORM_SUCCESS_FLAG";
	public static final String ACTION_PARAM_NAME = "act";

	public void setResourceLoader(ResourceLoader resourceLoader)
	{
		this.resourceLoader = resourceLoader;
	}

	public void setContextParam(Object contextParam)
	{
		this.contextParam = contextParam;
	}

	public void setVoClazz(String voClazz)
	{
		this.voClazz = voClazz;
	}

	public void setPersistence(IPersistence persistence)
	{
		this.persistence = persistence;
	}

	public void setUploadFilePathPrefix(String uploadFilePathPrefix)
	{
		this.uploadFilePathPrefix = uploadFilePathPrefix;
	}

	public void setSuccessJson(String successJson)
	{
		this.successJson = successJson;
	}
}
