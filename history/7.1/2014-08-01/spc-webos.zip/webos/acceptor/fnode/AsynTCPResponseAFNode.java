package spc.webos.acceptor.fnode;

import java.util.HashMap;
import java.util.Map;

import spc.webos.acceptor.SocketMessage;
import spc.webos.cache.ICache;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.flownode.impl.SendResponseAFNode;
import spc.webos.util.StringX;
import spc.webos.util.bytes.BytesUtil;
import spc.webos.util.http.HTTPHeader;
import spc.webos.util.http.HTTPUtil;

/**
 * �����첽����TCPӦ����
 * 
 * @author chenjs
 * 
 */
public class AsynTCPResponseAFNode extends SendResponseAFNode
{
	protected void send(IMessage msg) throws Exception
	{
		try
		{
			SocketMessage smsg = (SocketMessage) msg2sndobj(msg);
			if (smsg == null) return;
			send(msg, smsg);
			if (!smsg.longCnn || smsg.dhl.hdrLen <= 0)
			{
				log.info("nbc close");
				smsg.nbc.close();
			}
			msg.setInLocal(MsgLocalKey.SND_BUF, Boolean.TRUE);
		}
		catch (Exception e)
		{
			if (logex) log.warn("ERR to snd response", e);
			else throw e;
		}
	}

	protected void send(IMessage msg, SocketMessage smsg) throws Exception
	{
		if (smsg.repmsg == null || smsg.repmsg.length == 0)
		{
			log.warn("smsg.repmsg is null or len is 0!!!");
			return;
		}
		byte[] content = createSndContent(smsg);
		if (log.isInfoEnabled()) log.info("snd len:" + smsg.repmsg.length + "," + content.length
				+ ", " + smsg.dhl.hdrLen + ", " + autoSndLenHdr);

		if (smsg.dhl.hdrLen > 0 && autoSndLenHdr)
		{ // �Զ����ͷ������Ϣ
			log.debug("snd with auto hdrLen!!!");
			send(smsg, BytesUtil.merge(smsg.dhl.lenBytes(content.length), content,
					smsg.endFlag ? new byte[] { '\0' } : null, null), false);
			// ByteArrayOutputStream baos = new ByteArrayOutputStream();
			// baos.write(smsg.dhl.lenBytes(smsg.repmsg.length));
			// baos.write(createSndContent(smsg));
			// if (smsg.endFlag) baos.write('\0');
			// send(smsg, baos.toByteArray(), false);
		}
		else
		{
			log.debug("snd without auto hdrLen!!!");
			send(smsg, !smsg.endFlag ? content : BytesUtil.merge(content, new byte[] { '\0' }),
					false);
			// added by spc 2011-05-03 ����н�����־���ͽ�����־
			// if (smsg.endFlag) send(smsg, new byte[] { '\0' }, false);
		}
		smsg.nbc.flush();
	}

	protected byte[] createSndContent(SocketMessage smsg) throws Exception
	{
		if (smsg.reqHttpHdr == null) return smsg.repmsg;
		HTTPHeader hdr = smsg.repHttpHdr;
		if (hdr == null) hdr = new HTTPHeader();
		if (smsg.defRepHttpHdrParams != null)
		{ // �����Ĭ�ϵ�httpͷ���������ڵ�ǰͷ��Ϣ�����ϼ��ϡ�
			if (hdr.params == null || hdr.params.size() == 0) hdr.params = smsg.defRepHttpHdrParams;
			else
			{
				Map params = new HashMap(smsg.defRepHttpHdrParams);
				params.putAll(hdr.params);
				hdr.params = params;
			}
		}
		return HTTPUtil.packResponse(hdr, smsg.repmsg);
	}

	protected void send(SocketMessage smsg, byte[] buf, boolean autoFlush) throws Exception
	{
		if (isTrace(smsg.localPort) && log.isInfoEnabled()) log.info("trace snd bytes base64: "
				+ new String(StringX.encodeBase64(buf)) + "\n\t\tstr:\n" + new String(buf));
		else if (log.isDebugEnabled()) log.debug("snd bytes base64: "
				+ new String(StringX.encodeBase64(buf)) + "\n\t\tstr:\n" + new String(buf));
		smsg.nbc.write(buf);
		if (autoFlush) smsg.nbc.flush();
		if (log.isInfoEnabled()) log.info("suc to snd nbc: " + buf.length + ", flush:" + autoFlush
				+ ", remote:" + smsg.nbc.getRemoteAddress());
	}

	protected Object msg2sndobj(IMessage msg) throws Exception
	{
		Object[] obj = (Object[]) cache.poll(msg.getRefMsgSn());
		if (obj == null) obj = (Object[]) cache.poll(msg.getRefSeqNb());
		if (obj == null)
		{
			log.warn("Fail to poll cache: " + msg.getRefMsgSn() + ", " + msg.getRefSeqNb()
					+ ", size:" + cache.size() + ", keys:" + cache.getKeys());
			return null;
		}
		SocketMessage smsg = (SocketMessage) obj[0];
		IMessageConverter converter = (IMessageConverter) obj[1]; // ��ȡ������MessageConverter
		smsg.repmsg = converter.serialize(msg);
		return smsg;
	}

	protected boolean isSend(IMessage msg)
	{
		if (msg.getLocal().containsKey(MsgLocalKey.NO_RETURN))
		{
			log.info("no return flag has been set!!!");
			return false;
		}
		if (msg.getLocal().containsKey(MsgLocalKey.LOCAL_ACCESS4LOCAL))
		{
			log.info("LOCAL_ACCESS4LOCAL flag has been set!!!");
			return false;
		}
		return true;
	}

	protected ICache cache; // ���ڴ洢�첽��������Ӧ��ͨ����Ϣ
	protected boolean logex = true; // �����־�쳣��˵������ʧ�ܣ������̲����׳��쳣, Ĭ��Ϊtrue
	protected boolean autoSndLenHdr = true;

	// protected boolean sndLenWithBuf = true; // added by chenjs 2011-11-03,
	// true����ߺܶ�����

	public void setLogex(boolean logex)
	{
		this.logex = logex;
	}

	public void setAutoSndLenHdr(boolean autoSndLenHdr)
	{
		this.autoSndLenHdr = autoSndLenHdr;
	}

	public void setCache(ICache cache)
	{
		this.cache = cache;
	}
}