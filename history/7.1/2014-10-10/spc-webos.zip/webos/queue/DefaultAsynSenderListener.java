package spc.webos.queue;

import spc.webos.data.Status;
import spc.webos.log.Log;

public class DefaultAsynSenderListener implements IAsynSenderListener
{
	static Log log = Log.getLogger(DefaultAsynSenderListener.class);
	static DefaultAsynSenderListener DASL = new DefaultAsynSenderListener();

	private DefaultAsynSenderListener()
	{
	}

	public static IAsynSenderListener getInstance()
	{
		return DASL;
	}

	public void fail(QueueMessage qmsg, Status status)
	{
		log.error("Fail status:" + status + ":\n" + new String(qmsg.buf));
	}

	public void success(QueueMessage qmsg, Status status)
	{
		if (log.isInfoEnabled()) log.info("success to send msg...");
	}
}
