package spc.webos.cache;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import net.sf.ehcache.CacheException;
import net.sf.ehcache.CacheManager;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;

import spc.webos.config.AppConfig;
import spc.webos.constant.Common;
import spc.webos.log.Log;
import spc.webos.util.FileUtil;
import spc.webos.util.StringX;

public class EhCacheManager implements FactoryBean, InitializingBean, DisposableBean
{
	protected final Log logger = Log.getLogger(getClass());
	private Resource configLocation;
	private boolean shared = false;
	private CacheManager cacheManager;

	public void afterPropertiesSet() throws IOException, CacheException
	{
		logger.info("Initializing EHCache CacheManager");
		String cfg = new String(FileUtil.is2bytes(configLocation.getInputStream()),
				Common.CHARSET_UTF8);
		String webappRoot = StringX.null2emptystr(AppConfig.getInstance().getProperty(
				Common.WEBAPP_ROOT_PATH_KEY, null));// System.getProperty(Common.WEBAPP_ROOT_KEY);
		String webappKey = "${" + Common.WEBAPP_ROOT_PATH_KEY + "}";
		if (!StringX.nullity(webappRoot) && cfg.indexOf(webappKey) >= 0)
		{
			logger.info(Common.WEBAPP_ROOT_PATH_KEY + " will be replaced by " + webappRoot);
			cfg = StringX.replaceAll(cfg, webappKey, webappRoot);
		}
		ByteArrayInputStream bais = new ByteArrayInputStream(cfg.getBytes(Common.CHARSET_UTF8));
		// Shared CacheManager singleton at the VM level.
		cacheManager = shared ? CacheManager.create(bais) : new CacheManager(bais);
	}

	public Object getObject()
	{
		return this.cacheManager;
	}

	public Class getObjectType()
	{
		return (this.cacheManager != null ? this.cacheManager.getClass() : CacheManager.class);
	}

	public boolean isSingleton()
	{
		return true;
	}

	public void destroy()
	{
		logger.info("Shutting down EHCache CacheManager");
		this.cacheManager.shutdown();
	}

	public void setConfigLocation(Resource configLocation)
	{
		this.configLocation = configLocation;
	}

	public void setShared(boolean shared)
	{
		this.shared = shared;
	}
}