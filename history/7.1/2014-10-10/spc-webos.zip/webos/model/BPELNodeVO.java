package spc.webos.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import spc.webos.util.JsonUtil;

/**
 * genarated by sturdypine.chen Email: sturdypine@gmail.com description:
 */
public class BPELNodeVO implements ValueObject
{
	public static final long serialVersionUID = 20110131L;
	// ����������Ӧ�ֶε�����
	String msgSn; // ����
	String node; //
	String failAbort; //
	String refMsgSn; //
	String msgCd; //
	String lang;
	String callTyp; //
	String sndNode; //
	String sndAppCd; //
	String sndDt; //
	String sndTm; //
	String seqNb; //
	String status; //
	String retCd;
	String retDesc;
	String location;
	String ip;
	String appCd;
	String tmStamp; //

	// �ʹ�VO�����������VO����

	// �ʹ�VO�������������Sql����
	// Note: ���������Sql����ΪString, Inegter...��Java final classʱ�� ֻ��ʹ��Object����
	// ����ʱ��ֻ��ͨ��
	// Object��toString()������ʹ�á�
	public static final String TABLE = "bpl_node";
	public static final String[] BLOB_FIELD = null;
	public static final String SEQ_NAME = "msgSn";

	public BPELNodeVO()
	{
	}

	public void setPrimary(String msgSn)
	{
		this.msgSn = msgSn;
	}

	public String getPrimary(String delim)
	{
		StringBuffer buf = new StringBuffer();
		buf.append(this.msgSn);
		return buf.toString();
	}

	public Map getPrimary()
	{
		Map m = new HashMap();
		m.put("msgSn", msgSn);
		return m;
	}

	public String getTable()
	{
		return TABLE;
	}

	public String[] getBlobField()
	{
		return BLOB_FIELD;
	}

	public String getKeyName()
	{
		return SEQ_NAME;
	}

	public Serializable getKey()
	{
		return msgSn;
	}

	// set all properties to NULL
	public void setNULL()
	{
		this.msgSn = null;
		this.node = null;
		this.failAbort = null;
		this.refMsgSn = null;
		this.msgCd = null;
		this.callTyp = null;
		this.sndNode = null;
		this.sndAppCd = null;
		this.sndDt = null;
		this.sndTm = null;
		this.seqNb = null;
		this.status = null;
		this.tmStamp = null;
	}

	public boolean equals(Object o)
	{
		if (this == o) return true;
		if (!(o instanceof BPELNodeVO)) return false;
		BPELNodeVO obj = (BPELNodeVO) o;
		if (!msgSn.equals(obj.msgSn)) return false;
		if (!node.equals(obj.node)) return false;
		if (!failAbort.equals(obj.failAbort)) return false;
		if (!refMsgSn.equals(obj.refMsgSn)) return false;
		if (!msgCd.equals(obj.msgCd)) return false;
		if (!callTyp.equals(obj.callTyp)) return false;
		if (!sndNode.equals(obj.sndNode)) return false;
		if (!sndAppCd.equals(obj.sndAppCd)) return false;
		if (!sndDt.equals(obj.sndDt)) return false;
		if (!sndTm.equals(obj.sndTm)) return false;
		if (!seqNb.equals(obj.seqNb)) return false;
		if (!status.equals(obj.status)) return false;
		if (!tmStamp.equals(obj.tmStamp)) return false;
		return true;
	}

	// ֻ����������ɢ��
	public int hashCode()
	{
		long hashCode = getClass().hashCode();
		if (msgSn != null) hashCode += msgSn.hashCode();
		return (int) hashCode;
	}

	public int compareTo(Object o)
	{
		return -1;
	}

	// set all properties to default value...
	public void init()
	{
		this.failAbort = "1";
	}

	public String getMsgSn()
	{
		return msgSn;
	}

	public void setMsgSn(String msgSn)
	{
		this.msgSn = msgSn;
	}

	public String getNode()
	{
		return node;
	}

	public void setNode(String node)
	{
		this.node = node;
	}

	public String getFailAbort()
	{
		return failAbort;
	}

	public void setFailAbort(String failAbort)
	{
		this.failAbort = failAbort;
	}

	public String getRefMsgSn()
	{
		return refMsgSn;
	}

	public void setRefMsgSn(String refMsgSn)
	{
		this.refMsgSn = refMsgSn;
	}

	public String getMsgCd()
	{
		return msgCd;
	}

	public void setMsgCd(String msgCd)
	{
		this.msgCd = msgCd;
	}

	public String getCallTyp()
	{
		return callTyp;
	}

	public void setCallTyp(String callTyp)
	{
		this.callTyp = callTyp;
	}

	public String getSndNode()
	{
		return sndNode;
	}

	public void setSndNode(String sndNode)
	{
		this.sndNode = sndNode;
	}

	public String getSndAppCd()
	{
		return sndAppCd;
	}

	public void setSndAppCd(String sndAppCd)
	{
		this.sndAppCd = sndAppCd;
	}

	public String getSndDt()
	{
		return sndDt;
	}

	public void setSndDt(String sndDt)
	{
		this.sndDt = sndDt;
	}

	public String getSndTm()
	{
		return sndTm;
	}

	public void setSndTm(String sndTm)
	{
		this.sndTm = sndTm;
	}

	public String getSeqNb()
	{
		return seqNb;
	}

	public void setSeqNb(String seqNb)
	{
		this.seqNb = seqNb;
	}

	public String getStatus()
	{
		return status;
	}

	public void setStatus(String status)
	{
		this.status = status;
	}

	public String getTmStamp()
	{
		return tmStamp;
	}

	public void setTmStamp(String tmStamp)
	{
		this.tmStamp = tmStamp;
	}

	public void set(BPELNodeVO vo)
	{
		this.msgSn = vo.msgSn;
		this.node = vo.node;
		this.failAbort = vo.failAbort;
		this.refMsgSn = vo.refMsgSn;
		this.msgCd = vo.msgCd;
		this.callTyp = vo.callTyp;
		this.sndNode = vo.sndNode;
		this.sndAppCd = vo.sndAppCd;
		this.sndDt = vo.sndDt;
		this.sndTm = vo.sndTm;
		this.seqNb = vo.seqNb;
		this.status = vo.status;
		this.tmStamp = vo.tmStamp;
	}

	public static long getSerialVersionUID()
	{
		return serialVersionUID;
	}

	public StringBuffer toJson()
	{
		StringBuffer buf = new StringBuffer();
		buf.append(JsonUtil.obj2json(this));
		return buf;
	}

	public String getRetCd()
	{
		return retCd;
	}

	public void setRetCd(String retCd)
	{
		this.retCd = retCd;
	}

	public String getLang()
	{
		return lang;
	}

	public void setLang(String lang)
	{
		this.lang = lang;
	}

	public String getRetDesc()
	{
		return retDesc;
	}

	public void setRetDesc(String retDesc)
	{
		this.retDesc = retDesc;
	}

	public String getLocation()
	{
		return location;
	}

	public void setLocation(String location)
	{
		this.location = location;
	}

	public String getIp()
	{
		return ip;
	}

	public void setIp(String ip)
	{
		this.ip = ip;
	}

	public String getAppCd()
	{
		return appCd;
	}

	public void setAppCd(String appCd)
	{
		this.appCd = appCd;
	}

	public void afterLoad()
	{
		// TODO Auto-generated method stub

	}

	public void beforeLoad()
	{
		// TODO Auto-generated method stub

	}

	public void setManualSeq(Long seq)
	{

	}

	public void destory()
	{

	}

	public String toString()
	{
		StringBuffer buf = new StringBuffer(128);
		buf.append(getClass().getName() + "(serialVersionUID=" + serialVersionUID + "):");
		buf.append(toJson());
		return buf.toString();
	}
}
