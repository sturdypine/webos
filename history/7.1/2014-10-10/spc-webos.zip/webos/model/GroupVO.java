package spc.webos.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import spc.webos.util.JsonUtil;

/**
* genarated by sturdypine.chen
* Email: sturdypine@gmail.com
* description: 
*/
public class GroupVO implements ValueObject
{
	public static final long serialVersionUID = 20120406L;
	// ����������Ӧ�ֶε�����
	String id; // 
	String name; // 
	String depId; // 
	String orgId; // 
	String gtype; // 
	String gright; // 

	// �ʹ�VO�����������VO����
	
	// �ʹ�VO�������������Sql����
	// Note: ���������Sql����ΪString, Inegter...��Java final classʱ�� ֻ��ʹ��Object���� ����ʱ��ֻ��ͨ��
	// Object��toString()������ʹ�á�
	public static final String TABLE = "SYS_GROUP";
	public static final String[] BLOB_FIELD = null;
	public static final String SEQ_NAME = "null";

	
	public GroupVO()
	{
	}
	
	public void setPrimary()
	{
	}
	
	public String getPrimary(String delim)
	{
		StringBuffer buf = new StringBuffer();
		return buf.toString();
	}
	
	public Map getPrimary()
	{
		Map m = new HashMap();
		return m;
	}
	
	public String getTable()
	{
		return TABLE;
	}
	
	public String[] getBlobField()
	{
		return BLOB_FIELD;
	}
	
	public String getKeyName()
	{
		return SEQ_NAME;
	}
	
	public Serializable getKey()
	{
		return null;
	}
	
	// set all properties to NULL
	public void setNULL()
	{
    	this.id = null;
    	this.name = null;
    	this.depId = null;
    	this.orgId = null;
    	this.gtype = null;
    	this.gright = null;
	}
	
	public boolean equals(Object o)
	{
		if (this == o) return true;
		if (!(o instanceof GroupVO)) return false;
		GroupVO obj = (GroupVO) o;
		if (!id.equals(obj.id)) return false;
		if (!name.equals(obj.name)) return false;
		if (!depId.equals(obj.depId)) return false;
		if (!orgId.equals(obj.orgId)) return false;
		if (!gtype.equals(obj.gtype)) return false;
		if (!gright.equals(obj.gright)) return false;
		return true;
	}
	
	// ֻ����������ɢ��
	public int hashCode()
	{
		long hashCode = getClass().hashCode();
		return (int)hashCode;
	}
	
	public int compareTo(Object o)
	{
		return -1;
	}

	// set all properties to default value...
	public void init()
	{
	}
	
    public String getId()
    {
        return id;
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public String getName()
    {
        return name;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getDepId()
    {
        return depId;
    }
    
    public void setDepId(String depId)
    {
        this.depId = depId;
    }
    
    public String getOrgId()
    {
        return orgId;
    }
    
    public void setOrgId(String orgId)
    {
        this.orgId = orgId;
    }
    
    public String getGtype()
    {
        return gtype;
    }
    
    public void setGtype(String gtype)
    {
        this.gtype = gtype;
    }
    
    public String getGright()
    {
        return gright;
    }
    
    public void setGright(String gright)
    {
        this.gright = gright;
    }
    
	
	public void set(GroupVO vo)
	{
    	this.id = vo.id;
    	this.name = vo.name;
    	this.depId = vo.depId;
    	this.orgId = vo.orgId;
    	this.gtype = vo.gtype;
    	this.gright = vo.gright;
	}
	
	public static long getSerialVersionUID()
	{
		return serialVersionUID;
	}
	
	public StringBuffer toJson()
	{
		StringBuffer buf = new StringBuffer();
		buf.append(JsonUtil.obj2json(this));
		return buf;
	}
	
	public void afterLoad()
	{
		// TODO Auto-generated method stub
	}

	public void beforeLoad()
	{
		// TODO Auto-generated method stub
	}

	public void setManualSeq(Long seq)
	{
		
	}
	
	public void destory()
	{

	}
	
	public String toString()
	{
		StringBuffer buf = new StringBuffer(128);
		buf.append(getClass().getName() + "(serialVersionUID=" + serialVersionUID + "):");
		buf.append(toJson());
		return buf.toString();
	}
	
	public Object clone()
	{
		GroupVO obj = new GroupVO();
		obj.set(this);
		return obj;
	}
}
