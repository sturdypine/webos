package spc.webos.jsrmi.service;

import java.util.Map;

import spc.webos.service.IService;

public class JsrmiServiceConfigurer
{
	private Map services;

	public JsrmiServiceConfigurer()
	{
	}

	public JsrmiServiceConfigurer(Map services)
	{
		setServices(services);
	}

	public Map getServices()
	{
		if (services == null) return IService.SERVICES_JSRMI;
		services.putAll(IService.SERVICES_JSRMI);
		return services;
	}

	public void init()
	{
	}

	/**
	 * set serivces. for IoC use.
	 * 
	 * @param services
	 */
	public void setServices(Map services)
	{
		this.services = services;
	}
}
