package spc.webos.web.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;

import spc.webos.constant.Web;
import spc.webos.data.ArrayNode;
import spc.webos.data.AtomNode;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.persistence.Persistence;
import spc.webos.persistence.SQLItem;
import spc.webos.util.StringX;
import spc.webos.web.util.WebUtil;

public class ExtGridCtrller extends PageCtrller
{
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response)
			throws Exception
	{
		Map params = WebUtil.request2map(request, null);
		addCommonObj(params, request);
		// 1. ִ�з���
		Object data = WebUtil.invokeService(request, null, params);
		if (data instanceof IMessage)
		{
			List rows = ((IMessage) data).findArrayInResponse(
					request.getParameter(Web.REQ_KEY_RESULT_KEY_INMSG), new ArrayNode())
					.listValue();
			handleTable(paging(rows, request), ((IMessage) data).findAtomInResponse(
					request.getParameter(Web.REQ_KEY_TOTAL_SIZE_KEY_INMSG),
					new AtomNode(rows.size())), request, response);
			return null;
		}
		if (data instanceof ICompositeNode)
		{
			List rows = ((ICompositeNode) data).findArray(
					request.getParameter(Web.REQ_KEY_RESULT_KEY_INMSG), new ArrayNode())
					.listValue();
			handleTable(paging(rows, request), ((ICompositeNode) data).findAtom(
					request.getParameter(Web.REQ_KEY_TOTAL_SIZE_KEY_INMSG),
					new AtomNode(rows.size())), request, response);
			return null;
		}
		if (data instanceof Collection)
		{
			// a. ��ȡ�ֶ�����������ݽ�����е���Ҳ��List���ͣ���Ҫָ��ÿ�е��ֶ������ܱ�ΪJson��ʽ
			handleTable((Collection) data, params.get(Web.REQ_KEY_TOTAL_SIZE), request, response);
			return null;
		}
		// 2. �����ext�����ѯ����
		String selSql = (String) request.getParameter(Web.REQ_KEY_SQL_ID);
		// json ��ʽ�ı������ݣ�ǰ��Ҫ�����sql���
		if (!StringX.nullity(selSql)) handleSel(request, response, params);
		return null;
	}

	// added by chenjs 2011-12-22 �Ƿ�Ҫ����������ҳ
	protected List paging(List rows, HttpServletRequest request)
	{
		if (StringX.nullity(request.getParameter(Web.REQ_PAGING)) || rows == null
				|| rows.size() == 0) return rows;
		String limit = StringX.null2emptystr(request.getParameter(Web.REQ_GRIDDS_LIMIT),
				request.getParameter(Web.REQ_GRIDDS_DEF_LIMIT));
		if (StringX.nullity(limit)) return rows;
		String start = StringX.null2emptystr(request.getParameter(Web.REQ_GRIDDS_START), "0");
		if (rows.size() <= Integer.parseInt(limit))
		{ // ���Ŀǰ�������������limit���򲻷�ҳ��ֱ�ӷ���
			if (log.isInfoEnabled()) log.info("Fail to paging: rows size: " + rows.size()
					+ " <= imit: " + limit);
			return rows;
		}
		List nrows = new ArrayList();
		for (int i = Integer.parseInt(start); i < rows.size()
				&& (i < Integer.parseInt(start) + Integer.parseInt(limit)); i++)
			nrows.add(rows.get(i));
		return nrows;
	}

	protected void handleSel(HttpServletRequest request, HttpServletResponse response, Map model)
			throws Exception
	{
		List batchSQL = new ArrayList();
		String selSql = (String) request.getParameter(Web.REQ_KEY_SQL_ID);
		String sizeSql = (String) request.getParameter(Web.REQ_KEY_SIZE_SQL_ID);
		String delSql = (String) request.getParameter(Web.REQ_KEY_DEL_SQL_ID);
		String strBatchSQL = (String) request.getParameter(Web.REQ_KEY_BATCH_SQL);
		if (!StringX.nullity(strBatchSQL)) batchSQL = StringX.delimitedList(strBatchSQL,
				StringX.COMMA);
		if (!StringX.nullity(delSql)) batchSQL.add(delSql);
		if (!StringX.nullity(sizeSql)) batchSQL.add(sizeSql);
		if (!StringX.nullity(selSql)) batchSQL.add(selSql);
		addCommonObj(model, request);
		// Ϊ��������ܣ�ֱ���ò�ѯ�����json�ַ�����ʾ, ��ĳЩ������ܲ���Ҫǿ��ת�����ڲ�ѯ������溬�ж���������
		if (!model.containsKey("SQL_CLASS")) model.put(Persistence.RESULT_CLASS_PREFIX + selSql,
				SQLItem.RESULT_CLASS_JSON);
		// System.out.println(sizeSql+batchSQL+request.getParameter("SIZE_SQL_ID"));
		persistence.execute(batchSQL, model, model);

		if (sizeSql != null) sizeSql = sizeSql.replace('.', '_').toLowerCase();
		selSql = selSql.replace('.', '_').toLowerCase();
		List result = (List) model.get(selSql);
		Object totalSize = null;
		if (sizeSql != null) totalSize = model.get(sizeSql);
		handleTable(result, totalSize, request, response);
	}

	protected void handleTable(Collection data, Object totalSize, HttpServletRequest request,
			HttpServletResponse response) throws Exception
	{
		List columns = null;
		String column = (String) request.getParameter(Web.REQ_KEY_COLUMN);
		if (!StringX.nullity(column)) columns = StringX.split2list(column, StringX.COMMA);
		PrintWriter pw = response.getWriter();
		String callback = (String) request.getParameter("callback");
		if (!StringX.nullity(callback))
		{
			pw.print(callback);
			pw.print('(');
		}

		// handleTable(result, totalSize, request, response, columns);
		String v = StringX.table2extgrid(data, totalSize == null ? null : totalSize.toString(),
				columns);
		pw.print(v);
		if (!StringX.nullity(callback)) pw.print(')');
	}
}
