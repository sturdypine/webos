package spc.webos.flownode.util;

import java.util.List;
import java.util.Map;

import spc.webos.data.IMessage;
import spc.webos.flownode.ILookup;
import spc.webos.flownode.IFlowNode;
import spc.webos.util.SystemUtil;

public class Lookup implements ILookup
{
	protected Map trans; // ֱ�ӵĽ�����������Ϣ
	protected List supported; // ���ദ�����̾�֧��ĳһ�����͵Ľ����룬�����ǵ���������
	protected IFlowNode defaultFNode; // Ĭ�Ͻ��ܴ����Ľڵ�

	public IFlowNode lookup(IMessage msg)
	{
		String msgCd = msg.getMsgCd();
		IFlowNode fnode = null;
		if (trans != null)
		{
			fnode = (IFlowNode) trans.get(msgCd);
			if (fnode != null) return fnode;
		}
		try
		{
			System.out.println(msgCd);
			fnode = (IFlowNode) SystemUtil.getInstance().getBean(msgCd, IFlowNode.class);
			if (fnode != null) return fnode;
		}
		catch (Exception e)
		{
		}
		if (supported != null)
		{
			for (int i = 0; i < supported.size(); i++)
			{
				IFlowNode fn = (IFlowNode) supported.get(i);
				if (fn.support(msg)) return fn;
			}
		}
		return defaultFNode;
	}

	public void setTrans(Map trans)
	{
		this.trans = trans;
	}

	public void setSupported(List supported)
	{
		this.supported = supported;
	}

	public void setDefaultFNode(IFlowNode defaultFNode)
	{
		this.defaultFNode = defaultFNode;
	}
}
