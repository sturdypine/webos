package spc.webos.flownode.action;

import java.util.HashMap;
import java.util.Map;

import spc.webos.data.IMessage;
import spc.webos.flownode.IFlowContext;
import spc.webos.persistence.IPersistence;
import spc.webos.persistence.Persistence;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

public class PersistenceAction extends AbstractAction
{
	void execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		IPersistence persistence = Persistence.getInstance();
		Map params = new HashMap();
		SystemUtil.freemarker(params);
		Map results = new HashMap();
		persistence.execute(StringX.split(sqlId, StringX.COMMA), params, results);
		if (!StringX.nullity(resultKey)) msg.setInLocal(resultKey, results);
	}

	protected String sqlId;
	protected String resultKey;
	private static final long serialVersionUID = 1L;

	public String getSqlId()
	{
		return sqlId;
	}

	public void setSqlId(String sqlId)
	{
		this.sqlId = sqlId;
	}

	public String getResultKey()
	{
		return resultKey;
	}

	public void setResultKey(String resultKey)
	{
		this.resultKey = resultKey;
	}
}
