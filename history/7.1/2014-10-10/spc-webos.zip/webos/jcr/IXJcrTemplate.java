package spc.webos.jcr;

import java.util.List;

import org.springmodules.jcr.JcrOperations;

public interface IXJcrTemplate extends JcrOperations
{
	List getArchivesByPath(String path) throws Exception;

	List search(Archive archive, SearchCommand command) throws Exception;

	Archive getArchive(String uuid, boolean file) throws Exception;

	Archive getArchive(String uuid, boolean file, String[] fileNames) throws Exception;

	String insert(Archive archive) throws Exception;

	void deleteByUUID(final String uuid);

	boolean update(Archive archive) throws Exception;

	int delete(String uuid, String[] fileNames) throws Exception;
}
