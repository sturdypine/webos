package spc.webos.echain.service.impl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import spc.webos.data.CompositeNode;
import spc.webos.service.Service;
import spc.webos.util.StringX;
import spc.webos.web.common.ISessionUserInfo;

import com.ecc.echain.workflow.engine.EVO;

public class EChainService extends Service
{
	protected EVO fillEVO(EVO evo)
	{
		ISessionUserInfo sui = (ISessionUserInfo) ISessionUserInfo.SUI.get();
		if (sui != null)
		{
			if (StringX.nullity(evo.getCurrentUserID())) evo.setCurrentUserID(sui.getUserCode());
			if (StringX.nullity(evo.getOrgid())) evo.setOrgid(sui.getOrgId());
		}
		if (log.isDebugEnabled()) log.debug("evo:" + evo);
		return evo;
	}

	protected EVO map2evo(Map evomap)
	{
		Map map = new HashMap();
		Iterator keys = evomap.keySet().iterator();
		while (keys.hasNext())
		{
			String key = keys.next().toString();
			if (key.startsWith("evo.")) map.put(key.substring(4), evomap.get(key));
		}
		if (log.isDebugEnabled()) log.debug("evo.map:" + map);
		CompositeNode cnode = new CompositeNode(map);
		EVO evo = (EVO) cnode.toObject(new EVO());
		ISessionUserInfo sui = (ISessionUserInfo) ISessionUserInfo.SUI.get();
		if (sui != null)
		{
			if (StringX.nullity(evo.getCurrentUserID())) evo.setCurrentUserID(sui.getUserCode());
			if (StringX.nullity(evo.getOrgid())) evo.setOrgid(sui.getOrgId());
		}
		return evo;
	}

	protected Map evo2map(EVO evo)
	{
		CompositeNode cnode = new CompositeNode();
		cnode.set(evo);
		return cnode.plainMapValue();
	}
}
