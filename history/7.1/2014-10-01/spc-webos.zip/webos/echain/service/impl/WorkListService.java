package spc.webos.echain.service.impl;

import java.util.List;
import java.util.Map;
import java.util.Vector;

import spc.webos.echain.service.IWorkListService;

import com.ecc.echain.workflow.engine.EVO;
import com.ecc.echain.workflow.engine.WorkList;
import com.ecc.echain.workflow.engine.worklist.WorkListIF;
import com.ecc.echain.workflow.model.GatherVO;

public class WorkListService extends EChainService implements IWorkListService
{
	protected WorkListIF worklist = WorkList.getInstance();

	public List StatUserTodo(EVO evo)
	{
		if (log.isDebugEnabled()) log.debug("evo:" + evo);
		return worklist.StatUserTodo(evo);
	}

	public Vector getExceptionWorkList(EVO arg0)
	{
		if (log.isDebugEnabled()) log.debug("evo:" + arg0);
		return worklist.getExceptionWorkList(arg0);
	}

	public EVO getInstanceInfo(EVO arg0)
	{
		if (log.isDebugEnabled()) log.debug("evo:" + arg0);
		return worklist.getInstanceInfo(arg0);
	}

	public void getOriginalUserAllTodoWorkList()
	{
		worklist.getOriginalUserAllTodoWorkList();
	}

	public void getOriginalUserTodoWorkList()
	{
		worklist.getOriginalUserTodoWorkList();
	}

	public void getReplacerAllTodoWorkList()
	{
		worklist.getReplacerAllTodoWorkList();
	}

	public void getReplacerTodoWorkList()
	{
		worklist.getReplacerTodoWorkList();
	}

	public Vector getTaskPoolWorkList(EVO arg0)
	{
		if (log.isDebugEnabled()) log.debug("evo:" + arg0);
		return getTaskPoolWorkList(arg0);
	}

	public Vector getUserAllAnnounceWorkList(EVO arg0)
	{
		if (log.isDebugEnabled()) log.debug("evo:" + arg0);
		return getUserAllAnnounceWorkList(arg0);
	}

	public Vector getUserAllAvailableWorkList(EVO arg0)
	{
		if (log.isDebugEnabled()) log.debug("evo:" + arg0);
		return getUserAllAvailableWorkList(arg0);
	}

	public Vector getUserAllDoneWorkList(EVO arg0)
	{
		if (log.isDebugEnabled()) log.debug("evo:" + arg0);
		return getUserAllDoneWorkList(arg0);
	}

	public Vector getUserAllSignInWorkList(EVO arg0)
	{
		if (log.isDebugEnabled()) log.debug("evo:" + arg0);
		return getUserAllSignInWorkList(arg0);
	}

	public Vector getUserAllTodoWorkList(EVO arg0)
	{
		if (log.isDebugEnabled()) log.debug("evo:" + arg0);
		return getUserAllTodoWorkList(arg0);
	}

	public Vector getUserAvailableWorkList(EVO arg0)
	{
		if (log.isDebugEnabled()) log.debug("evo:" + arg0);
		return getUserAvailableWorkList(arg0);
	}

	public Vector getUserDoneWorkList(EVO arg0)
	{
		if (log.isDebugEnabled()) log.debug("evo:" + arg0);
		return getUserDoneWorkList(arg0);
	}

	public Vector getUserGatherTodoWorkList(GatherVO arg0, String arg1)
	{
		if (log.isDebugEnabled()) log.debug("gvo:" + arg0 + ", " + arg1);
		return getUserGatherTodoWorkList(arg0, arg1);
	}

	public Vector getUserSignInWorkList(EVO arg0)
	{
		if (log.isDebugEnabled()) log.debug("evo:" + arg0);
		return getUserSignInWorkList(arg0);
	}

	public Vector getUserStartupWorkList(EVO arg0)
	{
		if (log.isDebugEnabled()) log.debug("evo:" + arg0);
		return getUserStartupWorkList(arg0);
	}

	public Vector getUserTodoWorkList(EVO arg0)
	{
		if (log.isDebugEnabled()) log.debug("evo:" + arg0);
		return getUserTodoWorkList(arg0);
	}

	public Vector getUserWorkList(EVO arg0)
	{
		if (log.isDebugEnabled()) log.debug("evo:" + arg0);
		return getUserWorkList(arg0);
	}

	public Vector getWFStatusEndWorkList(EVO arg0)
	{
		if (log.isDebugEnabled()) log.debug("evo:" + arg0);
		return getWFStatusEndWorkList(arg0);
	}

	// -------------------------------------------------------------
	public List getUserSignInWorkList(Map evo)
	{
		return worklist.getUserSignInWorkList(map2evo(evo));
	}

	public List getUserAllSignInWorkList(Map evo)
	{
		return worklist.getUserAllSignInWorkList(map2evo(evo));
	}

	public List getUserTodoWorkList(Map evo)
	{
		return worklist.getUserTodoWorkList(map2evo(evo));
	}

	public List getUserDoneWorkList(Map evo)
	{
		return worklist.getUserDoneWorkList(map2evo(evo));
	}

	public List getUserAllTodoWorkList(Map evo)
	{
		return worklist.getUserAllTodoWorkList(map2evo(evo));
	}

	public List getUserAllAnnounceWorkList(Map evo)
	{
		return worklist.getUserAllAnnounceWorkList(map2evo(evo));
	}

	public List getUserAllDoneWorkList(Map evo)
	{
		return worklist.getUserAllDoneWorkList(map2evo(evo));
	}

	public List getUserAvailableWorkList(Map evo)
	{
		return worklist.getUserAvailableWorkList(map2evo(evo));
	}

	public List getUserAllAvailableWorkList(Map evo)
	{
		return worklist.getUserAllAvailableWorkList(map2evo(evo));
	}

	public List getExceptionWorkList(Map evo)
	{
		return worklist.getExceptionWorkList(map2evo(evo));
	}

	public List getWFStatusEndWorkList(Map evo)
	{
		return worklist.getWFStatusEndWorkList(map2evo(evo));
	}

	public Map getInstanceInfo(Map evo)
	{
		return evo2map(worklist.getInstanceInfo(map2evo(evo)));
	}

	public List getUserWorkList(Map evo)
	{
		return worklist.getUserWorkList(map2evo(evo));
	}

	public List getUserStartupWorkList(Map evo)
	{
		return worklist.getUserStartupWorkList(map2evo(evo));
	}

	public List getTaskPoolWorkList(Map evo)
	{
		return worklist.getTaskPoolWorkList(map2evo(evo));
	}

	public List StatUserTodo(Map evo)
	{
		return worklist.StatUserTodo(map2evo(evo));
	}
}
