package spc.webos.jsrmi.protocal.converters;

/**
 * @author spc
 */
public interface ConverterLookup
{
	Converter lookupConverterForType(Class type);

	Converter lookupConverterForTagName(String tagName);

	Converter getNullConverter();
}
