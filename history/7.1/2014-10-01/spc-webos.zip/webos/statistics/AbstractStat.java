package spc.webos.statistics;

import java.util.HashMap;
import java.util.Map;

import spc.webos.data.IMessage;
import spc.webos.data.Status;
import spc.webos.log.Log;
import spc.webos.persistence.IPersistence;
import spc.webos.persistence.Persistence;

public abstract class AbstractStat implements IStat
{
	String name;
	protected IPersistence persistence = Persistence.getInstance();
	protected Log log = Log.getLogger(getClass());

	public void init() throws Exception
	{
		if (name != null) STATISTICS.put(name, this);
		refresh();
	}

	public void setPersistence(IPersistence persistence)
	{
		this.persistence = persistence;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public void trigger(IMessage msg, long cur)
	{
		Statistics stat = find(msg);
		if (stat != null) stat(msg, cur, stat);
	}

	public boolean changeStatus(Map param)
	{
		return false;
	}

	public abstract Statistics find(IMessage msg);

	protected void stat(IMessage msg, long cur, Statistics stat)
	{
		// if (log.isDebugEnabled()) log.debug(h.getTransSN() + ","
		// + h.getStatus());
		Status status = msg.getStatus();
		if (status.isUnderWay())
		{
			stat.request();
			return;
		}
		long costTime = getCostTime(msg, cur, stat);
		if (status.isSuccess()) stat.success(msg.getMsgSn(), (int) costTime);
		else if (status.isFail()) stat.fail(status.getRetCd(), msg.getMsgSn(), (int) costTime);
	}

	public long getCostTime(IMessage msg, long cur, Statistics stat)
	{
		return 0;
	}

	public void refresh() throws Exception
	{
	}

	public Map checkStatus(Map param)
	{
		Map status = new HashMap();
		status.put("clazz", getClass().getName());
		status.put("name", name);
		return status;
	}
}
