package spc.webos.env;

import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.core.io.ResourceLoader;
import spc.webos.config.AppConfig;

/**
 * ��ģ�������࣬����һ��������Ϣ��ÿһ��������Ϣ�����ض���ģ��
 * 
 * @author chen.jinsong
 * 
 */
public class MultiModuleProperties extends Properties implements
		ResourceLoaderAware
{
	private static final long serialVersionUID = 20070715L;
	Map moduleLoactions;
	ResourceLoader resourceLoader;

	public void setResourceLoader(ResourceLoader resourceLoader)
	{
		this.resourceLoader = resourceLoader;
	}

	public Map getModuleLoactions()
	{
		return moduleLoactions;
	}

	public void setModuleLoactions(Map moduleLoactions)
	{
		this.moduleLoactions = moduleLoactions;
	}

	/**
	 * ��ʼ����������������Ϣ
	 * 
	 * @throws Exception
	 */
	public void init() throws Exception
	{
		Iterator iter = moduleLoactions.keySet().iterator();
		while (iter.hasNext())
		{ // ��ó�ʱ��Դ��Key
			String key = (String) iter.next();
			// System.out.println("KEY = " + key);
			super.put(key, loadProperties((String) moduleLoactions.get(key)));
		}
		moduleLoactions = null;
	}

	/**
	 * ����Properties�ķ���
	 */
	public String getProperty(String key)
	{
		// System.out.println("KEY = "+key);
		int index = key.indexOf('.');
		if (index < 0) return null;
		String module = key.substring(0, index);
		String name = key.substring(index + 1);
		// System.out.println("module=" + module + ", key="
		// + key.substring(index + 1));
		Properties p = (Properties) super.get(module);
		Object value = null;
		if (p == null)
		{
			value = AppConfig.getInstance().getProperty(module, name, null);
			if (value != null) value = value.toString();
		}
		return p == null ? (String) value : p.getProperty(name);
	}

	/**
	 * ��ָ���ĵ�ַ��ȡ������Ϣ
	 * 
	 * @param loaction
	 * @return
	 * @throws Exception
	 */
	Properties loadProperties(String loaction) throws Exception
	{
		InputStream is = null;
		try
		{
			is = resourceLoader.getResource(loaction).getInputStream();
			Properties p = new Properties();
			p.load(is);
			return p;
		}
		finally
		{
			try
			{
				if (is != null) is.close();
			}
			catch (Exception e)
			{
			}
		}
	}

	public Object clone()
	{
		return this;
	}
}
