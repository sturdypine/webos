package spc.webos.service.common.impl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import spc.webos.data.IMessage;
import spc.webos.service.Service;
import spc.webos.service.common.ISeqNoService;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

/**
 * �����ݿ������������ˮ��, ÿ���ؼ��ֶ�Ӧһ��SQL
 * 
 * @author spc
 * 
 */
public class DBSeqNoService extends Service implements ISeqNoService
{
	public synchronized String rndoGenSN(String key, IMessage msg, Map params) throws Exception
	{
		SequenceInfo seqInfo = (SequenceInfo) seqCache.get(key);
		if (next(seqInfo)) return String.valueOf(seqInfo.current);

		params = SystemUtil.freemarker(params, msg);
		String[] sqlId = (String[]) sqlInfo.get(key);
		for (int i = 0; i < tryTimes; i++)
			if (readBatch(sqlId, params, seqInfo)) break;
		if (next(seqInfo)) return String.valueOf(seqInfo.current);
		return null;
	}

	protected boolean next(SequenceInfo seqInfo)
	{
		seqInfo.current += seqInfo.step;
		return seqInfo.current <= seqInfo.min + seqInfo.cacheNum;
	}

	public void init() throws Exception
	{
		if (sqlInfo == null || sqlInfo.size() <= 0)
		{
			log.warn("sqlInfo is null");
			return;
		}
		Map info = new HashMap();
		Iterator keys = sqlInfo.keySet().iterator();
		while (keys.hasNext())
		{
			String key = keys.next().toString();
			String sql = sqlInfo.get(key).toString();
			info.put(key, StringX.split(sql, ","));
		}
		sqlInfo = info;
	}

	protected boolean readBatch(String[] sqlId, Map params, SequenceInfo seqInfo)
	{
		String curSn = persistence.execute(sqlId[0], params).toString();
		String nextSn = String.valueOf(Long.parseLong(curSn) + seqInfo.cacheNum);
		params.put("curSn", curSn);
		params.put("nextSn", nextSn);
		int[] rows = (int[]) persistence.execute(sqlId[1], params);
		if (rows[0] <= 0) return false;
		seqInfo.min = seqInfo.current = Long.parseLong(curSn);
		return true;
	}

	protected int tryTimes = 10;
	protected Map sqlInfo;
	protected Map seqCache = new HashMap();

	public void setSeqCache(Map seqCache)
	{
		this.seqCache = seqCache;
	}

	public void setTryTimes(int tryTimes)
	{
		this.tryTimes = tryTimes;
	}

	public void setSqlInfo(Map sqlInfo)
	{
		this.sqlInfo = sqlInfo;
	}
}
