package spc.webos.service.common.impl;

import java.text.ParseException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import spc.webos.service.Service;
import spc.webos.service.common.IWorkingDayService;
import spc.webos.util.StringX;

public class WorkingDayService extends Service implements IWorkingDayService
{
	static WorkingDayService WORKING_DAY = new WorkingDayService();
	Map workingDay; // ��������������ǹ����յ���Щʱ��
	Map holiday; // ��ŷ������������Ǽ��յ���Щʱ��
	String sqlId; // ����ǲ��������ļ�, �����������ļ���·��

	/**
	 * �ж�һ�������Ƿ��ǽڼ���
	 * 
	 * @param dt
	 *            ��ʽΪ1981-01-26 yyyy-MM-dd
	 * @return
	 * @throws ParseException
	 */
	public boolean isHoliday(String dt)
	{
		// System.out.println("dt = " + dt);
		dt = dt.replaceAll("-", StringX.EMPTY_STRING).replaceAll("/", StringX.EMPTY_STRING);
		String y = dt.substring(0, 4);
		String md = '|' + dt.substring(4);
		StringBuffer work = (StringBuffer) workingDay.get(y);
		if (work != null && work.indexOf(md) >= 0) return false;
		StringBuffer holiday = (StringBuffer) this.holiday.get(y);
		if (holiday != null && holiday.indexOf(md) >= 0) return true;
		Calendar c = Calendar.getInstance();
		c.set(Integer.parseInt(y), Integer.parseInt(dt.substring(4, 6)), Integer.parseInt(dt
				.substring(6, 8)));
		int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
		return dayOfWeek == 6 || dayOfWeek == 7;
	}

	public String toJson()
	{
		StringBuffer buf = new StringBuffer();
		buf.append('{');
		buf.append(toJson("workingDay", workingDay));
		buf.append(',');
		buf.append(toJson("holiday", holiday));
		buf.append('}');
		return buf.toString();
	}

	public String toJson(String k, Map days)
	{
		StringBuffer buf = new StringBuffer();
		buf.append(k);
		buf.append(':');
		buf.append('{');
		if (days != null)
		{
			Iterator keys = days.keySet().iterator();
			while (keys.hasNext())
			{
				String key = (String) keys.next();
				buf.append('\'');
				buf.append(key);
				buf.append('\'');
				buf.append(':');
				buf.append('\'');
				buf.append(days.get(key));
				buf.append('\'');
			}
		}
		buf.append('}');
		return buf.toString();
	}

	public synchronized void setHoliday(List dts)
	{

	}

	public synchronized void setWorkingDay(List dts)
	{

	}

	public void init() throws Exception
	{
		super.init();
		refresh();
	}

	public void refresh() throws Exception
	{
		Map workingDay = new HashMap();
		Map holiday = new HashMap();
		List record = (List) persistence.execute(sqlId, null);
		for (int i = 0; i < record.size(); i++)
		{
			List row = (List) record.get(i);
			int dt = Integer.parseInt(row.get(0).toString());
			String y = String.valueOf(dt / 10000);
			int md = dt % 10000;
			String strMD = (md >= 1000 ? String.valueOf(md) : '0' + String.valueOf(md)) + '|';
			Map map = "1".equals(row.get(1).toString()) ? workingDay : holiday;
			StringBuffer buf = (StringBuffer) map.get(y);
			if (buf == null)
			{
				buf = new StringBuffer('|');
				map.put(String.valueOf(y), buf);
			}
			buf.append(strMD);
		}
		this.workingDay = workingDay;
		this.holiday = holiday;
	}

	private WorkingDayService()
	{
	}

	public static WorkingDayService getInstance()
	{
		return WORKING_DAY;
	}

	public void setSqlId(String sqlId)
	{
		this.sqlId = sqlId;
	}
}
