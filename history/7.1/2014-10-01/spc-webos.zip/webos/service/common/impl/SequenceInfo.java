package spc.webos.service.common.impl;

public class SequenceInfo implements java.io.Serializable
{
	private static final long serialVersionUID = 1L;
	public long min = Long.MIN_VALUE;
	public long max = Long.MAX_VALUE;
	public long step = 1;
	public long current = 1;
	public long cacheNum = -1;

	public SequenceInfo()
	{
	}

	public SequenceInfo(long min, long max)
	{
		this(min, max, 1);
	}

	public SequenceInfo(long min, long max, long step)
	{
		this.min = min;
		this.max = max;
		this.step = step;
		this.current = min;
	}

	public void init()
	{
		current = min;
	}

	public long getMin()
	{
		return min;
	}

	public void setMin(long min)
	{
		this.min = min;
	}

	public long getMax()
	{
		return max;
	}

	public void setMax(long max)
	{
		this.max = max;
	}

	public long getStep()
	{
		return step;
	}

	public void setStep(long step)
	{
		this.step = step;
	}

	public long getCurrent()
	{
		return current;
	}

	public long getCacheNum()
	{
		return cacheNum;
	}

	public void setCacheNum(long cacheNum)
	{
		this.cacheNum = cacheNum;
	}

	public void setCurrent(long current)
	{
		this.current = current;
	}

	public String toString()
	{
		return "s:" + min + ", e:" + max + ", step:" + step + ", cur:" + current;
	}
}
