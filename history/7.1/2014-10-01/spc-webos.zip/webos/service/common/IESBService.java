package spc.webos.service.common;

import spc.webos.data.ICompositeNode;

public interface IESBService
{
	String esb(String reqXml) throws Exception;

	ICompositeNode execute(ICompositeNode transaction) throws Exception;
}
