package spc.webos.service.common;

import java.util.Map;

import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;

public interface IMsgFlowService
{
	ICompositeNode execute(ICompositeNode transaction) throws Exception;

	IMessage execute(IMessage msg) throws Exception;

	IMessage execute(String xml) throws Exception;

	// added by chenjs 2011-12-09 ֧��ǰ��griddsʹ��msgflow���û�ȡ���
	IMessage gridds(Map params) throws Exception;
}
