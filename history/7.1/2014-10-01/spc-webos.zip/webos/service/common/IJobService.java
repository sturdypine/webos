package spc.webos.service.common;

public interface IJobService
{
	void deleteTempFiles();

	void executeSql();
}
