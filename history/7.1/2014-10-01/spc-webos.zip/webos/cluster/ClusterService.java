package spc.webos.cluster;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;

import spc.webos.thread.DaemonThread;

/**
 * һ��ɸ��ؾ���ķ��񣬵�����ָ�����������������������������ʹ����������
 * 
 * @author spc
 * 
 */
public class ClusterService
{
	Map balancedServiceMap;
	List balancedServiceList = new ArrayList();
	int retryInterval = 60;
	long cursor = 0; // ��ǰ���ط����ָ�룬������ѯ���з���
	DaemonThread retryThread; // ���ϻָ��߳�
	static Logger log = Logger.getLogger(ClusterService.class);

	public void setBalancedServiceMap(Map balancedServiceMap)
	{
		this.balancedServiceMap = balancedServiceMap;
	}

	public void init()
	{
		Iterator values = balancedServiceMap.values().iterator();
		while (values.hasNext())
			balancedServiceList.add(values.next());
		retryThread = new DaemonThread()
		{
			public void execute() throws Exception
			{
				for (int i = 0; i < balancedServiceList.size(); i++)
				{
					IClusterService service = ((IClusterService) balancedServiceList
							.get(i));
					try
					{
						if (!service.available()) service.refresh();
					}
					catch (Exception e)
					{
						log.warn("retry:" + service.getClass() + ":"
								+ service.getName(), e);
					}
				}
				Thread.sleep(retryInterval * 1000);
			}
		};
		retryThread.start();
	}

	public final Object excute(Object req) throws Exception
	{
		return excute(null, req);
	}

	/**
	 * �Լ�Ⱥ�ķ�����һ����ѯ�����һ�ֻ�ûִ�гɹ��򷵻�
	 * 
	 * @param mainServiceName
	 * @param req
	 * @return
	 * @throws Exception
	 */
	public final Object excute(String mainServiceName, Object req)
			throws Exception
	{
		IClusterService service = null;
		if (mainServiceName != null) service = (IClusterService) balancedServiceMap
				.get(mainServiceName);
		try
		{
			if (service != null && service.available()) return service
					.execute(req);
		}
		catch (ServiceException se)
		{
		}
		int start = ((int) (cursor++)) % balancedServiceList.size();
		for (int i = 0; i <= balancedServiceList.size(); i++, start++)
		{
			if (start >= balancedServiceList.size()) start = 0;
			try
			{
				service = ((IClusterService) balancedServiceList.get(start));
				return service.execute(req);
			}
			catch (ServiceException se)
			{
			}
		}
		throw new ServiceException();
	}

	public final Object excute(Object req, int timeout) throws Exception
	{
		return excute(null, req, timeout);
	}

	/**
	 * timeout = -1 ��ʾ���޳���
	 * 
	 * @param mainServiceName
	 * @param req
	 * @param timeout
	 * @return
	 * @throws Exception
	 */
	public final Object excute(String mainServiceName, Object req, int timeout)
			throws Exception
	{
		IClusterService service = null;
		if (mainServiceName != null) service = (IClusterService) balancedServiceMap
				.get(mainServiceName);
		try
		{// ֻ�����������Ƿ���ü�飬�Ա��÷������һ��������
			if (service != null && service.available()) return service
					.execute(req);
		}
		catch (ServiceException se)
		{
		}
		long s = System.currentTimeMillis();
		int start = ((int) (cursor++)) % balancedServiceList.size();
		while (true)
		{
			if (start >= balancedServiceList.size()) start = 0;
			try
			{
				return ((IClusterService) balancedServiceList.get(start))
						.execute(req);
			}
			catch (ServiceException se)
			{
			}
			start++;
			if (timeout > 0 && System.currentTimeMillis() - s > timeout) break;
		}
		throw new ServiceException();
	}

	public void setRetryInterval(int retryInterval)
	{
		this.retryInterval = retryInterval;
	}

	public DaemonThread getRetryThread()
	{
		return retryThread;
	}
}
