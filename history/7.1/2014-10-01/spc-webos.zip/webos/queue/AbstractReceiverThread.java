package spc.webos.queue;

import java.util.Hashtable;

import spc.webos.log.Log;
import spc.webos.util.StringX;

public abstract class AbstractReceiverThread extends AccessThread
{
	protected byte[] messageId; // 701 2013-09-12 ������ȡ�߳̽���msgIdƥ���ȡ
	protected IOnMessage onMessage;
	protected Hashtable props;

	// protected int timeout = 1000;

	public AbstractReceiverThread()
	{
		super();
		rw = AccessThread.RW_READ;
	}

	public void execute() throws Exception
	{
		String qName = !StringX.nullity(qname) ? qname : bufferName;
		startThreadLog();
		try
		{
			Object obj = receive(qName);
			if (obj == null) return;
			if (onMessage == null) log.warn("onMessage is null for " + obj);
			else onMessage.onMessage(obj, (AccessTPool) pool, this);
		}
		finally
		{
			Log.print();
		}
	}

	// maybe QueueMessage, maybe IMessage
	public abstract Object receive(String qName) throws Exception;

	public Hashtable getProps()
	{
		return props;
	}

	public void setProps(Hashtable props)
	{
		this.props = props;
	}

	// public int getTimeout()
	// {
	// return timeout;
	// }
	//
	// public void setTimeout(int timeout)
	// {
	// this.timeout = timeout;
	// }

	public IOnMessage getOnMessage()
	{
		return onMessage;
	}

	public void setOnMessage(IOnMessage onMessage)
	{
		this.onMessage = onMessage;
	}

	public byte[] getMessageId()
	{
		return messageId;
	}

	public void setMessageId(byte[] messageId)
	{
		this.messageId = messageId;
	}

	public void setMessageId(String messageId)
	{
		this.messageId = messageId.getBytes();
	}
}
