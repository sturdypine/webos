package spc.webos.queue.ibmmq;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import spc.webos.queue.AccessTPool;
import spc.webos.queue.AccessThread;
import spc.webos.thread.DaemonThread;
import spc.webos.util.JsonUtil;

public class MQAccessTPool extends AccessTPool
{
	public MQAccessTPool()
	{
	}

	public MQAccessTPool(int rw, int size, Hashtable props, String bufferName)
	{
		this.rw = rw;
		this.size = size;
		this.props = props;
		this.bufferName = bufferName;
	}

	public DaemonThread borrow()
	{
		if (msgIdCache != null && msgBuf != null) return new ConditionReceiverThread(this, props,
				msgBuf, msgIdCache);
		if (AccessThread.RW_READ == rw)
		{
			if (creator == null) return new ReceiverThread(this, props, bufferName, buf, qname,
					onMessage, messageId);
			return new BlobReceiverThread(this, props, buf, qname, creator, onMessage);
		}
		return new SenderThread(this, props, buf, qname, msgIdCache);
	}

	public static List<AccessTPool> createATPoolList(String strPools)
	{
		List list = (List) JsonUtil.json2obj(strPools);
		List<AccessTPool> accessPools = new ArrayList<AccessTPool>();
		for (int i = 0; i < list.size(); i++)
		{
			MQAccessTPool pool = new MQAccessTPool();
			pool.setLocation((Map) list.get(i));
			accessPools.add(pool);
		}
		return accessPools;
	}
}
