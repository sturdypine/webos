package spc.webos.acceptor;

import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Map;

import org.xsocket.connection.INonBlockingConnection;

import spc.webos.buffer.IBuffer;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.thread.IBufferMessage;
import spc.webos.util.bytes.DefaultHeadLength;
import spc.webos.util.http.HTTPHeader;

/**
 * socketЭ����뱨��
 * 
 * @author spc
 * 
 */
public class SocketMessage implements IBufferMessage
{
	public HTTPHeader reqHttpHdr;
	public byte[] reqmsg; // ����������
	public HTTPHeader repHttpHdr;
	public Map defRepHttpHdrParams; // Ĭ��Ӧ�����
	public byte[] repmsg; // Ӧ��������

	public DefaultHeadLength dhl = new DefaultHeadLength();
	// public int hdrLen; // ���ķ��Ͷ���ͷ����
	// public boolean containHdrLenSelf; // 2012-11-26 chenjs ��Щģʽ����ͷ��Ϣ�������ȱ���
	// public boolean len2bcd;
	// public boolean hdrLenBinary;
	
	public boolean longCnn; // �ͻ����Ƿ�����
	public int localPort; // ���񷽽��ܶ˿�
	public boolean endFlag;
	public byte endFlagChar; // 712_20140901
	public boolean responseOrig; // 712_20140901 Ӧ��ʱ����ԭʼ���ݣ�������
	public String protocol; // Э��
	public InetAddress remoteAddress; // Զ�̿ͻ������ӵ�ַ
	public InetAddress localAddress; // ����˽ӿ�

	public IBuffer repbuf; // Ӧ��buffer
	public INonBlockingConnection nbc;
	public OutputStream os; // socketЭ��
	public Socket socket;
	
	public long requestTime = System.currentTimeMillis(); // 713_20140921 �������ʱ��

	public SocketMessage()
	{
	}

	public SocketMessage(Socket s, OutputStream os, byte[] reqmsg, int hdrLen, IBuffer repbuf,
			String protocol)
	{
		this.socket = s;
		this.reqmsg = reqmsg;
		this.os = os;
		dhl.hdrLen = hdrLen;
		remoteAddress = s.getInetAddress();
		localAddress = s.getLocalAddress();
		this.repbuf = repbuf;
		this.protocol = protocol;
		this.localPort = s.getLocalPort();
	}

	public SocketMessage(INonBlockingConnection nbc, byte[] reqmsg, int hdrLen,
			boolean containHdrLenSelf, IBuffer repbuf, String protocol, DefaultHeadLength dhl)
	{
		this(nbc, reqmsg, hdrLen, false, repbuf, protocol);
		this.dhl = dhl;
		// dhl.len2bcd = len2bcd;
		// dhl.hdrLenBinary = hdrLenBinary;
		// dhl.containHdrLenSelf = containHdrLenSelf;
	}

	public SocketMessage(INonBlockingConnection nbc, byte[] reqmsg, int hdrLen, IBuffer repbuf,
			String protocol, boolean len2bcd, boolean hdrLenBinary)
	{
		this(nbc, reqmsg, hdrLen, false, repbuf, protocol);
		dhl.len2bcd = len2bcd;
		dhl.hdrLenBinary = hdrLenBinary;
	}

	public SocketMessage(INonBlockingConnection nbc, byte[] reqmsg, int hdrLen, boolean endFlag,
			IBuffer repbuf, String protocol)
	{
		this.localPort = nbc.getLocalPort();
		this.reqmsg = reqmsg;
		this.nbc = nbc;
		dhl.hdrLen = hdrLen;
		this.endFlag = endFlag;
		remoteAddress = nbc.getRemoteAddress();
		localAddress = nbc.getLocalAddress();
		this.repbuf = repbuf;
		this.protocol = protocol;
	}

	public IMessage toMessage(IMessageConverter converter) throws Exception
	{
		IMessage msg = converter.deserialize(reqmsg);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_SOCKETMSG, this); // ���������Ϣ��ԭʼ��Ϣ
		msg.setInLocal(MsgLocalKey.ACCEPTOR_PROTOCOL, protocol);
		if (repbuf != null) msg.setInLocal(MsgLocalKey.LOCAL_REP_BUFFER, repbuf);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, reqmsg);
		return msg;
	}

	public String toString()
	{
		return "SM:: " + localPort + ", " + remoteAddress;
	}
}
