package spc.webos.endpoint;

public class PooledClusterEndpoint extends AbstractClusterEndpoint
{
	public void execute(Executable exe) throws Exception
	{
		int failCount = 0;
		while (true)
		{
			Endpoint endpoint = (Endpoint) endpointPool.borrow();
			try
			{
				if (execute(endpoint, exe, failCount++)) return;
			}
			finally
			{
				endpointPool.release(endpoint);
			}
		}
	}

	public void destory()
	{
		endpointPool.destory();
	}

	protected EndpointPool endpointPool;

	public void setEndpointPool(EndpointPool endpointPool)
	{
		this.endpointPool = endpointPool;
	}
}
