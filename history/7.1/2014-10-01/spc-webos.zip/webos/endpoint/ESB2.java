package spc.webos.endpoint;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import spc.webos.cache.ICache;
import spc.webos.cache.Map2Cache;
import spc.webos.constant.Common;
import spc.webos.log.Log;
import spc.webos.queue.AbstractReceiverThread;
import spc.webos.queue.AccessTPool;
import spc.webos.queue.IOnMessage;
import spc.webos.queue.IQueueAccess;
import spc.webos.queue.QueueMessage;
import spc.webos.queue.ibmmq.MQAccessTPool;
import spc.webos.queue.ibmmq.MQCnnPool;
import spc.webos.queue.ibmmq.QueueAccess;
import spc.webos.util.StringX;

public class ESB2 implements Endpoint
{
	protected IQueueAccess synAccess;
	protected boolean shortCnn;

	protected IQueueAccess access;
	protected String reqQName = "REQ";
	// protected String requestQName; // ҵ�����REQ.ESB
	protected String repQName = "REP";

	protected String jvm = StringX.EMPTY_STRING;
	private static boolean init;
	protected int timeout = 60;
	protected Map mqmd; // ����MQ��ϢĬ��ͷ��Ϣ

	protected String synReplyToQ;
	protected boolean matchMsgId = true;
	protected List<AccessTPool> synResponsePools; // ͬ��Ӧ���ȡ�̳߳�
	protected ICache cache = new Map2Cache(60);
	protected IOnMessage synResponseOnMessage = new ESB2OnMessage(this);

	protected String asynReplyToQ;
	protected List<AccessTPool> asynResponsePools; // �����ȡ�̳߳�
	protected IOnMessage asynResponseOnMessage;

	protected List<AccessTPool> requestPools; // �����ȡ�̳߳�
	protected IOnMessage requestOnMessage;

	public Log log = Log.getLogger(getClass());
	protected static ESB2 esb2 = new ESB2();
	public final static String VERSION = "1.0_20140110";

	public void init() throws Exception
	{
		if (init) throw new Exception("init repeat!!!");
		init = true;
		cache.setName("C_" + getSeqNb(10));
		// 701,2013-09-12 ����������ṩreplyToQ, ���첽��ȡ�߳��Ե�ǰjvm���ƥ���ȡmessageId��Ϣ
		String messageId = jvm + StringX.ZEROS;
		messageId = messageId.substring(0, 24);
		log.info("Ver:" + VERSION + ", start syn response pools:"
				+ (synResponsePools == null ? 0 : synResponsePools.size()) + ", msgId:" + messageId
				+ ", cache:" + cache.getName());
		for (int i = 0; synResponsePools != null && i < synResponsePools.size(); i++)
		{
			AccessTPool pool = synResponsePools.get(i);
			if (StringX.nullity(pool.getName())) pool.setName(synReplyToQ + "::" + i);
			if (matchMsgId) pool.setMessageId(messageId);
			if (StringX.nullity(pool.getQname())) pool.setQname(synReplyToQ);
			pool.setOnMessage(synResponseOnMessage);
			pool.init();
			pool.startAll();
		}

		log.info("start asyn response pools:"
				+ (asynResponsePools == null ? 0 : asynResponsePools.size()));
		for (int i = 0; asynResponsePools != null && i < asynResponsePools.size(); i++)
		{
			AccessTPool pool = asynResponsePools.get(i);
			if (StringX.nullity(pool.getQname())) pool.setQname(asynReplyToQ);
			if (StringX.nullity(pool.getName())) pool.setName(pool.getQname() + "::" + i);
			pool.setOnMessage(asynResponseOnMessage);
			pool.init();
			pool.startAll();
		}

		log.info("start request pools:" + (requestPools == null ? 0 : requestPools.size()));
		for (int i = 0; requestPools != null && i < requestPools.size(); i++)
		{
			AccessTPool pool = requestPools.get(i);
			if (StringX.nullity(pool.getName())) pool.setName(pool.getQname() + "::" + i);
			pool.setOnMessage(requestOnMessage);
			pool.init();
			pool.startAll();
		}
	}

	public void setLocation(String location) throws Exception
	{
		throw new RuntimeException("No method!!!");
	}

	public String getSeqNb()
	{
		return getSeqNb(15);
	}

	public String getSeqNb(int len)
	{
		String seqNb = jvm + getTimeSN(8) + random(24);
		return seqNb.substring(0, len);
	}

	public String getSeqNb(String appCd)
	{
		String seqNb = jvm + appCd + getTimeSN(8) + random(24);
		return seqNb.substring(0, 24);
	}

	public String getSeqNb(String appCd, int len)
	{
		String seqNb = jvm + appCd + getTimeSN(8) + random(24);
		return seqNb.substring(0, len);
	}

	static long LAST_TIME;

	public synchronized String getTimeSN(int num)
	{
		long time = System.currentTimeMillis();
		if (time <= LAST_TIME) time = LAST_TIME + 1; // �����ǰʱ�����һʱ����ͬһ���룬�������������һ����
		LAST_TIME = time;
		String str = String.valueOf(time);
		return num > str.length() ? str : str.substring(str.length() - num);
	}

	public String random(int len)
	{
		String random = String.valueOf(Math.random()).substring(2)
				+ String.valueOf(Math.random()).substring(2);
		random = random.replaceAll("E", StringX.EMPTY_STRING).replaceAll("-", StringX.EMPTY_STRING);
		return len > random.length() ? random : random.substring(random.length() - len);
	}

	public void sendResponse(byte[] buf) throws Exception
	{
		access.send(repQName, new QueueMessage(buf));
	}

	public void send(String qname, QueueMessage qmsg) throws Exception
	{
		access.send(qname, qmsg);
	}

	public void execute(Executable exe) throws Exception
	{
		if (log.isDebugEnabled()) log.debug("request msg utf8:"
				+ new String(exe.request, Common.CHARSET_UTF8));
		if (synResponsePools != null && synResponsePools.size() > 0) asyn(exe);
		else syn(exe);
	}

	public void asyn(Executable exe) throws Exception
	{
		if (exe.messageId == null) exe.messageId = exe.correlationID;
		String corId = new String(exe.correlationID);
		int timeout = exe.timeout > 0 ? exe.timeout : this.timeout;
		String reqQName = StringX.nullity(exe.reqQName) ? this.reqQName : exe.reqQName;
		String repQName = StringX.nullity(exe.repQName) ? synReplyToQ : exe.repQName;
		if (log.isInfoEnabled()) log.info("ver:" + VERSION + ", reqQ:" + reqQName + ", repQ:"
				+ repQName + ", jvm:" + jvm + ", timeout:" + timeout + ", return:"
				+ !exe.withoutReturn + ", corId:" + corId + ", matchMsgId:" + matchMsgId
				+ ", cache:" + cache.getName());
		exe.reqTime = System.currentTimeMillis();
		QueueMessage reqqmsg = new QueueMessage(exe.request, exe.correlationID, exe.messageId,
				timeout, reqQName);
		reqqmsg.replyToQ = repQName;
		send(reqQName, reqqmsg);
		if (exe.withoutReturn) return;
		QueueMessage qmsg = poll(corId, exe.timeout);
		exe.response = qmsg.buf;
		exe.resTime = System.currentTimeMillis();
		if (log.isInfoEnabled()) log.info("cost:" + (exe.resTime - exe.reqTime) + ",len:"
				+ exe.response.length + "\n\n\n");
	}

	public QueueMessage poll(String corId, int timeout) throws Exception
	{
		return (QueueMessage) cache.poll(corId, timeout * 1000);
	}

	public void syn(Executable exe) throws Exception
	{
		String reqQNm = StringX.nullity(exe.reqQName) ? reqQName : exe.reqQName;
		String repQNm = exe.repQName;
		byte[] corId = exe.correlationID;
		int timeout = exe.timeout > 0 ? exe.timeout : this.timeout;
		if (log.isInfoEnabled()) log.info("ver:" + VERSION + ", shortCnn:" + shortCnn + ", reqQ:"
				+ reqQNm + ", repQ:" + repQNm + ", timeout:" + timeout + ", return:"
				+ !exe.withoutReturn + ", corId:" + (corId == null ? "" : new String(corId)));

		try
		{
			synAccess.send(reqQNm, new QueueMessage(exe.request, corId, exe.messageId, timeout,
					reqQNm));
			if (exe.withoutReturn) return;
			QueueMessage qmsg = synAccess.receive(repQNm, corId, timeout);
			exe.response = qmsg.buf;
			exe.resTime = System.currentTimeMillis();
		}
		finally
		{
			if (shortCnn && synAccess != null) synAccess.destroy();
		}
	}

	public QueueMessage createQueueMessage()
	{
		QueueMessage qmsg = apply(null);
		qmsg.correlationId = getSeqNb(24).getBytes();
		return qmsg;
	}

	public QueueMessage apply(QueueMessage qmsg)
	{
		if (qmsg == null) qmsg = new QueueMessage();
		String msg = "";
		if (StringX.nullity(qmsg.replyToQ) && !StringX.nullity(synReplyToQ))
		{
			qmsg.replyToQ = synReplyToQ;
			msg += "replyToQ:" + synReplyToQ + ", ";
		}
		if (qmsg.expirySeconds == 0)
		{
			qmsg.expirySeconds = timeout;
			msg += "expiry:" + timeout + ", ";
		}
		if (StringX.nullity(qmsg.putAppName)) qmsg.putAppName = "ESB2_" + VERSION;

		if (mqmd == null || mqmd.size() <= 0) return qmsg;
		String val = (String) mqmd.get("appIdData");
		if (StringX.nullity(qmsg.applicationIdData) && !StringX.nullity(val))
		{
			qmsg.applicationIdData = val;
			msg += "appId:" + val + ", ";
		}
		val = (String) mqmd.get("appOriginData");
		if (StringX.nullity(qmsg.applicationOriginData) && !StringX.nullity(val))
		{
			qmsg.applicationOriginData = val;
			msg += "appOrigData:" + val + ", ";
		}
		val = (String) mqmd.get("replyToQMgr");
		if (StringX.nullity(qmsg.replyToQMgr) && !StringX.nullity(val))
		{
			qmsg.replyToQMgr = val;
			msg += "replyToQMgr:" + val + ", ";
		}

		val = (String) mqmd.get("putAppName");
		if (StringX.nullity(qmsg.putAppName) && !StringX.nullity(val))
		{
			qmsg.putAppName = val;
			msg += "putAppName:" + val + ", ";
		}
		if (log.isInfoEnabled()) log.info("default MQMQ:" + msg);
		return qmsg;
	}

	public void initESB() throws Exception
	{
		Properties p = new Properties();
		p.load(getClass().getClassLoader().getResource("esb.properties").openStream());
		init(p);
	}

	public void init(String fileName) throws Exception
	{
		Properties p = new Properties();
		p.load(getClass().getClassLoader().getResource(fileName).openStream());
		init(p);
	}

	public void init(Map map) throws Exception
	{
		if (map == null || map.size() == 0) return;

		String val = (String) map.get("access");
		if (!StringX.nullity(val)) setAccess(val);

		val = (String) map.get("synAccess");
		if (!StringX.nullity(val)) setSynAccess(val);

		val = (String) map.get("synResponsePools");
		if (!StringX.nullity(val)) setSynResponsePools(val);

		val = (String) map.get("asynResponsePools");
		if (!StringX.nullity(val)) setAsynResponsePools(val);

		val = (String) map.get("requestPools");
		if (!StringX.nullity(val)) setRequestPools(val);

		val = (String) map.get("synReplyToQ");
		if (!StringX.nullity(val)) synReplyToQ = val.trim();

		val = (String) map.get("asynReplyToQ");
		if (!StringX.nullity(val)) asynReplyToQ = val.trim();

		val = (String) map.get("matchMsgId");
		if (!StringX.nullity(val)) setMatchMsgId(new Boolean(val.trim()));

		val = (String) map.get("shortCnn");
		if (!StringX.nullity(val)) setShortCnn(new Boolean(val.trim()));

		val = (String) map.get("jvm");
		if (!StringX.nullity(val)) setJvm(val.trim());

		val = (String) map.get("reqQName");
		if (!StringX.nullity(val)) setReqQName(val.trim());

		val = (String) map.get("timeout");
		if (!StringX.nullity(val)) setTimeout(Integer.parseInt(val.trim()));

		// ��ȡMQMDĬ����Ϣ
		Map mqmd = new HashMap();
		Iterator keys = map.keySet().iterator();
		while (keys.hasNext())
		{
			String key = keys.next().toString();
			val = map.get(key).toString().trim();
			if (!key.startsWith("MQMD.") || StringX.nullity(val)) continue;
			mqmd.put(key.substring(5), val);
		}
		if (mqmd.size() > 0) this.mqmd = mqmd;
		init();
	}

	public void destory()
	{
		log.warn("ESB2 will destroy...");
		if (synAccess != null) synAccess.destroy();
		if (access != null) access.destroy();

		log.info("stop synResponsePools:"
				+ (synResponsePools == null ? 0 : synResponsePools.size()));
		for (int i = 0; synResponsePools != null && i < synResponsePools.size(); i++)
			synResponsePools.get(i).asynStopAll();

		log.info("stop asynResponsePools:"
				+ (asynResponsePools == null ? 0 : asynResponsePools.size()));
		for (int i = 0; asynResponsePools != null && i < asynResponsePools.size(); i++)
			asynResponsePools.get(i).asynStopAll();

		cache.removeAll();

		log.info("stop requestPools:" + (requestPools == null ? 0 : requestPools.size()));
		for (int i = 0; requestPools != null && i < requestPools.size(); i++)
			requestPools.get(i).asynStopAll();

		init = false;
	}

	public Endpoint clone() throws CloneNotSupportedException
	{
		throw new CloneNotSupportedException();
	}

	public IQueueAccess getAccess()
	{
		return access;
	}

	public void setAccess(IQueueAccess access)
	{
		this.access = access;
	}

	public String getReqQName()
	{
		return reqQName;
	}

	public void setReqQName(String reqQName)
	{
		this.reqQName = reqQName;
	}

	public void setShortCnn(boolean shortCnn)
	{
		this.shortCnn = shortCnn;
	}

	public String getSynReplyToQ()
	{
		return synReplyToQ;
	}

	public void setSynReplyToQ(String synReplyToQ)
	{
		this.synReplyToQ = synReplyToQ;
	}

	public String getRepQName()
	{
		return repQName;
	}

	public void setRepQName(String repQName)
	{
		this.repQName = repQName;
	}

	public List<AccessTPool> getSynResponsePools()
	{
		return synResponsePools;
	}

	public void setSynResponsePools(List<AccessTPool> synResponsePools)
	{
		this.synResponsePools = synResponsePools;
	}

	public IOnMessage getSynResponseOnMessage()
	{
		return synResponseOnMessage;
	}

	public void setSynResponseOnMessage(IOnMessage synResponseOnMessage)
	{
		this.synResponseOnMessage = synResponseOnMessage;
	}

	public void setSynResponsePools(String synResponsePools)
	{
		this.synResponsePools = MQAccessTPool.createATPoolList(synResponsePools);
	}

	public ICache getCache()
	{
		return cache;
	}

	public void setCache(ICache cache)
	{
		this.cache = cache;
	}

	public void setAccess(String chl) throws Exception
	{
		access = new QueueAccess(MQCnnPool.createChlList(chl));
		((QueueAccess) access).getMultiChannel().setAlgorithm(2); // ��ѯ
	}

	public void setSynAccess(String chl) throws Exception
	{
		synAccess = new QueueAccess(MQCnnPool.createChlList(chl));
	}

	public List<AccessTPool> getRequestPools()
	{
		return requestPools;
	}

	public void setRequestPools(List<AccessTPool> requestPools)
	{
		this.requestPools = requestPools;
	}

	public void setRequestPools(String requestPools)
	{
		this.requestPools = MQAccessTPool.createATPoolList(requestPools);
	}

	public IOnMessage getRequestOnMessage()
	{
		return requestOnMessage;
	}

	public void setRequestOnMessage(IOnMessage requestOnMessage)
	{
		this.requestOnMessage = requestOnMessage;
	}

	public void setAsynResponsePools(List<AccessTPool> asynResponsePools)
	{
		this.asynResponsePools = asynResponsePools;
	}

	public void setAsynResponsePools(String asynResponsePools)
	{
		this.asynResponsePools = MQAccessTPool.createATPoolList(asynResponsePools);
	}

	public void setAsynResponseOnMessage(IOnMessage asynResponseOnMessage)
	{
		this.asynResponseOnMessage = asynResponseOnMessage;
	}

	public String getJvm()
	{
		return jvm;
	}

	public void setJvm(String jvm)
	{
		this.jvm = jvm;
	}

	public int getTimeout()
	{
		return timeout;
	}

	public void setTimeout(int timeout)
	{
		this.timeout = timeout;
	}

	public boolean isMatchMsgId()
	{
		return matchMsgId;
	}

	public void setMatchMsgId(boolean matchMsgId)
	{
		this.matchMsgId = matchMsgId;
	}

	private ESB2()
	{
	}

	public static ESB2 getInstance()
	{
		return esb2;
	}
}

class ESB2OnMessage implements IOnMessage
{
	protected Log log = Log.getLogger("spc.webos.endpoint.ESB2OnMessage");
	protected ESB2 esb2;

	public ESB2OnMessage(ESB2 esb2)
	{
		this.esb2 = esb2;
	}

	public void onMessage(Object obj, AccessTPool pool, AbstractReceiverThread thread)
			throws Exception
	{
		QueueMessage qmsg = (QueueMessage) obj;
		String corId = new String(qmsg.correlationId);
		if (log.isDebugEnabled()) log.debug("response msg utf8:"
				+ new String(qmsg.buf, Common.CHARSET_UTF8));
		if (log.isInfoEnabled()) log.info("response corId:" + corId + ", msgId:"
				+ new String(qmsg.messageId) + ", len:" + qmsg.buf.length + ", cache name:"
				+ esb2.cache.getName() + ",size:" + esb2.cache.size() + "\n\n");
		esb2.cache.put(corId, qmsg);
	}
}
