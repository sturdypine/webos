package spc.webos.thread;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import spc.webos.config.AppConfig;
import spc.webos.constant.Config;
import spc.webos.constant.Common;
import spc.webos.data.IMessage;
import spc.webos.log.IDynamicLog;
import spc.webos.log.Log;
import spc.webos.service.IStatus;
import spc.webos.util.StringX;

public abstract class DaemonThread extends Thread implements IStatus
{
	protected int exceptionSleep;
	protected int status = STOPPED;
	protected int curStatus = STOPPED;

	protected long heartbeat; // ��һ������ʱ��
	protected long costTime; // ҵ����ʱ��
	protected long caseNum; // ����ҵ��������
	protected Map logExtMap;
	protected boolean init;

	protected ThreadPool pool; // �߳������̳߳�
	protected IDynamicLog dynamicLog;

	public static final int STOPPED = 0;
	public static final int RUNNING = 1;
	protected Log log = Log.getLogger(getClass());
	public static final Map THREADS = new Hashtable(); // ������HashMap����Ϊ�����ӣ�Ҳ��ɾ��

	public DaemonThread()
	{
		setDaemon(true);
	}

	public DaemonThread(ThreadPool pool)
	{
		setDaemon(true);
		this.pool = pool;
	}

	public long getHeartbeat()
	{
		return heartbeat;
	}

	// �߳���ֹͣǰ���ͷ���Դ
	public void release()
	{
		// log.info("Thread(" + getName() + ") release...");
	}

	public void init() throws Exception
	{
		init = true;
		// ������ģʽ ����debug����, �������ж���
		// if (pool != null && pool.getLogName() != null) Log.setCurLog(pool
		// .getLogName());
	}

	public boolean startThreadLog()
	{
		if (pool == null) return false;
		Log.start(pool.getLogName());
		Log.setFTLCondition(((String) AppConfig.getInstance().getProperty(pool.getLogScriptKey(),
				StringX.EMPTY_STRING)).trim());
		// Log.setFTLCondition(pool.getLogScript()); //
		// ������־�ű����̻߳�����,���Ա���ҵ���߳��Լ�����,
		return true;
	}

	public String getPoolName()
	{
		return pool == null ? null : pool.getName();
	}

	public void setHeartbeat(long heartbeat)
	{
		this.heartbeat = heartbeat;
	}

	public void run()
	{
		curStatus = RUNNING;
		status = RUNNING;
		if (getName() != null) THREADS.put(getName(), this); // �̻߳�����
		try
		{
			if (!init) init();
		}
		catch (Exception e)
		{
			log.error("DaemonThread(" + getName() + ") init fail:", e);
			return;
		}
		while (status == RUNNING)
		{
			try
			{
				heartbeat = System.currentTimeMillis();
				execute();
			}
			catch (Throwable e)
			{
				log.error("DaemonThread(" + getName() + "):", e);
				Log.print();
				try
				{
					if (exceptionSleep > 0) Thread.sleep(exceptionSleep);
				}
				catch (Exception ee)
				{
				}
			}
			finally
			{
				Log.print();
				Log.printNotice();
			}
		}
		if (getName() != null) THREADS.remove(getName()); // �߳�ֹͣ��ɾ��
		curStatus = STOPPED;
		release(); // �ͷ���Դ
		log.warn("Thread(" + getName() + ") stopped!!!");
		Log.print();
	}

	public void ressetStatistic()
	{
		this.caseNum = 0;
		this.costTime = 0;
	}

	public abstract void execute() throws Exception;

	public int getStatus()
	{
		return status;
	}

	public void asynStop()
	{
		log.warn("Thread(" + getName() + ") will stop");
		this.status = STOPPED;
	}

	public void setStatus(int status)
	{
		this.status = status;
	}

	// public int getFcb()
	// {
	// return fcb;
	// }
	//
	// public void setFcb(int fcb)
	// {
	// this.fcb = fcb;
	// }

	public long getCostTime()
	{
		return costTime;
	}

	public void setCostTime(long costTime)
	{
		this.costTime = costTime;
	}

	public long getCaseNum()
	{
		return caseNum;
	}

	public void setCaseNum(long caseNum)
	{
		this.caseNum = caseNum;
	}

	public int getCurStatus()
	{
		return curStatus;
	}

	public Map checkStatus(Map param)
	{
		Map status = new HashMap();
		status.put("name", getName());
		status.put("heartbeat", new Long(getHeartbeat()));
		status.put("status", new Integer(getStatus()));
		status.put("curStatus", new Integer(getCurStatus()));
		status.put("cost", new Long(getCostTime()));
		status.put("caseNum", new Long(getCaseNum()));
		status.put("state", getState().toString());
		status.put("clazz", getClass().getName());
		status.put("stackTrace", StringX.stackTrace(getStackTrace(), -1));
		if (getPoolName() != null) status.put("pool", getPoolName());
		Map logExt = Log.getLogExt();
		if (logExt != null)
		{
			Object msg = logExt.get(Common.MODEL_MSG_OBJ);
			if (msg instanceof IMessage)
			{
				status.put(Common.MODEL_MSG_SN, ((IMessage) msg).getMsgSn());
				status.put(Common.MODEL_MSG_CD, ((IMessage) msg).getMsgCd());
			}
		}
		return status;
	}

	public IDynamicLog getDynamicLog()
	{
		return dynamicLog;
	}

	public void setDynamicLog(IDynamicLog dynamicLog)
	{
		this.dynamicLog = dynamicLog;
	}

	public boolean changeStatus(Map param)
	{
		return false;
	}

	public void refresh() throws Exception
	{
	}

	public ThreadPool getPool()
	{
		return pool;
	}

	public void setPool(ThreadPool pool)
	{
		this.pool = pool;
	}
}
