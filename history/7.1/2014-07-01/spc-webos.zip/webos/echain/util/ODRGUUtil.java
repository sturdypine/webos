package spc.webos.echain.util;

import spc.webos.model.DepVO;
import spc.webos.model.GroupVO;
import spc.webos.model.OrgVO;
import spc.webos.model.RoleVO;
import spc.webos.model.UserVO;

import com.ecc.echain.org.model.DepModel;
import com.ecc.echain.org.model.GroupModel;
import com.ecc.echain.org.model.OrgModel;
import com.ecc.echain.org.model.RoleModel;
import com.ecc.echain.org.model.UserModel;

public class ODRGUUtil
{
	public static UserModel uservo2UserModel(UserVO user)
	{
		UserModel um = new UserModel();
		um.setAdminflag(user.getCode().equalsIgnoreCase("admin"));
		um.setDepid(user.getDepId());
		um.setEmail(user.getEmail());
		um.setOrgid(user.getOrgId());
		um.setSaflag(false);
		um.setUserid(user.getCode());
		um.setUsername(user.getName());
		um.setUserstatus(1);
		um.setWfadminflag(um.isAdminflag());
		return um;
	}

	public static OrgModel orgvo2OrgModel(OrgVO org)
	{
		OrgModel om = new OrgModel();
		om.setOrgcode(org.getCode());
		om.setOrgid(org.getId());
		om.setOrglevel(org.getId().length() / 2);
		om.setOrgname(org.getSname());
		om.setOrgstatus(1);
		om.setSuporgid(org.getParentId());
		return om;
	}

	public static GroupModel gvo2GroupModel(GroupVO group)
	{
		GroupModel gm = new GroupModel();
		gm.setDepid(group.getDepId());
		gm.setGroupid(group.getId());
		gm.setGroupname(group.getName());
		gm.setGrouptype(group.getGtype());
		gm.setGroupright(group.getGright());
		gm.setOrgid(group.getOrgId());
		return gm;
	}

	public static DepModel dvo2DepModel(DepVO dep)
	{
		DepModel dm = new DepModel();
		dm.setDepid(dep.getId());
		dm.setDeplevel(dep.getLevel());
		dm.setDepname(dep.getName());
		dm.setDepstatus(dep.getStatus());
		dm.setOrgid(dep.getOrgId());
		dm.setSupdepid(dep.getParentId());
		return dm;
	}

	public static RoleModel rvo2RoleModel(RoleVO role)
	{
		RoleModel rm = new RoleModel();
		rm.setDepid(role.getDepId());
		rm.setOrgid(role.getOrgId());
		rm.setRoleid(role.getId());
		rm.setRolename(role.getName());
		rm.setRoleright(role.getMenu());
		return rm;
	}
}
