package spc.webos.buffer;

import java.util.LinkedList;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import net.sf.ehcache.store.MemoryStoreEvictionPolicy;
import spc.webos.data.IMessage;

public class MsgCacheBuffer extends AbstractEhcacheBuffer
{
	protected LinkedList keys = new LinkedList();
	protected boolean refsn; // true��ʾ����bufferʱ�Բο���ˮ��Ϊ����

	public MsgCacheBuffer()
	{
	}

	public MsgCacheBuffer(String name, int cap)
	{
		super(name, cap);
	}

	public void init() throws Exception
	{
		super.init();
		if (cache == null)
		{
			cache = new Cache(name, 600, MemoryStoreEvictionPolicy.FIFO, false, null, false, 80,
					80, false, 120, null, null);
			CacheManager.create().addCache(cache);
		}
	}

	public synchronized void add(Object v)
	{
		IMessage msg = (IMessage) v;
		String sn = getAddKey(msg);
		if (log.isDebugEnabled()) log.debug("put to sn: " + sn);
		keys.add(sn);
		cache.put(new Element(sn, v));
		notifyAll();
	}

	public synchronized void addFirst(Object v)
	{
		IMessage msg = (IMessage) v;
		String sn = getAddKey(msg);
		keys.addFirst(sn);
		if (log.isDebugEnabled()) log.debug("put to sn: " + sn);
		cache.put(new Element(sn, v));
		notifyAll();
	}

	public String getAddKey(IMessage msg)
	{
		return refsn ? msg.getRefMsgSn() : msg.getMsgSn();
	}

	public Object pollFromBuf()
	{
		String sn = (String) keys.poll();
		Element e = cache.get(sn);
		if (e == null) return null;
		Object v = e.getObjectValue();
		cache.remove(sn);
		notifyAll();
		return v;
	}

	public synchronized Object poll(String key, long timeout) throws Exception
	{
		KeyWaitWithTime wwt = new KeyWaitWithTime(this, key, timeout);
		Object v = null;
		while (v == null)
		{
			while (wwt.condition())
				wwt.timeWait();
			v = get(key);
			remove(key);
		}
		return v;
	}

	public void remove(String key)
	{
		keys.remove(key);
		cache.remove(key);
		notifyAll();
	}

	public Object get(String key)
	{
		Element e = cache.get(key);
		if (e == null) return null;
		Object v = e.getObjectValue();
		return v;
	}

	public void setRefsn(boolean refsn)
	{
		this.refsn = refsn;
	}
}
