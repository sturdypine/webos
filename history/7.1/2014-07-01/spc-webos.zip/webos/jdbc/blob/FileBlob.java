package spc.webos.jdbc.blob;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import spc.webos.jdbc.JdbcUtil;
import spc.webos.model.ValueObject;
import spc.webos.util.FileUtil;

public class FileBlob extends AbstractBlob
{
	File file;

	public FileBlob()
	{
	}

	public FileBlob(String file)
	{
		this(new File(file));
	}

	public FileBlob(String file, ValueObject vo, String fieldName)
	{
		this.file = new File(file);
		this.vo = vo;
		this.fieldName = fieldName;
	}

	public FileBlob(File file, ValueObject vo, String fieldName)
	{
		this.file = file;
		this.vo = vo;
		this.fieldName = fieldName;
	}

	public FileBlob(File file)
	{
		this.file = file;
	}

	public File getFile()
	{
		return file;
	}

	public void setFile(File file)
	{
		this.file = file;
	}

	public InputStream inputStream() throws IOException
	{
		if (is != null) return is;
		close();
		if (vo != null)
		{
			File file = JdbcUtil.getTempFileByVO(vo, fieldName);
			if (file != null) file.delete();
		}
		is = new BufferedInputStream(new FileInputStream(file));
		return is;
	}

	public int length()
	{
		return (int) file.length();
	}

	public String base64() throws Exception
	{
		return FileUtil.file2base64(file);
	}

	public byte[] bytes()
	{
		try
		{
			return FileUtil.file2bytes(file);
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
	}
}
