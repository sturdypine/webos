package spc.webos.jdbc;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import spc.webos.log.Log;
import spc.webos.model.ValueObject;
import spc.webos.persistence.Persistence;
import spc.webos.util.FileUtil;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

public class JdbcUtil
{
	public static String JDBC_TEMP_DIR = Persistence.getInstance().getCfgLocation() + "/tempdir";
	static File tempdir;
	static Log log = Log.getLogger(JdbcUtil.class);

	public static File getTempFile(ValueObject vo, String fileName, InputStream is)
	{
		File target = null;
		try
		{
			File parent = new File(getTempdir(), vo.getTable());
			if (!parent.exists()) parent.mkdirs();
			target = new File(parent, fileName);
			if (target != null && target.exists()) target.delete();
			if (is != null && target != null) FileUtil.is2os(is, new BufferedOutputStream(
					new FileOutputStream(target)), true, true);
		}
		catch (Exception e)
		{
			log.error("JdbcUtil.getTempFile: fileName:" + fileName + ", vo:" + vo.toString(), e);
		}

		return target;
	}

	public static File getTempFileByVO(ValueObject vo, String fieldName)
	{
		try
		{
			String fileName = genFileNameByVO(vo, fieldName);
			File parent = new File(getTempdir(), vo.getTable());
			if (!parent.exists()) parent.mkdirs();
			File target = new File(parent, fileName);
			return target.exists() ? target : null;
		}
		catch (Exception e)
		{
			log.error("getTempFileByVO: fieldName:" + fieldName + ", vo:" + vo.toString(), e);
		}
		return null;
	}

	public static String genFileNameByVO(Object vo, String fieldName)
	{
		String primary = null;
		String fileType = null;
		if (vo instanceof ValueObject) primary = vo.getClass().getName() + "|" + fieldName + "|"
				+ ((ValueObject) vo).getPrimary("'");
		else primary = String.valueOf(Math.random());
		try
		{
			StringBuffer name = new StringBuffer(StringX.md5(primary.getBytes()));
			if (fileType != null && fileType.length() > 0)
			{
				name.append('.');
				name.append(fileType);
			}
			return name.toString();
		}
		catch (Exception e)
		{
			log.error("genFileNameByVO: fieldName:" + fieldName + ", vo:" + vo.toString(), e);
		}
		return null;
	}

	public static File getTempdir() throws IOException
	{
		if (tempdir == null) tempdir = SystemUtil.getInstance().getResourceLoader().getResource(
				JDBC_TEMP_DIR).getFile();
		return tempdir;
	}
}
