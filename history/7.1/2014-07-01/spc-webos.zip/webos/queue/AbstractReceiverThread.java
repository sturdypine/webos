package spc.webos.queue;

import java.util.Hashtable;

import spc.webos.config.AppConfig;
import spc.webos.log.Log;
import spc.webos.util.StringX;

public abstract class AbstractReceiverThread extends AccessThread
{
	protected byte[] messageId; // 701 2013-09-12 ������ȡ�߳̽���msgIdƥ���ȡ
	protected IOnMessage onMessage;
	protected Hashtable props;
	protected int timeout = 1000;

	public AbstractReceiverThread()
	{
		super();
		rw = AccessThread.RW_READ;
	}

	public void execute() throws Exception
	{
		String qName = !StringX.nullity(qname) ? qname : bufferName;
		startThreadLog();
		String logName = (String) AppConfig.getInstance().getProperty(
				"Log.Q_" + qName.replace('.', '_'), null);
		if (!StringX.nullity(logName)) Log.start(logName);
		// long receiveNum = 0; // ����������������ִ��û�з��͵���Ϣ��˯�ߣ������������
		// for (int i = 0; i < bufs.size(); i++)
		// {
		try
		{
			// IBuffer buf = (IBuffer) bufs.get(i);
			// String bufName = buf.getName();
			// String qName = buf2queueMapping != null ? (String)
			// buf2queueMapping.get(bufferName)
			// : bufferName;
			// String qName = !StringX.nullity(qname) ? qname : bufferName;
			// if (StringX.nullity(qName)) qName = bufferName;
			// if (log.isDebugEnabled()) log.debug("receiver: bufName:" +
			// bufName + ", qname:"
			// + qName);
			// if (buf.getWriters().size() > 1 && bufs.size() > 1)
			// {
			// if (log.isInfoEnabled()) log.info(bufName + "'s writers : " +
			// buf.getWriters()
			// + ", buf.size: " + bufs.size());
			// continue; // �����ǰ��д�ߣ�����ʱ��������buf����Ϊ���ܴ�bufд����ȥ
			// }
			Object obj = receive(qName);
			if (obj == null) return;
			if (onMessage == null) log.warn("onMessage is null!!!");
			else onMessage.onMessage(obj, (AccessTPool) pool, this);

			// if (obj != null)
			// {
			// if (obj instanceof QueueMessage)
			// {
			// IMessageConverter converter = ((MQAccessTPool)
			// pool).getConverter();
			// if (converter != null)
			// {
			// IMessage mesg = converter.deserialize(((QueueMessage) obj).buf);
			// mesg.setCorrelationID(((QueueMessage) obj).correlationId);
			// mesg.setInLocal(MsgLocalKey.MQGET_QMSG_KEY, obj);
			// handle(mesg);
			// // buf.put(mesg);
			// }
			// else handle(obj); // buf.put(obj);
			// }
			// else handle(obj);
			// // receiveNum++;
			// }
			// else log.debug("receive obj is null!!!");
		}
		finally
		{
			// else if (log.isDebugEnabled()) log.debug("msg is null by "
			// + Thread.currentThread().getName());
			Log.print();
		}
		// }
		// if (receiveNum <= 0 && bufs.size() > 1)
		// {
		// log.info("MQ read sleep 50 ms!!!");
		// Thread.sleep(50); //
		// }
		// ������еĶ�û����Ҫ���͵ı��ģ���˯�ߣ��������ѭ���ķ�cpu
		// Log.print();
	}

	// protected void handle(Object obj)
	// {
	// if (buf != null)
	// { // �����buffer����뵽buffer���д���
	// buf.put(obj);
	// if (log.isDebugEnabled()) log.debug("buf(" + buf.getName() + ") size: " +
	// buf.size());
	// return;
	// }
	// log.debug("handle msg by msgflow...");
	// try
	// {
	// ((MQAccessTPool) pool).getMsgFlow().execute((IMessage) obj);
	// }
	// catch (Throwable e)
	// {
	// log.warn("fail to handle", e);
	// }
	// }

	public abstract Object receive(String qName) throws Exception;

	// maybe QueueMessage, maybe IMessage

	public Hashtable getProps()
	{
		return props;
	}

	public void setProps(Hashtable props)
	{
		this.props = props;
	}

	public int getTimeout()
	{
		return timeout;
	}

	public void setTimeout(int timeout)
	{
		this.timeout = timeout;
	}

	public IOnMessage getOnMessage()
	{
		return onMessage;
	}

	public void setOnMessage(IOnMessage onMessage)
	{
		this.onMessage = onMessage;
	}

	public byte[] getMessageId()
	{
		return messageId;
	}

	public void setMessageId(byte[] messageId)
	{
		this.messageId = messageId;
	}

	public void setMessageId(String messageId)
	{
		this.messageId = messageId.getBytes();
	}
}
