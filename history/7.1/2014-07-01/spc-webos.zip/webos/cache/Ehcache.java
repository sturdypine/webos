package spc.webos.cache;

import java.util.Collection;
import java.util.Iterator;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

public class Ehcache extends AbstractCache
{
	public void evictExpiredElements()
	{
		cache.evictExpiredElements();
	}

	public Collection getKeys()
	{
		return cache.getKeys();
	}

	public int size()
	{
		return cache.getSize();
	}

	// ��ehcache�������Ķ���ʱʱ,
	// ehcacheֻ�����ڴ����������߳�ʱԪ�ر�����ʱ�Żᴥ��notifyElementExpired,notifyElementEvictedʱ��
	// �����Ҫһ������������ж���Ľӿ�,�����ڱ����п��Դ�������ĳ�ʱ����
	public void visitAll()
	{
		Iterator keys = cache.getKeys().iterator();
		while (keys.hasNext())
			get(keys.next());
	}

	public Object get(Object key)
	{
		if (cache == null || key == null) return null;
		try
		{
			Element e = cache.get(key);
			if (e != null) return e.getObjectValue(); // e.getValue()
			else if (log.isDebugEnabled()) log.debug("cannot find key:[" + key + "], ecache:"
					+ cache.getName());
		}
		catch (Exception e)
		{
			log.warn("ehcahe.get", e);
		}
		return null;
	}

	public synchronized Object put(Object key, Object o)
	{
		if (cache == null || key == null || o == null) return null;
		try
		{
			cache.put(new Element(key, o));
			notifyAll();
			if (log.isDebugEnabled()) log.debug("success to put [" + key + "] in cache: "
					+ cache.getName());
			return o;
		}
		catch (Exception e)
		{
			log.warn("ehcahe.put", e);
		}
		return null;
	}

	public void setCache(Cache cache)
	{
		this.cache = cache;
	}

	public void removeAll()
	{
		try
		{
			cache.removeAll();
			if (log.isDebugEnabled()) log.debug("success to removeAll cache:" + cache.getName());
		}
		catch (Exception e)
		{
			log.warn("ehcahe.removeAll", e);
		}
	}

	public Object remove(Object o)
	{
		cache.remove(o);
		if (log.isDebugEnabled()) log.debug("success to remove one object from cache:"
				+ cache.getName());
		return o;
	}

	Cache cache;

	public void put(String key, Object buf, long expireSeconds) throws Exception
	{
	}

	public Object get(String key, boolean browse)
	{
		return null;
	}
}
