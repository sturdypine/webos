package spc.webos.jsrmi.protocal.converters;

import spc.webos.jsrmi.protocal.io.MarshallingContext;
import spc.webos.jsrmi.protocal.io.StreamReader;
import spc.webos.jsrmi.protocal.io.StreamWriter;
import spc.webos.jsrmi.protocal.io.UnmarshallingContext;
import spc.webos.log.Log;

public interface Converter
{
	public final static Log log = Log.getLogger(Converter.class);
	
	boolean canConvert(Class type);

	void marshal(Object source, MarshallingContext marshallingContext,
			StreamWriter streamWriter);

	Object unmarshal(StreamReader reader,
			UnmarshallingContext unmarshallingContext);
}
