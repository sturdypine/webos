package spc.webos.flownode;

import java.io.StringWriter;
import java.io.Writer;
import java.util.Map;

import spc.webos.constant.Common;
import spc.webos.data.IMessage;
import spc.webos.data.converter.XMLConverter2;
import spc.webos.data.validator.IMessageValidator;
import spc.webos.data.validator.MessageErrors;
import spc.webos.exception.MsgErrException;
import spc.webos.service.Service;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;
import freemarker.template.Template;

public abstract class AbstractFNode extends Service implements IFlowNode
{
	protected ISupport support;
	protected IMessageValidator validator;

	public void validate(IMessage msg)
	{
		if (validator == null) return;
		MessageErrors errors = new MessageErrors(msg);
		errors = validator.validate(msg, errors);
		if (errors.getErrorCount() > 0 && log.isDebugEnabled()) log.debug("check errors:"
				+ errors.toCNode());
		if (errors.getErrorCount() > 0) throw new MsgErrException(errors);
	}

	public void freemarker(IMessage msg, IFlowContext cxt, Template template, int mode,
			String[] batchSql, Writer writer, Map root) throws Exception
	{
		root = SystemUtil.freemarker(root, msg);
		if (batchSql != null)
		{
			if (mode == 0) persistence.query(batchSql, root, root);
			else if (mode == 1) persistence.execute(batchSql, root, root);
			else persistence.dquery(batchSql, root, root);
		}
		SystemUtil.freemarker(template, root, writer);
	}

	public String freemarker(IMessage msg, IFlowContext cxt, Template template, int mode,
			String[] batchSql, Map root) throws Exception
	{
		Writer writer = new StringWriter();
		freemarker(msg, cxt, template, mode, batchSql, writer, root);
		return writer.toString();
	}

	public void apply(IMessage msg, String xml, String charset) throws Exception
	{
		IMessage repmsg = XMLConverter2.getInstance().deserialize(
				StringX.nullity(charset) ? xml.getBytes(Common.CHARSET_UTF8) : xml
						.getBytes(charset));
		msg.getTransaction().apply(repmsg.getTransaction());
	}

	public void applyIf(IMessage msg, String xml, String charset) throws Exception
	{
		IMessage repmsg = XMLConverter2.getInstance().deserialize(
				StringX.nullity(charset) ? xml.getBytes(Common.CHARSET_UTF8) : xml
						.getBytes(charset));
		msg.getTransaction().applyIf(repmsg.getTransaction());
	}

	public void init() throws Exception
	{
		super.init();
		if (!StringX.nullity(name))
		{
			FLOW_NODES.put(name, this);
			FLOW_NODES_PROXY.put(name, this);
		}
	}

	// public IFlowNode getTransFNode(String name)
	// {
	// return (IFlowNode) FLOW_NODES_PROXY.get(name);
	// }

	public IFlowNode getFlowNode(String name)
	{
		return (IFlowNode) FLOW_NODES_PROXY.get(name);
	}

	public void setSelf(Object proxyBean)
	{
		// super.setSelf(proxyBean);
		self = proxyBean;
		if (!StringX.nullity(name))
		{
			FLOW_NODES_PROXY.put(name, proxyBean);
			FLOW_NODES.put(name, this);
		}
	}

	public void setValidator(IMessageValidator validator)
	{
		this.validator = validator;
	}

	public boolean support(IMessage msg)
	{
		return support.support(msg);
	}

	public ISupport getSupport()
	{
		return support;
	}

	public void setSupport(ISupport support)
	{
		this.support = support;
	}

	public Object compensate(IMessage msg, IFlowContext cxt)
	{
		return null;
	}
}
