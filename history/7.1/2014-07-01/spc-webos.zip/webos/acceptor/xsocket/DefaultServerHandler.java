package spc.webos.acceptor.xsocket;

import java.io.IOException;
import java.net.InetAddress;
import java.nio.BufferUnderflowException;

import org.xsocket.connection.ConnectionUtils;
import org.xsocket.connection.IConnectHandler;
import org.xsocket.connection.IDataHandler;
import org.xsocket.connection.IDisconnectHandler;
import org.xsocket.connection.INonBlockingConnection;

import spc.webos.acceptor.ISecurity;
import spc.webos.acceptor.SocketMessage;
import spc.webos.buffer.IBuffer;
import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.Message;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.flownode.MessageFlow;
import spc.webos.log.Log;
import spc.webos.util.StringX;
import spc.webos.util.bytes.BytesUtil;
import spc.webos.util.http.HTTPHeader;
import spc.webos.util.http.HTTPUtil;

/**
 * ʹ�� xsocket �����Ϊ�ײ�NIO�ķ���ģ��, ͬʱ֧�ֿͻ����첽ҵ���ͬ��ҵ������
 * 
 * @author spc
 * 
 */
public class DefaultServerHandler implements IConnectHandler, IDataHandler, IDisconnectHandler
{
	protected Log log = Log.getLogger(getClass()); // serverhandler�޸�Ϊlogger
	protected String name;
	protected XSocketAcceptor acceptor;

	public boolean onConnect(INonBlockingConnection cnn) throws IOException
	{
		if (!acceptor.isF5() && log.isInfoEnabled()) log.info("onCnn::" + cnn.getLocalPort()
				+ ",remote: " + cnn.getRemoteAddress() + ":" + cnn.getRemotePort() + ", thread: "
				+ Thread.currentThread().getName());
		// added by spc 2011-05-03 ����socket�������Ľ���IPȨ��
		ISecurity security = acceptor.getSecurity();
		if (security != null
				&& !security.isAuthorizedClient(cnn.getRemoteAddress(), acceptor.getPort()))
		{
			log.warn("onCnn::" + cnn.getLocalPort() + ",remote: " + cnn.getRemoteAddress()
					+ ", unauthorized for server port: " + acceptor.getPort());
			cnn.close();
		}
		// added by spc 2011-05-03 end
		Log.print();
		cnn.setAutoflush(false); // chenjs 2012-12-12 �ֹ�ˢ��
		return true;
	}

	public int length(byte[] lenBytes)
	{
		// added by chenjs 2011-06-25 ֧�����붨��ͷ�ĳ�����ϢΪ������ģʽ
		// modified by chenjs 2012-11-25 ����containHdrLenSelf�����ж�
		// if (acceptor.isHdrLenBinary()) return NumberX.bytes2int(lenBytes)
		// - (acceptor.isContainHdrLenSelf() ? acceptor.getHdrLen() : 0);
		// return new Integer(isLen2bcd() ? EBCDUtil.bcd2gbk(lenBytes) : new
		// String(lenBytes).trim())
		// .intValue() - (acceptor.isContainHdrLenSelf() ? acceptor.getHdrLen()
		// : 0);

		// 2012-12-12 chenjs ʹ��acceptor����ĳ��ȴ���ģʽ
		return acceptor.length(lenBytes);
	}

	// �����������ķ���
	protected boolean handleOverSizeMsg(INonBlockingConnection cnn, int len) throws IOException
	{
		log.warn("onData: too long msg, localPort:" + cnn.getLocalPort() + ",remote: "
				+ cnn.getRemoteAddress() + ", len:" + len + ", maxbytes:" + acceptor.getMaxbytes()
				+ ", cnn will close!!!");
		cnn.close();
		return false;
	}

	protected boolean handleBufFull(INonBlockingConnection cnn) throws IOException
	{
		log.warn("Buffer(" + getReqbuf().getName() + ") is full!!!");
		cnn.close();
		return false;
	}

	public boolean onDisconnect(INonBlockingConnection cnn) throws IOException
	{
		// InetAddress remoteAddr = cnn.getRemoteAddress();
		// String remoteIP = remoteAddr != null ? remoteAddr.getHostAddress() :
		// StringX.EMPTY_STRING;
		if (!acceptor.isF5() && log.isInfoEnabled()) log.info("onDiscnn::" + cnn.getLocalPort()
				+ ",remote: " + cnn.getRemoteAddress() + ":" + cnn.getRemotePort() + ", thread: "
				+ Thread.currentThread().getName());
		// if (getHdrLen() <= 0 && !acceptor.isEndFlag())
		// { // ǰ���Ƕ�����
		// log.info("short cnn to doMsg...");
		// doMsg(cnn, cnn.readBytesByLength(cnn.available()), remoteIP);
		// }
		Log.print();
		return true;
	}

	public boolean onData(INonBlockingConnection cnn) throws IOException
	{
		if (!StringX.nullity(acceptor.getLogName())) Log.start(acceptor.getLogName());
		InetAddress remoteAddr = cnn.getRemoteAddress();
		String remoteIP = remoteAddr != null ? remoteAddr.getHostAddress() : StringX.EMPTY_STRING;
		if (!acceptor.isF5() && log.isInfoEnabled()) log.info("onData::" + cnn.available() + ","
				+ cnn.getLocalPort() + ",remote: " + remoteAddr + ", thread: "
				+ Thread.currentThread().getName());
		if (cnn.available() <= 0) return true;
		cnn = ConnectionUtils.synchronizedConnection(cnn); // ���պͷ���ͬ��
		while (true)
		{ // ֻ����ͷ���Ȳſ���һ�����緢���˶�ʱ�������
			cnn.markReadPosition();
			try
			{
				byte[] msg = null;
				if (getHdrLen() > 0)
				{ // modified by spc 2011-05-03 ���ͷ����Ϊ0���ʾ����û����Ƴ���ͷ
					byte[] lenbytes = cnn.readBytesByLength(getHdrLen());
					int len = length(lenbytes);
					if (!acceptor.isF5() && log.isInfoEnabled()) log
							.info("len:" + len + ", lenbytes:" + StringX.base64(lenbytes) + ","
									+ new String(lenbytes));
					if (acceptor.getMaxbytes() > 0 && len > acceptor.getMaxbytes()) return handleOverSizeMsg(
							cnn, len);
					// modified by spc 2011-03-19
					// ��ĳ����������£�ǰ��ֻ����һ���涨�ֽڳ��ȵ�ֵ������00000000, û��������
					// 710_20140601 �������ݴ���ͷ������Ϣ
					msg = (len == 0 ? new byte[0] : (acceptor.ignoreHdrLen ? cnn
							.readBytesByLength(len) : BytesUtil.merge(lenbytes,
							cnn.readBytesByLength(len))));
					doMsg(cnn, msg, remoteIP);
					cnn.removeReadMark();
				}
				else if (acceptor.isEndFlag())
				{ // ����н�����־
					msg = cnn.readBytesByLength(cnn.available());
					log.info("short cnn endchar:" + msg[msg.length - 1] + ", len: " + msg.length);
					if (msg[msg.length - 1] != acceptor.getEndFlagChar())
					{ // �����ȡ�����һ���ֽڲ��ǽ���������ȴ�������
						cnn.resetToReadMark();
						break;
					}
					// ȥ����β��ͨ�ñ�־��0
					// byte[] buf = new byte[msg.length - 1];
					// System.arraycopy(msg, 0, buf, 0, buf.length);
					msg = BytesUtil.arraycopy(msg, 0, msg.length - 1);
					doMsg(cnn, msg, remoteIP);
					cnn.removeReadMark();
				}
				else
				{ // û���κν�����־��ǰ���Ƕ����ӷ�����
					msg = cnn.readBytesByLength(cnn.available());
					boolean end = (!cnn.isOpen() || isShortCnnEnd(cnn, msg));
					if (!acceptor.isF5() && log.isInfoEnabled()) log.info("short cnn::end:" + end
							+ ", open:" + cnn.isOpen());
					if (end)
					{
						doMsg(cnn, msg, remoteIP);
						cnn.removeReadMark();
					}
					else cnn.resetToReadMark();
					break;
					// msg = cnn.readBytesByLength(cnn.available());
				}
				if (cnn.available() <= 0) break;
			}
			catch (BufferUnderflowException bue)
			{
				cnn.resetToReadMark();
				if (log.isDebugEnabled()) log.debug("onData::" + cnn.getLocalPort() + ",remote: "
						+ remoteAddr + ", BufferUnderflowException len: " + cnn.available()
						+ " to be continued!!!");
				break;
			}
			catch (IOException ioe)
			{
				throw ioe;
			}
			catch (Exception e)
			{
				throw new RuntimeException(e);
			}
		}
		Log.print();
		return true;
	}

	public boolean isShortCnnEnd(INonBlockingConnection cnn, byte[] msg)
	{
		if (acceptor.isEndFlagOpen()) return !cnn.isOpen();
		// �����httpЭ�飬��ʹ��httpЭ�鱨��ͷ�ж�
		if (acceptor.isHttp()) return isHttpEnd(cnn, msg);
		return true; // ����һƬ��������Ϊ�������
	}

	public boolean isHttpEnd(INonBlockingConnection cnn, byte[] msg)
	{
		HTTPHeader header = new HTTPHeader();
		try
		{
			int offset = HTTPUtil.unpackRequestHeader(msg, header);
			int len = msg.length - offset; // http�����峤��
			int contentLength = Integer.parseInt(StringX.null2emptystr(
					header.params.get("Content-Length"), "-1"));
			if (contentLength < 0)
			{
				log.info("HTTP Content-Length is -1\n" + new String(msg));
				return false;
			}
			log.info("HTTP Content-Length:" + contentLength + ", len:" + len);
			return len >= contentLength;
		}
		catch (Exception e)
		{
			log.warn(new String(msg), e);
			return false;
		}
	}

	protected boolean doMsg(INonBlockingConnection cnn, byte[] msg, String remoteIP)
			throws IOException
	{
		if (!acceptor.isF5() && log.isInfoEnabled()) log.info("do msg::" + msg.length
				+ ", available:" + cnn.available());
		if (!acceptor.isF5() && acceptor.isTrace(acceptor.getPort()) && log.isInfoEnabled()) log
				.info("trace do msg::base64:\n" + new String(StringX.encodeBase64(msg))
						+ "\nstring:\n" + new String(msg));
		else if (!acceptor.isF5() && log.isDebugEnabled()) log.debug("do msg::base64:\n"
				+ new String(StringX.encodeBase64(msg)) + "\nstring:\n" + new String(msg));
		IBuffer reqbuf = getReqbuf();
		if (reqbuf != null)
		{
			if (reqbuf.isFull())
			{ // ��� buffer �Ѿ����ˣ���ϵ�ǰ�˵���������
				log.warn("buf(" + reqbuf.getName() + ") is full!!");
				if (!handleBufFull(cnn)) return false;
			}
			reqbuf.put(socketmsg2msg(createSocketMessage(cnn, msg), remoteIP));
		} // 700 2013-05-17 ���������߳�ֱ��ִ����Ϣ������Ϣ��
		else handle(createSocketMessage(cnn, msg), remoteIP);
		return true;
	}

	protected SocketMessage createSocketMessage(INonBlockingConnection cnn, byte[] msg)
	{
		if (!acceptor.isHttp())
		{
			SocketMessage smsg = new SocketMessage(cnn, msg, getHdrLen(),
					acceptor.isContainHdrLenSelf(), acceptor.getRepbuf(),
					Common.ACCEPTOR_PROTOCOL_TCPIP_XSOCKET, acceptor.getDhl());
			smsg.localPort = acceptor.getPort();
			smsg.longCnn = acceptor.isLongCnn();
			return smsg;
		}
		HTTPHeader header = new HTTPHeader();
		byte[] content = HTTPUtil.unpackRequest(msg, header);
		SocketMessage smsg = new SocketMessage(cnn, content, getHdrLen(),
				acceptor.isContainHdrLenSelf(), acceptor.getRepbuf(),
				Common.ACCEPTOR_PROTOCOL_TCPIP_XSOCKET, acceptor.getDhl());
		smsg.reqHttpHdr = header;
		smsg.defRepHttpHdrParams = acceptor.getDefRepHttpHdrParams();
		smsg.localPort = acceptor.getPort();
		smsg.longCnn = acceptor.isLongCnn();
		return smsg;
	}

	protected void handle(SocketMessage smsg, String remoteIP)
	{
		MessageFlow msgflow = getMsgFlow();
		if (msgflow == null) return;
		try
		{
			long start = System.currentTimeMillis();
			IMessage msg = socketmsg2msg(smsg, remoteIP);
			msg.setTransaction(getConverter().deserialize(smsg.reqmsg, msg).getTransaction());

			msgflow.execute(msg);
			if (!acceptor.isF5() && log.isInfoEnabled()) log.info("C:"
					+ (System.currentTimeMillis() - start) + ", jfree:"
					+ (Runtime.getRuntime().freeMemory() / 1000000) + "M, thread:"
					+ Thread.currentThread().getName());
		}
		catch (Throwable t)
		{
			log.warn("handle:" + remoteIP, t);
		}
	}

	public void init() throws Exception
	{
		// added by chenjs. 2011-06-20 �޸�Handler��־Ϊlog4j��־����, �����ô�ͳ�߳���־��ʽ,
		// �������޸���־��Ϊÿ����ͬ��acceptorָ��һ����־�����ļ�
		if (acceptor != null && !StringX.nullity(acceptor.getLogName())) log = Log
				.getLogger(acceptor.getLogName());
	}

	protected IMessage socketmsg2msg(SocketMessage smsg, String remoteIP)
	{
		IMessage msg = new Message(); // converter.deserialize(smsg.reqmsg);
		// modified by spc. for performance
		// String ip = smsg.remoteAddress != null ?
		// smsg.remoteAddress.getHostAddress()
		// : StringX.EMPTY_STRING;
		// if (StringX.nullity(ip)) log.warn("remote IP is NULL!!!");
		int index = remoteIP.indexOf(':');
		msg.setInLocal(MsgLocalKey.ACCEPTOR_REMOTE_HOST, index > 0 ? remoteIP.substring(0, index)
				: remoteIP);
		int localPort = (smsg.localPort <= 0 ? acceptor.getPort() : smsg.localPort);
		msg.setInLocal(MsgLocalKey.ACCEPTOR_LOCAL_PORT, String.valueOf(localPort));
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_SOCKETMSG, smsg); // ���������Ϣ��ԭʼ��Ϣ
		msg.setInLocal(MsgLocalKey.ACCEPTOR_PROTOCOL, smsg.protocol);
		msg.setInLocal(MsgLocalKey.LOCAL_REP_BUFFER, smsg.repbuf);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, smsg.reqmsg);
		msg.setInLocal(MsgLocalKey.LOCAL_MSG_CONVERTER, getConverter());
		msg.setInLocal(MsgLocalKey.LOCAL_MSGCVT_DELAY, Boolean.TRUE); // �ӳٽ���
		if (getMsgFlow() != null) msg.setInLocal(MsgLocalKey.LOCAL_MSG_MSGFLOW, getMsgFlow());
		return msg;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public IBuffer getReqbuf()
	{
		return acceptor.getReqbuf();
	}

	public int getHdrLen()
	{
		return acceptor.getHdrLen();
	}

	public boolean isLen2bcd()
	{
		return acceptor.isLen2bcd();
	}

	public IMessageConverter getConverter()
	{
		return acceptor.getConverter();
	}

	public MessageFlow getMsgFlow()
	{
		return acceptor.getMsgFlow();
	}

	public XSocketAcceptor getAcceptor()
	{
		return acceptor;
	}

	public void setAcceptor(XSocketAcceptor acceptor)
	{
		this.acceptor = acceptor;
	}
}
