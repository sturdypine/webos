package spc.webos.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ApplicationContextEvent;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.ContextStartedEvent;
import org.springframework.context.event.ContextStoppedEvent;

import spc.webos.acceptor.Acceptor;
import spc.webos.acceptor.SendResponseTPool;
import spc.webos.log.LogManager;
import spc.webos.pool.ObjectPool;
import spc.webos.queue.AccessTPool;
import spc.webos.queue.AccessThread;
import spc.webos.thread.BizHandlerTPool;
import spc.webos.thread.DaemonThread;
import spc.webos.thread.ThreadPool;

/**
 * spring�����õ�jvm�߳��� ���� appCxt ��������ʱ������ֹͣʱֹͣ
 * 
 * @author spc
 * 
 */
public class StartupAppListener implements ApplicationListener
{
	protected List receivers; // ������Ϣ���߳�/�̳߳�
	protected List processors; // �ڲ������߳�/�̳߳�
	protected List senders; // ������Ϣ�߳�/�̳߳�
	protected ApplicationContext cxt;
	protected boolean started;
	protected int interval = 5; // modified by spc, �첽�����̴߳�4.5���Ϊ1��.
	protected static Logger log = Logger.getLogger(StartupAppListener.class);
	final static StartupAppListener SAL = new StartupAppListener();

	public void onApplicationEvent(ApplicationEvent event)
	{
		// System.err
		// .println("onApplicationEvent=" + event.getSource().getClass());
		if (event instanceof ContextRefreshedEvent || event instanceof ContextStartedEvent)
		{
			ApplicationContextEvent evt = (ApplicationContextEvent) event;
			cxt = evt.getApplicationContext();
			log.info("ContextRefreshedEvent...");
			try
			{
				long start = System.currentTimeMillis();
				boot();
				log.info("JVM(" + SystemUtil.JVM + ") App(" + SystemUtil.APP
						+ ") started successfully, cost: " + (System.currentTimeMillis() - start));
			}
			catch (Exception e)
			{
				log.error("boot", e);
				throw new RuntimeException(e);
			}
		}
		else if (event instanceof ContextStoppedEvent || event instanceof ContextClosedEvent)
		{
			try
			{
				unboot();
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			log.info("JVM(" + SystemUtil.JVM + ") App(" + SystemUtil.APP + ") stopped...");
		}
	}

	// ֹͣ�������
	synchronized void unboot()
	{
		if (!started) return;
		log.info("start to unboot threads...");
		// 0. ֹͣ������
		if (Acceptor.ACCEPTORS.size() > 0)
		{
			log.info("start to asynStop ACCEPTORS:" + Acceptor.ACCEPTORS.size());
			asynStop(Acceptor.ACCEPTORS.values());
		}

		// 1. ֹͣ�������߳�
		if (receivers == null || receivers.size() == 0) log.info("No receivers:");
		else
		{
			log.info("stop receivers:" + receivers.size());
			asynStop(receivers);
		}
		// 2. ֹͣ�ڲ����߳�
		if (processors == null || processors.size() == 0) log.info("No processors:");
		else
		{
			try
			{
				log.info("waiting for " + interval + " seconds for unboot processors!!!");
				Thread.sleep(interval * 1000);
			}
			catch (Exception e)
			{
			}
			log.info("stop processors:" + processors.size());
			asynStop(processors);
		}

		// 3. ֹͣ�������߳�
		if (senders == null || senders.size() == 0) log.info("No senders:");
		else
		{
			log.info("stop senders:" + senders.size());
			asynStop(senders);
		}

		// 4. �ͷŻ����еĶ������Դ�� ����MQ����
		log.info("start to unboot pools...");
		try
		{
			Iterator iter = ObjectPool.POOLS.values().iterator();
			while (iter.hasNext())
			{
				ObjectPool pool = (ObjectPool) iter.next();
				try
				{
					pool.destory();
				}
				catch (Exception e)
				{
					log.warn("unboot ObjectPool: " + pool.getName(), e);
				}
			}
			ObjectPool.POOLS.clear(); // 2012-05-12 ��134�д���������ֲĿǰλ��
		}
		catch (Exception e)
		{
			log.warn("unboot ObjectPool", e);
		}

		interrupt(Acceptor.ACCEPTORS.values()); // ֹͣ������������ҵ�����߳�
		interrupt(receivers);
		receivers = null;
		interrupt(processors);
		processors = null;
		interrupt(senders);
		senders = null;

		try
		{
			log.info("waiting for 100 ms for unboot log threads!!!");
			Thread.sleep(100);
		}
		catch (Exception e)
		{
		}

		log.info("start to unboot log threads...");
		LogManager.getInstance().asynStopAll();
		LogManager.getInstance().interruptAll(); // ֹͣ��־�߳�
		started = false;
		cxt = null;
		log.info("success to unboot threads...");
	}

	// �첽ֹͣ���
	void asynStop(Collection components)
	{
		if (components == null) return;
		int no = 0;
		Iterator comp = components.iterator();
		while (comp.hasNext())
		{
			Object component = comp.next();
			if (component instanceof DaemonThread)
			{
				((DaemonThread) component).asynStop();
				log.info("success to unboot DaemonThread NO." + (1 + (++no)) + ", Name:"
						+ ((DaemonThread) component).getName());
			}
			else if (component instanceof ThreadPool)
			{
				((ThreadPool) component).asynStopAll();
				log.info("success to unboot ThreadPool NO." + (1 + (++no)) + ", Name:"
						+ ((ThreadPool) component).getName());
			}
			else log.warn((1 + (++no)) + ":" + component.getClass()
					+ " is not DaemonThread or ThreadPool");
		}
	}

	// ֹͣһЩ��˯�߻����������߳����
	void interrupt(Collection components)
	{
		if (components == null) return;
		int no = 0;
		Iterator comp = components.iterator();
		while (comp.hasNext())
		{
			Object component = comp.next();
			try
			{
				if (component instanceof Acceptor)
				{
					((Acceptor) component).interruptAll();
					log.info("success to unboot Acceptor NO." + (1 + (++no)) + ", Name:"
							+ ((Acceptor) component).getName());
				}
				else if (component instanceof DaemonThread)
				{
					((DaemonThread) component).interrupt();
					log.info("success to unboot DaemonThread NO." + (1 + (++no)) + ", Name:"
							+ ((DaemonThread) component).getName());
				}
				else if (component instanceof ThreadPool)
				{
					((ThreadPool) component).interruptAll();
					log.info("success to unboot ThreadPool NO." + (1 + (++no)) + ", Name:"
							+ ((ThreadPool) component).getName());
				}
				else log.warn((1 + (++no)) + ":" + component.getClass()
						+ " is not DaemonThread or ThreadPool");
			}
			catch (Exception e)
			{
				log.warn("interrupt: " + component.getClass(), e);
			}
		}
	}

	// �����������������
	boolean boot() throws Exception
	{
		if (started)
		{
			log.warn("startup has been executed...");
			return true;
		}
		log.info("Start to boot thread or thread pool of JVM(" + SystemUtil.JVM + ") App("
				+ SystemUtil.APP + ")");
		if (receivers == null) receivers = getReceivers(); // ������Ϣ���߳�/�̳߳�
		if (processors == null) processors = getProcessors(); // �ڲ������߳�/�̳߳�
		if (senders == null) senders = getSenders(); // ������Ϣ�߳�/�̳߳�

		// 1. �����������߳�
		if (senders == null || senders.size() == 0) log.info("No senders:");
		else
		{
			log.info("start senders:" + senders.size());
			boot(senders);
		}

		// 2. �����ڲ����߳�
		if (processors == null || processors.size() == 0) log.info("No processors:");
		else
		{
			log.info("start processors:" + processors.size());
			boot(processors);
		}

		// 3. �����������߳�
		if (receivers == null || receivers.size() == 0) log.info("No receivers:");
		else
		{
			log.info("start receivers:" + receivers.size());
			boot(receivers);
		}

		// 4. ����tcp ������
		if (Acceptor.ACCEPTORS.size() > 0)
		{
			log.info("start TCP/IP acceptors: " + Acceptor.ACCEPTORS.size());
			boot(Acceptor.ACCEPTORS.values());
		}

		started = true;

		// ��jvm�쳣������ֹͣʱ���ͷ��߳���
		Runtime.getRuntime().addShutdownHook(new Thread()
		{
			public void run()
			{
				System.err.println("JVM will stop...");
				unboot();
			}
		});
		log.info("end to boot threads...");
		return true;
	}

	// �����߳����
	void boot(Collection components) throws Exception
	{
		if (components == null) return;
		int no = 0;
		Iterator comp = components.iterator();
		while (comp.hasNext())
		{
			Object component = comp.next();
			if (component instanceof DaemonThread)
			{
				((DaemonThread) component).start();
				log.info("success to boot DaemonThread NO." + (1 + (++no)) + ", Name:"
						+ ((DaemonThread) component).getName());
			}
			else if (component instanceof ThreadPool)
			{
				((ThreadPool) component).startAll();
				log.info("success to boot ThreadPool NO." + (1 + (++no)) + ", Name:"
						+ ((ThreadPool) component).getName());
			}
			else log.warn((1 + (++no)) + ":" + component.getClass()
					+ " is not DaemonThread or ThreadPool");
		}
	}

	public void setReceivers(List receivers)
	{
		this.receivers = receivers;
	}

	public void setProcessors(List processors)
	{
		this.processors = processors;
	}

	public void setSenders(List senders)
	{
		this.senders = senders;
	}

	public void setInterval(int interval)
	{
		this.interval = interval;
	}

	List getSenders()
	{
		List senders = null;
		try
		{
			senders = (List) cxt.getBean("senders");
		}
		catch (Exception e)
		{
		}
		if (senders != null) return senders;
		senders = new ArrayList();
		Iterator names = ThreadPool.POOLS.keySet().iterator();
		while (names.hasNext())
		{
			String name = (String) names.next();
			ThreadPool tp = (ThreadPool) ThreadPool.POOLS.get(name);
			if (tp instanceof SendResponseTPool)
			{
				senders.add(tp);
				continue;
			}
			if (!(tp instanceof AccessTPool)) continue;
			if (((AccessTPool) tp).getRw() == AccessThread.RW_WRITE) senders.add(tp);
		}
		return senders;
	}

	List getReceivers()
	{
		List receivers = null;
		try
		{
			receivers = (List) cxt.getBean("receivers");
		}
		catch (Exception e)
		{
		}
		if (receivers != null) return receivers;
		receivers = new ArrayList();
		Iterator names = ThreadPool.POOLS.keySet().iterator();
		while (names.hasNext())
		{
			String name = (String) names.next();
			ThreadPool tp = (ThreadPool) ThreadPool.POOLS.get(name);
			if (!(tp instanceof AccessTPool)) continue;
			if (((AccessTPool) tp).getRw() == AccessThread.RW_READ) receivers.add(tp);
		}
		return receivers;
	}

	List getProcessors()
	{
		List processors = null;
		try
		{
			processors = (List) cxt.getBean("processors");
		}
		catch (Exception e)
		{
		}
		if (processors != null) return processors;
		processors = new ArrayList();
		Iterator names = ThreadPool.POOLS.keySet().iterator();
		while (names.hasNext())
		{
			String name = (String) names.next();
			ThreadPool tp = (ThreadPool) ThreadPool.POOLS.get(name);
			if (tp instanceof BizHandlerTPool) processors.add(tp);
		}
		return processors;
	}

	private StartupAppListener()
	{
	}

	public static StartupAppListener getInstance()
	{
		return SAL;
	}
}
