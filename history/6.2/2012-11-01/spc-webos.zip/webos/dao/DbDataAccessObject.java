package spc.webos.dao;

import spc.webos.persistence.IPersistence;
import spc.webos.persistence.Persistence;

public class DbDataAccessObject implements DataAccessObject
{
	// protected Logger logger = Logger.getLogger(getClass());
	protected IPersistence persistence = Persistence.getInstance();

	public void setPersistence(IPersistence persistence)
	{
		this.persistence = persistence;
	}

	/**
	 * �ṩinit��������, ��spring2.0���� default-init-method
	 * 
	 */
	public void init()
	{
	}

	// ͬ��
	public void destory()
	{
	}
}
