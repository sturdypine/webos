package spc.webos.service.common.impl;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;

import spc.webos.config.AppConfig;
import spc.webos.service.Service;
import spc.webos.service.common.IJobService;
import spc.webos.util.FileUtil;
import spc.webos.util.SystemUtil;

/**
 * ��ʱ���ù�������
 * 
 * @author sturdypine.chen
 * 
 */
public class JobService extends Service implements IJobService
{
	PathMatcher pathMatcher = new AntPathMatcher();

	public void executeSql()
	{
		try
		{
			List sqlIds = (List) AppConfig.getInstance().getProperty(AppConfig.MODULE_JOB,
					"jobSqlId", null);
			if (sqlIds == null || sqlIds.size() == 0)
			{
				log.warn("job.jobSqlId is null...");
				return;
			}
			Map params = new HashMap();
			persistence.execute(sqlIds, params, params);
		}
		catch (Throwable e)
		{
			log.error("JobService.excuteSql:", e);
		}
	}

	public void deleteTempFiles()
	{
		if (tempFiles == null) return;
		try
		{
			Iterator paths = tempFiles.keySet().iterator();
			while (paths.hasNext())
			{
				String path = paths.next().toString();
				Map params = (Map) tempFiles.get(path);
				File file = SystemUtil.getInstance().getResourceLoader().getResource(path)
						.getFile();
				if (!file.exists() || !file.isDirectory()) continue;

				Object aliveTime = params.get("aliveTime");
				int aliveSeconds = aliveTime == null ? defTempFileAliveTime : Integer
						.parseInt(aliveTime.toString());
				File[] files = file.listFiles();
				if (files == null || files.length == 0) continue;
				for (int i = 0; i < files.length; i++)
				{
					File f = files[i];
					long eclipseTm = System.currentTimeMillis() - f.lastModified();
					if (eclipseTm > aliveSeconds * 1000)
					{
						if (log.isInfoEnabled()) log.info("file: " + f.getAbsolutePath()
								+ " will be deleted. eclipseTm:" + (eclipseTm / 1000) + ", alive: "
								+ aliveSeconds);
						FileUtil.delete(f);
					}
				}
			}
		}
		catch (Exception e)
		{
			log.error("JobService.deleteTempFiles:", e);
		}
	}

	Map tempFiles;
	int defTempFileAliveTime = 30;

	public void setDefTempFileAliveTime(int defTempFileAliveTime)
	{
		this.defTempFileAliveTime = defTempFileAliveTime;
	}

	public void setTempFiles(Map tempFiles)
	{
		this.tempFiles = tempFiles;
	}
}
