package spc.webos.flownode.decision;

import spc.webos.data.IMessage;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.StringX;

/**
 * ����jbmp variables�е�ĳ���������ж�
 * 
 * @author spc
 * 
 */
public class BPLVariableDecision extends AbstractDecision
{
	private static final long serialVersionUID = 1L;

	public String decide(IMessage msg, IFlowContext cxt) throws Exception
	{
		if (toLowerOrUpper == 0) return StringX.null2emptystr(msg.getBplVariable(varKey));
		if (toLowerOrUpper == 1) return StringX.null2emptystr(msg.getBplVariable(varKey))
				.toLowerCase();
		return StringX.null2emptystr(msg.getBplVariable(varKey)).toUpperCase();
	}

	protected String varKey;
	protected int toLowerOrUpper = 0; // 0 ��ʾ���䣬 1 ��Сд�� 2 ���д

	public String getVarKey()
	{
		return varKey;
	}

	public void setVarKey(String varKey)
	{
		this.varKey = StringX.trim(varKey);
	}

	public int getToLowerOrUpper()
	{
		return toLowerOrUpper;
	}

	public void setToLowerOrUpper(int toLowerOrUpper)
	{
		this.toLowerOrUpper = toLowerOrUpper;
	}

	public void setToLowerOrUpper(String toLowerOrUpper)
	{
		this.toLowerOrUpper = Integer.parseInt(StringX.trim(toLowerOrUpper));
	}
}
