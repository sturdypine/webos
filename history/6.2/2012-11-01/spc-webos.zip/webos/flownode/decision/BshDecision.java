package spc.webos.flownode.decision;

import spc.webos.constant.Common;
import spc.webos.data.IMessage;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;
import bsh.Interpreter;

public class BshDecision extends AbstractDecision
{
	private static final long serialVersionUID = 1L;

	public String decide(IMessage msg, IFlowContext cxt) throws Exception
	{
		if (inter == null) inter = SystemUtil.bsh("String decide(){" + bsh + "}", null);
		inter.set(Common.MODEL_CXT_KEY, cxt);
		inter.set(Common.MODEL_MSG, msg);
		inter.set(Common.MODEL_MSG_SN, msg.getMsgSn());
		inter.set(Common.MODEL_MSG_CD, msg.getMsgCd());
		inter.set(Common.MODEL_MSG_LOCAL, msg.getLocal());
		inter.eval("String _transition=decide()");
		String transition = StringX.trim((String) inter.get("_transition"));
		if (log.isInfoEnabled()) log.info("transition:" + transition);
		return transition;
	}

	protected transient Interpreter inter;
	protected String bsh;

	public String getBsh()
	{
		return bsh;
	}

	public void setBsh(String bsh)
	{
		this.bsh = StringX.trim(bsh);
	}
}