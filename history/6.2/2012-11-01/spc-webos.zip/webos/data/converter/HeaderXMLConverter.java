package spc.webos.data.converter;

import java.util.HashMap;

import spc.webos.constant.MsgLocalKey;
import spc.webos.data.Array2Node2XML;
import spc.webos.data.IMessage;
import spc.webos.data.Message;
import spc.webos.data.util.MessageUtil;
import spc.webos.log.Log;

/**
 * ��־ģ�����XML������Ϣ��Ϊ�����ESB�����ܣ�����Ҫ����xml���ĵ�body���֣�ֻ����ͷ����
 * 
 * @author spc
 * 
 */
public class HeaderXMLConverter implements IMessageConverter
{
	public IMessage deserialize(byte[] buf) throws Exception
	{
		return deserialize(buf, null);
	}

	public IMessage deserialize(byte[] buf, IMessage reqmsg) throws Exception
	{
		// ICompositeNode header = MessageUtil.getCNodeHeader(buf);
		// modified by spc. ȥ��body���֣��������ֲ������
		byte[] xml = MessageUtil.removeBody(buf);
		Message msg = new Message(xml);
		// msg.setHeader(header);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, buf);
		return msg;
	}

	public byte[] serialize(IMessage msg) throws Exception
	{
		byte[] repBytes = (byte[]) msg.getInLocal(MsgLocalKey.LOCAL_REP_BYTES);
		if (usingRepBytes && repBytes != null)
		{
			if (log.isDebugEnabled()) log.debug("usingRepBytes, len: " + repBytes.length);
			return repBytes;
		}
		byte[] originalBytes = (byte[]) msg.getInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES);
		byte[] header = msg.getHeader().toXml((String) null, IMessage.TAG_HEADER, false,
				Array2Node2XML.getInstance(), new HashMap());
		return MessageUtil.addHeader(originalBytes, header);
	}

	public IMessage deserialize(byte[] buf, int offset, int len) throws Exception
	{
		return deserialize(buf, offset, len, null);
	}

	public IMessage deserialize(byte[] buf, int offset, int len, IMessage reqmsg) throws Exception
	{
		return null;
	}

	public HeaderXMLConverter()
	{
	}

	protected boolean usingRepBytes;
	protected Log log = Log.getLogger(getClass());
	static HeaderXMLConverter HXC = new HeaderXMLConverter();

	public void setUsingRepBytes(boolean usingRepBytes)
	{
		this.usingRepBytes = usingRepBytes;
	}

	public static IMessageConverter getInstance()
	{
		return HXC;
	}
}
