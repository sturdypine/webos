package spc.webos.data;

import spc.webos.constant.Common;
import spc.webos.data.converter.XMLConverter;
import spc.webos.util.StringX;

/**
 * �󸽼�����ϵͳ�е���Ϣͷ
 * ũ����������Ʊ����һ���ļ����䶨��ͷ�淶
 * 
 * @author chenjs
 * 
 */
public class BlobMsgHeader0 extends FixedMessage implements IBlobMsgHeader 
{
	private static final long serialVersionUID = 1L;
	// { "ver","headLen", "msgCd", "sndMbrCd", "sndAppCd", "sndDt","sndTm",
	// "seqNb", "rcvMbrCd", "rcvAppCd","gzip",
	// "sliceNo", "isLast","fileId", "multiFiles"}
	public static final String[] FIELDS = { "headLen", "msgCd", "sndMbrCd", "sndAppCd", "sndDt",
			"sndTm", "seqNb", "rcvMbrCd", "rcvAppCd", "callTyp", "refCallTyp", "refMsgCd",
			"refSndMbrCd", "refSndAppCd", "refSndDt", "refSeqNb", "gzip", "sliceNo", "isLast",
			"fileId", "multiFiles", "retCd", "fixLen" };
	public static final int[] LEN = { 4, 10, 4, 3, 8, 6, 15, 4, 3, 4, 4, 10, 4, 3, 8, 15, 1, 6, 1,
			24, 1, 12, 3 };
	public static final int[] OFFSET = { 0, 4, 14, 18, 21, 29, 35, 50, 54, 57, 61, 65, 75, 79, 82,
			90, 105, 106, 112, 113, 137, 138, 150, 153 };
	// { 0, 1, 4, 14, 18, 21, 29, 35, 50, 54, 57, 58, 64, 65, 89,90 };
	public static final int[] TYPE = { TYPE_I, TYPE_S, TYPE_S, TYPE_S, TYPE_S, TYPE_S, TYPE_S,
			TYPE_S, TYPE_S, TYPE_S, TYPE_S, TYPE_S, TYPE_S, TYPE_S, TYPE_S, TYPE_S, TYPE_S, TYPE_I,
			TYPE_S, TYPE_S, TYPE_S, TYPE_S, TYPE_I };
	static final int LENGTH = 153;
	static final int FIXLEN = 153;
	public final static String YES = "1";
	public final static String NO = "0";
	public static final String EXT_KEY = "blobext";

	protected byte[] xml;

	public BlobMsgHeader0()
	{
		msg = new byte[LENGTH];
		setIsLast(NO);
		setHeadLen(String.valueOf(LENGTH));
		setFixLen(FIXLEN);
		setGzip(YES);
		setMultiFiles(NO);
		setSliceNo(0);
	}

	public BlobMsgHeader0(byte[] msg)
	{
		this.msg = msg;
	}

	public BlobMsgHeader0(ICompositeNode cnode)
	{
		msg = new byte[LENGTH];
		set(cnode);
		setHeadLen(String.valueOf(LENGTH));
	}

	public String[] fields()
	{
		return FIELDS;
	}

	public int[] len()
	{
		return LEN;
	}

	public int length()
	{
		return LENGTH;
	}

	public int[] offset()
	{
		return OFFSET;
	}

	public int[] type()
	{
		return TYPE;
	}

	public IMessage toMessage() throws Exception
	{
		byte[] xml = getXml();
		IMessage msg = xml == null ? new Message() : XMLConverter.getInstance().deserialize(xml);
		msg.init();
		String msgCd = getMsgCd();
		ICompositeNode mesg = new CompositeNode();
		mesg.set(IMessage.TAG_HEADER_MSG_RCVAPP, getRcvAppCd());
		mesg.set(IMessage.TAG_HEADER_MSG_RCVNODE, getRcvMbrCd());
		mesg.set(IMessage.TAG_HEADER_MSG_CD, msgCd);
		mesg.set(IMessage.TAG_HEADER_MSG_SN, getSeqNb());
		mesg.set(IMessage.TAG_HEADER_MSG_SNDNODE, getSndMbrCd());
		mesg.set(IMessage.TAG_HEADER_MSG_SNDAPP, getSndAppCd());
		mesg.set(IMessage.TAG_SNDDT, getSndDt());
		mesg.set(IMessage.TAG_SNDTM, getSndTm());
		msg.setMsg(mesg);

		if (msgCd.endsWith(Common.ESB_REQMSG_END)) msg.setInRequest(BlobMsgHeader.EXT_KEY,
				toCNode(null));
		else msg.setInResponse(BlobMsgHeader.EXT_KEY, toCNode(null));
		return msg;
	}

	public byte[] getXml()
	{
		if (xml != null) return xml;
		int fixLen = getFixLen();
		int xmlLen = Integer.parseInt(getHeadLen()) - fixLen;
		if (xmlLen <= 0) return null;
		xml = read(fixLen, xmlLen);
		return xml;
	}

	public void setXml(byte[] xml)
	{
		this.xml = xml;
	}

	public byte[] toMsg()
	{
		if (xml == null || xml.length == 0) return msg;
		byte[] buf = new byte[FIXLEN + xml.length];
		System.arraycopy(msg, 0, buf, 0, FIXLEN);
		System.arraycopy(xml, 0, buf, FIXLEN, xml.length);
		this.msg = buf;
		setHeadLen(String.valueOf(buf.length));
		xml = null;
		return msg;
	}

	/**
	 * ��ǰ����������Ϣ�Ƿ��������������Ƹ���
	 * 
	 * @return
	 */
	public boolean containBlob()
	{
		return msg.length > Integer.parseInt(getHeadLen());
	}

	// ������xml���Ĳ���
	// public ICompositeNode toCNode(ICompositeNode cnode)
	// {
	// CompositeNode cn = new CompositeNode();
	// ext = getExt();
	// if (ext != null && ext.size() > 0) cn.set(ext);
	// ICompositeNode blobext = super.toCNode(cnode);
	// cn.set(EXT_KEY, blobext);
	// return cn;
	// }
	//
	// public void set(ICompositeNode cnode)
	// {
	// ICompositeNode blobext = cnode.findComposite(EXT_KEY, null);
	// if (blobext != null) super.set(cnode);
	//
	// CompositeNode ext = new CompositeNode(cnode);
	// ext.remove(EXT_KEY);
	// setExt(ext);
	// }

	public String getMsgSn()
	{
		return getSndMbrCd() + getSndAppCd() + '-' + getSndDt() + '-' + getSeqNb();
	}

	// GEN METHOD
	public String getHeadLen()
	{
		return readStr(OFFSET[0], LEN[0]);
	}

	public void setHeadLen(String headLen)
	{
		writeStr(OFFSET[0], LEN[0], StringX.int2str(headLen, LEN[0]));
	}

	public String getMsgCd()
	{
		return readStr(OFFSET[1], LEN[1]);
	}

	public void setMsgCd(String msgCd)
	{
		writeStr(OFFSET[1], LEN[1], msgCd);
	}

	public String getSndMbrCd()
	{
		return readStr(OFFSET[2], LEN[2]);
	}

	public void setSndMbrCd(String sndMbrCd)
	{
		writeStr(OFFSET[2], LEN[2], sndMbrCd);
	}

	public String getSndAppCd()
	{
		return readStr(OFFSET[3], LEN[3]);
	}

	public void setSndAppCd(String sndAppCd)
	{
		writeStr(OFFSET[3], LEN[3], sndAppCd);
	}

	public String getSndDt()
	{
		return readStr(OFFSET[4], LEN[4]);
	}

	public void setSndDt(String sndDt)
	{
		writeStr(OFFSET[4], LEN[4], sndDt);
	}

	public String getSndTm()
	{
		return readStr(OFFSET[5], LEN[5]);
	}

	public void setSndTm(String sndTm)
	{
		writeStr(OFFSET[5], LEN[5], sndTm);
	}

	public String getSeqNb()
	{
		return readStr(OFFSET[6], LEN[6]);
	}

	public void setSeqNb(String seqNb)
	{
		writeStr(OFFSET[6], LEN[6], seqNb);
	}

	public String getRcvMbrCd()
	{
		return readStr(OFFSET[7], LEN[7]);
	}

	public void setRcvMbrCd(String rcvMbrCd)
	{
		writeStr(OFFSET[7], LEN[7], rcvMbrCd);
	}

	public String getRcvAppCd()
	{
		return readStr(OFFSET[8], LEN[8]);
	}

	public void setRcvAppCd(String rcvAppCd)
	{
		writeStr(OFFSET[8], LEN[8], rcvAppCd);
	}

	public String getCallTyp()
	{
		return readStr(OFFSET[9], LEN[9]);
	}

	public void setCallTyp(String callTyp)
	{
		writeStr(OFFSET[9], LEN[9], callTyp);
	}

	public String getRefCallTyp()
	{
		return readStr(OFFSET[10], LEN[10]);
	}

	public void setRefCallTyp(String refCallTyp)
	{
		writeStr(OFFSET[10], LEN[10], refCallTyp);
	}

	public String getRefMsgCd()
	{
		return readStr(OFFSET[11], LEN[11]);
	}

	public void setRefMsgCd(String refMsgCd)
	{
		writeStr(OFFSET[11], LEN[11], refMsgCd);
	}

	public String getRefSndMbrCd()
	{
		return readStr(OFFSET[12], LEN[12]);
	}

	public void setRefSndMbrCd(String refSndMbrCd)
	{
		writeStr(OFFSET[12], LEN[12], refSndMbrCd);
	}

	public String getRefSndAppCd()
	{
		return readStr(OFFSET[13], LEN[13]);
	}

	public void setRefSndAppCd(String refSndAppCd)
	{
		writeStr(OFFSET[13], LEN[13], refSndAppCd);
	}

	public String getRefSndDt()
	{
		return readStr(OFFSET[14], LEN[14]);
	}

	public void setRefSndDt(String refSndDt)
	{
		writeStr(OFFSET[14], LEN[14], refSndDt);
	}

	public String getRefSeqNb()
	{
		return readStr(OFFSET[15], LEN[15]);
	}

	public void setRefSeqNb(String refSeqNb)
	{
		writeStr(OFFSET[15], LEN[15], refSeqNb);
	}

	public String getGzip()
	{
		return readStr(OFFSET[16], LEN[16]);
	}

	public void setGzip(String gzip)
	{
		writeStr(OFFSET[16], LEN[16], gzip);
	}

	public int getSliceNo()
	{
		return Integer.parseInt(readStr(OFFSET[17], LEN[17]));
	}

	public void setSliceNo(int sliceNo)
	{
		writeStr(OFFSET[17], LEN[17], StringX.int2str(String.valueOf(sliceNo), LEN[17]));
	}

	public String getIsLast()
	{
		return readStr(OFFSET[18], LEN[18]);
	}

	public void setIsLast(String isLast)
	{
		writeStr(OFFSET[18], LEN[18], isLast);
	}

	public String getFileId()
	{
		return readStr(OFFSET[19], LEN[19]);
	}

	public void setFileId(String fileId)
	{
		writeStr(OFFSET[19], LEN[19], fileId);
	}

	public String getMultiFiles()
	{
		return readStr(OFFSET[20], LEN[20]);
	}

	public void setMultiFiles(String multiFiles)
	{
		writeStr(OFFSET[20], LEN[20], multiFiles);
	}

	public String getRetCd()
	{
		return readStr(OFFSET[21], LEN[21]);
	}

	public void setRetCd(String retCd)
	{
		writeStr(OFFSET[21], LEN[21], retCd);
	}

	public int getFixLen()
	{
		return Integer.parseInt(readStr(OFFSET[22], LEN[22]));
	}

	public void setFixLen(int fixLen)
	{
		writeStr(OFFSET[22], LEN[22], StringX.int2str(String.valueOf(fixLen), LEN[22]));
	}

	public byte[] toMsg(boolean containXml)
	{
		// TODO Auto-generated method stub
		return null;
	}

	public boolean containXML()
	{
		// TODO Auto-generated method stub
		return false;
	}

	public IBlobMsgHeader newInstance()
	{
		return new BlobMsgHeader0();
	}
}