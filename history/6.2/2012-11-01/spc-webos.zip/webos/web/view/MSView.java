package spc.webos.web.view;

import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipOutputStream;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.support.RequestContext;

import spc.webos.constant.Common;
import spc.webos.constant.Web;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;
import freemarker.template.Template;

/**
 * response.setContentType ("application/vnd.ms-excel; charset=gb2312");
 * response.setHeader ("Content-Disposition",
 * "attachment;filename=\"tmp.xls\"");
 * 
 * response.setContentType ("application/msword; charset=gb2312");
 * response.setContentType ( "application/application/vnd.ms-powerpoint;
 * charset=gb2312"); response.setContentType ("application/pdf;
 * charset=gb2312"); response.setContentType ("application/octet-stream;
 * charset=gb2312"); response.setContentType ("text/html; charset=gb2312");
 * 
 * @author sturdypine.chen
 * 
 */
public class MSView implements View, ResourceLoaderAware, ApplicationContextAware
{
	static final String NAME_TAG = "name";
	static final String SRC_TAG = "src";

	public void render(Map model, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		String template = (String) model.get(Web.REQ_KEY_TEMPLATE_ID); // ���õ�ģ��ID
		if (StringX.nullity(template)) template = (String) req
				.getParameter(Web.REQ_KEY_TEMPLATE_ID);
		model.put(Common.SPRING_MACRO_REQ_CXT_KEY, new RequestContext(req));
		// ����ģ���������й�����Ϣ
		genarateReport(template, model, res);
	}

	/**
	 * ��ɶ������ĵ����������봦��
	 */
	public void init() throws Exception
	{
		loadConfig();
	}

	void loadConfig() throws Exception
	{
		if (configLocation == null) return;
		InputStream is = configLocation.getInputStream();
		SAXReader reader = new SAXReader(false);
		Document doc = reader.read(is);
		templates = new HashMap(); // ÿһ������ģ�����Ϣ
		Element root = doc.getRootElement();

		// ��ø�����ģ�������
		List templates = root.elements("template");
		for (int i = 0; templates != null && i < templates.size(); i++)
		{
			Element templateElem = (Element) templates.get(i);
			String tempateID = templateElem.attributeValue("id"); // ��ñ�����ģ��ID
			// ��ö�Ӧ����ģ��ID�ľ�������, ��Ϊ֧�ֶ����
			ArrayList listSheets = new ArrayList();
			List sheets = templateElem.elements("sheet");
			for (int j = 0; sheets != null && j < sheets.size(); j++)
			{
				Element sheet = (Element) sheets.get(j);

				Map mapSheet = new HashMap();
				mapSheet.put(NAME_TAG, sheet.attributeValue(NAME_TAG));
				mapSheet.put(SRC_TAG, sheet.attributeValue(SRC_TAG));
				listSheets.add(mapSheet);
			}
			this.templates.put(tempateID, listSheets);
		}
		is.close();
	}

	ApplicationContext appCxt;
	ResourceLoader resourceLoader; // ģ���ļ�����Դ������
	Resource configLocation; // �����ļ�λ��
	Map templates = new HashMap(); // ģ�������ļ���Ϣ
	final static MSView MS_VIEW = new MSView();

	private MSView()
	{
	}

	/**
	 * �������ɵ��ļ�����
	 * 
	 * @param templateID
	 * @param rootModel
	 * @param bos
	 * @return
	 * @throws Exception
	 */
	private int genarateReport(String templateID, Map root, HttpServletResponse res)
			throws Exception
	{
		int bufferSize = 1024;
		String fileName = (String) root.get(Web.REQ_KEY_DOWNLOAD_FILE_NAME); // �����ļ���
		ServletOutputStream out = res.getOutputStream();
		BufferedOutputStream bos = new BufferedOutputStream(out, bufferSize);

		ArrayList sheets = (ArrayList) templates.get(templateID);
		if (sheets == null || sheets.size() <= 1)
		{ // ֻ��һ��ģ���ļ�, û��Ҫ���ô���ļ��еķ�ʽ

			String template = null;
			if (sheets == null)
			{// ���û��ģ�壬��urlֱ���ṩģ��Id
				template = templateID;
				int index = templateID.indexOf('/');
				// viewName������һ���ģ�壬Ҳ������bean name����msView,
				// �������ĵ�ַ��������//˵���Ѿ����Զ�λ,����Ҫ��ftl
				if (index > 0 && index == templateID.lastIndexOf('/')) template = templateID
						.substring(0, index)
						+ '/' + Common.TEMPLATE_TYPE_FTL + '/' + templateID.substring(index + 1);
				template += '.' + Common.TEMPLATE_TYPE_FTL;
			}
			else
			{
				Map sheet = (Map) sheets.get(0);
				fileName = (String) sheet.get(NAME_TAG);
				template = (String) sheet.get(SRC_TAG);
			}
			if (StringX.nullity(fileName)) fileName = templateID + '.' + Common.OBJECT_TYPE_EXCEL;

			res.setContentType(Common.getContentType(fileName));
			res.setHeader(Common.REQ_HEADER_KEY_1, "attachment; filename="
					+ new String(StringX.utf82str(fileName).getBytes(), Common.CHARSET_ISO));

			OutputStreamWriter osw = new OutputStreamWriter(bos);
			Template temp = SystemUtil.getInstance().getFtlCfg().getTemplate(template);
			temp.process(root, osw);
			osw.flush();
			bos.flush();
			bos.close();
			return 1;
		}
		if (StringX.nullity(fileName)) fileName = "data.zip";
		// ��ģ���ļ�, ��Ҫ�������
		res.setContentType(Common.FILE_ZIP_CONTENTTYPE);
		res.setHeader(Common.REQ_HEADER_KEY_1, "attachment; filename="
				+ new String(StringX.utf82str(fileName).getBytes(), Common.CHARSET_ISO));
		ZipOutputStream zos = new ZipOutputStream(bos);
		for (int i = 0; i < sheets.size(); i++)
		{
			Map sheet = (Map) sheets.get(i);
			fileName = (String) sheet.get(NAME_TAG);
			zos.putNextEntry(new ZipEntry(fileName));

			OutputStreamWriter osw = new OutputStreamWriter(zos);
			Template t = SystemUtil.getInstance().getFtlCfg().getTemplate(
					(String) sheet.get(SRC_TAG));
			t.process(root, osw);
			osw.flush();
			zos.closeEntry();
		}
		zos.flush();
		zos.close(); // zip����� ����close, ����ͨ������OutStream.close()���ﵽĿ��
		return sheets.size();
	}

	public void setConfigLocation(Resource configLocation)
	{
		this.configLocation = configLocation;
	}

	public void setResourceLoader(ResourceLoader resourceLoader)
	{
		this.resourceLoader = resourceLoader;
	}

	public void close()
	{
	}

	public static MSView getInstance()
	{
		return MS_VIEW;
	}

	public String getContentType()
	{
		return Common.FILE_ZIP_CONTENTTYPE;
	}

	public void setApplicationContext(ApplicationContext appCxt)
	{
		this.appCxt = appCxt;
	}
}
