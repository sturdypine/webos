package spc.webos.web.view;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.View;

import spc.webos.config.AppConfig;
import spc.webos.constant.Common;
import spc.webos.constant.Web;
import spc.webos.exception.AppException;
import spc.webos.log.Log;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;
import spc.webos.web.util.WebUtil;
import freemarker.template.Template;

// import
// org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

public class ExceptionView implements View
{
	String errPage = "main/ftl/error.ftl";
	public final static String ERR_CLASS_KEY = "ERR_CLAZZ";
	static Log LOG = Log.getLogger(ExceptionView.class);
	static ExceptionView EX_VIEW = new ExceptionView();

	private ExceptionView()
	{
	}

	public static ExceptionView getInstance()
	{
		return EX_VIEW;
	}

	public String getContentType()
	{
		return Common.FILE_HTML_CONTENTTYPE;
	}

	public void render(Map model, HttpServletRequest request, HttpServletResponse response)
	{
		Exception ex = (Exception) model.get(Common.MODEL_EXCEPTION); // SimpleMappingExceptionResolver.DEFAULT_EXCEPTION_ATTRIBUTE
		if (!AppConfig.isProductMode()) LOG.error("ExView", ex);
		WebUtil.request2map(request, model);

		if (ex instanceof AppException)
		{
			AppException appEx = (AppException) ex;
			model.put(Web.REQ_KEY_EX_CODE, SystemUtil.APP + appEx.getCode());
			model.put(Web.REQ_KEY_EX_LOC, appEx.getLocation());
			try
			{
				model.put(Web.REQ_KEY_EX_MSG, SystemUtil.getInstance().getAppCxt().getMessage(
						SystemUtil.RETCD_PATH + appEx.getCode(), appEx.getArgs(), null));
			}
			catch (Exception e)
			{
				model.put(Web.REQ_KEY_EX_MSG, "Undefined desc!!!");
				LOG.warn("Fail to get error desc for " + appEx.getCode(), e);
			}
		}
		else
		{
			model.put(Web.REQ_KEY_EX_CODE, StringX.EMPTY_STRING);
			model.put(Web.REQ_KEY_EX_MSG, ex.toString());
			StackTraceElement[] stack = ex.getCause() != null ? ex.getCause().getStackTrace() : ex
					.getStackTrace();
			String loc = stack[0].getClassName() + '.' + stack[0].getMethodName() + ':'
					+ stack[0].getLineNumber();
			model.put(Web.REQ_KEY_EX_LOC, loc);
		}
		response.setStatus(Web.SERVER_EXCEPTION_STATUS_CODE);
		request.setAttribute(Web.RESP_ATTR_ERROR_KEY, Boolean.TRUE);

		String errPage = request.getParameter(Web.REQ_KEY_ERR_PAGE);
		if (errPage == null || errPage.length() == 0) errPage = this.errPage;
		try
		{
			Template t = SystemUtil.getInstance().getFtlCfg().getTemplate(errPage);
			t.process(model, response.getWriter());
			response.getWriter().flush();
		}
		catch (Exception e)
		{
			LOG.error("errPage:" + errPage, e);
		}
	}

	public void setErrPage(String errPage)
	{
		this.errPage = errPage;
	}
}
