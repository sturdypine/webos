package spc.webos.jsrmi.view;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class JspViewRender {

	public void render(String[] params, 
			HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		String page = "/WEB-INF/view/" + params[1] + ".jsp";
		RequestDispatcher rd = request.getRequestDispatcher(page);
		rd.forward(request, response);
	}

}
