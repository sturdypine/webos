
package spc.webos.jsrmi.protocal.converters;

import spc.webos.jsrmi.protocal.io.MarshallingContext;
import spc.webos.jsrmi.protocal.io.StreamReader;
import spc.webos.jsrmi.protocal.io.StreamWriter;
import spc.webos.jsrmi.protocal.io.UnmarshallingContext;

public class ReferenceConverter implements Converter {

	public boolean canConvert(Class type) {
		throw new UnsupportedOperationException();
	}

	public void marshal(Object source, MarshallingContext context, StreamWriter streamWriter) {
		throw new UnsupportedOperationException();
	}

	public Object unmarshal(StreamReader reader, UnmarshallingContext unmarshallingContext) {
		int idx = Integer.valueOf(reader.getValue()).intValue();
		return unmarshallingContext.getObjects().get(idx);
	}

}
