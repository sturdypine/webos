
package spc.webos.jsrmi.protocal.io;

import spc.webos.jsrmi.protocal.JsrmiCall;
import spc.webos.jsrmi.protocal.converters.ConverterLookup;

public interface MarshallingStrategy {

	void marshal(Object obj, ConverterLookup converterLookup, StreamWriter streamWriter);

	JsrmiCall unmarshal(StreamReader reader, ConverterLookup converterLookup);
	
}
