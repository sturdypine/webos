package spc.webos.queue.tlq;

import java.util.Hashtable;
import java.util.List;

import spc.webos.queue.AccessTPool;
import spc.webos.queue.AccessThread;
import spc.webos.thread.DaemonThread;

public class TLQAccessTPool extends AccessTPool
{
	public TLQAccessTPool()
	{
	}

	public TLQAccessTPool(int rw, int size, Hashtable props, List bufferNames)
	{
		this.rw = rw;
		this.size = size;
		this.props = props;
		this.bufferNames = bufferNames;
	}

	public DaemonThread borrow()
	{
		if (AccessThread.RW_READ == rw) { return new TLQReceiverThread(this, props, bufs,
				buf2queueMapping); }
		return null;
	}
}
