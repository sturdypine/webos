package spc.webos.queue.tlq;

import java.util.Hashtable;

import spc.webos.pool.ObjectPool;

public class TLQCnnPool extends ObjectPool
{
	protected Hashtable props;
	protected int cnnHoldTime = -1; // ���ӱ��ֵ����ʱ�䣬 -1��ʾ���޳�
	protected int cnnIdleTime = -1;

	public Object newIntance()
	{
		return new TLQManager(props, cnnHoldTime, cnnIdleTime);
	}

	public synchronized Object borrow()
	{
		TLQManager tlqm = null;
		if (pool.size() == 0)
		{
			log.warn("pool is empty, need to borrow one object:" + getClass().getName() + ", name:"
					+ name + ", max:" + max);
			tlqm = (TLQManager) newIntance();
		}
		else tlqm = (TLQManager) pool.removeFirst();
		return tlqm;
	}

	public boolean release(Object obj)
	{
		TLQManager tlqm = (TLQManager) obj;
		if (!super.release(tlqm)) tlqm.disconnect();
		return true;
	}

	public synchronized void destory()
	{
		log.warn("start to destory object pool(" + name + ") : " + pool.size());
		for (int i = 0; i < pool.size(); i++)
			((TLQManager) pool.get(i)).disconnect();
		pool.clear();
	}

	public Hashtable getProps()
	{
		return props;
	}

	public void setProps(Hashtable props)
	{
		this.props = props;
	}

	public void setCnnHoldTime(int cnnHoldTime)
	{
		this.cnnHoldTime = cnnHoldTime;
	}

	public void setCnnIdleTime(int cnnIdleTime)
	{
		this.cnnIdleTime = cnnIdleTime;
	}
}
