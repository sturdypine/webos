package spc.webos.cache;

import java.util.HashMap;
import java.util.Map;

import spc.webos.log.Log;

public abstract class AbstractCache implements ICache
{
	String name;
	protected Log log = Log.getLogger(getClass());

	public void setName(String name)
	{
		this.name = name;
	}

	public void init() throws Exception
	{
		if (getName() != null) CACHE.put(getName(), this);
	}

	public Object getMessage(String key) throws Exception// for ���ʻ�
	{
		return get(key);
	}

	public synchronized Object poll(Object key, long timeout) throws Exception
	{
		return poll(key, new CacheWaitWithTime((String) key, timeout));
	}

	public synchronized Object poll(Object key, WaitWithTime wwt) throws Exception
	{
		wwt.setTarget(this);
		Object v = null;
		while (v == null)
		{
			while (wwt.condition())
				wwt.timeWait();
			v = get(key);
			remove(key);
		}
		return v;
	}

	public Object poll(Object key) throws Exception
	{
		Object v = get(key);
		remove(key);
		return v;
	}

	public String getName()
	{
		return name;
	}

	public boolean changeStatus(Map param)
	{
		return false;
	}

	public Map checkStatus(Map param)
	{
		Map status = new HashMap();
		status.put("name", name);
		status.put("clazz", getClass());
		return status;
	}

	public void refresh() throws Exception
	{
	}
}
