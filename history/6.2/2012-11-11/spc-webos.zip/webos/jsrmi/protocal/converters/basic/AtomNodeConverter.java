package spc.webos.jsrmi.protocal.converters.basic;

import spc.webos.data.IAtomNode;
import spc.webos.jsrmi.protocal.ProtocalTag;
import spc.webos.jsrmi.protocal.converters.Converter;
import spc.webos.jsrmi.protocal.io.MarshallingContext;
import spc.webos.jsrmi.protocal.io.StreamWriter;

/**
 * ת��message�е�IAtomNode�ڵ�
 * 
 * @author spc
 * 
 */
public class AtomNodeConverter extends AbstractBasicConverter implements
		Converter
{
	public boolean canConvert(Class type)
	{
		if (type == null) return false;
		return IAtomNode.class.isAssignableFrom(type);
	}

	public Object fromString(String value)
	{
		return value;
	}

	protected String getType()
	{
		return ProtocalTag.TAG_DOUBLE;
	}

	public void marshal(Object source, MarshallingContext context,
			StreamWriter streamWriter)
	{
		IAtomNode atom = (IAtomNode) source;
		if (atom.isBoolean())
		{
			streamWriter.startNode(ProtocalTag.TAG_BOOLEAN);
			streamWriter.setValue(String.valueOf(atom.booleanValue() ? 1 : 0));
			streamWriter.endNode();
			return;
		}
		if (atom.isDouble()) streamWriter.startNode(ProtocalTag.TAG_DOUBLE);
		else if (atom.isInteger()) streamWriter.startNode(ProtocalTag.TAG_INT);
		else if (atom.isLong()) streamWriter.startNode(ProtocalTag.TAG_LONG);
		else streamWriter.startNode(ProtocalTag.TAG_STRING);
		streamWriter.setValue(atom.stringValue());
		streamWriter.endNode();
	}
}
