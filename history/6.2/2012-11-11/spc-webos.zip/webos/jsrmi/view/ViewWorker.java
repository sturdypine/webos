package spc.webos.jsrmi.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import spc.webos.jsrmi.request.AbstractRequestWorker;
import spc.webos.jsrmi.request.RequestWorker;
import spc.webos.jsrmi.request.ValidationException;

public class ViewWorker extends AbstractRequestWorker implements RequestWorker {

	public void processRequest(HttpServletRequest request, HttpServletResponse response) {
		throw new UnsupportedOperationException("This worker has not been implemented yet!");
	}

	public void validate(HttpServletRequest request, HttpServletResponse response) throws ValidationException {
		
	}

}
