package spc.webos.web.form;

import java.io.Serializable;

public interface Form extends Serializable, Cloneable
{

}
