package spc.webos.web.form;

import spc.webos.model.ValueObject;

public class CommonForm implements Form
{
	private static final long serialVersionUID = 1L;
	ValueObject vo;
	String act; // insert, update

	public ValueObject getVo()
	{
		return vo;
	}

	public void setVo(ValueObject vo)
	{
		this.vo = vo;
	}

	public String getAct()
	{
		return act;
	}

	public void setAct(String act)
	{
		this.act = act;
	}
}
