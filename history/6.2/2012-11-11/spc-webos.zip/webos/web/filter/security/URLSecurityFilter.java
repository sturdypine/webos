package spc.webos.web.filter.security;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.util.StringUtils;

import spc.webos.constant.AppRetCode;
import spc.webos.constant.Common;
import spc.webos.constant.Web;
import spc.webos.exception.AppException;
import spc.webos.util.StringX;
import spc.webos.web.common.ISessionUserInfo;
import spc.webos.web.controller.VerifyImageCtrller;
import spc.webos.web.filter.AbstractURLFilter;
import spc.webos.web.util.WebUtil;
import spc.webos.web.view.ExceptionView;

public class URLSecurityFilter extends AbstractURLFilter
{
	protected int maxInactiveInterval = 72000; // ���sessionʱ��Ϊ20��Сʱ
	protected AntPathBasedFilterDefinitionMap source = new AntPathBasedFilterDefinitionMap();
	protected String suiClazz = "spc.webos.web.common.SessionUserInfo";
	protected String loginUriPrefix = "/jsrmi/login/login";
	public final static String AUTH_ANONYMOUS = "PUBLIC"; // ����Ȩ��
	public final static String MUST_LOGIN = "LOGIN";

	public void filter(ServletRequest request, ServletResponse response, FilterChain chain,
			String patternURL) throws IOException, ServletException
	{
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		ISessionUserInfo.SUI.set(null); // ��յ�ǰ�̵߳ĵĵ�¼����
		String uri = getUri(req);
		if (log.isDebugEnabled()) log.debug("uri: " + uri);
		HttpSession session = req.getSession(uri.indexOf(loginUriPrefix) >= 0); // ֻ�е�¼url���ܴ���session
		ISessionUserInfo sui = session == null ? null : (ISessionUserInfo) session
				.getAttribute(ISessionUserInfo.USER_SESSION_INFO_KEY);
		try
		{
			Date dt = new Date();
			if (sui == null && uri.indexOf(loginUriPrefix) >= 0)
			{
				if (log.isInfoEnabled()) log.info("user login...");
				sui = (ISessionUserInfo) (Class.forName(suiClazz)).newInstance();
				sui.setLoginDt(dt);
				sui.setLoginIP(request.getRemoteAddr());
				session.setMaxInactiveInterval(maxInactiveInterval);
				session.setAttribute(ISessionUserInfo.USER_SESSION_INFO_KEY, sui);
			}
			if (sui != null)
			{
				sui.setLastVisitDt(dt);
				sui.setSession(session);
				sui.setRequest(req);
				sui.setResponse(res);

				String verifyCode = (String) session
						.getAttribute(VerifyImageCtrller.VERIFY_IMG_SESSION_KEY);
				if (verifyCode != null)
				{
					sui.setVerifyCode(verifyCode);
					session.removeAttribute(VerifyImageCtrller.VERIFY_IMG_SESSION_KEY);
				}
				ISessionUserInfo.SUI.set(sui); // ���SessionUserInfo����ThreadLocal����ȥ
				sui.removeExpiredTransient();
			}
			else log.debug("SUI is null...");
		}
		catch (Exception e)
		{
			log.error(StringX.EMPTY_STRING, e);
		}
		List validRoles = source.lookupAttributes(uri); // ����ܺϷ������URI�Ľ�ɫ,����
		// System.out.println("uri="+uri+", "+validRoles);
		if (log.isDebugEnabled()) log.debug("validRoles:" + validRoles);
		if (validRoles.contains(AUTH_ANONYMOUS))
		{ // ���õ�½���ܷ��ʵ���Դ
			chain.doFilter(request, response);
			return;
		}
		if (sui == null || sui.getUserCode() == null)
		{
			log.warn("sui is null or usercode is null!!!");
			reportERROR(req, res);
			return;
		}
		if (validRoles.contains(MUST_LOGIN))
		{ // ֻ��Ҫ��½���ܷ��ʵ���Դ
			chain.doFilter(request, response);
			return;
		}
		// �ж�Ȩ��, �Ƿ����������URL
		// 1. ���ǰ�õķǷ����ʵ���Դ�Ľ�ɫ
		List unValidRoles = source.lookupAttributes('-' + uri); // ��ò��ܺϷ������URI�Ľ�ɫ,����
		if (unValidRoles.size() > 0)
		{
			int unValidTimes = 0;
			for (int i = 0; i < unValidRoles.size(); i++)
			{// ˵������Դ�ǵ�ǰ��ɫ���ܷ��ʵ�, ����һ���˿���ӵ�ж����ɫ, ֻ������ӵ�еĽ�ɫ�����ܷ��ʲ���˵�����ܷ���
				if (sui.getUserRole().contains(unValidRoles.get(i))) unValidTimes++;
			}
			if (unValidTimes > 0)
			{ // ������ӵ�е����н�ɫ�����ܷ��ʴ�ģ��
				request.setAttribute(Web.RESP_ATTR_ERROR_KEY, Boolean.TRUE);
				log.warn("no right to visit some resource!!!");
				reportERROR(req, res);
				return;
			}
		}

		// 2. ��úϷ���ԴȨ��
		for (int i = 0; i < validRoles.size(); i++)
		{
			if (sui.getUserRole().contains(validRoles.get(i)))
			{ // ����Դ��Ȩ�ޱ�����ӵ��, ��Ϸ�ͨ��
				chain.doFilter(request, response);
				return;
			}
		}
		// û��ͨ���� 2 ������Դ����Ϸ����. �ض�λ����½ҳ��
		log.warn("no right to visit !!!");
		request.setAttribute(Web.RESP_ATTR_ERROR_KEY, Boolean.TRUE);
		reportERROR(req, res);
	}

	private void reportERROR(HttpServletRequest req, HttpServletResponse res) throws IOException
	{
		log.info("report error!!!");
		if (req.getParameter(Web.REQ_KEY_EX_TYPE) != null)
		{
			Map params = WebUtil.request2map(req, null);
			params.put(Common.MODEL_EXCEPTION, new AppException(AppRetCode.FILTER_UNVALID_URI()));
			params.put(ExceptionView.ERR_CLASS_KEY, getClass().getName());
			ExceptionView.getInstance().render(params, req, res);
		}
		else res.sendRedirect(req.getContextPath());
	}

	/**
	 * ������õ�Url��Դ��Ӧ��Ȩ�� or ��ɫ or ����ģ����Ϣ
	 * 
	 * @param s
	 */
	public void setDefinitionSource(String s)
	{
		BufferedReader br = new BufferedReader(new StringReader(s));
		int counter = 0;
		String line;

		while (true)
		{
			counter++;
			try
			{
				line = br.readLine();
			}
			catch (IOException ioe)
			{
				throw new IllegalArgumentException(ioe.getMessage());
			}
			if (line == null) break;
			line = line.trim();
			if (line.startsWith("//")) continue;
			if (line.equals("CONVERT_URL_TO_LOWERCASE_BEFORE_COMPARISON"))
			{
				source.setConvertUrlToLowercaseBeforeComparison(true);
				continue;
			}
			if (line.lastIndexOf('=') == -1) continue;

			// Tokenize the line into its name/value tokens
			String[] nameValue = StringUtils.delimitedListToStringArray(line, "=");
			String name = nameValue[0].trim().toLowerCase();
			String value = nameValue[1].trim();

			if (!StringUtils.hasLength(name) || !StringUtils.hasLength(value)) throw new IllegalArgumentException(
					"Failed to parse a valid name/value pair from " + line);
			String[] roles = StringUtils.delimitedListToStringArray(value, StringX.COMMA);
			List configAttributes = new ArrayList(); // ÿһ��URL��Ӧ�Ľ�ɫ ���� Ȩ������
			// ����
			// ģ�鹦�ܺ� ��Ϣ
			for (int i = 0; roles != null && i < roles.length; i++)
				configAttributes.add(roles[i]);
			roles = null;

			// Register the regular expression and its attribute
			source.addSecureUrl(name, configAttributes);
		}
	}

	public void setSuiClazz(String suiClazz)
	{
		this.suiClazz = suiClazz;
	}

	public void setMaxInactiveInterval(int maxInactiveInterval)
	{
		this.maxInactiveInterval = maxInactiveInterval;
	}

	public void setLoginUriPrefix(String loginUriPrefix)
	{
		this.loginUriPrefix = loginUriPrefix;
	}
}
