package spc.webos.web.handler;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.servlet.handler.BeanNameUrlHandlerMapping;

public class PathNameUrlHandlerMapping extends BeanNameUrlHandlerMapping
{
	protected Object lookupHandler(String urlPath, HttpServletRequest request)
			throws Exception
	{
		// System.out.println("urlPath: " + urlPath);
		Object handler = super.lookupHandler(urlPath, request);
		return handler == null ? getRootHandler() : handler;
		// System.out.println("urlPath: " + handler);
	}
}
