package spc.webos.web.security;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * ��Ҫ��Get��ʽ��URL���д���Կ�ļ���
 * 
 * @author Hate
 */
public class URLEncoder
{
	public boolean isValidURL(String queryString, String urlKey)
	{
		if (queryString == null || queryString.length() == 0) return true;
		byte[] key = systemKey;
		if (urlKey != null && urlKey.length() > 0)
		{
			key = urlKey.getBytes();
		}
		if (!queryString.startsWith(SECRET_KEY)) return false;
		int index = queryString.indexOf('&');
		if (index < 0) return true;
		String secretKey = queryString.substring(SECRET_KEY.length() + 1, index);
		String str = queryString.substring(index + 1);
		String secret = getDigest(str, key);
		return secret.equals(secretKey);
	}

	/**
	 * ����һ��URL��queryString����
	 * 
	 * @param queryString
	 * @param variable
	 * @return
	 */
	public String getEncodedURL(String queryString, String urlKey)
	{
		if (queryString == null || queryString.length() == 0) return queryString;
		StringBuffer secretKey = new StringBuffer(SECRET_KEY);
		secretKey.append("=");
		byte[] key = systemKey;
		if (urlKey != null && urlKey.length() > 0)
		{
			key = urlKey.getBytes();
		}
		secretKey.append(getDigest(queryString, key));
		secretKey.append("&");
		return secretKey.append(queryString).toString();
	}

	public static String getDigest(String str, byte[] key)
	{
		try
		{
			StringBuffer secretKey = new StringBuffer();
			MessageDigest md5 = MessageDigest.getInstance("MD5");
			md5.update(str.getBytes());
			byte[] encodedURL = md5.digest(key);
			for (int i = 0; i < encodedURL.length; i++)
			{ // ��Md5���ܺ��128bit�Ĵ�����,תΪ16���Ƶ��ַ���
				secretKey.append(Integer.toHexString((encodedURL[i] & 0xff)));
			}
			return secretKey.toString();
		}
		catch (NoSuchAlgorithmException e)
		{
		}
		return null;
	}

	public static URLEncoder getInstance()
	{
		return urlEncoder;
	}

	public static final String SECRET_KEY = "_KEY_";

	private URLEncoder()
	{
	}

	static URLEncoder urlEncoder = new URLEncoder();

	/**
	 * ϵͳ��Կ��ÿ��ϵͳ��������һ���������Կ, ���ڽ⿪���������URL��ȫ
	 */
	static final byte[] systemKey = ("" + Math.random()).substring(2).getBytes();
}
