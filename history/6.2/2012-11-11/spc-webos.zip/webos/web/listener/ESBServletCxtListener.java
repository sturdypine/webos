package spc.webos.web.listener;

import java.util.Map;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import spc.webos.endpoint.ESB;
import spc.webos.log.Log;
import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;

public class ESBServletCxtListener implements ServletContextListener
{
	static Log log = Log.getLogger(ESBServletCxtListener.class);

	public void contextDestroyed(ServletContextEvent evt)
	{
		ESB.getInstance().destory();
	}

	/**
	 * <context-param> <param-name>ESBConfig</param-name>
	 * <param-value>hostname=172.16
	 * .1.227&port=651000&cnnHoldTime=300&CCSID=1208&channel=SVRCONN_GWIN
	 * &qmName=QM_GW_IN&appCd=NNS&maxCnnNum=20</param-value> </context-param>
	 * <listener> <listener-class> spc.esb.ESBServletCxtListener
	 * </listener-class> </listener>
	 * 
	 */
	public void contextInitialized(ServletContextEvent evt)
	{
		log.info("servlet context init...");
		try
		{
			String esbconfig = StringX.trim(evt.getServletContext().getInitParameter("ESBConfig"));
			if (!StringX.nullity(esbconfig))
			{
				initESB(esbconfig);
				return;
			}
			esbconfig = StringX.trim(evt.getServletContext().getInitParameter("esbconfig"));
			if (!StringX.nullity(esbconfig))
			{
				initESB((Map) JsonUtil.json2obj(esbconfig));
			}
		}
		catch (Exception e)
		{
			log.warn("ESB.init", e);
			throw new RuntimeException(e);
		}
	}

	public void initESB(String esbconfig) throws Exception
	{
		ESB.getInstance().init(esbconfig);
	}

	/**
	 * <param-name>ESBConfig</param-name> <param-value>{appCd:
	 * 'NNS',channels:[{cnnHoldTime:300,maxCnnNum:20,channel:{hostname:'192.168.4.73',port:33300,channel:'SVRCONN_GW'
	 * } } , {cnnHoldTime:300,maxCnnNum:20,channel:{hostname:
	 * '192.168.4.73',port:33399,channel:'SVRCONN_GW'}}]}</param-value >
	 * 
	 * @param esbconfig
	 * @throws Exception
	 */
	public void initESB(Map esbconfig) throws Exception
	{
		ESB.getInstance().init(esbconfig);
	}
}
