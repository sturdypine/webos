package spc.webos.web.listener;

import java.util.Map;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import spc.webos.log.Log;
import spc.webos.web.common.ISessionUserInfo;

/**
 * �����û�session����
 * 
 * @author spc
 * 
 */
public class OnlineUserSessionListener implements HttpSessionListener
{
	protected static Log log = Log.getLogger(OnlineUserSessionListener.class);

	public void sessionCreated(HttpSessionEvent evt)
	{
		if (log.isInfoEnabled()) log.info("sessionCreated..." + evt.getSession().getId());
	}

	public void sessionDestroyed(HttpSessionEvent evt)
	{
		if (log.isInfoEnabled()) log.info("sessionDestroyed..." + evt.getSession().getId());
		ISessionUserInfo sui = (ISessionUserInfo) evt.getSession().getAttribute(
				ISessionUserInfo.USER_SESSION_INFO_KEY);
		Map onlineUser = (Map) evt.getSession().getAttribute(ISessionUserInfo.ALL_ONLINE_USER_KEY);
		if (onlineUser != null && sui != null)
		{
			if (log.isInfoEnabled()) log.info("userCd: " + sui.getUserCode()
					+ "'s sessionDestroyed!!!");
			onlineUser.remove(sui.getUserCode());
		}
	}
}
