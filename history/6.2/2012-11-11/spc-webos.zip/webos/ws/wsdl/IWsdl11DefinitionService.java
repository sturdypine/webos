package spc.webos.ws.wsdl;

import java.util.Map;

import spc.webos.util.tree.TreeNode;

public interface IWsdl11DefinitionService
{
	String wsdl(Map param) throws Exception;

	String schema(Map param) throws Exception;

	// ��һ�����Ľṹ���һ��schema
	String struct2schema(TreeNode node, String type) throws Exception;
}
