package spc.webos.ws.endpoint;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.transform.Source;

import org.springframework.ws.server.endpoint.AbstractSaxPayloadEndpoint;
import org.springframework.xml.transform.StringSource;
import org.xml.sax.ContentHandler;

import spc.webos.constant.Common;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.data.INode;
import spc.webos.data.INode2XML;
import spc.webos.data.INodeVisitor;
import spc.webos.data.Message;
import spc.webos.data.SOAPNode2XML;
import spc.webos.data.converter.DefaultSaxHandler;
import spc.webos.data.converter.SaxHandler;
import spc.webos.flownode.MessageFlow;
import spc.webos.log.Log;
import spc.webos.util.StringX;

/**
 * ͨ��Sax endpoint�ڵ㡣 ������е�message���ģ�����ͨ�ý���ģʽ
 * 
 * @author spc
 * 
 */
public class MessageSaxEndpoint extends AbstractSaxPayloadEndpoint
{
	protected Log log = Log.getLogger(getClass());
	protected SaxHandler handler = new DefaultSaxHandler();
	protected MessageFlow msgFlow;
	protected String prefix = StringX.EMPTY_STRING;
	protected String ns; // �����ռ�
	protected String nsuri; // �����ռ�
	protected String logName; // �����Ҫ�߳���־�����ṩ��־��
	protected INode2XML node2xml = new SOAPNode2XML();

	public ContentHandler createContentHandler() throws Exception
	{
		handler.start();
		return handler;
	}

	public Source getResponse(ContentHandler handler) throws Exception
	{
		return new StringSource(getResponseAsString(handler));
	}

	public String getResponseAsString(ContentHandler handler) throws Exception
	{
		boolean startlog = Log.startWithRequired(logName);
		String xml = null;
		try
		{
			ICompositeNode root = this.handler.root();
			if (log.isDebugEnabled()) log.debug(root.toXml(IMessage.TAG_ROOT, true, node2xml));
			IMessage msg = deserialize(root);
			if (msgFlow != null) msgFlow.execute(msg);
			xml = serialize(msg);
			if (log.isDebugEnabled()) log.debug("rep soap xml:" + xml);
		}
		catch (Throwable t)
		{
			log.error("handleRequest", t);
			if (t instanceof Exception) throw (Exception) t;
			else throw new Exception(t);
		}
		finally
		{
			if (startlog) Log.print();
		}
		return xml;
	}

	public IMessage deserialize(ICompositeNode root) throws Exception
	{
		root.dfs(new INodeVisitor()
		{
			public boolean visitor(INode node, INode parent, String name)
			{
				if (node == null) return true;
				Map ext = node.getExt();
				if (ext == null || ext.size() == 0) return true;
				List removeKeys = new ArrayList();
				Iterator keys = ext.keySet().iterator();
				while (keys.hasNext())
				{ // added by chenjs 2012-01-01 ESB
					// XML���Ĳ�֧�������ռ�����Զ��壬ɾ���������ռ�����Զ���
					String key = keys.next().toString();
					if (key.indexOf(':') > 0) removeKeys.add(key);
				}
				for (int i = 0; i < removeKeys.size(); i++)
					ext.remove((String) removeKeys.get(i));
				node.setExt(ext);
				return true;
			}
		});
		return new Message(root);
	}

	public String serialize(IMessage msg) throws Exception
	{
		String rootName = prefix + StringX.replaceAll(msg.getMsgCd(), ".", "") + "Response";
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		msg.getTransaction().toXml(baos, StringX.nullity(ns) ? null : ns, rootName, true, node2xml,
				new HashMap());
		String xml = new String(baos.toByteArray(), Common.CHARSET_UTF8);
		if (!StringX.nullity(ns) && !StringX.nullity(nsuri))
		{
			xml = "<"
					+ ns
					+ ":"
					+ rootName
					+ " xmlns:"
					+ ns
					+ "=\""
					+ nsuri
					+ "\" xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
					+ xml.substring(rootName.length() + ns.length() + 3);
		}
		return xml;
	}

	public void setMsgFlow(MessageFlow msgFlow)
	{
		this.msgFlow = msgFlow;
	}

	public void setHander(SaxHandler handler)
	{
		this.handler = handler;
	}

	public void setNs(String ns)
	{
		this.ns = ns;
	}

	public void setNsuri(String nsuri)
	{
		this.nsuri = nsuri;
	}

	public void setPrefix(String prefix)
	{
		this.prefix = prefix;
	}

	public void setLogName(String logName)
	{
		this.logName = logName;
	}

	public INode2XML getNode2xml()
	{
		return node2xml;
	}

	public void setNode2xml(INode2XML node2xml)
	{
		this.node2xml = node2xml;
	}
}
