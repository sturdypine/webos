package spc.webos.queue.tlq;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.queue.AbstractReceiverThread;
import spc.webos.queue.AccessTPool;
import spc.webos.queue.QueueMessage;
import spc.webos.thread.ThreadPool;

public class TLQReceiverThread extends AbstractReceiverThread
{
	protected Hashtable props;
	protected TLQManager tlqm;

	public TLQReceiverThread()
	{
		super();
	}

	public TLQReceiverThread(ThreadPool pool, Hashtable props, List bufs, Map buf2queueMapping)
	{
		super();
		this.pool = pool;
		this.props = props;
		this.bufs = bufs;
		this.buf2queueMapping = buf2queueMapping;
	}

	public void release()
	{
		super.release();
		tlqm.disconnect();
	}

	public void init() throws Exception
	{
		super.init();
		if (tlqm == null) tlqm = new TLQManager(props, ((AccessTPool) pool).getCnnHoldTime(), -1);
		refresh();
	}

	public void refresh() throws Exception
	{
		super.refresh();
		tlqm.reconnect(-1);
	}

	public Object receive(String qname) throws Exception
	{
		QueueMessage qmsg = receiveMQMessage(qname);
		if (qmsg == null) return null;
		IMessageConverter converter = ((AccessTPool) getPool()).getConverter();
		if (converter == null) return qmsg;
		IMessage msg = converter.deserialize(qmsg.buf);
		msg.setCorrelationID(qmsg.correlationId);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_QMSG, qmsg); // ���������Ϣ��ԭʼ��Ϣ
		msg.setInLocal(MsgLocalKey.ACCEPTOR_PROTOCOL, Common.ACCEPTOR_PROTOCOL_QUEUE_MQ);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, qmsg.buf);
		if (((AccessTPool) getPool()).getMsgFlow() != null) msg.setInLocal(
				MsgLocalKey.LOCAL_MSG_MSGFLOW, ((AccessTPool) getPool()).getMsgFlow());
		return msg;
	}

	public QueueMessage receiveMQMessage(String qname)
	{
		// MQMessage mqmsg = new MQMessage();
		// QueueMessage qmsg = null;
		// try
		// {
		// mqm.connect(-1);
		// Accessor.receive(mqm, qname, gmo, mqmsg);
		// qmsg = new QueueMessage(mqmsg, qname);
		// if (log.isDebugEnabled())
		// {
		// byte[] header = MessageUtil.getHeader(qmsg.buf);
		// log.debug("read buf size: " + qmsg.buf.length + ", header: "
		// + (header != null ? new String(header) : "null") + "\nbuf in utf-8:"
		// + new String(qmsg.buf, Common.CHARSET_UTF8));
		// }
		// }
		// catch (MQException mqe)
		// {
		// if (Accessor.handleMQException(mqe) == Accessor.MQ_TIME_OUT)
		// {
		// // if (log.isDebugEnabled()) log.debug("qName:" + qname +
		// // " has no msg");
		// }
		// else
		// {
		// log.error("mqe.ret==-1...wait to reconnect..." + qname +
		// ", thread will sleep:"
		// + Accessor.CNN_EXCEPTION_SLEEP + " seconds!!!", mqe);
		// mqm.disconnect();
		// try
		// { // ����Ϣʧ�ܿ����Ƕ��й���������ʧ�ܣ� Ҳ�����Ƕ��й�������û�ж���(���������һ��ֻ�ڿ���ʱ�ڣ�����û���ö�)
		// Thread.sleep(Accessor.CNN_EXCEPTION_SLEEP * 1000);
		// }
		// catch (Exception e)
		// {
		// }
		// }
		// return null;
		// }
		// catch (Exception e)
		// {
		// log.error("read qName:" + qname + " mq message", e);
		// return null;
		// }
		//
		// try
		// {
		// if (((MQAccessTPool) pool).isCorrelation()) qmsg.correlationId =
		// mqmsg.messageId; // ���ù�����
		// else qmsg.correlationId = mqmsg.correlationId; // ���ù�����
		// if (log.isInfoEnabled()) log
		// .info("inQTm:"
		// + new SimpleDateFormat(SystemUtil.DF_SALL17).format(mqmsg.putDateTime
		// .getTime()) + ",corId:\n" + new String(mqmsg.correlationId)
		// + ", t: " + getName());
		// return qmsg;
		// }
		// catch (Exception e)
		// {
		// try
		// {
		// log.error("in utf-8:" + new String(qmsg.buf, Common.CHARSET_UTF8),
		// e);
		// }
		// catch (UnsupportedEncodingException e1)
		// {
		// log.warn("UnsupportedEncodingException for utf-8", e1);
		// }
		// }
		return null;
	}

	public Hashtable getProps()
	{
		return props;
	}

	public void setProps(Hashtable props)
	{
		this.props = props;
	}
}
