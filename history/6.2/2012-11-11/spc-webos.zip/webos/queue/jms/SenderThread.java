package spc.webos.queue.jms;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import spc.webos.data.IMessage;
import spc.webos.queue.AbstractSenderThread;
import spc.webos.queue.QueueMessage;

public class SenderThread extends AbstractSenderThread
{
	protected int retryTimes = 5; // �������ʧ�ܵĳ��Դ���, -1��ʾ������
	protected int retryInterval = 100; // ���Է��͵ļ��, 0 ��ʾ�����
	public static final ThreadLocal EAI_MSG = new ThreadLocal(); // ��ǰ�߳�Ҫ���͵�eaimsg
	JmsTemplate jms;

	public void setJms(JmsTemplate jms)
	{
		this.jms = jms;
	}

	public boolean send(String queueName, QueueMessage qmsg)
	{
		long failTimes = 0;
		EAI_MSG.set(qmsg);
		try
		{
			while (true)
			{
				jms.send(queueName, new MessageCreator()
				{
					public Message createMessage(Session session)
							throws JMSException
					{
						BytesMessage msg = session.createBytesMessage();
						try
						{
							IMessage m = (IMessage) EAI_MSG.get();
							msg.writeBytes(m.write2bytes());
							// ����ˮ����Ϊ������
							msg.setJMSCorrelationID(m.getMsgSn());
						}
						catch (Exception e)
						{
							throw new JMSException("Fail:eaiMsg.toByteArray");
						}
						return msg;
					}
				});
				return true;
			}
		}
		catch (Exception e)
		{
			failTimes++;
			log.error("SenderThread:failTimes=" + failTimes + ",retryTimes="
					+ retryTimes + ",retryInterval=" + retryInterval, e);
			if (retryTimes > 0 && failTimes > retryTimes) return false;
			try
			{
				if (this.retryInterval > 0) Thread.sleep(retryInterval);
			}
			catch (Exception ee)
			{
			}
		}
		finally
		{
			EAI_MSG.set(null); // ��������
		}
		return true;
	}
}
