package spc.webos.queue.ibmmq;

import java.util.ArrayList;
import java.util.List;

import spc.webos.constant.Common;
import spc.webos.log.Log;
import spc.webos.queue.IQueueAccess;
import spc.webos.queue.QueueMessage;
import spc.webos.util.StringX;

import com.ibm.mq.MQC;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;

public class QueueAccess implements IQueueAccess
{
	protected List<MQCnnPool> cnnpools;
	protected Log log = Log.getLogger(getClass());
	protected int retryTimes = 1;
	protected int retryInterval = 0;
	protected boolean sndRandomStart = false;
	protected boolean matchCorId = true; // 2012-05-30, ĳЩ�������ܲ���ʱ��FA����ƥ�佻��

	public QueueAccess()
	{
	}

	public QueueAccess(List<MQCnnPool> cnnpools)
	{
		this.cnnpools = cnnpools;
	}

	public QueueAccess(MQCnnPool cnnpool)
	{
		this.cnnpools = new ArrayList<MQCnnPool>();
		this.cnnpools.add(cnnpool);
	}

	public void destroy()
	{
		if (cnnpools == null) return;
		for (int i = 0; i < cnnpools.size(); i++)
			cnnpools.get(i).destory();
	}

	public void send(String qname, QueueMessage qmsg) throws Exception
	{
		// 2012-05-16 ���ö�ͨ�����͡�
		Accessor.sendCluster(sndRandomStart, cnnpools, qname, new MQPutMessageOptions(),
				qmsg.toMQMessage(new MQMessage()), retryTimes, retryInterval);
		// MQManager mqm = (MQManager) cnnPool.borrow();
		// try
		// {
		// if (log.isInfoEnabled()) log.info("sn:" + qmsg.sn + ", corId:"
		// + (qmsg.correlationId != null ? new String(qmsg.correlationId) :
		// ""));
		// if (log.isDebugEnabled()) log.debug("req:" + new String(qmsg.buf,
		// Common.CHARSET_UTF8));
		// Accessor.send(mqm, qname, new MQPutMessageOptions(),
		// qmsg.toMQMessage(new MQMessage()),
		// 0, 0);
		// }
		// catch (MQException mqex)
		// {
		// log.warn("send", mqex);
		// if (Accessor.handleMQException(mqex) ==
		// Accessor.MQ_CONNECTION_BROKER) mqm.disconnect(); // �����ǰ�쳣�������쳣��ر�����
		// throw new AppException(AppRetCode.PROTOCOL_MQ(), new Object[] {
		// qname,
		// String.valueOf(mqex.reasonCode), String.valueOf(mqex.completionCode)
		// });
		// }
		// finally
		// {
		// cnnPool.release(mqm);
		// }
	}

	// 2012-05-12 ʹ��ͨ���б����н���
	public QueueMessage receive(String qname, byte[] correlationId, int timeout) throws Exception
	{
		MQMessage mqmsg = new MQMessage();
		MQGetMessageOptions gmo = new MQGetMessageOptions();
		gmo.options = MQC.MQGMO_WAIT;
		if (timeout > 0) gmo.waitInterval = timeout * 1000;
		if (matchCorId && correlationId != null)
		{ // matchCorId Ϊ����ĳЩ���ܲ��Գ��ϣ����FAͬ������ 2012-05-30
			gmo.matchOptions = MQC.MQMO_MATCH_CORREL_ID;
			mqmsg.correlationId = correlationId;
		}
		else if (log.isDebugEnabled()) log.debug("unmatch: " + matchCorId);
		Accessor.receive(cnnpools, qname, gmo, mqmsg);
		byte[] buf = new byte[mqmsg.getDataLength()];
		mqmsg.readFully(buf);
		if (log.isDebugEnabled()) log.debug("rep:" + new String(buf, Common.CHARSET_UTF8)
				+ "\nrep.base64:" + StringX.base64(buf));
		return new QueueMessage(buf, mqmsg.correlationId, mqmsg.messageId);
	}

	// public QueueMessage receive(String qname, byte[] correlationId, int
	// timeout) throws Exception
	// {
	// MQManager mqm = (MQManager) cnnPool.borrow();
	// try
	// {
	// MQMessage resMQMsg = new MQMessage();
	// MQGetMessageOptions gmo = new MQGetMessageOptions();
	// gmo.options = MQC.MQGMO_WAIT;
	// if (timeout > 0) gmo.waitInterval = timeout * 1000;
	// if (correlationId != null)
	// {
	// gmo.matchOptions = MQC.MQMO_MATCH_CORREL_ID;
	// resMQMsg.correlationId = correlationId;
	// }
	// Accessor.receive(mqm, qname, gmo, resMQMsg);
	// byte[] buf = new byte[resMQMsg.getDataLength()];
	// resMQMsg.readFully(buf);
	// if (log.isDebugEnabled()) log.debug("res:" + new String(buf));
	// return new QueueMessage(buf, resMQMsg.correlationId, resMQMsg.messageId);
	// }
	// catch (MQException mqex)
	// {
	// log.warn("send", mqex);
	// if (Accessor.handleMQException(mqex) == Accessor.MQ_CONNECTION_BROKER)
	// mqm.disconnect(); // �����ǰ�쳣�������쳣��ر�����
	// throw new AppException(AppRetCode.PROTOCOL_MQ(), new Object[] { qname,
	// String.valueOf(mqex.reasonCode), String.valueOf(mqex.completionCode) });
	// }
	// catch (IOException ioe)
	// {
	// throw new AppException(AppRetCode.NET_COMMON(), ioe);
	// }
	// finally
	// {
	// cnnPool.release(mqm);
	// }
	// }

	// 2012-05-16 ʹ��send, recieve��Ϸ������
	public QueueMessage execute(String reqQName, String repQName, QueueMessage qmsg, int timeout)
			throws Exception
	{
		byte[] corId = qmsg.correlationId; // ����ˮ����Ϊmq��Ϣ������
		if (log.isDebugEnabled()) log.debug("snd corId:"
				+ (qmsg.correlationId == null ? "" : new String(qmsg.correlationId)));
		MQMessage reqMQMsg = new MQMessage();
		reqMQMsg.write(qmsg.buf);
		// ��������˳�ʱʱ�䡣����Ϣ����ȡ��ʱ��Ӧ���г�ʱʱ�䣬MQ����Ϣ��Чʱ��Ϊ100����

		if (log.isDebugEnabled()) log.debug("req:" + new String(qmsg.buf));
		if (corId != null) reqMQMsg.correlationId = corId;
		if (qmsg.expirySeconds > 0) reqMQMsg.expiry = qmsg.expirySeconds * 10; // 2012-11-01 ������Ϣ�ĳ�ʱʱ��
		Accessor.sendCluster(sndRandomStart, cnnpools, reqQName, new MQPutMessageOptions(),
				reqMQMsg, retryTimes, retryInterval); // ������Ϣ

		if (StringX.nullity(repQName))
		{ // added by spc 2011-03-11 ���Ӧ�����Ϊ�գ����ʾ����Ҫ����
			log.info("repQName is null!!!");
			return null;
		}
		return receive(repQName, corId, timeout);
	}

	// public QueueMessage execute(String reqQName, String repQName,
	// QueueMessage qmsg, int timeout)
	// throws Exception
	// {
	// MQManager mqm = (MQManager) cnnPool.borrow();
	// try
	// {
	// byte[] corId = qmsg.correlationId; // ����ˮ����Ϊmq��Ϣ������
	// if (log.isInfoEnabled()) log.info("start to send sn:" + qmsg.sn +
	// ", timeout:"
	// + timeout);
	// MQMessage reqMQMsg = new MQMessage();
	// reqMQMsg.write(qmsg.buf);
	// // ��������˳�ʱʱ�䡣����Ϣ����ȡ��ʱ��Ӧ���г�ʱʱ�䣬MQ����Ϣ��Чʱ��Ϊ100����
	// // if (qmsg.expirySeconds > 0) reqMQMsg.expiry = qmsg.expirySeconds
	// // * 10;
	//
	// if (log.isDebugEnabled()) log.debug("req:" + new String(qmsg.buf));
	// if (corId != null) reqMQMsg.correlationId = corId;
	// long start = 0;
	// Accessor.send(mqm, reqQName, new MQPutMessageOptions(), reqMQMsg,
	// retryTimes,
	// retryInterval); // ������Ϣ
	// if (StringX.nullity(repQName))
	// { // added by spc 2011-03-11 ���Ӧ�����Ϊ�գ����ʾ����Ҫ����
	// log.info("repQName is null!!!");
	// return null;
	// }
	// if (log.isInfoEnabled())
	// {
	// start = System.currentTimeMillis();
	// log.info("success send sn:" + qmsg.sn);
	// }
	//
	// // ���ݹ������ù�������Ϣ
	// MQMessage repMQMsg = new MQMessage();
	// MQGetMessageOptions gmo = new MQGetMessageOptions();
	// gmo.options = MQC.MQGMO_WAIT;
	// gmo.waitInterval = timeout * 1000;
	// gmo.matchOptions = MQC.MQMO_MATCH_CORREL_ID;
	// repMQMsg.correlationId = corId;
	// Accessor.receive(mqm, repQName, gmo, repMQMsg);
	// if (log.isInfoEnabled())
	// {
	// long end = System.currentTimeMillis();
	// log.info("corId:" + new String(corId) + ", cost:" + (end - start) + ","
	// + (end - repMQMsg.putDateTime.getTimeInMillis()));
	// }
	// byte[] buf = new byte[repMQMsg.getDataLength()];
	// repMQMsg.readFully(buf);
	// if (log.isDebugEnabled()) log.debug("rep buf:" + new String(buf));
	// return new QueueMessage(buf, repMQMsg.correlationId, repMQMsg.messageId);
	// }
	// catch (MQException mqex)
	// {
	// log.warn("QueueAccess: reqQName:" + reqQName + ", repQName:" + repQName,
	// mqex);
	// if (Accessor.handleMQException(mqex) == Accessor.MQ_CONNECTION_BROKER)
	// mqm.disconnect(); // �����ǰ�쳣�������쳣��ر�����
	// throw new AppException(AppRetCode.PROTOCOL_MQ(), new Object[] { repQName,
	// String.valueOf(mqex.reasonCode), String.valueOf(mqex.completionCode) });
	// }
	// catch (Throwable t)
	// {
	// throw new AppException(AppRetCode.NET_COMMON(), t);
	// }
	// finally
	// {
	// cnnPool.release(mqm);
	// }
	// }

	/**
	 * ���ĳ�����У�����������������Ϣ��һЩ�Զ����ƣ����糬ʱת���ȵ�
	 * 
	 * @param qname
	 * @param gmo
	 * @throws Exception
	 */
	// public void browse(String qname, MQGetMessageOptions gmo) throws
	// Exception
	// {
	// MQManager mqm = (MQManager) cnnPool.borrow();
	// MQQueue queue = null;
	// try
	// {
	// queue = mqm.accessQueue(qname, MQC.MQOO_BROWSE);
	// queue.get(new MQMessage(), gmo);
	// }
	// finally
	// {
	// cnnPool.release(mqm);
	// mqm.closeQueue();
	// }
	// }

	public void setCnnPool(MQCnnPool cnnPool)
	{
		this.cnnpools = new ArrayList<MQCnnPool>();
		this.cnnpools.add(cnnPool);
	}

	public void setCnnpools(List<MQCnnPool> cnnpools)
	{
		this.cnnpools = cnnpools;
	}

	public int getRetryTimes()
	{
		return retryTimes;
	}

	public void setRetryTimes(int retryTimes)
	{
		this.retryTimes = retryTimes;
	}

	public int getRetryInterval()
	{
		return retryInterval;
	}

	public void setRetryInterval(int retryInterval)
	{
		this.retryInterval = retryInterval;
	}

	public MQCnnPool getFirstMQCnnPool()
	{
		return cnnpools.get(0);
	}

	public void setMatchCorId(boolean matchCorId)
	{
		this.matchCorId = matchCorId;
	}

	public boolean isSndRandomStart()
	{
		return sndRandomStart;
	}

	public void setSndRandomStart(boolean sndRandomStart)
	{
		this.sndRandomStart = sndRandomStart;
	}
}
