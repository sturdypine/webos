package spc.webos.resallocate.fnode;

import spc.webos.data.CompositeNode;
import spc.webos.data.IMessage;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.resallocate.service.IResourcePoolService;

public class CheckAFNode extends AbstractFNode
{
	protected IResourcePoolService resourcePoolService;

	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		msg.setResponse(new CompositeNode(resourcePoolService.checkStatus(msg.getRequest()
				.mapValue())));
		return null;
	}

	public void setResourcePoolService(IResourcePoolService resourcePoolService)
	{
		this.resourcePoolService = resourcePoolService;
	}
}
