package spc.webos.flownode.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.jbpm.graph.def.ActionHandler;
import org.jbpm.graph.def.Node;
import org.jbpm.graph.exe.ExecutionContext;

import spc.webos.constant.BPLVariables;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.flownode.IFlowContext;
import spc.webos.flownode.IFlowNode;
import spc.webos.log.Log;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

public abstract class AbstractAction implements ActionHandler
{
	private static final long serialVersionUID = 1L;
	protected String name;
	protected String ext;
	protected String exProcessName; // �쳣����������
	protected String exHandlerMode; // �쳣����ģʽ: null,0��ʾ�쳣�׳�,
	// protected String exTargetBean;
	protected String exFnode; // added by spc 2011-03-24 ȡ��exTargetBean
	// 1��ʾ�쳣���׳�����Ӱ��BPL���̵ļ���ִ��
	public final static String EX_HANDLER_MODE_THROW = "0";
	public final static String EX_HANDLER_MODE_CATCH = "1";
	protected transient Log log = Log.getLogger(getClass());
	protected transient static ThreadLocal CUR_MSG = new ThreadLocal();

	public void execute(ExecutionContext ecxt) throws Exception
	{
		Node curnode = ecxt.getToken().getNode();
		if (curnode != null && StringX.nullity(name)) name = curnode.getName();
		if (log.isDebugEnabled()) log.debug("start action: " + name);
		IFlowContext cxt = (IFlowContext) ecxt.getContextInstance().getTransientVariable(
				IFlowContext.JBPM_FLOW_CXT_KEY);
		IMessage msg = (IMessage) ecxt.getContextInstance().getTransientVariable(
				IFlowContext.JBPM_MSG_KEY);
		CUR_MSG.set(msg);
		if (!StringX.nullity(getExFnode())) addExHandler(msg, getExFnode());
		try
		{
			execute(msg, cxt);
			if (!StringX.nullity(getExFnode())) removeExHandler(msg);
		}
		catch (Exception ex)
		{
			msg.setEx(ex);
			if (log.isDebugEnabled()) log.debug("ex in action:" + name + ", exProcessName:"
					+ exProcessName + ", exFnode:" + exFnode + ", exHandlerMode:" + exHandlerMode
					+ ", handler chain: " + getExHandlers(msg), ex);
			if (!StringX.nullity(exProcessName)) msg.setInLocal(
					MsgLocalKey.LOCAL_JBPM_PROCESS_NAME, exProcessName);
			if ((!StringX.nullity(getExFnode())) && EX_HANDLER_MODE_CATCH.equals(exHandlerMode))
			{ // �쳣�ػ���
				IFlowNode fnode = getFlowNode(getExFnode());
				if (fnode == null) log.warn("cannot find ex fnode by: " + getExFnode());
				fnode.execute(msg, cxt);
			}
			else throw ex;
		}
		finally
		{
			CUR_MSG.set(null);
		}
	}

	protected IFlowNode getFlowNode(String name)
	{
		IFlowNode fnode = (IFlowNode) IFlowNode.FLOW_NODES_PROXY.get(name);
		if (fnode != null) return fnode;
		fnode = (IFlowNode) SystemUtil.getInstance().getBean(name, IFlowNode.class);
		return fnode;
	}

	// ���ӵ�ǰ�쳣�����ڵ㵽�쳣��������
	protected static void addExHandler(IMessage msg, String exFnode)
	{
		if (StringX.nullity(exFnode)) return;
		Map variables = (Map) msg.getInLocal(MsgLocalKey.LOCAL_BPL_VARIABLES);
		List handlers = (List) variables.get(BPLVariables.EX_HANDLERS);
		if (handlers == null)
		{
			handlers = new ArrayList();
			variables.put(BPLVariables.EX_HANDLERS, handlers);
		}
		handlers.add(exFnode);
	}

	protected static List getExHandlers(IMessage msg)
	{
		Map variables = (Map) msg.getInLocal(MsgLocalKey.LOCAL_BPL_VARIABLES);
		return (List) variables.get(BPLVariables.EX_HANDLERS);
	}

	// ɾ���쳣�б��ж��㴦���ڵ�
	protected static void removeExHandler(IMessage msg)
	{
		Map variables = (Map) msg.getInLocal(MsgLocalKey.LOCAL_BPL_VARIABLES);
		List handlers = (List) variables.get(BPLVariables.EX_HANDLERS);
		if (handlers != null) handlers.remove(handlers.size() - 1);
	}

	public static void setInMsgLocal(String key, Object value)
	{
		current().setInLocal(key, value);
	}

	public static void removeMsgLocal(String key)
	{
		current().getLocal().remove(key);
	}

	public static void setVariable(String key, Object value)
	{
		Map variables = (Map) (current().getInLocal(MsgLocalKey.LOCAL_BPL_VARIABLES));
		if (variables != null) variables.put(key, value);
	}

	public static void removeVariable(String key)
	{
		Map variables = (Map) current().getInLocal(MsgLocalKey.LOCAL_BPL_VARIABLES);
		if (variables != null) variables.remove(key);
	}

	public static void setInMsg(String path, Object value)
	{
		current().getTransaction().set(path, value);
	}

	public static void removeFromMsg(String path)
	{
		current().getTransaction().remove(path);
	}

	public static void removeFromMsg(List paths)
	{
		if (paths == null) return;
		for (int i = 0; i < paths.size(); i++)
			removeFromMsg(paths.get(i).toString());
	}

	public static IMessage current()
	{
		return (IMessage) CUR_MSG.get();
	}

	abstract void execute(IMessage msg, IFlowContext cxt) throws Exception;

	public void init() throws Exception
	{
	}

	public String getName()
	{
		return name;
	}

	public String getExt()
	{
		return ext;
	}

	public void setExt(String ext)
	{
		this.ext = ext;
	}

	public void setName(String name)
	{
		this.name = StringX.trim(name);
	}

	public String getExHandlerMode()
	{
		return exHandlerMode;
	}

	public void setExHandlerMode(String exHandlerMode)
	{
		this.exHandlerMode = StringX.trim(exHandlerMode);
	}

	public String getExProcessName()
	{
		return exProcessName;
	}

	public void setExProcessName(String exProcessName)
	{
		this.exProcessName = exProcessName;
	}

	// public String getExTargetBean()
	// {
	// return exTargetBean;
	// }
	//
	// public void setExTargetBean(String exTargetBean)
	// {
	// this.exTargetBean = exTargetBean;
	// }

	public String getExFnode()
	{
		return exFnode;
		// return (!StringX.nullity(exFnode)) ? exFnode : exTargetBean;
	}

	public void setExFnode(String exFnode)
	{
		this.exFnode = exFnode;
	}
}
