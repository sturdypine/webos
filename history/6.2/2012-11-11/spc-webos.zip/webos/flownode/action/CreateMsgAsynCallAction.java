package spc.webos.flownode.action;

import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.Status;
import spc.webos.flownode.IFlowContext;
import spc.webos.model.BPELNodeVO;
import spc.webos.util.SystemUtil;

public class CreateMsgAsynCallAction extends CreateMsgCallAction
{
	private static final long serialVersionUID = 1L;

	public void execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		IMessage nsubmsg = createSubRequestMsg(msg, cxt);
		msg.setInLocal(MsgLocalKey.LOCAL_NSUB_MSG, nsubmsg); // 2012-05-12�����´������ӱ���
		before(msg, nsubmsg, cxt);
		executeTargetFNode(nsubmsg, cxt);
	}

	protected void before(IMessage parent, IMessage submsg, IFlowContext cxt) throws Exception
	{
		BPELNodeVO nodeVO = new BPELNodeVO();
		submsg.getMsg().toObject(nodeVO);
		nodeVO.setNode(name);
		nodeVO.setMsgSn(submsg.getMsgSn());
		nodeVO.setRefMsgSn(parent.getMsgSn());
		nodeVO.setFailAbort(failAbort);
		nodeVO.setStatus(Status.STATUS_UNDERWAY);
		nodeVO.setTmStamp(SystemUtil.getInstance().getCurrentDate(SystemUtil.DF_SALL17));

		parent.setInLocal(MsgLocalKey.LOCAL_LAST_NODE, nodeVO);
		// Persistence.getInstance().insert(nodeVO);
		// Ϊ�˼���jbpm3Asyn2�����ݿ�ģʽ��������Ϣ��jbpm3Asyn����ʱ���
	}

	public CreateMsgAsynCallAction()
	{
		fnodes = "asynESBCall";
	}
}
