package spc.webos.flownode.impl;

import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.flownode.util.AsynESBCallDelayTask;

/**
 * �첽ִ�нڵ�, for JBPM3AsynCFNode �ڵ�����ͼʹ��
 * 
 * @author spc
 * 
 */
public class AsynESBCallAFNode extends AbstractFNode
{
	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		if (log.isDebugEnabled()) log.debug("current msg is: " + msg.toXml(true));
		IMessage parent = (IMessage) msg.getInLocal(MsgLocalKey.LOCAL_PARENT_MSG);
		if (parent != null)
		{
			if (log.isDebugEnabled()) log.debug("parent msg is: " + parent.toXml(true));
		}
		else
		{
			log.info("parent msg is null!!!");
			parent = msg;
		}

		// ��call ESB�������뵱ǰ��Ϣ����ʱ���������б���
		String qname = (mqPutAFNode == null ? this.qname : mqPutAFNode.getQname());
		if (log.isInfoEnabled()) log.info("add AsynESBCallDelayTask to parent: qname: " + qname);
		AsynESBCallDelayTask delayTask = new AsynESBCallDelayTask(msg, cxt, qname, mqPutAFNode);
		parent.addDelayTask(delayTask); // ���ܵ�ǰ�����ǵ�һ�α�bpl��������ô��ǰ�̻߳�����msg����Ϊ������
		return null;
	}

	protected MQPutAFNode mqPutAFNode;
	protected String qname;

	public void setMqPutAFNode(MQPutAFNode mqPutAFNode)
	{
		this.mqPutAFNode = mqPutAFNode;
	}

	public String getQname()
	{
		return qname;
	}

	public void setQname(String qname)
	{
		this.qname = qname;
	}
}
