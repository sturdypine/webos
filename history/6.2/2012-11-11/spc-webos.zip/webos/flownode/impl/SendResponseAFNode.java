package spc.webos.flownode.impl;

import spc.webos.acceptor.SocketMessage;
import spc.webos.buffer.IBuffer;
import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.data.converter.XMLConverter2;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.queue.QueueMessage;
import spc.webos.util.StringX;

/**
 * ���ݽ���Э��ѡ����Ӧ��ʽ. Ŀǰ֧��TCP/IP QUEUE
 * 
 * @author spc
 * 
 */
public class SendResponseAFNode extends AbstractFNode
{
	protected IMessageConverter converter = XMLConverter2.getInstance();

	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		if (!isSend(msg)) return null;
		send(msg);
		return null;
	}

	protected void send(IMessage msg) throws Exception
	{
		snd2buf(msg);
	}

	/**
	 * ���͵�ǰ������Ϣ
	 * 
	 * @param msg
	 * @throws Exception
	 */
	protected void snd2buf(IMessage msg) throws Exception
	{
		IBuffer repbuf = (IBuffer) msg.getLocal().get(MsgLocalKey.LOCAL_REP_BUFFER); // ��ǰ�����Ƿ�ָ����Ӧ��buffer
		if (repbuf == null && msg.getLocal().containsKey(MsgLocalKey.LOCAL_REP_BUFFER_NAME)) repbuf = (IBuffer) IBuffer.BUFFERS
				.get((String) msg.getLocal().get(MsgLocalKey.LOCAL_REP_BUFFER_NAME));
		if (repbuf == null)
		{
			log.info("current assigned rep buf is null!!!");
			return;
		}
		Object sndObj = msg2sndobj(msg);
		if (sndObj != null)
		{
			repbuf.put(sndObj);
			msg.setInLocal(MsgLocalKey.SND_BUF, Boolean.TRUE);
			if (log.isInfoEnabled()) log.info("send msg to buf: " + repbuf.getName()
					+ ", buf.size:" + repbuf.size());
		}
	}

	protected Object msg2sndobj(IMessage msg) throws Exception
	{
		IMessageConverter converter = getMsgConverter(msg);
		Object sndObj = null;
		if (((String) msg.getInLocal(MsgLocalKey.ACCEPTOR_PROTOCOL))
				.startsWith(Common.ACCEPTOR_PROTOCOL_TCPIP))
		{ // tcp���뷽ʽ
			SocketMessage smsg = (SocketMessage) msg
					.getInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_SOCKETMSG);
			smsg.repmsg = converter.serialize(msg);
			sndObj = smsg;
		}
		else if (((String) msg.getInLocal(MsgLocalKey.ACCEPTOR_PROTOCOL))
				.startsWith(Common.ACCEPTOR_PROTOCOL_QUEUE))
		{ // queue���뷽ʽ
			sndObj = new QueueMessage(msg, converter.serialize(msg), msg.getMsgSn(), msg
					.getCorrelationID(), null);
		}
		return sndObj;
	}

	protected IMessageConverter getMsgConverter(IMessage msg)
	{
		IMessageConverter msgConverter = (IMessageConverter) msg
				.getInLocal(MsgLocalKey.LOCAL_MSG_CONVERTER);
		return msgConverter == null ? converter : msgConverter;
	}

	/**
	 * �жϵ�ǰ�����Ƿ���ҪӦ��
	 * 
	 * @param msg
	 * @return
	 */
	protected boolean isSend(IMessage msg)
	{
		if (msg.getLocal().containsKey(MsgLocalKey.NO_RETURN))
		{
			log.info("no return flag has been set!!!");
			return false;
		}
		if (msg.getLocal().containsKey(MsgLocalKey.LOCAL_ACCESS4LOCAL))
		{
			log.info("LOCAL_ACCESS4LOCAL flag has been set!!!");
			return false;
		}
//		String refMsgCd = msg.getRefMsgCd(); // ʹ�òο����ģ���Ϊԭ�����Ѿ�����ResponseAFNode����ˡ�
//		if (!refMsgCd.endsWith(Common.ESB_REQMSG_END))
//		{
//			log.info("It is a response msg");
//			return false;
//		}
		if (msg.getAttr() != null && !StringX.nullity(msg.getAttr().toAttr())
				&& msg.getAttr().getResMsgNum() <= 0) // modified by chenjs,
		// 2010-10-12
		// ��ֹ����attrΪ��ָ��
		{
			log.info("msg's attr(" + msg.getAttr().toAttr() + ")is without return");
			return false;
		}
		return true;
	}

	public void setConverter(IMessageConverter converter)
	{
		this.converter = converter;
	}
}
