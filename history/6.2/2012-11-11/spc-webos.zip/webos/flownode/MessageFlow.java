package spc.webos.flownode;

import java.util.HashMap;
import java.util.Map;

import spc.webos.data.IMessage;
import spc.webos.log.IDynamicLog;
import spc.webos.log.Log;
import spc.webos.service.IStatus;
import spc.webos.util.SystemUtil;

public class MessageFlow implements IStatus
{
	protected IFlowNode entryFNode;
	protected IFlowNode exFNode;
	protected IFlowNode finalFNode;
	protected IFlowContext cxt;
	protected String name;
	protected String logName; // �����Ҫ�߳���־�����ṩ��־��
	protected IDynamicLog dynamicLog;
	protected String logScript;
	protected static Log log = Log.getLogger(MessageFlow.class);
	public final static Map MESSAGE_FLOW = new HashMap();

	public MessageFlow()
	{
	}

	public MessageFlow(String name, IFlowNode entryFNode, IFlowContext cxt, IFlowNode exFNode,
			IFlowNode finalFNode)
	{
		this.name = name;
		this.entryFNode = entryFNode;
		this.cxt = cxt;
		this.exFNode = exFNode;
		this.finalFNode = finalFNode;
	}

	public Object execute(IMessage msg) throws Throwable
	{
		boolean startlog = Log.startWithRequired(logName);
		if (dynamicLog != null) Log.change(dynamicLog.logName(logName, msg));
		if (Log.CUR_EXT.get() == null)
		{
			Map logExtMap = SystemUtil.freemarker(null, msg);
			logExtMap.put("sn", msg.getMsgSn());
			Log.setLogExt(logExtMap);
		}
		if (log.isDebugEnabled()) log.debug("mf: " + name + ", sn: " + msg.getMsgSn() + ", msgCd: "
				+ msg.getMsgCd());
		if (log.isDebugEnabled()) log.debug("in msg: " + msg.toXml(true));
		if (exFNode != null) msg.setContainExFnode(true);
		try
		{
			return entryFNode.execute(msg, cxt);
		}
		catch (Throwable e)
		{
			if (exFNode != null)
			{
				try
				{
					log.debug("start to message flow exception fnode...");
					msg.setEx(e);
					exFNode.execute(msg, cxt);
				}
				catch (Throwable ee)
				{
					log.error("Ex in exfnode in MessageFlow(" + getName() + ")", ee);
				}
			}
			else throw e;
		}
		finally
		{
			try
			{
				if (finalFNode != null)
				{
					log.debug("start to message flow final fnode...");
					finalFNode.execute(msg, cxt);
				}
			}
			catch (Throwable t)
			{
				log.error("Ex in finalFNode in MessageFlow(" + getName() + ")", t);
			}
			if (log.isDebugEnabled()) log.debug("out msg: " + msg.toXml(true));
			if (startlog) Log.print();
		}
		return null;
	}

	public void setEntryFNode(IFlowNode entryFNode)
	{
		this.entryFNode = entryFNode;
	}

	public void setExFNode(IFlowNode exFNode)
	{
		this.exFNode = exFNode;
	}

	public void setFinalFNode(IFlowNode finalFNode)
	{
		this.finalFNode = finalFNode;
	}

	public void setCxt(IFlowContext cxt)
	{
		this.cxt = cxt;
	}

	public boolean changeStatus(Map param)
	{
		return false;
	}

	public Map checkStatus(Map param)
	{
		return null;
	}

	public String getName()
	{
		return name;
	}

	public void refresh() throws Exception
	{
	}

	public void setLogName(String logName)
	{
		this.logName = logName;
	}

	public IFlowNode getEntryFNode()
	{
		return entryFNode;
	}

	public IFlowNode getExFNode()
	{
		return exFNode;
	}

	public IFlowNode getFinalFNode()
	{
		return finalFNode;
	}

	public String getLogName()
	{
		return logName;
	}

	public IDynamicLog getDynamicLog()
	{
		return dynamicLog;
	}

	public void init() throws Exception
	{
		if (name != null) MESSAGE_FLOW.put(name, this);
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getLogScript()
	{
		return logScript;
	}

	public void setLogScript(String logScript)
	{
		this.logScript = logScript;
	}

	public void setDynamicLog(IDynamicLog dynamicLog)
	{
		this.dynamicLog = dynamicLog;
	}
}
