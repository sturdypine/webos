package spc.webos.exception;

import java.util.HashMap;
import java.util.Map;

import spc.webos.data.Status;
import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;

public class AppException extends RuntimeException
{
	public AppException(Status status)
	{
		this.code = status.getRetCd(); // chenjs 2012-09-09 ���ӷ�������Ϣ
		this.status = status;
	}

	public AppException(String code, Throwable t)
	{
		this(code, t, null, null, null);
	}

	public AppException(String code, Throwable t, Object[] args)
	{
		this(code, t, args, null, null);
	}

	public AppException(String code, Throwable t, Object[] args, Object detail)
	{
		this(code, t, args, detail, null);
	}

	public AppException(String code, Throwable t, Object[] args, Object detail, String msgFormat)
	{
		super(t);
		this.code = code;
		this.args = args;
		this.detail = detail;
		this.msgFormat = msgFormat;
	}

	public AppException(String code)
	{
		this(code, (Object[]) null);
	}

	public AppException(String code, String defErrMsg)
	{
		this.code = code;
		this.defErrMsg = defErrMsg;
	}

	public AppException(String code, Object[] args)
	{
		this(code, args, null, null);
	}

	public AppException(String code, Object[] args, Object detail)
	{
		this(code, args, detail, null);
	}

	public AppException(String code, Object[] args, Object detail, String msgFormat)
	{
		super(code);
		this.code = code;
		this.args = args;
		this.detail = detail;
		this.msgFormat = msgFormat;
	}

	public boolean isSysLevel()
	{
		return code.startsWith("1") || code.startsWith("9");
	}

	public Object getDetail()
	{
		return detail;
	}

	public void setDetail(Object detail)
	{
		this.detail = detail;
	}

	public StringBuffer toJson()
	{
		Map params = new HashMap();
		params.put("code", code);
		if (getCause() != null) params.put("exception", getCause().toString());
		if (args != null && args.length > 0) params.put("args", args);
		// if (detail != null && !(detail instanceof IMessage)) params
		// .put("detail", detail.toString());
		if (!StringX.nullity(defErrMsg)) params.put("defErrMsg", defErrMsg);
		if (!StringX.nullity(msgFormat)) params.put("msgFormat", msgFormat);
		if (status != null) params.put("status", status);
		StringBuffer buf = new StringBuffer();
		buf.append(JsonUtil.obj2json(params));
		return buf;
	}

	public String toString()
	{
		return "Exception: code:" + code + ", defErrMsg:" + defErrMsg;
	}

	protected Status status;
	protected String code; // ��Ϣ����, ϵͳͳһ����һ���쳣����ľ�̬�࣬Ȼ������һ�������Ӧ����Ϣ��Ϣ�������ļ�
	// String location; // �����쳣��λ��, һ���Ǵ���λ��

	// String defMsg; // ͨ����Ӧ����Ϣ�����Ҳ�����Ϣ��Ϣ���Ĭ��ֵ
	protected Object[] args; // ��Ϣ������������Ϣ��Ҫʹ��MessageFormat
	protected String defErrMsg; // Ĭ�ϵĴ�����Ϣ
	protected String msgFormat; // �������쳣�׳��ط���ʾ�ṩmsgFormat
	protected Object detail; // ��ҪΪjsrmi׼��. ���Դ�һ��������󵽿ͻ���

	static final long serialVersionUID = 0;

	public Object[] getArgs()
	{
		return args;
	}

	public void setArgs(Object[] args)
	{
		this.args = args;
	}

	public String getCode()
	{
		return code;
	}

	public void setCode(String code)
	{
		this.code = code;
	}

	public String getLocation()
	{
		return getLocation(getStackTrace());
	}

	public static String getLocation(StackTraceElement[] stack)
	{
		return stack[0].getClassName() + '.' + stack[0].getMethodName() + ':'
				+ stack[0].getLineNumber();
	}

	public Status getStatus()
	{
		return status;
	}

	public void setStatus(Status status)
	{
		this.status = status;
	}

	public String getMsgFormat()
	{
		return msgFormat;
	}

	public void setMsgFormat(String msgFormat)
	{
		this.msgFormat = msgFormat;
	}

	public String getDefErrMsg()
	{
		return defErrMsg;
	}

	public void setDefErrMsg(String defErrMsg)
	{
		this.defErrMsg = defErrMsg;
	}
}
