package spc.webos.constant;

import spc.webos.data.AtomNode;
import spc.webos.data.CompositeNode;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.util.StringX;

public class Common
{
	// ��ǰ�汾��Ϣ
	public static final String VERSION = "6.2.5";
	public static final String VERSION_DATE = "20121010";

	// ���Ľ��뷽ʽ
	public static final String ACCEPTOR_PROTOCOL_HTTP = "HTTP";
	public static final String ACCEPTOR_PROTOCOL_UDP = "UDP";
	public static final String ACCEPTOR_PROTOCOL_TCPIP = "TCPIP";
	public static final String ACCEPTOR_PROTOCOL_TCPIP_SYN = "TCPIP-SYN"; // tcpipͬ������
	public static final String ACCEPTOR_PROTOCOL_TCPIP_ASYN = "TCPIP-ASYN"; // tcpip�첽����
	public static final String ACCEPTOR_PROTOCOL_TCPIP_XSOCKET = "TCPIP-XSOCKET"; // tcpip����xsocket��Ϊnio���
	public static final String ACCEPTOR_PROTOCOL_QUEUE = "QUEUE";
	public static final String ACCEPTOR_PROTOCOL_QUEUE_MQ = "QUEUE-MQ"; // mq����
	public static final String ACCEPTOR_PROTOCOL_QUEUE_TLQ = "QUEUE-TLQ"; // tlq����
	public static final String ACCEPTOR_PROTOCOL_QUEUE_JMS = "QUEUE-JMS"; // jms����

	public static final int MQ_EXPIRY_UNIT = 10; // MQ��Ϣ��ʱʱ��ĵ�λ,
	// MQ��Ϣ�ĳ�ʱ������λʱ��Ϊ100����
	public static final String WEBAPP_ROOT_PATH_KEY = "webapp.root";
	public static final String WEBAPP_ROOT_KEY = "webAppRootKey";

	public static final String YES = "1";
	public static final String NO = "0";

	public static final String APP_CD_ESB = "ESB";
	public static final String APP_CD_BPL = "BPL";
	// 2011-09-23 chenjs δ�����ڴ��뼶ȡ�����ı�����һλ�Ƿ�Ϊ0����
	public static final String ESB_REQMSG_END = "0";

	public static final String TEMPLATE_TYPE_FTL = "ftl";
	public static final String TEMPLATE_TYPE_JSP = "jsp";

	// model�й̶��ļ�ֵ��Ϣ
	public static final String MODEL_PERSISTENCE_KEY = "persistence";
	public static final String MODEL_ROOT_KEY = "_root";
	public static final String MODEL_STATICS_KEY = "_statics";
	public static final String MODEL_ENUMS_KEY = "_enums";
	public static final String MODEL_SUI_KEY = "SUI";
	public static final String MODEL_REQUEST_KEY = "req";
	public static final String MODEL_APP_PATH_KEY = "appPath";
	public static final String MODEL_HTTP_CONTENT_TYPE = "_contentType";
	public static final String MODEL_APP_CFG_KEY = "_cfg";
	public static final String MODEL_WEB_UTIL_KEY = "_webutil";
	public static final String MODEL_SYS_UTIL_KEY = "_sysutil";
//	public static final String MODEL_REPORT_UTIL_OLD_KEY = "rptutil";
	public static final String MODEL_REPORT_UTIL_KEY = "_rptutil";
	public static final String MODEL_FILE_UTIL_KEY = "_fileutil";
	public static final String MODEL_JSON_UTIL_KEY = "_jsonutil";
	public static final String MODEL_CXT_KEY = "_ctx";
	public static final String MODEL_DICT_KEY = "_dict";
	public static final String MODEL_STRINGX_KEY = "_stringx";
	public static final String MODEL_EXCEPTION = "exception";
	public static final String MODEL_SERVICE_KEY = "services";
	public static final String MODEL_APPMS = "_appms";
	public static final String MODEL_CALENDAR = "_calendar";
	public static final String MODEL_MSG = "msg";
	public static final String MODEL_PARENT_MSG = "pmsg";
	public static final String MODEL_MSG_PREQUEST = "prequest";
	public static final String MODEL_MSG_PRESPONSE = "presponse";
	public static final String MODEL_XML = "xml";
	public static final String MODEL_MSG_OBJ = "MSG";
	public static final String MODEL_MSG_SN = "msgSn";
	public static final String MODEL_MSG_REQUEST = "request";
	public static final String MODEL_MSG_RESPONSE = "response";
	public static final String MODEL_MSG_CD = "msgCd";
	public static final String MODEL_MSG_LOCAL = "msgLocal";
	public static final String MODEL_MSG_LOCAL_BPL_VARS = "msgBplVars";
	public static final String MODEL_MSG_ATTR = "msgAttr";

	public final static String REQ_HEADER_KEY_1 = "Content-Disposition";

	public final static String CHARSET_UTF8 = "UTF-8";
	public final static String CHARSET_GBK = "GBK";
	public final static String CHARSET_ISO = "ISO8859_1";

	public final static String SPRING_MACRO_REQ_CXT_KEY = "springMacroRequestContext";

	// response��ʽ
	public final static String OCTET_CONTENTTYPE = "application/octet-stream";
	public final static String FILE_ZIP_CONTENTTYPE = "application/x-zip-compressed";
	public final static String FILE_WORD_CONTENTTYPE = "application/msword";
	public final static String FILE_EXCEL_CONTENTTYPE = "application/vnd.ms-excel";
	public final static String FILE_POWERPOINT_CONTENTTYPE = "application/ms-powerpoint";
	public final static String FILE_PDF_CONTENTTYPE = "application/pdf";
	public final static String FILE_HTML_CONTENTTYPE = "text/html";
	public final static String FILE_TEXT_CONTENTTYPE = "text/plain";
	public final static String FILE_XML_CONTENTTYPE = "text/xml";
	public static final String OBJECT_TYPE_EXCEL = "xls";
	public static final String OBJECT_TYPE_EXCELXML = "xlsx";
	public static final String OBJECT_TYPE_POWERPOINT = "ppt";
	public static final String OBJECT_TYPE_POWERPOINTXML = "pptx";
	public static final String OBJECT_TYPE_WORD = "doc";
	public static final String OBJECT_TYPE_WORDXML = "docx";
	public static final String OBJECT_TYPE_PDF = "pdf";
	public static final String OBJECT_TYPE_HTM = "htm";
	public static final String OBJECT_TYPE_HTML = "html";
	public static final String OBJECT_TYPE_TEXT = "txt";
	public static final String OBJECT_TYPE_ASP = "asp";
	public static final String OBJECT_TYPE_PHP = "php";
	public static final String OBJECT_TYPE_JSP = "jsp";
	public static final String OBJECT_TYPE_JAVA = "java";
	public static final String OBJECT_TYPE_XML = "xml";

	public static ICompositeNode EMPTYHDRMSG; // ������־ʱ����ͷ

	static
	{
		EMPTYHDRMSG = new CompositeNode();
		EMPTYHDRMSG.set(IMessage.TAG_HEADER_LANGUAGE, new AtomNode(StringX.EMPTY_STRING));
		EMPTYHDRMSG.set(IMessage.TAG_HEADER_CALLTYPE, new AtomNode(StringX.EMPTY_STRING));
		EMPTYHDRMSG.set(IMessage.TAG_HEADER_MSG_CD, new AtomNode(StringX.EMPTY_STRING));
		EMPTYHDRMSG.set(IMessage.TAG_HEADER_MSG_SN, new AtomNode(StringX.EMPTY_STRING));
		EMPTYHDRMSG.set(IMessage.TAG_HEADER_MSG_RCVAPPSN, new AtomNode(StringX.EMPTY_STRING));
		EMPTYHDRMSG.set(IMessage.TAG_HEADER_MSG_SNDNODE, new AtomNode(StringX.EMPTY_STRING));
		EMPTYHDRMSG.set(IMessage.TAG_HEADER_MSG_SNDAPP, new AtomNode(StringX.EMPTY_STRING));
		EMPTYHDRMSG.set(IMessage.TAG_HEADER_MSG_RCVNODE, new AtomNode(StringX.EMPTY_STRING));
		EMPTYHDRMSG.set(IMessage.TAG_HEADER_MSG_RCVAPP, new AtomNode(StringX.EMPTY_STRING));
		EMPTYHDRMSG.set(IMessage.TAG_HEADER_MSG_REFMSGCD, new AtomNode(StringX.EMPTY_STRING));
		EMPTYHDRMSG.set(IMessage.TAG_HEADER_MSG_REFCALLTYP, new AtomNode(StringX.EMPTY_STRING));
		EMPTYHDRMSG.set(IMessage.TAG_HEADER_MSG_REFSNDNODE, new AtomNode(StringX.EMPTY_STRING));
		EMPTYHDRMSG.set(IMessage.TAG_HEADER_MSG_REFSNDAPP, new AtomNode(StringX.EMPTY_STRING));
		EMPTYHDRMSG.set(IMessage.TAG_HEADER_MSG_REFSNDDT, new AtomNode(StringX.EMPTY_STRING));
		EMPTYHDRMSG.set(IMessage.TAG_HEADER_MSG_REFSNDSN, new AtomNode(StringX.EMPTY_STRING));
	}

	public static final String VERSION()
	{
		return VERSION;
	}

	public static final String VERSION_DATE()
	{
		return VERSION_DATE;
	}

	public final static String getContentType(String suffix)
	{
		int index = suffix.lastIndexOf('.');
		if (index >= 0) suffix = suffix.substring(index + 1);
		if (suffix.equalsIgnoreCase(Common.OBJECT_TYPE_HTM)
				|| suffix.equalsIgnoreCase(Common.OBJECT_TYPE_HTML)) return FILE_HTML_CONTENTTYPE;
		if (suffix.equalsIgnoreCase(Common.OBJECT_TYPE_WORD)
				|| suffix.equalsIgnoreCase(Common.OBJECT_TYPE_WORDXML)) return Common.FILE_WORD_CONTENTTYPE;
		if (suffix.equalsIgnoreCase(Common.OBJECT_TYPE_EXCEL)
				|| suffix.equalsIgnoreCase(Common.OBJECT_TYPE_EXCELXML)) return Common.FILE_EXCEL_CONTENTTYPE;
		if (suffix.equalsIgnoreCase(Common.OBJECT_TYPE_POWERPOINT)
				|| suffix.equalsIgnoreCase(Common.OBJECT_TYPE_POWERPOINTXML)) return Common.FILE_POWERPOINT_CONTENTTYPE;
		if (suffix.equalsIgnoreCase(Common.OBJECT_TYPE_PDF)) return Common.FILE_PDF_CONTENTTYPE;
		if (suffix.equalsIgnoreCase(Common.OBJECT_TYPE_XML)) return FILE_XML_CONTENTTYPE;
		if (suffix.equalsIgnoreCase(Common.OBJECT_TYPE_TEXT)
				|| suffix.equalsIgnoreCase(Common.OBJECT_TYPE_JAVA)
				|| suffix.equalsIgnoreCase(Common.OBJECT_TYPE_JSP)
				|| suffix.equalsIgnoreCase(Common.OBJECT_TYPE_ASP)
				|| suffix.equalsIgnoreCase(Common.OBJECT_TYPE_PHP)) return FILE_TEXT_CONTENTTYPE;

		return Common.OCTET_CONTENTTYPE;
	}

	public static final String ACTION_SELECT = "SELECT";
	public static final String ACTION_DELETE = "DELETE";
	public static final String ACTION_INSERT = "INSERT";
	public static final String ACTION_UPDATE = "UPDATE";
}
