package spc.webos.queue.jms;

import java.util.ArrayList;
import java.util.List;

public class ConditionReceiverThread extends ReceiverThread
{
	List condition = new ArrayList();
	int idleSleepTime = 50; // û������ʱ˯��ʱ��

	public void addCondition(String condition)
	{ // JMSCorrelationID='123456'
		synchronized (condition)
		{
			if (!this.condition.contains(condition)) this.condition.add(condition);
		}
	}

	public void removeCondition(String condition)
	{
		synchronized (condition)
		{
			this.condition.remove(condition);
		}
	}

	public void execute() throws Exception
	{
		Object[] conditions = null;
		synchronized (condition)
		{
			conditions = condition.toArray();
		}
		if (conditions == null || conditions.length == 0)
		{
			Thread.sleep(idleSleepTime);
			return;
		}
		// System.out.print("ReceiverThread..");
		for (int i = 0; i < conditions.length; i++)
		{
			// BytesMessage msg = (BytesMessage)
			// jms.receiveSelected(destination,
			// conditions[i].toString());
			// if (msg == null) return;
			// byte[] content = new byte[(int) msg.getBodyLength()];
			// msg.readBytes(content);
			// buffer.put(new EAIMessage(content));
		}
	}

	public void setIdleSleepTime(int idleSleepTime)
	{
		this.idleSleepTime = idleSleepTime;
	}

	public List getCondition()
	{
		return condition;
	}

	public void setCondition(List condition)
	{
		this.condition = condition;
	}
}
