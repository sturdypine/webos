package spc.webos.queue;

import spc.webos.buffer.IBuffer;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.log.Log;
import spc.webos.queue.ibmmq.MQAccessTPool;
import spc.webos.util.StringX;

public abstract class AbstractReceiverThread extends AccessThread
{
	public AbstractReceiverThread()
	{
		super();
		rw = AccessThread.RW_READ;
	}

	public void execute() throws Exception
	{
		startThreadLog();
		long receiveNum = 0; // ����������������ִ��û�з��͵���Ϣ��˯�ߣ������������
		for (int i = 0; i < bufs.size(); i++)
		{
			try
			{
				IBuffer buf = (IBuffer) bufs.get(i);
				String bufName = buf.getName();
				String qName = buf2queueMapping != null ? (String) buf2queueMapping.get(bufName)
						: bufName;
				if (StringX.nullity(qName)) qName = bufName;
				// if (log.isDebugEnabled()) log.debug("receiver: bufName:" +
				// bufName + ", qname:"
				// + qName);
				if (buf.getWriters().size() > 1 && bufs.size() > 1)
				{
					if (log.isInfoEnabled()) log.info(bufName + "'s writers : " + buf.getWriters()
							+ ", buf.size: " + bufs.size());
					continue; // �����ǰ��д�ߣ�����ʱ��������buf����Ϊ���ܴ�bufд����ȥ
				}

				Object obj = receive(qName);
				if (obj != null)
				{
					if (obj instanceof QueueMessage)
					{
						IMessageConverter converter = ((MQAccessTPool) pool).getConverter();
						if (converter != null)
						{
							IMessage mesg = converter.deserialize(((QueueMessage) obj).buf);
							mesg.setCorrelationID(((QueueMessage) obj).correlationId);
							mesg.setInLocal(MsgLocalKey.MQGET_QMSG_KEY, obj);
							buf.put(mesg);
						}
						else buf.put(obj);
					}
					else buf.put(obj);
					if (log.isDebugEnabled()) log.debug("buf(" + buf.getName() + ") size: "
							+ buf.size());
					receiveNum++;
				}
				// else log.debug("receive obj is null!!!");
			}
			finally
			{
				// else if (log.isDebugEnabled()) log.debug("msg is null by "
				// + Thread.currentThread().getName());
				Log.print();
			}
		}
		if (receiveNum <= 0 && bufs.size() > 1)
		{
			log.info("MQ read sleep 50 ms!!!");
			Thread.sleep(50); //
		}
		// ������еĶ�û����Ҫ���͵ı��ģ���˯�ߣ��������ѭ���ķ�cpu
		Log.print();
	}

	public abstract Object receive(String qName) throws Exception;
	// maybe QueueMessage, maybe IMessage
}
