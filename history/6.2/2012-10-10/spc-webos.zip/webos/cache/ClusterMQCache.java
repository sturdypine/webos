package spc.webos.cache;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import spc.webos.log.Log;
import spc.webos.queue.ibmmq.Accessor;
import spc.webos.queue.ibmmq.MQCnnPool;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;

public class ClusterMQCache implements ICache
{
	public Object get(Object key)
	{
		return get(key.toString(), true, 0);
	}

	public Object poll(Object key)
	{
		return get(key.toString(), false, 0);
	}

	public Object poll(Object key, long timeout)
	{
		return get(key.toString(), false, timeout);
	}

	public byte[] get(String key, boolean browse)
	{
		return get(key, browse, 0);
	}

	public byte[] get(String key, boolean browse, long timeout)
	{
		if (key.length() > 48) throw new RuntimeException("key len: " + key.length() + " > 48");
		String strkey = key + BLANKS;
		String messageId = strkey.substring(0, 24);
		String corId = strkey.substring(24, 48);
		byte[] buf = null;
		MQMessage mqmsg = new MQMessage();
		MQGetMessageOptions gmo = new MQGetMessageOptions();
		// ƥ��������corrid msgid������
		gmo.matchOptions = MQC.MQMO_MATCH_CORREL_ID | MQC.MQMO_MATCH_MSG_ID;
		// ���û�з��������ı��ģ����ȴ����̷���
		if (timeout <= 0) gmo.options = MQC.MQGMO_NO_WAIT;
		else
		{
			gmo.options = MQC.MQGMO_WAIT;
			gmo.waitInterval = (int) timeout;
		}
		mqmsg.correlationId = corId.getBytes();
		mqmsg.messageId = messageId.getBytes();

		int index = ((int) (Math.random() * 1000000) % cnnpools.size());
		for (int i = 0; i < cnnpools.size(); i++)
		{
			if (index >= cnnpools.size()) index = 0;
			MQCnnPool cnnpool = (MQCnnPool) cnnpools.get(index++);
			try
			{
				mqmsg.clearMessage();
				if (browse) Accessor.browse(cnnpool, qname, gmo, mqmsg);
				else Accessor.receive(cnnpool, qname, gmo, mqmsg);
				if (buf == null)
				{
					buf = new byte[mqmsg.getDataLength()];
					mqmsg.readFully(buf);
				}
				if (browse) return buf; // ����������ģʽ����ȡ������
			}
			catch (MQException e)
			{
				if (e.reasonCode == 2033)
				{
					log.info("no msg 2033 in:" + cnnpool.getProps() + ", qname:" + qname);
					continue;
				}
				log.warn("fail to read:" + cnnpool.getProps() + ", qname:" + qname, e);
			}
			catch (Exception e)
			{
				log.warn("fail to read:" + cnnpool.getProps() + ", qname:" + qname, e);
			}
		}
		return buf;
	}

	public Object put(Object key, Object o) throws Exception
	{
		MQMessage mqmsg = null;
		if (o instanceof MQMessage) mqmsg = (MQMessage) o;
		else
		{
			mqmsg = new MQMessage();
			mqmsg.write((byte[]) o);
		}
		put(key.toString(), mqmsg, -1);
		return o;
	}

	public void put(String key, byte[] buf, long expireSeconds) throws Exception
	{
		MQMessage mqmsg = new MQMessage();
		mqmsg.write(buf);
		put(key.toString(), mqmsg, expireSeconds);
	}

	public void put(String key, MQMessage mqmsg, long expireSeconds) throws Exception
	{
		if (key.toString().length() > 48) throw new RuntimeException("key len: "
				+ key.toString().length() + " > 48");
		String strkey = key + BLANKS;
		String messageId = strkey.substring(0, 24);
		String corId = strkey.substring(24, 48);

		mqmsg.correlationId = corId.getBytes();
		mqmsg.messageId = messageId.getBytes();
		if (expireSeconds > 0) mqmsg.expiry = (int) expireSeconds * 10;
		Accessor.sendAll(cnnpools, qname, new MQPutMessageOptions(), mqmsg, 1, 0);
	}

	public int size()
	{
		return 0;
	}

	public void removeAll()
	{
		try
		{
			for (int i = 0; i < cnnpools.size(); i++)
				Accessor.clearAll((MQCnnPool) cnnpools.get(i), qname, 100000);
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
	}

	public Object poll(Object key, WaitWithTime wwt)
	{
		return poll(key, wwt.timeout);
	}

	public Collection getKeys()
	{
		throw new UnsupportedOperationException("getKeys()");
	}

	public Object getMessage(String key)
	{
		throw new UnsupportedOperationException("getMessage(String key)");
	}

	public Object remove(Object o)
	{
		throw new UnsupportedOperationException("remove (Object o)");
	}

	public boolean changeStatus(Map param)
	{
		return false;
	}

	public Map checkStatus(Map param)
	{
		return null;
	}

	public void refresh() throws Exception
	{
	}

	protected String name;
	protected String qname;
	protected List cnnpools;
	protected Log log = Log.getLogger(getClass());
	public static final String BLANKS = "                                                ";

	public String getQname()
	{
		return qname;
	}

	public void setQname(String qname)
	{
		this.qname = qname;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getName()
	{
		return name;
	}

	public void setCnnpools(List cnnpools)
	{
		this.cnnpools = cnnpools;
	}

	public void init() throws Exception
	{
		if (name == null) name = qname;
		if (getName() != null) CACHE.put(getName(), this);
	}
}
