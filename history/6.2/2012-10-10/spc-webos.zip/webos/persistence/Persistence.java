package spc.webos.persistence;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import net.sf.cglib.proxy.Enhancer;
import net.sf.ehcache.CacheManager;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.core.io.ResourceLoader;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.namedparam.AbstractSqlParameterSource;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.util.StringUtils;

import spc.webos.config.AppConfig;
import spc.webos.constant.AppRetCode;
import spc.webos.constant.Common;
import spc.webos.data.CompositeNode;
import spc.webos.data.Message;
import spc.webos.data.validator.AbstractMessageValidator;
import spc.webos.data.validator.MessageErrors;
import spc.webos.exception.AppException;
import spc.webos.exception.MsgErrException;
import spc.webos.flownode.IFlowNode;
import spc.webos.jdbc.XJdbcTemplate;
import spc.webos.jdbc.namedparam.MapSqlParameterSource;
import spc.webos.jdbc.rowmapper.AbstractRowMapper;
import spc.webos.jdbc.rowtype.RowList;
import spc.webos.jdbc.rowtype.RowMap;
import spc.webos.jdbc.rowtype.RowXMap;
import spc.webos.log.Log;
import spc.webos.matrix.IMatrix;
import spc.webos.matrix.ListMatrix;
import spc.webos.message.DictMessageSource;
import spc.webos.model.ValueObject;
import spc.webos.persistence.loader.SQLItemXmlLoader;
import spc.webos.persistence.loader.VOSQLItemLoader;
import spc.webos.persistence.stat.SqlPerformanceStat;
import spc.webos.service.Service;
import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;
import spc.webos.util.tree.TreeNode;
import spc.webos.web.common.ISessionUserInfo;
import bsh.Interpreter;
import freemarker.template.Configuration;
import freemarker.template.Template;

public class Persistence extends Service implements ApplicationContextAware, ResourceLoaderAware,
		IPersistence
{
	public boolean contain(Class clazz)
	{
		return voSQLMap.get(clazz) != null;
	}

	public boolean contain(String sqlId)
	{
		return getSQLConfig(sqlId) != null;
	}

	public List update(List list)
	{
		if (list == null || list.size() == 0) return null;
		List result = new ArrayList();
		for (int i = 0; i < list.size(); i++)
			result.add(new Integer(update((ValueObject) list.get(i))));
		return result;
	}

	public List insert(List list)
	{
		if (list == null || list.size() == 0) return null;
		List result = new ArrayList();
		for (int i = 0; i < list.size(); i++)
			result.add(new Integer(insert((ValueObject) list.get(i))));
		return result;
	}

	public List delete(List list)
	{
		if (list == null || list.size() == 0) return null;
		List result = new ArrayList();
		for (int i = 0; i < list.size(); i++)
			result.add(new Integer(delete((ValueObject) list.get(i))));
		return result;
	}

	public List query(Map paramMap)
	{
		String sqlID = (String) paramMap.get(QUERY_SQL_ID_KEY);
		return (List) persistence.execute(sqlID, paramMap);
	}

	public XJdbcTemplate getDefautlJdbcTemplate()
	{
		return defautlJdbcTemplate;
	}

	/**
	 * Ĭ��Ϊ������ΪWhere����
	 * 
	 * @param obj
	 * @return
	 */
	public int update(ValueObject obj)
	{
		return update(obj, (String[]) null, false);
	}

	/**
	 * ��ָ������������ΪWhere����
	 * 
	 * @param obj
	 * @param whereProperties
	 * @param updateNULL
	 *            �Ƿ���������null
	 */
	public int update(ValueObject obj, String[] whereProperties, boolean updateNULL)
	{
		Map paramMap = new HashMap();
		if (whereProperties != null && whereProperties.length > 0) paramMap.put(
				ASSIGNED_FIELDS_KEY, whereProperties);
		if (updateNULL) paramMap.put(UPDATE_NULL_KEY, Boolean.TRUE);
		int[] rows = (int[]) excute(obj, obj.getClass(), SQLItem.UPDATE, paramMap);
		return rows[0];
	}

	public int update(ValueObject obj, String[] whereProperties, String updateTail,
			boolean updateNULL, Map paramMap)
	{
		if (paramMap == null) paramMap = new HashMap();
		paramMap.put(UPDATE_ATTACH_TAIL_KEY, updateTail);
		if (whereProperties != null && whereProperties.length > 0) paramMap.put(
				ASSIGNED_FIELDS_KEY, whereProperties);
		if (updateNULL) paramMap.put(UPDATE_NULL_KEY, Boolean.TRUE);
		int[] rows = (int[]) excute(obj, obj.getClass(), SQLItem.UPDATE, paramMap);
		return rows[0];
	}

	public List get(ValueObject obj)
	{
		return get(obj, null);
	}

	public List get(ValueObject obj, Map paramMap)
	{
		return get(obj, (String[]) null, true, false, paramMap);
	}

	public List get(ValueObject obj, String[] assignedProperties, boolean lazyLoading,
			boolean forUpdate, Map paramMap)
	{
		if (paramMap == null) paramMap = new HashMap();
		if (assignedProperties != null && assignedProperties.length > 0) paramMap.put(
				ASSIGNED_FIELDS_KEY, assignedProperties);
		List result = (List) excute(obj, obj.getClass(), SQLItem.SELECT, paramMap);
		if (result == null || result.size() == 0) return result;
		/*
		 * modified by cjs 090712 if (lazyLoading) enhance(result,
		 * (BulkBeanItem) voMapping.get(obj .getClass()), paramMap); Cache cache
		 * = cacheManager.getCache(obj.getClass().getName()); if
		 * (assignedProperties == null && lazyLoading && cache != null) { //
		 * ֻ�������Ĳ�ѯ��Ϣ�Ż��� for (int i = 0; i < result.size(); i++) { ValueObject
		 * value = (ValueObject) result.get(i); cache.put(new
		 * net.sf.ehcache.Element(value.getKey(), value)); } }
		 */
		return result;
	}

	public ValueObject find(ValueObject obj)
	{
		return find(obj, null);
	}

	public ValueObject find(ValueObject obj, Map paramMap)
	{
		return find(obj, (String[]) null, true, false, paramMap);
	}

	public ValueObject find(ValueObject obj, String[] assignedProperties, boolean lazyLoading,
			boolean forUpdate, Map paramMap)
	{
		/*
		 * modified by cjs 090712 Serializable key = obj.getKey(); if (key !=
		 * null && assignedProperties == null) { // ��黺�� Cache cache =
		 * cacheManager.getCache(obj.getClass().getName());
		 * net.sf.ehcache.Element ele = null; if (cache != null) ele =
		 * cache.get(key); if (ele != null) return (ValueObject)
		 * ele.getObjectValue(); }
		 */
		List result = get(obj, assignedProperties, lazyLoading, forUpdate, paramMap);
		if (result == null || result.size() == 0) return null;
		return (ValueObject) result.get(0);
	}

	public int insert(ValueObject obj)
	{
		return insert(obj, new HashMap());
	}

	public int insert(ValueObject obj, Map paramMap)
	{
		UUID uuid = (UUID) this.uuidMap.get(obj.getClass()); // ֻ�����ӵ�ʱ��Ų���uuid
		if (uuid != null) paramMap.put(UUID_KEY, uuid);
		else paramMap.put(UUID_KEY, defUUID); // ���û���Զ�������, �����Ĭ��������ʽ
		int[] rows = (int[]) excute(obj, obj.getClass(), SQLItem.INSERT, paramMap);
		return rows[0];
	}

	public int delete(ValueObject obj, String[] whereProperties, Map paramMap)
	{
		if (paramMap == null) paramMap = new HashMap();
		if (whereProperties != null && whereProperties.length > 0) paramMap.put(
				ASSIGNED_FIELDS_KEY, whereProperties);
		int[] rows = (int[]) excute(obj, obj.getClass(), SQLItem.DELETE, paramMap);
		return rows[0];
	}

	public int delete(ValueObject obj)
	{
		int[] rows = (int[]) excute(obj, obj.getClass(), SQLItem.DELETE, new HashMap());
		return rows[0];
	}

	/**
	 * ͨ��SQlId, �Ͳ���ִ�в�ѯ���, ������
	 * 
	 * @param sqlID
	 * @param paramMap
	 * @return
	 */
	public Object execute(String sqlId, Map paramMap) throws DataAccessException
	{
		return single(sqlId, paramMap);
	}

	public Object dquery(String sqlId, Map paramMap) throws DataAccessException
	{
		return single(sqlId, paramMap);
	}

	public Map dquery(String[] sqlIds, Map paramMap, Map resultMap)
	{
		return batch(sqlIds, paramMap, resultMap);
	}

	public Map query(String[] sqlIds, Map paramMap, Map resultMap)
	{
		return batch(sqlIds, paramMap, resultMap);
	}

	/**
	 * ִֻ�в�ѯ
	 */
	public Object query(String sqlId, Map paramMap) throws DataAccessException
	{
		return single(sqlId, paramMap);
	}

	/**
	 * �ʺ��ڱ�������, ��һ��SQLִ��, ���ѽ������SQL Id�ŵ�model��ȥ
	 * 
	 * @param sqlIDs
	 *            ��Ҫִ�е�һ��SQL
	 * @param paramMap
	 * @param model
	 */
	public Map execute(List sqlIds, Map paramMap, Map resultMap)
	{
		for (int i = 0; i < sqlIds.size(); i++)
		{
			String sqlId = ((String) ((List) sqlIds).get(i)).replace('.', '_').toLowerCase();
			String id = sqlId;
			int index = id.indexOf('_');
			String key = id.substring(index + 1);
			Object result = execute(id, paramMap);
			if (result != null)
			{
				paramMap.put(key, result);
				if (resultMap != paramMap) resultMap.put(sqlId, result);
			}
		}
		return resultMap;
	}

	public Map execute(String[] sqlIds, Map paramMap, Map resultMap)
	{
		return batch(sqlIds, paramMap, resultMap);
	}

	public Collection performance(Map params)
	{
		return SqlPerformanceStat.getInstance().getSqls().values();
	}

	protected Object single(String sqlId, Map paramMap)
	{
		sqlId = sqlId.replace('.', '_').toLowerCase();
		Object res = null;
		Object item = getSQLConfig(sqlId);
		if (item == null)
		{
			log.warn("cannot find sql id: " + sqlId);
			throw new AppException(AppRetCode.DB_UNDEFINED_SQLID(), new Object[] { sqlId });
		}
		if (paramMap == null) paramMap = new HashMap();
		if (item instanceof SQLItem) res = excute(sqlId, (SQLItem) item, paramMap);
		else res = excute(sqlId, (ReportItem) item, paramMap);
		return res;
	}

	protected Map batch(String[] sqlIds, Map paramMap, Map resultMap)
	{
		for (int i = 0; i < sqlIds.length; i++)
		{
			String sqlId = sqlIds[i].replace('.', '_').toLowerCase();
			String id = sqlId;
			int index = id.indexOf('_');
			String key = id.substring(index + 1);
			Object result = execute(id, paramMap);
			if (result != null)
			{
				paramMap.put(key, result);
				if (resultMap != paramMap) resultMap.put(sqlId, result);
			}
		}
		return resultMap;
	}

	/**
	 * ��֤vo
	 * 
	 * @param vo
	 * @return
	 */
	public boolean validate(ValueObject vo)
	{
		TreeNode root = (TreeNode) voValidatorMap.get(vo.getClass());
		if (root == null) return true;
		if (log.isDebugEnabled()) log.debug("start to validate vo:" + vo.getClass());
		CompositeNode cnode = new CompositeNode();
		cnode.set(vo);
		Message msg = new Message();
		msg.init();
		msg.setRequest(cnode);
		MessageErrors errors = new MessageErrors(msg);
		try
		{
			AbstractMessageValidator.validate(msg, root, null, cnode, errors);
		}
		catch (Exception e)
		{
			log.error("fail to validator vo:" + vo.getClass(), e);
		}
		if (errors.getErrorCount() > 0) throw new MsgErrException(errors);
		return true;
	}

	/**
	 * ������SQL�����ļ����õ�SQl�ŵ��ڴ�Map��.
	 */
	public void init() throws Exception
	{
		if (log.isInfoEnabled()) log.info("Persistence.init start...product = " + product);
		super.init();
		// System.out.println("Persistence.init start...productMode = "
		// + AppConfig.isProductMode());
		cacheManager = CacheManager.create(); // ����һ�����������
		/*
		 * InputStream is = configLocation.getInputStream(); SAXReader reader =
		 * new SAXReader(false); Document doc = reader.read(is); Element root =
		 * doc.getRootElement();
		 */
		refresh();
		loadSeqenceOfTable(false);
		log.info("Persistence.init over...");
	}

	public void refresh() throws Exception
	{
		Map sqlMap = new HashMap();
		String location = cfgLocation + "/sql/";
		if (log.isInfoEnabled()) log.info("Load sqlocation=" + location);
		// ��ȡ��ͨSQL��������
		SQLItemXmlLoader.readSqlDir(resourceLoader, location, sqlMap, product);
		/*
		 * DBList sqls = root.elements("sqlmap"); for (int i = 0; i <
		 * sqls.size(); i++) { Element ele = (Element) sqls.get(i); String
		 * namespace = ele.attributeValue("id"); boolean debug = new
		 * Boolean(ele.attributeValue("debug", "false")) .booleanValue(); String
		 * location = ele.attributeValue("location"); if
		 * (logger.isInfoEnabled()) logger.info(location + ", debug = " +
		 * debug); if (productMode || !debug) // ����ģʽ ������ �Դ������ļ�Ϊ�ǵ���ģʽ,
		 * ��������ģ�����ݵ�sqlMap�� sqlMap.put(namespace,
		 * SQLItemXmlLoader.parseXmlFile(resourceLoader
		 * .getResource(location).getInputStream())); else // ����ģʽֻ�Ŷ�λ�ļ�,
		 * ��̬������ִ�е�SQL�ļ� sqlMap.put(namespace, location); }
		 */

		// ��ȡVO����������ӳ���ϵ
		// logger.info("mapping.size = " + (sqls == null ? 0 : sqls.size()));
		location = cfgLocation + "/mapping/";
		if (log.isInfoEnabled()) log.info("Load mappingLocation=" + location);
		Map voSQLMap = new HashMap();
		Map voMapping = new HashMap();
		Map voManualSequenceMap = new HashMap();
		Map voValidatorMap = new HashMap();
		VOSQLItemLoader.readMappingDir(resourceLoader, location, voSQLMap, voMapping,
				voManualSequenceMap, voValidatorMap, cacheManager);

		// asign value
		this.sqlMap = sqlMap;
		this.voSQLMap = voSQLMap;
		this.voMapping = voMapping;
		this.voManualSequenceMap = voManualSequenceMap;
		this.voValidatorMap = voValidatorMap;
	}

	/**
	 * ����voManualSequenceMap�������õı���seqence��Ϣ�� �������ĳ�ű���sequence���ֶ��ģ���ѯ��ǰ�������ֵ������
	 * 
	 * @param forcingLoading
	 *            ���Ϊtrue��ʾǿ�Ƽ����µ���Ϣ
	 */
	public Map loadSeqenceOfTable(boolean forcingLoading)
	{
		synchronized (voManualSequenceMap)
		{
			Iterator keys = voManualSequenceMap.keySet().iterator();
			while (keys.hasNext())
			{
				Class clazz = (Class) keys.next();
				Object[] value = (Object[]) voManualSequenceMap.get(clazz);
				if (value[3] != null && !forcingLoading) continue;
				Map param = new HashMap();
				param.put("table", value[0]);
				param.put("column", value[1]);
				if (value[2] != null) param.put(JT_KEY, value[2]);
				value[3] = (Long) execute(TABLE_SEQUENCE_SQL_ID, param);
				if (log.isInfoEnabled()) log.info("talbe=" + value[0] + ", column=" + value[1]
						+ ", datasource=" + value[2] + ", sequence=" + value[3]);
			}
			return voManualSequenceMap;
		}
	}

	// public void clearCache(Class clazz)
	// {
	// Cache cache = this.cacheManager.getCache(clazz.getName());
	// if (cache != null) cache.removeAll();
	// }

	boolean product = true;
	SqlPerformanceStat sps; // sql ����ͳ��
	ApplicationContext appCxt;
	XJdbcTemplate defautlJdbcTemplate; // Ĭ������Դ
	// Resource configLocation; // SQL�����ļ�λ��
	Map sqlMap = new HashMap(); // ϵͳ���е�SQL�������
	Map voSQLMap = new HashMap(); // ֱ�Ӷ���ʽ���ʵ�SQL�������
	Map voMapping = new HashMap(); // ÿ��vo�����й�������vo���Ե�������Ϣ
	Map voValidatorMap = new HashMap(); // ÿ��vo����֤��Ϣ
	Map voManualSequenceMap = new HashMap(); // �洢ÿ��VO���ֹ���������sequence���ֶ���Ϣ
	Map uuidMap = new HashMap(); // ÿ��VO�Զ����uuid
	DefaultUUID defUUID = new DefaultUUID(); // Ĭ������UUID��
	Map ctxParam = new HashMap(); // ��������, �����ⲿ���û����Ĳ���, ��Ϊ����Ӧ�õ����ݲ�������
	String cfgLocation = "/WEB-INF/env/persistence";
	// String mappingLocation = "/WEB-INF/env/persistence/mapping/";
	// String sqlLocation = "/WEB-INF/env/persistence/sql/";
	ResourceLoader resourceLoader; // ��Դ������
	// String delim = "."; // ���ʷָ�����, ���ʷ�ʽnamespace.sqlID
	// boolean productMode = true; // ��ʾ��������ģʽ, ֻ����һ��SQL, ���Ч��
	CacheManager cacheManager; // �־ò㻺�棬 ����ecacheʵ��
	// ClassObjectPool sqlPool = new ClassObjectPool(StringWriter.class, 50);
	final Log log = Log.getLogger(getClass());
	static final Persistence persistence = new Persistence();

	private Persistence()
	{
		name = "persistence";
	}

	public static Persistence getInstance()
	{
		return persistence;
	}

	public void setUuidMap(Map uuidMap) throws ClassNotFoundException
	{
		Iterator keys = uuidMap.keySet().iterator();
		while (keys.hasNext())
		{
			String key = keys.next().toString();
			this.uuidMap.put(Class.forName(key), uuidMap.get(key));
		}
	}

	public void setApplicationContext(ApplicationContext appCxt)
	{
		this.appCxt = appCxt;
	}

	public void setDefautlJdbcTemplate(XJdbcTemplate defautlJdbcTemplate)
	{
		this.defautlJdbcTemplate = defautlJdbcTemplate;
	}

	public void setResourceLoader(ResourceLoader resourceLoader)
	{
		this.resourceLoader = resourceLoader;
	}

	/**
	 * ����cglib������ ��ÿ���������Խ�����ǿ�� ���ö�̬��ʱ���أ� ����Ҫʹ�õ�ʱ�����
	 * 
	 * @param result
	 * @param bulkBeanItem
	 */
	void enhance(List result, BulkBeanItem bulkBeanItem, Map paramMap)
	{
		if (bulkBeanItem == null) return;
		try
		{
			for (int i = 0; i < result.size(); i++)
			{
				Object obj = result.get(i);
				List properties = bulkBeanItem.getProperties();
				Object[] values = new Object[properties.size()];
				for (int j = 0; j < properties.size(); j++)
				{
					Object[] bulkBeans = (Object[]) properties.get(j);
					values[j] = Enhancer.create((Class) bulkBeans[2], new LazyResultLoader(this,
							bulkBeans, obj, paramMap));
				}
				bulkBeanItem.getVoProperties().setPropertyValues(obj, values);
			}
		}
		catch (Exception e)
		{
			// e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	/**
	 * ��һ������ִ��select, delete, update, insert���ֲ���...
	 * 
	 * @param msg
	 * @param clazz
	 *            �ں���superclass�ļ̳�ģʽ�£���Ҫָ��obj����������
	 * @param operator
	 * @param paramMap
	 * @return
	 */
	Object excute(ValueObject vo, Class clazz, int operator, Map paramMap)
	{
		if (log.isDebugEnabled()) log.debug("vo: " + vo.toString());
		validate(vo); // ��֤��ǰvo
		SQLItem[] items = (SQLItem[]) voSQLMap.get(clazz);// :
		SQLItem item = items[operator];
		String sqlId = clazz.toString().toLowerCase().replace(' ', '_').replace('.', '_') + '_'
				+ item.type;
		// ����Ƿ���Ȩ��ִ�д�sql
		// ISessionUserInfo sui = (ISessionUserInfo) ISessionUserInfo.SUI.get();
		// if (sui != null && !sui.containSqlId(sqlId)) throw new
		// AppException(AppRetCode.DB_UNAUTH,
		// new Object[] { sqlId });
		/*
		 * modified by cjs 090712 if (operator == SQLItem.DELETE || operator ==
		 * SQLItem.UPDATE) { // delete �� update SQL��䣬��Ҫ�Գ־ò��޸�, Note:
		 * ����insert������ǲ����Ƿ��뻺�棬 ��Ϊ // ���ǵ�����
		 * ������Щ�޸Ķ�����ʧ�ܣ�������������������漰���п����޸ĵļ�¼�����Ƕ�������� Cache cache =
		 * cacheManager.getCache(vo.getClass().getName()); if (cache != null) {
		 * if (vo.getKey() != null) cache.remove(vo.getKey()); else
		 * cache.removeAll(); // �������Ķ���û��ָ����key����ô�ܿ��ܶԴ˱����������ݶ����޸� } }
		 */
		// loadSQLItem(clazz);
		paramMap.put(VO_KEY, vo);
		if (item.type == SQLItem.INSERT)
		{ // ���������
			Long sequence = seqenceOfTable(clazz);
			if (sequence != null)
			{
				paramMap.put(SEQ_KEY, sequence);
				vo.setManualSeq(sequence);
			}
		}
		Object value = null;
		try
		{
			value = excute(sqlId, item, paramMap);
		}
		finally
		{
			vo.destory();
		}
		return value;
	}

	/**
	 * ִ�б����ڵ�
	 * 
	 * @param sqlID
	 * @param item
	 * @param paramMap
	 * @return
	 */
	Object excute(String sqlID, ReportItem item, Map paramMap)
	{
		String lowerId = sqlID.toLowerCase();
		// ����Ƿ���Ȩ��ִ�д�sql
		ISessionUserInfo sui = (ISessionUserInfo) ISessionUserInfo.SUI.get();
		if (sui != null && !sui.containSqlId(lowerId)) throw new AppException(
				AppRetCode.DB_UNAUTH(), new Object[] { lowerId });

		// 1. ��ȡ���е�������sql
		execute(item.dependence, paramMap, paramMap);
		for (int i = 0; i < item.dependence.length; i++)
		{
			String id = item.dependence[i];
			paramMap.put(MATRIX_PREFIX + id.replace('.', '_'),
					new ListMatrix((List) paramMap.get(id)));
		}

		// 2. ִ��Ԥ����
		if (item.preScripts != null)
		{
			for (int i = 0; i < item.preScripts.size(); i++)
			{
				Script s = (Script) item.preScripts.get(i);
				Object result = paramMap.get(s.target);
				excuteScript(sqlID, result, paramMap, null, item, s);
			}
		}
		excFnodes(sqlID, Boolean.TRUE, item.preFnodes, paramMap);

		// 3 ִ��main
		List mainResult = new ArrayList();
		IMatrix matrix = new ListMatrix(mainResult);
		paramMap.put(lowerId, mainResult);
		paramMap.put(sqlID, mainResult);
		paramMap.put(MATRIX_PREFIX + lowerId, matrix);
		paramMap.put(MATRIX_PREFIX + lowerId.substring(lowerId.indexOf('.') + 1), matrix);
		bsh(paramMap, null, item, item.main);

		// 4 ִ��post
		if (item.postScripts != null)
		{
			for (int i = 0; i < item.postScripts.size(); i++)
			{
				Script s = (Script) item.postScripts.get(i);
				Object result = paramMap.get(s.target);
				// System.out.println(sqlID+s.target+result);
				excuteScript(sqlID, result, paramMap, null, item, s);
			}
		}
		excFnodes(sqlID, Boolean.FALSE, item.postFnodes, paramMap);
		// 7. ����ǲ�ѯ�ṹ��Ҫִ��������,��ִ��������
		if (item.rowIndex != null && mainResult != null) makeRowIndex(sqlID, item.rowIndex,
				(List) mainResult, paramMap);

		return mainResult;
	}

	/**
	 * ����һ���ض���SQLConfig, ִ�в����ؽ��
	 * 
	 * @param sqlID
	 * @param conf
	 * @param paramMap
	 * @return
	 * @throws DataAccessException
	 */
	Object excute(String sqlID, SQLItem item, Map paramMap) throws DataAccessException
	{
		if (log.isDebugEnabled()) log.debug("sqlitem : " + item);
		// ����Ƿ���Ȩ��ִ�д�sql
		ISessionUserInfo sui = (ISessionUserInfo) ISessionUserInfo.SUI.get();
		if (sui != null && !sui.containSqlId(sqlID)) throw new AppException(AppRetCode.DB_UNAUTH(),
				new Object[] { sqlID });

		// ִ���Ⱦ�SQL
		if (item.dependence != null)
		{
			for (int i = 0; i < item.dependence.length; i++)
			{
				String sid = item.dependence[i].replace('.', '_').toLowerCase();
				if (!paramMap.containsKey(sid)) execute(sid, paramMap); // ����Ⱦ�����SQL�Ѿ�����
				else if (log.isInfoEnabled()) log.info("dependence sqlid: " + sid
						+ " has been existed...");
			}
		}

		String jtName = (String) paramMap.get(JT_KEY + sqlID);
		if (StringX.nullity(jtName)) jtName = (String) paramMap.get(JT_KEY); // �ض�sql������2010-09-26
		if (StringX.nullity(jtName)) jtName = item.jt;
		// ������õ�����Դ
		XJdbcTemplate jt = null;
		if (!StringX.nullity(jtName)) jt = (XJdbcTemplate) appCxt.getBean(jtName,
				XJdbcTemplate.class);
		if (jt == null) jt = defautlJdbcTemplate;

		// 1. ִ��ǰ�ýű�����
		if (item.preScript != null)
		{
			bsh(paramMap, jt, item, item.preScript); // �����Ԥ��������
			RuntimeException ex = (RuntimeException) paramMap.get(EX_KEY); // �����Ԥ���������쳣��־���׳��쳣
			if (ex != null) throw ex;
		}
		// 2.ִ��ǰ��fnodes
		excFnodes(sqlID, Boolean.TRUE, item.preFnodes, paramMap);

		paramMap.put(DB_TYPE_KEY, jt.getDbType());
		String sql = processSQL(sqlID, item.t, paramMap);
		paramMap.put(SQL_PREFIX + sqlID, sql);
		paramMap.put(LAST_SQL_KEY, sql);
		if (log.isInfoEnabled()) log.info("SQL(" + sqlID + "): " + sql);
		if (sql.length() <= 6) return null;
		// �����ǰSQL���������һ����SQL��ʶ, ��ʾ��SQL�ڴ������²�ִ��, һ�����ڱ�������ִ��
		// modified by sturdypine. ���SQL���ĳ���С�ڵ���6���ַ�, ��ִ��
		// System.out.println("sql: " + sql);
		/*
		 * modified by cjs 090712 if (item.flushClazzArray != null) { // �����ػ���
		 * for (int i = 0; i < item.flushClazzArray.length; i++) { Cache cache =
		 * cacheManager.getCache(item.flushClazzArray[i] .getName()); if (cache
		 * != null) cache.removeAll(); } }
		 */
		Object result = null;
		SQLItem.setCurrentItem(item);

		long millis = (sps != null) ? System.currentTimeMillis() : 0;
		try
		{
			result = item.isSelect() ? excSelect(sqlID, sql, jt, item, paramMap)
					: (item.prepared ? (item.procedure ? excProcedure(sql, jt, paramMap)
							: excPrepared(sql, jt, paramMap)) : excDelUpdIns(sql, jt, item,
							paramMap));
		}
		finally
		{
			SQLItem.setCurrentItem(null);
			if (sps != null) sps.add(sqlID, sql, (int) (System.currentTimeMillis() - millis),
					result != null);
		}
		paramMap.put(sqlID, result);

		// 5. ִ�к��ýű�
		if (item.postScripts != null)
		{
			for (int i = 0; i < item.postScripts.size(); i++)
			{
				Script s = (Script) item.postScripts.get(i);
				excuteScript(sqlID, result, paramMap, jt, item, s);
			}
		}

		// 6.ִ�к���fnodes
		excFnodes(sqlID, Boolean.FALSE, item.postFnodes, paramMap);

		// 7. ����ǲ�ѯ�ṹ��Ҫִ��������,��ִ��������
		if (item.isSelect() && item.rowIndex != null && result != null) makeRowIndex(sqlID,
				item.rowIndex, (List) result, paramMap);
		return result;
	}

	/**
	 * �������õ�����������������
	 * 
	 * @param sqlId
	 * @param rowIndexMF
	 * @param data
	 * @param params
	 */
	void makeRowIndex(String sqlId, String rowIndexMF, List data, Map params)
	{
		MessageFormat mf = null;
		Template t = null;
		Map rowIndex = new HashMap();
		Object[] row = null;
		for (int i = 0; i < data.size(); i++)
		{
			Object r = data.get(i);
			if (r instanceof List)
			{ // row is a list
				if (mf == null) mf = new MessageFormat(rowIndexMF);
				if (row == null) row = ((List) r).toArray();
				else ((List) r).toArray(row);
				rowIndex.put(mf.format(row), new Integer(i));
			}
			else
			{ // row is a map
				try
				{
					if (t == null) t = new Template("RI", new StringReader(rowIndexMF),
							new Configuration());
					StringWriter out = new StringWriter();
					t.process((Map) r, out);
					rowIndex.put(out.toString(), new Integer(i));
				}
				catch (Exception e)
				{
					throw new RuntimeException(e);
				}
			}
		}
		params.put(sqlId + ROW_INDEX_POSTFIX, rowIndex);
	}

	void excFnodes(String sqlId, Boolean pre, String[] fnodes, Map params)
	{
		if (fnodes == null) return;
		for (int i = 0; i < fnodes.length; i++)
		{
			IFlowNode fnode = (IFlowNode) IFlowNode.FLOW_NODES.get(fnodes[i]);
			if (fnode == null) log.error("can not find fnode:" + fnodes[i]);
			else
			{
				Message msg = new Message();
				msg.init();
				msg.setInRequest("sqlId", sqlId);
				msg.setInRequest("pre", pre);
				msg.setInRequest(PARAMS_KEY, params);
				try
				{
					fnode.execute(msg, null);
				}
				catch (Exception e)
				{
					log.error(fnodes[i], e);
				}
			}
		}
	}

	// ִ�� Prepared ���� SQL
	Object excPrepared(String sql, XJdbcTemplate jt, Map paramMap)
	{
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jt);
		Object vo = paramMap.get(VO_KEY);
		AbstractSqlParameterSource source = null;
		if (vo == null) source = new MapSqlParameterSource(paramMap);
		else source = new BeanPropertySqlParameterSource(vo);
		int rows = namedParameterJdbcTemplate.update(sql, source);
		if (log.isDebugEnabled()) log.debug("influenced rows: " + rows);
		return new int[] { rows };
	}

	// ִ�д����ز����Ĵ洢����
	Object excProcedure(String sql, XJdbcTemplate jt, Map params)
	{
		CSCallback cscb = new CSCallback(sql, params);
		return jt.execute(cscb.prepare(), cscb);
	}

	// ִ�� DELETE_UPDATE_INSERT_SQL ���� SQL
	Object excDelUpdIns(String sql, XJdbcTemplate jt, SQLItem item, Map paramMap)
	{
		if (item.delim == null || item.delim.length() == 0 || sql.indexOf(item.delim) < 0)
		{
			int rows = jt.update(sql);
			if (log.isDebugEnabled()) log.debug("influenced rows: " + rows);
			return new int[] { rows }; // ����Ӱ�������
		}
		// ����Update
		int[] rows = jt.batchUpdate(StringUtils.split(sql, item.delim));
		if (log.isDebugEnabled()) log
				.debug("influenced rows: " + StringX.join(rows, StringX.COMMA));
		return rows;
	}

	// ִ�� Select ���� SQL
	Object excSelect(String sqlID, String sql, XJdbcTemplate jt, SQLItem item, Map params)
	{
		// �����ֶ�ת����Ϣ
		AbstractRowMapper.COLUMN_CONVERTER.set(item.columnConverters);
		AbstractRowMapper.COLUMN_CASE.set(item.column);

		// �Ƿ����û���, ����л������ȼ�黺��
		// �ø������д�����, ��ѯ���RESULT_CLASS_PREFIX
		List result = null;
		try
		{
			String resultClass = (String) params.get(RESULT_CLASS_PREFIX + sqlID);
			if (resultClass == null) resultClass = item.resultClass;
			result = jt.query(sql, resultClass);
			// CLM_PREFIX, ����н���������ҽ�����Ƕ��У�����ȡ�˽������clm��Ϣ
			if (result != null && result.size() > 0)
			{
				Object r = result.get(0);
				String[] clms = null;
				if (r instanceof RowList) clms = ((RowList) r).getColumnName();
				else if (r instanceof RowMap) clms = ((RowMap) r).getColumnName();
				else if (r instanceof RowXMap) clms = ((RowXMap) r).getColumnName();
				if (clms != null) params.put(CLM_PREFIX + sqlID, clms);
			}
		}
		finally
		{
			AbstractRowMapper.COLUMN_CONVERTER.set(null);
			AbstractRowMapper.COLUMN_CASE.set(null);
		}
		// List result = qr.result;
		// if (qr.rsmd != null) paramMap.put(sqlID + "_RSMD", qr.rsmd);
		if (result == null || result.size() == 0) return item.firstRowOnly ? null
				: new LinkedList();
		// �Ƿ�Ψһ�д���
		// boolean firstRowOnly = item.firstRowOnly;
		// Boolean _firstRowOnly = (Boolean) paramMap.get("_FIRST_ROW_ONEY_");
		// if (_firstRowOnly != null) firstRowOnly =
		// _firstRowOnly.booleanValue();
		return item.firstRowOnly ? ((List) result).get(0) : result;
	}

	/**
	 * ͨ��SQLID����һ��SQL������
	 * 
	 * @param sqlID
	 * @return
	 */
	public Object getSQLConfig(String sqlID)
	{
		sqlID = sqlID.toLowerCase(); // ��Сд������
		int indexOfDelim = sqlID.indexOf('.');
		if (indexOfDelim < 0) indexOfDelim = sqlID.indexOf('_');
		Map namespaceSQLMap = getSQLMap(sqlID.substring(0, indexOfDelim));
		Object item = namespaceSQLMap.get(sqlID.substring(indexOfDelim + 1));
		return item;
	}

	/**
	 * ͨ��namespace �Ҵ�ģ�������SQL�����ļ�
	 * 
	 * @param namespace
	 * @return
	 */
	Map getSQLMap(String namespace)
	{
		try
		{
			Object obj = sqlMap.get(namespace);
			if (obj instanceof Map) return (Map) obj;
			Map namespaceSQLMap = new HashMap();
			String sqlLocation = this.cfgLocation + "/sql/";
			InputStream is = resourceLoader.getResource(sqlLocation + (String) obj)
					.getInputStream();
			try
			{
				SQLItemXmlLoader.parseXmlFile(namespace, is, namespaceSQLMap, true);
			}
			finally
			{
				is.close();
			}
			return namespaceSQLMap;
		}
		catch (Exception e)
		{
			log.error("Can not find SQL File for namespace(" + namespace + ")", e);
			throw new RuntimeException(e);
		}
	}

	void excuteScript(String sqlID, Object result, Map paramMap, XJdbcTemplate jt, Object item,
			Script s)
	{
		if (s.type == Script.BEENSHELL)
		{
			bsh(paramMap, jt, item, s); // ����к�������
			RuntimeException ex = (RuntimeException) paramMap.get(EX_KEY); // ����ں��������쳣��־���׳��쳣
			if (ex != null) throw ex;
		}
		else if (s.type == Script.MATRIX_INNER_EXP && result instanceof List)
		{
			IMatrix matrix = new ListMatrix((List) result);
			paramMap.put(MATRIX_PREFIX + sqlID, matrix);
			paramMap.put(MATRIX_PREFIX + sqlID.substring(sqlID.indexOf('.') + 1), matrix);
			matrixExp(matrix, s, paramMap);
		}
	}

	/**
	 * ��Beansheel��������Ҫִ�еĺ���
	 * 
	 */
	void bsh(Map paramMap, XJdbcTemplate jt, Object item, Script script)
	{
		try
		{
			Interpreter i = script.i;
			if (i == null)
			{
				i = new Interpreter();
				i.setClassLoader(Thread.currentThread().getContextClassLoader());
			}
			i.set(PARAMS_KEY, paramMap);
			if (ctxParam != null) i.set(Common.MODEL_CXT_KEY, ctxParam);
			i.set(Common.MODEL_STRINGX_KEY, StringX.STRINGX);
			i.set(Common.MODEL_SUI_KEY, ISessionUserInfo.SUI.get());
			i.set(Common.MODEL_APP_CFG_KEY, AppConfig.getInstance().getConfig());
			i.set(Common.MODEL_SYS_UTIL_KEY, SystemUtil.getInstance());
			i.set(Common.MODEL_DICT_KEY, DictMessageSource.getInstance().getDict());

			if (script.i != null) i.eval("_FN();");
			else i.eval(proccessScript(script, paramMap));
		}
		catch (Exception e)
		{
			log.error("beenshell:" + script, e);
			// e.printStackTrace();
			throw new RuntimeException("Ex.beenshell script=" + script.script);
		}
	}

	void matrixExp(IMatrix matrix, Script script, Map paramMap)
	{
		try
		{
			// IMatrix matrix = new ListMatrix(result);
			matrix.process(proccessScript(script, paramMap), ";");
		}
		catch (Exception e)
		{
			log.error("matrixExp:" + script, e);
			throw new RuntimeException("matrixExp script=" + script.script);
		}
	}

	String proccessScript(Script script, Map params) throws IOException
	{
		if (!script.isTemplate) return script.script;
		if (ctxParam != null) params.put(Common.MODEL_CXT_KEY, ctxParam);
		String id = "script";
		return processSQL(id,
				new Template(id, new StringReader(script.script), new Configuration()), params);
	}

	/**
	 * ��Freemarker����SQLģ�����
	 * 
	 * @param sqlID
	 * @param paramMap
	 * @param out
	 */
	String processSQL(String sqlID, Template t, Map root)
	{
		long s = 0;
		if (log.isDebugEnabled()) s = System.currentTimeMillis();
		StringWriter sw = new StringWriter();
		try
		{
			if (ctxParam != null) root.put(Common.MODEL_CXT_KEY, ctxParam);
			sw.getBuffer().setLength(0);
			SystemUtil.freemarker(t, root, sw);
			String sql = StringX.trim(sw.toString());
			if (sqlID.indexOf(':') > 0)
			{ // VO��ص�SQL����
				if (sql.endsWith("where 1=1")) sql = sql.substring(0, sql.length() - 9);
				sql = sql.replaceAll("where 1=1 and", "where");
			}
			if (log.isDebugEnabled())
			{
				long cost = System.currentTimeMillis() - s;
				log.debug("processSQL cost: " + cost + ", " + sqlID);
			}
			return sql;
		}
		catch (Throwable tt)
		{
			log.warn("sql freemarker", tt);
			throw new AppException(AppRetCode.DB_FREEMARKER(),
					new Object[] { sqlID, tt.toString() }, tt);
		}
	}

	/**
	 * �������л�ȡVO���������Ϣ
	 * 
	 * @param clazz
	 */
	/*
	 * synchronized SQLItem[] loadSQLItem(Class clazz) { SQLItem[] items =
	 * (SQLItem[]) voSQLMap.get(clazz); if (items != null) return items; String
	 * clazzName = clazz.getName(); String packageName = clazzName.substring(0,
	 * clazzName.lastIndexOf('.')); String dir = (String)
	 * voSQLMap.get(packageName); try { // ��VO������ò���һ����ȡ��ֱ�Ӳ����޸�, �����������ͨSQLģʽ
	 * VOSQLItemLoader.readDir(resourceLoader, dir, voSQLMap, voMapping,
	 * voManualSequenceMap, cacheManager); voSQLMap.remove(packageName);
	 * loadSeqenceOfTable(false); } catch (Exception e) { throw new
	 * RuntimeException(e); }
	 * 
	 * return (SQLItem[]) voSQLMap.get(clazz); }
	 */

	// ��ȡĳ�ű����ֶ�������¼����������
	public Long seqenceOfTable(Class clazz)
	{
		Object[] value = (Object[]) voManualSequenceMap.get(clazz);
		if (value == null) return null;
		synchronized (value)
		{
			value[3] = new Long(((Long) value[3]).longValue() + 1);
			return (Long) value[3];
		}
	}

	public void setCtxParam(Map ctxParam)
	{
		this.ctxParam = ctxParam;
	}

	public void setCfgLocation(String cfgLocation)
	{
		this.cfgLocation = cfgLocation;
	}

	public String getCfgLocation()
	{
		return cfgLocation;
	}

	public void setSps(SqlPerformanceStat sps)
	{
		this.sps = sps;
	}

	public void setProduct(boolean product)
	{
		this.product = product;
	}

	public int update(ValueObject obj, List whereProps, boolean updateNULL)
	{
		return update(
				obj,
				whereProps == null ? null : (String[]) whereProps.toArray(new String[whereProps
						.size()]), updateNULL);
	}

	public int update(ValueObject obj, List whereProps, String updateTail, boolean updateNULL,
			Map params)
	{
		return update(
				obj,
				whereProps == null ? null : (String[]) whereProps.toArray(new String[whereProps
						.size()]), updateTail, updateNULL, params);
	}

	public int delete(ValueObject obj, List whereProps, Map params)
	{
		return delete(
				obj,
				whereProps == null ? null : (String[]) whereProps.toArray(new String[whereProps
						.size()]), params);
	}

	public List get(ValueObject obj, List assignedProps, boolean lazyLoading, boolean forUpdate,
			Map params)
	{
		return get(
				obj,
				assignedProps == null ? null : (String[]) assignedProps
						.toArray(new String[assignedProps.size()]), lazyLoading, forUpdate, params);
	}

	public ValueObject find(ValueObject obj, List assignedProps, boolean lazyLoading,
			boolean forUpdate, Map params)
	{
		return find(
				obj,
				assignedProps == null ? null : (String[]) assignedProps
						.toArray(new String[assignedProps.size()]), lazyLoading, forUpdate, params);
	}

	public Map dquery(List sqlIds, Map params, Map resultMap)
	{
		return dquery((String[]) sqlIds.toArray(new String[sqlIds.size()]), params, resultMap);
	}

	public Map query(List sqlIds, Map params, Map results)
	{
		return query((String[]) sqlIds.toArray(new String[sqlIds.size()]), params, results);
	}
}

/**
 * ֧�ִ洢���̶������������ĵ���
 * 
 * @author spc
 * 
 */
class CSCallback implements CallableStatementCallback
{
	protected String sql;
	protected Map params;
	protected List inOutParams = new ArrayList();
	public final static String PREFIX = ":{";
	public final static String POSTFIX = "}";
	public final static String PARAM_NAME = "name";
	public final static String PARAM_TYPE = "type";
	public final static String PARAM_OUT = "out";
	public final static String PARAM_CLASS = "class";
	public final static String TYPE_RS = "RS";
	public final static String TYPE_I = "I";
	public final static String TYPE_L = "L";
	public final static String TYPE_D = "D";
	public final static String TYPE_BD = "BD";
	public final static String TYPE_S = "S";

	public CSCallback(String sql, Map params)
	{
		this.sql = sql;
		this.params = params;
	}

	public String prepare()
	{
		int start = sql.indexOf(PREFIX);
		while (start >= 0)
		{
			int end = sql.indexOf(POSTFIX, start);
			inOutParams.add(JsonUtil.json2obj(sql.substring(start + 1, end + 1)));
			sql = sql.substring(0, start) + "?" + sql.substring(end + 1);
			start = sql.indexOf(PREFIX);
		}
		return sql;
	}

	public Object doInCallableStatement(CallableStatement cs) throws SQLException
	{
		for (int i = 0; i < inOutParams.size(); i++)
		{
			Map p = (Map) inOutParams.get(i);
			String name = (String) p.get(PARAM_NAME);
			String type = StringX.null2emptystr((String) p.get(PARAM_TYPE));
			Boolean out = (Boolean) p.get(PARAM_OUT);
			if (out == null || !out.booleanValue())
			{ // �������
				if (type.equalsIgnoreCase(TYPE_I)) cs.setInt(i + 1,
						Integer.parseInt((String) params.get(name)));
				else if (type.equalsIgnoreCase(TYPE_L)) cs.setLong(i + 1,
						Long.parseLong((String) params.get(name)));
				else if (type.equalsIgnoreCase(TYPE_D)) cs.setDouble(i + 1,
						Double.parseDouble((String) params.get(name)));
				else if (type.equalsIgnoreCase(TYPE_BD)) cs.setBigDecimal(i + 1, new BigDecimal(
						(String) params.get(name)));
				else cs.setString(i + 1, (String) params.get(name));
			}
			else
			{
				if (type.equalsIgnoreCase(TYPE_I)) cs.registerOutParameter(i + 1, Types.INTEGER);
				else if (type.equalsIgnoreCase(TYPE_L)) cs
						.registerOutParameter(i + 1, Types.BIGINT);
				else if (type.equalsIgnoreCase(TYPE_D)) cs
						.registerOutParameter(i + 1, Types.DOUBLE);
				else if (type.equalsIgnoreCase(TYPE_BD)) cs.registerOutParameter(i + 1,
						Types.DECIMAL);
				else if (type.equalsIgnoreCase(TYPE_RS)) cs.registerOutParameter(i + 1,
						Types.JAVA_OBJECT);
				else cs.registerOutParameter(i + 1, Types.VARCHAR);
			}
		}
		cs.execute();
		Map result = new HashMap();
		for (int i = 0; i < inOutParams.size(); i++)
		{
			Map p = (Map) inOutParams.get(i);
			String name = (String) p.get(PARAM_NAME);
			String type = StringX.null2emptystr((String) p.get(PARAM_TYPE));
			Boolean out = (Boolean) p.get(PARAM_OUT);
			if (out != null && out.booleanValue())
			{
				String value = null;
				if (type.equalsIgnoreCase(TYPE_I)) value = String.valueOf(cs.getInt(i + 1));
				else if (type.equalsIgnoreCase(TYPE_L)) value = String.valueOf(cs.getLong(i + 1));
				else if (type.equalsIgnoreCase(TYPE_D)) value = String.valueOf(cs.getDouble(i + 1));
				else if (type.equalsIgnoreCase(TYPE_BD)) value = cs.getBigDecimal(i + 1)
						.toPlainString();
				else if (type.equalsIgnoreCase(TYPE_RS))
				{
					// String clazz = StringX.null2emptystr((String)
					// p.get(PARAM_CLASS), "list");
					// ResultSet rs = (ResultSet) cs.getObject(i + 1);
					// // while(rs.isLast()) rs.n
					// rs.close();
				}
				else value = cs.getString(i + 1);
				result.put(name, value);
			}
		}
		return result;
	}
}
