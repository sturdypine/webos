package spc.webos.web.view;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.View;

import com.lowagie.text.Cell;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfWriter;

public class PDFTableView implements View
{
	static String contentType = "application/x-zip-compressed";

	public String getContentType()
	{
		return contentType;
	}
	
	public void render(Map model, HttpServletRequest request, HttpServletResponse response)
			throws Exception
	{
		String fileName = (String) model.get("FILE_NAME");
		if (fileName == null || "".equals(fileName))
		{
			fileName = "data";
		}
		ByteArrayOutputStream baos = new ByteArrayOutputStream(4096);
		Document document = getDocument();
		PdfWriter writer = newWriter(document, baos);

		// Apply preferences and build metadata.
		writer.setViewerPreferences(PdfWriter.AllowPrinting | PdfWriter.PageLayoutSinglePage);

		// Build PDF document.
		document.open();
		buildPdfDocument(model, document, writer, request, response);
		document.close();

		// Write content type and also length (determined via byte array).
		response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
		response.setContentLength(baos.size());

		// Flush byte array to servlet output stream.
		ServletOutputStream out = response.getOutputStream();
		// ZipOutputStream zos = new ZipOutputStream(out);
		baos.writeTo(out);
		out.flush();
		out.close();
	}

	protected Document getDocument()
	{
		// Return a letter-sized, landscape page
		return new Document(PageSize.A4.rotate());
	}

	protected void buildPdfDocument(Map model, Document pdfDoc, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		Map tableBasicInfo = (Map) model.get("tableBasicInfo");
		List headerInfo = (List) model.get("headerInfo");
		BaseFont bfChinese = BaseFont.createFont("STSong-Light", "UniGB-UCS2-H",
				BaseFont.NOT_EMBEDDED);
		Font fontChinese = new Font(bfChinese, 12, Font.NORMAL);
		Table table = new Table(headerInfo.size());
		table.setWidth(100);
		table.setBorderWidth(1);

		for (int i = 0; i < headerInfo.size(); i++)
		{
			Map mapRow = (Map) headerInfo.get(i);
			String headerName = (String) mapRow.get("chineseName");
			Cell cell = new Cell();
			cell.add(new Paragraph(headerName, fontChinese));
			table.addCell(cell);
		}

		List tableData = (List) model.get("tableData");
		for (int i = 0; i < tableData.size(); i++)
		{
			Map mapRow = (Map) tableData.get(i);
			for (int j = 0; j < headerInfo.size(); j++)
			{
				Map headRow = (Map) headerInfo.get(j);
				String fieldName = (String) headRow.get("fieldName");
				Cell cell = new Cell();
				cell.add(new Paragraph((String) mapRow.get(fieldName), fontChinese));
				table.addCell(cell);
			}
		}
		pdfDoc.add(new Paragraph((String) tableBasicInfo.get("chineseName"), fontChinese));
		pdfDoc.add(table);
	}

	protected PdfWriter newWriter(Document document, OutputStream os) throws DocumentException
	{
		return PdfWriter.getInstance(document, os);
	}
}
