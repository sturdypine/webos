package spc.webos.web.form.workflow;

import spc.webos.model.ValueObject;
import spc.webos.web.form.Form;

public class CommonWorkflowForm implements Form
{
	private static final long serialVersionUID = 1L;
	ValueObject wfVO;
	ValueObject stepVO;
	String action; // insert, update

	public ValueObject getWfVO()
	{
		return wfVO;
	}

	public void setWfVO(ValueObject wfVO)
	{
		this.wfVO = wfVO;
	}

	public ValueObject getStepVO()
	{
		return stepVO;
	}

	public void setStepVO(ValueObject stepVO)
	{
		this.stepVO = stepVO;
	}

	public String getAction()
	{
		return action;
	}

	public void setAction(String action)
	{
		this.action = action;
	}
}
