package spc.webos.web.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import spc.webos.constant.Common;
import spc.webos.constant.Web;
import spc.webos.log.Log;
import spc.webos.service.IService;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

public class WebUtil
{
	public final static WebUtil WEB_UTIL = new WebUtil();
	static Log log = Log.getLogger(WebUtil.class);

	public static Map request2map(HttpServletRequest req, Map params)
	{
		params = SystemUtil.freemarker(params);
		Enumeration names = req.getParameterNames();
		while (names.hasMoreElements())
		{
			String paramName = names.nextElement().toString();
			String value = req.getParameter(paramName);
			if (value != null && value.length() > 0) params.put(paramName, StringX.utf82str(value));
		}

		params.put(Common.MODEL_REQUEST_KEY, req);
		params.put(Common.MODEL_APP_PATH_KEY, req.getContextPath());
		params.put(Common.MODEL_WEB_UTIL_KEY, WEB_UTIL);
		return params;
	}

	// �������еõ����и����Ĳ�����
	public static List getUploadFileNames(HttpServletRequest req)
	{
		List names = new ArrayList();
		java.util.Enumeration enu = req.getParameterNames();
		while (enu.hasMoreElements())
		{
			String name = (String) enu.nextElement();
			if (name.startsWith("file.")) names.add(name);
		}
		return names;
	}

	// ִ�з���
	public static Object invokeService(HttpServletRequest req, String serviceMethod, Map params)
			throws Exception
	{
		if (StringX.nullity(serviceMethod)) serviceMethod = req
				.getParameter(Web.REQ_KEY_SERVICE_METHOD);
		if (StringX.nullity(serviceMethod)) return null;
		Object result = null;
		String[] serviceNames = serviceMethod.split(StringX.COMMA);
		for (int i = 0; i < serviceNames.length; i++)
		{
			String serviceName = serviceNames[i];
			int index = serviceName.indexOf('.');
			Object service = IService.SERVICES_PROXY.get(serviceName.substring(0, index));
			Method method = null;
			try
			{
				try
				{ // ���ȵ�����Map�����ķ���
					method = service.getClass().getMethod(serviceName.substring(index + 1),
							new Class[] { Map.class });
					result = method.invoke(service, new Object[] { params });
				}
				catch (Exception e)
				{
					method = service.getClass().getMethod(serviceName.substring(index + 1), null);
					result = method.invoke(service, null);
				}
			}
			catch (InvocationTargetException ite)
			{
				if (log.isInfoEnabled()) log
						.info("call:" + serviceMethod, ite.getTargetException());
			}
		}
		if (result != null) params.put(Web.REQ_KEY_SERVICE_DATA, result);
		return result;
	}
}

/**
 * ��Request��װΪһ��Map, ���ڸ���ʶ��Map�Ĳ���
 * 
 * @author Hate
 */
/*
 * class RequestSessionMap extends HashMap { private static final long
 * serialVersionUID = 1L;
 * 
 * public RequestSessionMap(HttpServletRequest req) { super(); data = req; }
 * 
 * public RequestSessionMap(HttpSession session) { super(); data = session; }
 * 
 * public Object get(Object key) { Object value = super.get(key);
 * System.out.println("key: " + key + ", v : " + value); if (value != null)
 * return value; if (data instanceof HttpServletRequest) { HttpServletRequest
 * req = (HttpServletRequest) data; String strKey = key.toString(); if
 * (strKey.startsWith("attr_")) return req.getAttribute(strKey); else if
 * (strKey.startsWith("param_")) return req .getParameter(strKey); // else if
 * (strKey.startsWith("params_")) value = req.getParameter(strKey); } else if
 * (data instanceof HttpSession) { value = ((HttpSession)
 * data).getAttribute(key.toString()); } return value; }
 * 
 * Object data; }
 */