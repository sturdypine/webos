package spc.webos.web.listener;

import java.net.InetAddress;
import java.util.Map;

import javax.servlet.ServletContextEvent;

import org.apache.derby.drda.NetworkServerControl;

import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;

/**
 * ����spring����ǰ����derby
 * 
 * @author spc
 * 
 */
public class CxtLoaderWithDerbyListener extends CxtLoaderListener
{
	public final static String DERBY_CONFIG = "derbyConfig";

	public void contextInitialized(ServletContextEvent event)
	{
		if (!startServer(event)) System.out.println("Err to start derby...");
		super.contextInitialized(event);
	}

	public void contextDestroyed(ServletContextEvent event)
	{
		super.contextDestroyed(event);
		System.out.println("start to stop derby");
		NetworkServerControl.main(new String[] { "shutdown", "-p", String.valueOf(port),
				"-noSecurityManager" });
		try
		{
			Thread.sleep(1000);
		}
		catch (InterruptedException e)
		{
		}
	}

	public boolean startServer(ServletContextEvent event)
	{
		try
		{
			String derbyCfg = event.getServletContext().getInitParameter(DERBY_CONFIG);
			if (!StringX.nullity(derbyCfg))
			{
				Map derbyParams = (Map) JsonUtil.json2obj(derbyCfg);
				Object val = derbyParams.get("port");
				if (val != null) port = Integer.parseInt(val.toString());
				String home = (String) derbyParams.get("home");
				if (!StringX.nullity(home))
				{
					home = StringX.replaceAll(home, "{webapp.root}", event.getServletContext()
							.getRealPath(StringX.EMPTY_STRING).replace('\\', '/'));
					System.setProperty("derby.system.home", home);
				}
			}
			new NetworkServerThread(port).start();
			Thread.sleep(1000);
			server = new NetworkServerControl(InetAddress.getByName("localhost"), port);
			return isServerStarted(server, 4);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	private static boolean isServerStarted(NetworkServerControl networkservercontrol, int i)
	{
		int j = 1;
		while (true)
		{
			if (j > i) break;
			j++;
			try
			{
				Thread.sleep(500L);
				networkservercontrol.ping();
			}
			catch (Exception e)
			{
				if (j >= i) return false;
				continue;
			}
			return true;
		}
		return false;
	}

	private int port = 1527;
	// private String tracingDirectory;
	private NetworkServerControl server;
}

class NetworkServerThread extends Thread
{
	private int port;

	public NetworkServerThread(int port)
	{
		this.port = port;
		setDaemon(true);
	}

	public void run()
	{
		try
		{
			System.out.println("derby start: " + port);
			NetworkServerControl.main(new String[] { "start", "-p", String.valueOf(port),
					"-noSecurityManager" });
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
	}
}
