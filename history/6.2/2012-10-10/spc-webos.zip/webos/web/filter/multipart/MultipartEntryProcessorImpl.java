package spc.webos.web.filter.multipart;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class MultipartEntryProcessorImpl implements MultipartEntryProcessor
{
	protected File tempDir = null;
	protected OutputStream output = null;
	protected MultipartEntry entry = null;
	protected StringBuffer parameterValue = new StringBuffer();
	protected String sessionId = null;
	MultipartFilter filter;

	public MultipartEntryProcessorImpl(File tempDir, String sessionId, MultipartFilter filter)
	{
		this.sessionId = sessionId;
		this.tempDir = tempDir;
		this.filter = filter;
		if (!tempDir.exists()) tempDir.mkdirs();
	}

	public void beginEntry(MultipartEntry entry)
	{
		this.entry = entry;
		if (entry.isFile())
		{
			String tempFileName = this.tempDir.getAbsolutePath() + File.separator
					+ entry.getFileNameOnly() + "." + this.sessionId;

			this.entry.setTempFileName(tempFileName);
			try
			{
				this.output = new BufferedOutputStream(new FileOutputStream(tempFileName), 8 * 1024);
			}
			catch (FileNotFoundException e)
			{
				e.printStackTrace();
			}
		}
		else if (entry.isParameter())
		{
			parameterValue.delete(0, parameterValue.length());
		}
	}

	public void addByte(int data)
	{
		if (this.entry.isFile())
		{
			try
			{
				this.output.write(data);
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		else if (this.entry.isParameter())
		{
			parameterValue.append((char) data);
		}
	}

	public void addBytes(byte[] bytes, int start, int length)
	{
		if (this.entry.isFile())
		{
			try
			{
				output.write(bytes, start, length);
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		else if (this.entry.isParameter())
		{
			parameterValue.append(new String(bytes, start, length));
		}
	}

	// todo when trailining line breaks after files and parameter values are
	// removed, remove the
	// this.parameterValue.toString().trim() call.

	public void endEntry()
	{
		try
		{
			if (entry.isFile())
				output.close();
			else if (entry.isParameter())
			{
				if (filter.getTargetCharset() != null)
					entry.setParameterValue(new String(parameterValue.toString().trim().getBytes(
							filter.getSourceCharset()), filter.getTargetCharset()));
				else entry.setParameterValue(parameterValue.toString().trim());
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		this.entry = null;
	}

	public void dispose()
	{
		try
		{
			finalize();
		}
		catch (Throwable throwable)
		{
		}
	}

	protected void finalize() throws Throwable
	{
		super.finalize();

		tempDir = null;
		output = null;
		entry = null;
		parameterValue = null;
		sessionId = null;
	}
}
