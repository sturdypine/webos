package spc.webos.web.filter;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import spc.webos.log.Log;
import spc.webos.util.StringX;

public class LoggerFilter extends AbstractURLFilter
{
	public static final String EXT_URL_KEY = "url";
	public static final String EXT_METHOD_KEY = "method";
	public static final String DEFAULT_LOG = "request";

	public void filter(ServletRequest req, ServletResponse res, FilterChain chain, String patternURL)
			throws IOException, ServletException
	{
		HttpServletRequest request = (HttpServletRequest) req;
		long start = System.currentTimeMillis();
		// ByteArrayOutputStream baos = new ByteArrayOutputStream();
		// SystemUtil.is2os(request.getInputStream(), baos, true, true);
		// System.out.println("log: "+baos.toString());

		Map paramMap = queryStringToMap(patternURL);
		String logName = (String) paramMap.get("name");
		String logLevel = (String) paramMap.get("level");

		Map ext = new HashMap();
		String query = request.getQueryString();
		String url = StringX.nullity(query) ? request.getRequestURI() : request.getRequestURI()
				+ '?' + query;
		ext.put(EXT_URL_KEY, url);
		ext.put(EXT_METHOD_KEY, request.getMethod());
		Log.setLogExt(ext);

		Log.start(!StringX.nullity(logName) ? logName : DEFAULT_LOG);
		if (!StringX.nullity(logLevel)) Log.setCurLevel(logLevel);
		// System.out.println("patternURL:" + patternURL + ",ext:" + ext +
		// ",logname:" + logName);
		if (log.isInfoEnabled()) log.info("url:" + url + ", method:" + request.getMethod()
				+ ", remote:" + request.getRemoteAddr() + ", logname:" + logName + ", loglevel:"
				+ logLevel + ", thread:" + Thread.currentThread().getName());
		try
		{
			chain.doFilter(req, res);
		}
		catch (ServletException se)
		{
			log.info("LoggerFilter", se);
			throw se;
		}
		finally
		{
			if (log.isInfoEnabled()) log.info("E: (" + (System.currentTimeMillis() - start)
					+ "), jvm free: " + (Runtime.getRuntime().freeMemory() / 1000000) + "M");
			Log.print();
			Log.printNotice();
		}
	}
}
