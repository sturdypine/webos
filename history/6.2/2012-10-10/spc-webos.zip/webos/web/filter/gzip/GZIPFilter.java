package spc.webos.web.filter.gzip;

/**
 * ������ѹ���󷵻ؿͻ���, ����������������.. ��filterӦ�÷��ڶ�Filter�������
 */
import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import spc.webos.web.filter.AbstractURLFilter;

public class GZIPFilter extends AbstractURLFilter
{
	public final static String HTTP_HEADER_CONTENT_ENCODING = "content-encoding";
	public final static String HTTP_HEADER_ACCEPT_ENCODING = "accept-encoding";
	public final static String ENCODING_GZIP = "gzip";

	public void filter(ServletRequest req, ServletResponse res, FilterChain chain, String patternURL)
			throws IOException, ServletException
	{
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) res;

		HttpServletRequest wrappedRequest = request;
		String ce = request.getHeader(HTTP_HEADER_CONTENT_ENCODING);
		if (ce != null && ce.indexOf(ENCODING_GZIP) != -1)
		{
			// System.out.println("GZIPFilter(in yes): " +
			// request.getRequestURI());
			wrappedRequest = new GZIPRequestWrapper(request);
		}

		// System.out.println(request.getRequestURI()+ ", getQueryString =
		// "+request.getQueryString());
		// Enumeration headers = request.getHeaderNames();
		// while (headers.hasMoreElements())
		// {
		// String h = (String) headers.nextElement();
		// System.out.println("encode= " + h + ", " + request.getHeader(h));
		// }
		// "content-encoding"
		String ae = request.getHeader(HTTP_HEADER_ACCEPT_ENCODING);
		if (ae != null && ae.indexOf(ENCODING_GZIP) != -1)
		{
			// System.out.println("GZIPFilter(out yes): " +
			// request.getRequestURI());
			// System.out.println("GZIP supported, compressing.");
			GZIPResponseWrapper wrappedResponse = new GZIPResponseWrapper(response);
			chain.doFilter(wrappedRequest, wrappedResponse);
			wrappedResponse.finishResponse();
			return;
		}
		chain.doFilter(wrappedRequest, res);
	}
}
