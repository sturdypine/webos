package spc.webos.endpoint;

import spc.webos.pool.ObjectPool;

public class EndpointPool extends ObjectPool
{
	protected Endpoint endpoint;

	public EndpointPool()
	{
	}

	public EndpointPool(int max, Endpoint endpoint)
	{
		this.max = max;
		this.endpoint = endpoint;
	}

	public Object newIntance() throws Exception
	{
		Endpoint point = endpoint.clone();
		point.init();
		return point;
	}

	public synchronized Object borrow() throws Exception
	{
		Endpoint point = null;
		if (pool.size() == 0)
		{
			log.warn("pool is empty, need to borrow one object:" + getClass().getName() + ", name:"
					+ name + ", max:" + max);
			point = (Endpoint) newIntance();
		}
		else point = (Endpoint) pool.removeFirst();
		return point;
	}

	public boolean release(Object obj)
	{
		Endpoint point = (Endpoint) obj;
		if (!super.release(point)) point.destory();
		return true;
	}

	public void destory()
	{
		if (log.isInfoEnabled()) log.info("start to destory object pool(" + name + ") : "
				+ pool.size());
		for (int i = 0; i < pool.size(); i++)
			((Endpoint) pool.get(i)).destory();
		pool.clear();
	}

	public void setEndpoint(Endpoint endpoint)
	{
		this.endpoint = endpoint;
	}
}
