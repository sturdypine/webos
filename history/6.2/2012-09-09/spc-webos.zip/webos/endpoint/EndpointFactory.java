package spc.webos.endpoint;

import java.util.ArrayList;
import java.util.List;

import spc.webos.log.Log;
import spc.webos.util.StringX;

/**
 * ������Դ�����, ��̬����endpoint���͡�����tcp://192.168.0.01:8080,
 * http://192.168.0.01:8080/FA/ws. Ŀǰֻ֧��tcp/httpЭ��
 * 
 * @author chenjs
 * 
 */
public class EndpointFactory
{
	public Endpoint getEndpoint(String location) throws Exception
	{
		if (StringX.nullity(location)) return null;
		location = StringX.trim(location);
		String[] locs = location.split(",|;");
		if (locs.length > 1)
		{ // ˵���Ǽ�Ⱥģʽ
			List endpoints = new ArrayList();
			for (int i = 0; i < locs.length; i++)
			{
				Endpoint endpoint = getEndpoint(locs[i]);
				if (endpoint != null) endpoints.add(endpoint);
			}
			if (endpoints.size() == 0) return null;
			if (endpoints.size() == 1) return (Endpoint) endpoints.get(0);
			return new ClusterEndpoint(endpoints);
		}
		String loc = location.toLowerCase();
		if (loc.startsWith("tcp"))
		{ // is a tcp protocol
			SocketEndpoint endpoint = new SocketEndpoint(location);
			endpoint.init();
			return endpoint;
		}
		else if (loc.startsWith("http")) return new HttpEndpoint(location);
		else if (loc.startsWith("udp"))
		{
			UDPEndpoint endpoint = new UDPEndpoint(location);
			endpoint.init();
			return endpoint;
		}
		log.warn("undefined protocal: " + location);
		return null;
	}

	static EndpointFactory factory = new EndpointFactory();

	public static EndpointFactory getInstance()
	{
		return factory;
	}

	protected Log log = Log.getLogger(EndpointFactory.class);
}
