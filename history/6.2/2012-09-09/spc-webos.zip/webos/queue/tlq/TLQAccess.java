package spc.webos.queue.tlq;

import java.io.IOException;

import spc.webos.constant.AppRetCode;
import spc.webos.constant.Common;
import spc.webos.exception.AppException;
import spc.webos.log.Log;
import spc.webos.queue.IQueueAccess;
import spc.webos.queue.QueueMessage;

import com.tongtech.tlq.base.TlqException;
import com.tongtech.tlq.base.TlqMessage;
import com.tongtech.tlq.base.TlqMsgOpt;

public class TLQAccess implements IQueueAccess
{
	protected TLQCnnPool cnnPool;
	protected Log log = Log.getLogger(getClass());

	public void destroy()
	{
		if (cnnPool != null) cnnPool.destroy();
	}

	public void send(String qname, QueueMessage qmsg) throws Exception
	{
		TLQManager tlqm = (TLQManager) cnnPool.borrow();
		try
		{
			if (log.isInfoEnabled()) log.info("sn:" + qmsg.sn + ", corId:"
					+ (qmsg.correlationId != null ? new String(qmsg.correlationId) : ""));
			if (log.isDebugEnabled()) log.debug("req:" + new String(qmsg.buf, Common.CHARSET_UTF8));
			tlqm.connect(1);

			TlqMessage tlqmsg = QMsgtoTLQMsg(qmsg, new TlqMessage());
			TlqMsgOpt msgOpt = new TlqMsgOpt();
			msgOpt.OperateType = TlqMsgOpt.TLQOT_PUT;
			msgOpt.QueName = qname;
			tlqm.tlqQcu.putMessage(tlqmsg, msgOpt);
		}
		catch (TlqException tlqex)
		{
			log.warn("send", tlqex);
			if (TLQManager.isCnnBrokenEx(tlqex)) tlqm.disconnect(); // �����ǰ�쳣�������쳣��ر�����
			throw new AppException(AppRetCode.PROTOCOL_MQ(), new Object[] { qname,
					String.valueOf(tlqex.getTlqErrno()), String.valueOf(tlqex.getErrorCode()) });
		}
		finally
		{
			cnnPool.release(tlqm);
		}
	}

	public QueueMessage receive(String qname, byte[] correlationId, int timeout) throws Exception
	{
		TLQManager tlqm = (TLQManager) cnnPool.borrow();
		try
		{
			tlqm.connect(1);

			TlqMessage tlqmsg = new TlqMessage();
			TlqMsgOpt msgOpt = new TlqMsgOpt();
			msgOpt.QueName = qname;
			msgOpt.WaitInterval = timeout;
			if (correlationId != null)
			{
				msgOpt.MatchOption = TlqMsgOpt.TLQMATCH_CORRMSGID;
				tlqmsg.CorrMsgId = correlationId;
			}
			msgOpt.OperateType = TlqMsgOpt.TLQOT_GET;
			tlqm.tlqQcu.getMessage(tlqmsg, msgOpt);
			QueueMessage qmsg = TLQMsgtoMQMsg(tlqmsg, new QueueMessage());
			qmsg.qname = qname;
			return qmsg;
		}
		catch (TlqException tlqex)
		{
			log.warn("receive", tlqex);
			if (TLQManager.isCnnBrokenEx(tlqex)) tlqm.disconnect(); // �����ǰ�쳣�������쳣��ر�����
			throw new AppException(AppRetCode.PROTOCOL_MQ(), new Object[] { qname,
					String.valueOf(tlqex.getTlqErrno()), String.valueOf(tlqex.getErrorCode()) });
		}
		finally
		{
			cnnPool.release(tlqm);
		}
	}

	public QueueMessage execute(String reqQName, String repQName, QueueMessage qmsg, int timeout)
			throws Exception
	{
		send(reqQName, qmsg);
		return receive(repQName, qmsg.correlationId, timeout);
	}

	public static TlqMessage QMsgtoTLQMsg(QueueMessage qmsg, TlqMessage tlqmsg) throws IOException
	{
		if (qmsg.correlationId != null) tlqmsg.CorrMsgId = qmsg.correlationId;
		if (qmsg.messageId != null) tlqmsg.MsgId = qmsg.messageId;
		if (qmsg.expirySeconds > 0) tlqmsg.Expiry = qmsg.expirySeconds;
		// if (!StringX.nullity(qmsg.applicationIdData)) mqmsg.applicationIdData
		// = applicationIdData;
		// if (!StringX.nullity(qmsg.applicationOriginData))
		// mqmsg.applicationOriginData = applicationOriginData;
		// if (!StringX.nullity(qmsg.putAppName)) mqmsg.putApplicationName =
		// putAppName;
		// mqmsg.feedback = feedback;
		if (qmsg.priority >= 0) tlqmsg.Priority = (char) qmsg.priority;

		tlqmsg.MsgType = TlqMessage.BUF_MSG; // ��Ϣ����
		tlqmsg.MsgSize = qmsg.buf.length; // ��Ϣ��С
		tlqmsg.setMsgData(qmsg.buf);
		return tlqmsg;
	}

	public static QueueMessage TLQMsgtoMQMsg(TlqMessage tlqmsg, QueueMessage qmsg)
			throws IOException
	{
		qmsg.correlationId = tlqmsg.CorrMsgId;
		qmsg.messageId = tlqmsg.MsgId;
		// if (!StringX.nullity(qmsg.applicationIdData)) mqmsg.applicationIdData
		// = applicationIdData;
		// if (!StringX.nullity(qmsg.applicationOriginData))
		// mqmsg.applicationOriginData = applicationOriginData;
		// if (!StringX.nullity(qmsg.putAppName)) mqmsg.putApplicationName =
		// putAppName;
		// mqmsg.feedback = feedback;

		qmsg.buf = tlqmsg.getMsgData();
		return qmsg;
	}

	public void setCnnPool(TLQCnnPool cnnPool)
	{
		this.cnnPool = cnnPool;
	}
}
