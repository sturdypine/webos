package spc.webos.queue.tlq;

import java.util.Hashtable;

import spc.webos.constant.AppRetCode;
import spc.webos.exception.AppException;
import spc.webos.log.Log;

import com.tongtech.tlq.base.TlqConnContext;
import com.tongtech.tlq.base.TlqConnection;
import com.tongtech.tlq.base.TlqException;
import com.tongtech.tlq.base.TlqQCU;

/**
 * MQ �������Ӷ��󣬺���������
 * 
 * @author spc
 * 
 */
public class TLQManager
{
	public TlqConnection tlqCnn;
	public TlqQCU tlqQcu;
	public Hashtable props;
	protected long createTm; // ����ʱ��
	public int holdtime = -1; //
	// ���ӵ���󱣴�ʱ�䣬��������Զ�̵�MQ����HA�������һ�������̣߳��������ڼ���������Ϣ��
	protected long lastUseTm; // ��һ��ʹ��ʱ��
	public int idletime = -1;

	public static final String QM_NAME = "qmName";
	public static int CNN_EXCEPTION_SLEEP = 30; // �쳣����˯��
	static final Log log = Log.getLogger(TLQManager.class);

	public TLQManager()
	{
	}

	public TLQManager(Hashtable props, int holdtime, int idletime)
	{
		this.props = props;
		this.holdtime = holdtime;
		this.idletime = idletime;
	}

	public void connect(int count)
	{
		if (validate()) return;
		reconnect(count);
	}

	public boolean validate()
	{
		return tlqQcu != null
				&& (holdtime <= 0 || System.currentTimeMillis() - createTm < holdtime * 1000)
				&& (idletime <= 0 || System.currentTimeMillis() - lastUseTm < idletime * 1000);
	}

	public void reconnect(int count)
	{
		if (log.isInfoEnabled()) log.info("reconnect : " + count + ", props: " + props);
		long i = 0;
		String qmname = (String) props.get(QM_NAME);
		while (true)
		{
			try
			{
				disconnect();

				TlqConnContext tlqCnnCxt = new TlqConnContext();
				// tlqConnContext.BrokerId = 111; //���� tlqcli.conf�е�����
				tlqCnnCxt.BrokerId = -1;
				tlqCnnCxt.HostName = (String) props.get("hostname");
				tlqCnnCxt.ListenPort = Integer.parseInt(props.get("port").toString());
				tlqCnn = new TlqConnection(tlqCnnCxt);
				tlqQcu = tlqCnn.openQCU(qmname);

				createTm = System.currentTimeMillis(); // ��������ʱ��
				lastUseTm = System.currentTimeMillis();
				return;
			}
			catch (TlqException tlqex)
			{
				log.warn("TLQ access error:" + props + ", failtimes:" + i + ", sleep:"
						+ CNN_EXCEPTION_SLEEP + " seconds,count:" + count, tlqex);
				Log.print();
				i++;
				if (count >= 0 && i >= count) throw new AppException(AppRetCode.PROTOCOL_TLQ(),
						new Object[] { qmname, String.valueOf(tlqex.getTlqErrno()),
								String.valueOf(tlqex.getErrorCode()) });
				try
				{
					Thread.sleep(CNN_EXCEPTION_SLEEP * 1000);
				}
				catch (Exception ee)
				{
				}
				if (count < 0) continue;
			}
			finally
			{
				Log.print();
			}
		}
	}

	public void disconnect()
	{
		if (tlqCnn == null) return;
		log.warn("tlqcnn will disconnect:" + props);
		try
		{
			tlqQcu.close();
		}
		catch (TlqException e)
		{
			log.warn("tlqQcu close:" + props, e);
		}
		tlqQcu = null;
		try
		{
			tlqCnn.close();
		}
		catch (TlqException e)
		{
			log.warn("tlqcnn close:" + props, e);
		}
		tlqCnn = null;
	}

	public static boolean isCnnBrokenEx(TlqException tlqex)
	{
		return !isNoMsgEx(tlqex);
	}

	public static boolean isNoMsgEx(TlqException tlqex)
	{
		return tlqex.getTlqErrno() == 2603;
	}
}
