package spc.webos.flownode.impl;

import spc.webos.Main;
import spc.webos.data.IMessage;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.SystemUtil;

/**
 * JVM�յ�ͣ����ָ��Ĵ���
 * 
 * @author spc
 * 
 */
public class JVMHaltAFNode extends AbstractFNode
{
	public static final String DEFAULT_NAME = "Halt";

	public JVMHaltAFNode()
	{
		name = DEFAULT_NAME;
	}

	public Object execute(IMessage msg, IFlowContext cxt)
	{
		Main.stop();
		msg.setInResponse("jvm", SystemUtil.JVM);
		msg.setInResponse("msg", "JVM(" + SystemUtil.JVM
				+ ") will halt in seconds...");
		return null;
	}
}
