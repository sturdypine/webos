package spc.webos.flownode.action;

import java.util.Map;

import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

/**
 * ����������
 * 
 * @author spc
 * 
 */
public class SubProcessCallAction extends TargetFNodeAction
{
	private static final long serialVersionUID = 1L;

	public void execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		String subProcess = getSubProcessName(msg, cxt);
		if (log.isInfoEnabled()) log.info("subProcess: " + subProcess);
		msg.setInLocal(MsgLocalKey.LOCAL_JBPM_PROCESS_NAME, subProcess);
		super.execute(msg, cxt);
	}

	protected String getSubProcessName(IMessage msg, IFlowContext cxt) throws Exception
	{
		if (!StringX.nullity(subProcessName)) return subProcessName;
		if (!StringX.nullity(subProcessNameTemplate))
		{
			Map root = SystemUtil.freemarker(null, msg);
			root.put(Common.MODEL_CXT_KEY, cxt);
			return StringX.trim(SystemUtil.freemarker(subProcessNameTemplate, root));
		}
		return (String) msg.getInLocal(MsgLocalKey.SUB_PROCESS_NAME_KEY);
	}

	public SubProcessCallAction()
	{
		fnodes = "jbpm3Syn"; // Ĭ��Ϊͬ������
	}

	// public final static String SUB_PROCESS_NAME_KEY = "SUB_PROC_NAME";
	protected String subProcessName;
	protected String subProcessNameTemplate;

	public String getSubProcessName()
	{
		return subProcessName;
	}

	public void setSubProcessName(String subProcessName)
	{
		this.subProcessName = subProcessName;
	}

	public String getSubProcessNameTemplate()
	{
		return subProcessNameTemplate;
	}

	public void setSubProcessNameTemplate(String subProcessNameTemplate)
	{
		this.subProcessNameTemplate = subProcessNameTemplate;
	}
}
