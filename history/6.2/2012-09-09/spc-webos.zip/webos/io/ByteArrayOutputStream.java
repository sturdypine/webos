package spc.webos.io;

import java.io.IOException;
import java.io.OutputStream;

public class ByteArrayOutputStream extends OutputStream
{
	ByteArray buf;

	public ByteArray getBuf()
	{
		return buf;
	}

	public void setBuf(ByteArray buf)
	{
		this.buf = buf;
	}

	public ByteArrayOutputStream()
	{
		this.buf = new ByteArray();
	}

	public ByteArrayOutputStream(ByteArray buf)
	{
		this.buf = buf;
	}

	public void write(int b) throws IOException
	{
		buf.write((byte) b);
	}

	public void write(byte b[], int off, int len)
	{
		buf.write(b, off, len);
	}
}
