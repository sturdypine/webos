package spc.webos.util.tree;

public interface ITreeNodeMatcher
{
	boolean match(TreeNode tnode);
}
