package spc.webos.ws.wsdl;

import java.io.StringWriter;
import java.util.List;
import java.util.Map;

import spc.webos.data.INode;
import spc.webos.model.MsgSchemaVO;
import spc.webos.service.Service;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;
import spc.webos.util.tree.TreeNode;
import freemarker.template.Template;

public class Wsdl11DefinitionService extends Service implements IWsdl11DefinitionService
{
	String path = StringX.EMPTY_STRING;
	String schemaFtl = "schema.ftl";
	String wsdlFtl = "wsdl.ftl";
	boolean array2 = true; // �Ƿ�������ñ�׼��ģʽ������<array><v></v></array>ģʽ
	final static String MODEL_KEY = "MODEL";
	final static String MODEL_IMPORT = "IMPORT"; // wsdl���Ƿ����ȫ�ĵ�schema�ļ�
	final static String REQUEST_KEY = "REQUEST";
	final static String RESPONSE_KEY = "RESPONSE";

	public String wsdl(Map param) throws Exception
	{
		if (!MODEL_IMPORT.equals((String) param.get(MODEL_KEY)))
		{
			param.put("noheader", Boolean.TRUE);
			param.put("schema", schema(param));
		}
		Template t = SystemUtil.getInstance().getFtlCfg().getTemplate(path + wsdlFtl);
		StringWriter sw = new StringWriter();
		t.process(param, sw);
		return sw.toString();
	}

	public String schema(Map param) throws Exception
	{
		String msgCd = (String) param.get("reqMsgCd");
		String resMsgCd = (String) param.get("resMsgCd");

		return schema(msgCd, createTree(msgCd), createTree(resMsgCd), param);
	}

	/**
	 * ����һ�����ı��, һ�������Ľṹ�� һ����Ӧ���Ľṹ����һ��schema
	 * 
	 * @param msgCd
	 * @param reqRoot
	 * @param resRoot
	 * @return
	 * @throws Exception
	 */
	public String schema(String msgCd, TreeNode reqRoot, TreeNode resRoot, Map param)
			throws Exception
	{
		StringBuffer request = new StringBuffer();
		StringBuffer response = new StringBuffer();

		MsgSchemaVO vo = null;
		if (resRoot != null && resRoot.getChildren() != null)
		{
			vo = (MsgSchemaVO) resRoot.getTreeNodeValue();
			vo.setFtyp("M");
			response.append(struct2schema(resRoot, RESPONSE_KEY));
		}

		if (reqRoot != null && reqRoot.getChildren() != null)
		{
			vo = (MsgSchemaVO) reqRoot.getTreeNodeValue();
			vo.setFtyp("M");
			request.append(struct2schema(reqRoot, REQUEST_KEY));
		}

		Template t = null;
		try
		{
			t = SystemUtil.getInstance().getFtlCfg().getTemplate(path + msgCd + ".ftl");
		}
		catch (Exception e)
		{
		}
		try
		{
			if (t == null) t = SystemUtil.getInstance().getFtlCfg().getTemplate(
					path + msgCd.substring(0, 3) + ".ftl"); // ���û�����ݽ��������ö����Ľ����ļ������Ƿ�ϵͳ��ͳһ�Ľ����ļ�
		}
		catch (Exception e)
		{
		}
		if (t == null) t = SystemUtil.getInstance().getFtlCfg().getTemplate(path + schemaFtl);
		if (request.length() > 5) param.put(REQUEST_KEY, request.toString());
		if (response.length() > 5) param.put(RESPONSE_KEY, response.toString());
		StringWriter sw = new StringWriter();
		t.process(param, sw);
		return sw.toString();
	}

	String atom2schema(String prefix, String name, String type, MsgSchemaVO msgstruct, boolean array)
	{
		return prefix + "<xs:element name=\"" + name + "\" type=\"" + type + "\" minOccurs=\""
				+ (msgstruct.getOptional().equals("M") ? "1" : "0")
				+ (array ? "\" />" : "\" maxOccurs='1' />");
	}

	/**
	 * ����һ�����ı�Ŵ����ݿ����ҵ��˱�ŵĽ��׽ṹ
	 * 
	 * @param msgCd
	 * @return
	 */
	TreeNode createTree(String msgCd)
	{
		if (StringX.nullity(msgCd)) return null;
		MsgSchemaVO msgStructVO = new MsgSchemaVO();
		msgStructVO.setMsgCd(msgCd);
		List msgStructs = persistence.get(msgStructVO);
		if (msgStructs == null || msgStructs.size() == 0) return null;
		msgStructVO = new MsgSchemaVO();
		msgStructVO.setSeq(new Integer(0));
		msgStructs.add(msgStructVO); // ����һ�����ڵ�

		TreeNode root = new TreeNode();
		root.createTree(msgStructs);
		return root;
	}

	String array2schema(TreeNode node, String type)
	{
		StringBuffer schema = new StringBuffer();
		List child = node.getChildren();
		String t = type;
		if (child == null || child.size() == 0)
		{ // ����ڵ�Ϊԭ�ӽڵ�
			t = "string";
		}
		else
		{ // Ϊmap����
			t = type;
			schema.append(struct2schema(node, t));
		}
		if (!array2)
		{
			schema.append("\n<xs:complexType name=\"" + type + "Array\">");
			schema.append("\n\t<xs:element name=\"v\" type=\"" + t + "\" minOccurs=\"1\" />"); // ��������飬������ǩ����ʱ����Ҫ��Ԫ��
			schema.append("\n</xs:complexType>");
		}
		return schema.toString();
	}

	// �ṹ���ͱ�Ϊschema
	public String struct2schema(TreeNode node, String type)
	{
		List child = node.getChildren();
		StringBuffer schema = new StringBuffer();
		for (int i = 0; i < child.size(); i++)
		{
			TreeNode n = (TreeNode) child.get(i);
			MsgSchemaVO vo = (MsgSchemaVO) n.getTreeNodeValue();
			// System.out.println(vo);
			// System.out.println(vo.getReqName()+":"+(vo.getFtype().charAt(0)
			// == (char) INode.TYPE_MAP));
			if (vo.getFtyp().charAt(0) == (char) INode.TYPE_MAP) // �ڵ㻹��map
			schema.append(struct2schema(n, vo.getEsbName() + "Type"));
			else if (vo.getFtyp().charAt(0) == (char) INode.TYPE_ARRAY)
			{
				schema.append(array2schema(n, vo.getEsbName() + "Type"));
			}
		}
		schema.append("\n<xs:complexType name=\"" + type + "\">");
		for (int i = 0; i < child.size(); i++)
		{
			TreeNode n = (TreeNode) child.get(i);
			MsgSchemaVO vo = (MsgSchemaVO) n.getTreeNodeValue();
			if (vo.getFtyp().charAt(0) == (char) INode.TYPE_MAP) // �ڵ㻹��map
			schema
					.append(atom2schema("\n\t", vo.getEsbName(), vo.getEsbName() + "Type", vo,
							false));
			else if (vo.getFtyp().charAt(0) == (char) INode.TYPE_ARRAY) schema.append(atom2schema(
					"\n\t", vo.getEsbName(), vo.getEsbName() + (array2 ? "Type" : "TypeArray"), vo,
					array2));
			else schema.append(atom2schema("\n\t", vo.getEsbName(), "xs:string", vo, false));
		}
		schema.append("\n</xs:complexType>");
		return schema.toString();
	}

	public void setPath(String path)
	{
		this.path = path;
	}

	public void setSchemaFtl(String schemaFtl)
	{
		this.schemaFtl = schemaFtl;
	}

	public void setArray2(boolean array2)
	{
		this.array2 = array2;
	}

	public void setWsdlFtl(String wsdlFtl)
	{
		this.wsdlFtl = wsdlFtl;
	}
}
