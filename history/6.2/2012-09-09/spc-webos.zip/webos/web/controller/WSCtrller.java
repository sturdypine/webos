package spc.webos.web.controller;

import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;
import org.xml.sax.InputSource;

import spc.webos.constant.Common;
import spc.webos.data.ICompositeNode;
import spc.webos.data.converter.SaxHandler;
import spc.webos.data.converter.XMLConverter;
import spc.webos.log.Log;
import spc.webos.ws.endpoint.MessageSaxEndpoint;

/**
 * �򵥵�webservice���ܴ���ctrller
 * 
 * @author spc
 * 
 */
public class WSCtrller implements Controller
{
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response)
			throws Exception
	{
		if (log.isInfoEnabled()) log.info("WS request: " + request.getRemoteAddr() + ", uri: "
				+ request.getRequestURI());
		InputStream is = request.getInputStream();
		SaxHandler handler = (SaxHandler) msgSaxEndpoint.createContentHandler();
		InputSource input = new InputSource(is);
		input.setEncoding(incharset);
		XMLConverter.getXMLReader(handler).parse(input);
		ICompositeNode body = handler.root().findComposite(argPath, null);
		if (bodyFirstChild) body = getBodyFirstChild(body);
		handler.root().clear();
		handler.root().set(body);
		if (log.isDebugEnabled()) log.debug("WS req body: " + body.toXml("body", true));
		String repsoap = msgSaxEndpoint.getResponseAsString(handler);
		if (log.isDebugEnabled()) log.debug("WS rep body: " + repsoap);
		response.setCharacterEncoding(outcharset);
		response.setContentType(Common.FILE_XML_CONTENTTYPE);
		response.getWriter().write(SOAP_ROOT_START_TAG);
		response.getWriter().write(repsoap);
		// response.getWriter().write(
		// new String(FileUtil.file2bytes(new File("r:/soap-rep.xml")),
		// "utf-8"));
		response.getWriter().write(SOAP_ROOT_END_TAG);
		return null;
	}

	protected ICompositeNode getBodyFirstChild(ICompositeNode soapBody)
	{
		String key = soapBody.keys().next().toString();
		return soapBody.findComposite(key, null);
	}

	// added by chenjs 2011-12-20 SOAP body�е�һ������Ϊ esb body
	protected boolean bodyFirstChild;
	protected String argPath = "Body/tran";
	protected String outcharset = Common.CHARSET_UTF8;
	protected String incharset = Common.CHARSET_UTF8;
	protected MessageSaxEndpoint msgSaxEndpoint;
	protected Log log = Log.getLogger(getClass());
	public final String SOAP_ROOT_START_TAG = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\"><SOAP-ENV:Header/><SOAP-ENV:Body>";
	public final String SOAP_ROOT_END_TAG = "</SOAP-ENV:Body></SOAP-ENV:Envelope>";

	public void setOutcharset(String outcharset)
	{
		this.outcharset = outcharset;
	}

	public void setIncharset(String incharset)
	{
		this.incharset = incharset;
	}

	public void setMsgSaxEndpoint(MessageSaxEndpoint msgSaxEndpoint)
	{
		this.msgSaxEndpoint = msgSaxEndpoint;
	}

	public void setEndpoint(MessageSaxEndpoint msgSaxEndpoint)
	{
		this.msgSaxEndpoint = msgSaxEndpoint;
	}

	public void setArgPath(String argPath)
	{
		this.argPath = argPath;
	}

	public void setBodyFirstChild(boolean bodyFirstChild)
	{
		this.bodyFirstChild = bodyFirstChild;
	}
}
