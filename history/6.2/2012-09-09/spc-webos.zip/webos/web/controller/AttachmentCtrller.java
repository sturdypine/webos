package spc.webos.web.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import spc.webos.constant.Common;
import spc.webos.constant.Web;
import spc.webos.jdbc.JdbcUtil;
import spc.webos.jdbc.blob.FileBlob;
import spc.webos.model.ValueObject;
import spc.webos.persistence.IPersistence;
import spc.webos.persistence.Persistence;
import spc.webos.util.FileUtil;
import spc.webos.util.StringX;

public class AttachmentCtrller implements Controller
{
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response)
			throws Exception
	{
		String[] fields = null;
		String fieldName = (String) request.getParameter(Web.REQ_KEY_FN);
		if (fieldName != null && fieldName.length() > 0) fields = fieldName.split(StringX.COMMA);
		String strZip = (String) request.getParameter(Web.REQ_KEY_ZIP);
		boolean zip = false;
		if (strZip != null && strZip.length() > 0) zip = new Boolean(strZip).booleanValue();
		String clazz = (String) request.getParameter(Web.REQ_KEY_VO);
		// System.out.println(clazz+","+request.getQueryString());
		ValueObject vo = (ValueObject) Class.forName(clazz).newInstance();
		ServletRequestDataBinder binder = new ServletRequestDataBinder(vo, StringX.EMPTY_STRING);
		binder.bind(request);
		vo = persistence.find(vo);

		if (fields == null) fields = vo.getBlobField();
		if (fields != null && fields.length > 1) zip = true;

		OutputStream os = null;
		try
		{
			if (!zip)
			{
				Method m = vo.getClass().getDeclaredMethod(
						"get" + Character.toUpperCase(fields[0].charAt(0)) + fields[0].substring(1)
								+ "Name", null);
				String fileName = (String) m.invoke(vo, null);
				os = new BufferedOutputStream(response.getOutputStream());
				// System.out.println("ct=" + fileName + ", "+fileType+", "
				// + getContentType(fileType));
				response.setContentType(Common.getContentType(fileName));
				response.setHeader(Common.REQ_HEADER_KEY_1, "attachment; filename="
						+ new String(StringX.utf82str(fileName).getBytes(), Common.CHARSET_ISO));
				// os.write("aaaaa".getBytes());
				genUnzip(vo, fields[0], os, null);
				os.flush();
			}
			else
			{
				response.setHeader(Common.REQ_HEADER_KEY_1, "attachment; filename=data.zip");
				os = new ZipOutputStream(new BufferedOutputStream(response.getOutputStream()));
				response.setContentType(Common.FILE_ZIP_CONTENTTYPE);
				genZip(vo, fields, (ZipOutputStream) os);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if (os != null) os.close();
		}
		// response.getWriter().println(vo.toString());
		return null;
	}

	void genUnzip(ValueObject vo, String fieldName, OutputStream os, String[] fields)
			throws Exception
	{
		File target = JdbcUtil.getTempFileByVO(vo, fieldName);
		if (target == null)
		{
			Map paramMap = new HashMap();
			if (fields == null) paramMap.put(Persistence.FILE_FIELDS_KEY,
					new String[] { fieldName });
			else paramMap.put(Persistence.FILE_FIELDS_KEY, fields);
			vo = persistence.find(vo, paramMap);
			Method m = vo.getClass().getDeclaredMethod(
					"get" + Character.toUpperCase(fieldName.charAt(0)) + fieldName.substring(1),
					null);
			FileBlob blob = (FileBlob) m.invoke(vo, null);
			target = blob.getFile();
		}
		if (target != null && target.exists())
		{
			FileUtil.is2os(new BufferedInputStream(new FileInputStream(target)), os, true, false);
		}
	}

	void genZip(ValueObject vo, String[] fields, ZipOutputStream zos) throws Exception
	{
		for (int i = 0; i < fields.length; i++)
		{
			Method m = vo.getClass().getDeclaredMethod(
					"get" + Character.toUpperCase(fields[i].charAt(0)) + fields[i].substring(1)
							+ "Name", null);
			String fileName = (String) m.invoke(vo, null);
			// System.out.println(fields[i]+", "+fileName);
			zos.putNextEntry(new ZipEntry(fileName));
			genUnzip(vo, fields[i], zos, fields);
			zos.flush();
			zos.closeEntry();
		}
	}

	protected IPersistence persistence = Persistence.getInstance();

	public void setPersistence(IPersistence persistence)
	{
		this.persistence = persistence;
	}
}
