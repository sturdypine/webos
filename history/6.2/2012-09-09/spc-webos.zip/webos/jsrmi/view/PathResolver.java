package spc.webos.jsrmi.view;

/**
 * @author  lenovo
 */
public interface PathResolver {
	
	/**
	 * Get the requested service name.
	 * @return the service name
	 */
	public String getRequestService();
	
	/** 
	 * Get the service parameters.
	 * @return the service parameters
	 */
	public String[] getParameters();
	
}
