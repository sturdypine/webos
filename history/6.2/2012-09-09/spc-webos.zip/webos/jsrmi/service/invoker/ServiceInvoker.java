package spc.webos.jsrmi.service.invoker;

import java.io.InputStream;
import java.io.Writer;

public interface ServiceInvoker
{

	/**
	 * Invoke the object with the request from the input stream.
	 * 
	 * @param service
	 *            the service to invoke
	 * @param reader
	 *            the input reader
	 * @param writer
	 *            the output writer
	 */
	public void invoke(Object service, InputStream inputStream, Writer writer)
			throws Throwable;

}
