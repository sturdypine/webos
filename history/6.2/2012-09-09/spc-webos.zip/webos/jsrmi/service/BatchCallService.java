package spc.webos.jsrmi.service;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import spc.webos.jsrmi.protocal.JsrmiCall;
import spc.webos.jsrmi.protocal.Signature;
import spc.webos.jsrmi.service.invoker.JsrmiInvoker;
import spc.webos.service.Service;

public class BatchCallService extends Service implements IBatchCallService, ApplicationContextAware
{
	public List doBC(List services, List args)
	{
		// System.out.println("doBatchCall:" + services);
		List results = new ArrayList(services.size());
		for (int i = 0; i < services.size(); i++)
		{
			String service = (String) services.get(i);
			int index = service.indexOf('.');
			String serviceName = service.substring(0, index);
			if (jsrmiCfg == null) jsrmiCfg = (JsrmiServiceConfigurer) appCxt.getBean(
					"jsrmiConfigBean", JsrmiServiceConfigurer.class);

			Object serviceObj = jsrmiCfg.getServices().get(serviceName);
			String methodName = service.substring(index + 1);
			List arguments = (List) args.get(i);
			if (arguments == null) arguments = new ArrayList();
			JsrmiCall call = new JsrmiCall(methodName, arguments.toArray());
			Signature signature = new Signature(serviceObj.getClass(), call.getMethodName(), call
					.getArgumentTypes());
			Method method = JsrmiInvoker.getInstance().lookupMethod(serviceObj, call, signature);
			Object result = null;
			try
			{
				result = method.invoke(serviceObj, call.getArguments());
			}
			catch (IllegalArgumentException e)
			{
				throw new ServiceInvocationException(e);
			}
			catch (IllegalAccessException e)
			{
				throw new ServiceInvocationException(e);
			}
			catch (InvocationTargetException e)
			{
				e.printStackTrace();
				result = e.getTargetException();
				if (result instanceof RuntimeException) throw (RuntimeException) result;
				else throw new RuntimeException("Unkown Exception..");
			}
			results.add(result);
		}
		return results;
	}

	public void setApplicationContext(ApplicationContext appCxt)
	{
		this.appCxt = appCxt;
	}

	JsrmiServiceConfigurer jsrmiCfg;
	ApplicationContext appCxt;

	public void setJsrmiCfg(JsrmiServiceConfigurer jsrmiCfg)
	{
		this.jsrmiCfg = jsrmiCfg;
	}
}
