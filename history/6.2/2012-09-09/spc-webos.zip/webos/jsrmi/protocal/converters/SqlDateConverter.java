
package spc.webos.jsrmi.protocal.converters;

import spc.webos.jsrmi.protocal.ProtocalTag;
import spc.webos.jsrmi.protocal.converters.map.AbstractMapConverter;
import spc.webos.jsrmi.protocal.io.MarshallingContext;
import spc.webos.jsrmi.protocal.io.StreamReader;
import spc.webos.jsrmi.protocal.io.StreamWriter;
import spc.webos.jsrmi.protocal.io.UnmarshallingContext;

public class SqlDateConverter extends AbstractMapConverter implements Converter {

	public boolean canConvert(Class type) {
		if (type == null) {
			return false;
		}
		
		return java.sql.Date.class.equals(type);
	}
	
	public Object unmarshal(StreamReader reader,
			UnmarshallingContext unmarshallingContext) {
		throw new UnsupportedOperationException("done in the MapConverter");
	}

	protected void marshalMapObject(Object value, MarshallingContext context, StreamWriter streamWriter) {
		java.sql.Date date = (java.sql.Date) value;
		streamWriter.startNode(ProtocalTag.TAG_STRING);
		streamWriter.setValue("value");
		streamWriter.endNode();
		context.convertAnother(new java.util.Date(date.getTime()));
	}

}
