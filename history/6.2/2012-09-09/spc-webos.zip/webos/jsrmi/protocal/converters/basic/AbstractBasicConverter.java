package spc.webos.jsrmi.protocal.converters.basic;

import java.math.BigDecimal;
import java.math.BigInteger;

import spc.webos.jsrmi.protocal.ProtocalTag;
import spc.webos.jsrmi.protocal.converters.Converter;
import spc.webos.jsrmi.protocal.io.MarshallingContext;
import spc.webos.jsrmi.protocal.io.StreamReader;
import spc.webos.jsrmi.protocal.io.StreamWriter;
import spc.webos.jsrmi.protocal.io.UnmarshallingContext;
import spc.webos.util.StringX;

public abstract class AbstractBasicConverter implements Converter
{
	public void marshal(Object source, MarshallingContext context, StreamWriter streamWriter)
	{
		String t = getType();
		streamWriter.startNode(t);
		// ���׽�����������������������, �����������ڷ������ϱ�Ϊutf��ʾ���󴫵��ͻ���
		// ����String�еĻس���\nת��
		if (ProtocalTag.TAG_STRING.equals(t))
		{
			String v = StringX.str2utf8(source.toString());
			if (v.indexOf('\n') >= 0) v = v.replaceAll("\n", "\\\\n");
			streamWriter.setValue(v);
		}
		else if (source instanceof BigDecimal) streamWriter.setValue(((BigDecimal) source)
				.toPlainString());
		else streamWriter.setValue(source.toString());
		streamWriter.endNode();
	}

	protected String getType()
	{
		throw new UnsupportedOperationException();
	}

	public Object unmarshal(StreamReader reader, UnmarshallingContext unmarshallingContext)
	{
		return fromString(reader.getValue());
	}

	public abstract Object fromString(String string);

}
