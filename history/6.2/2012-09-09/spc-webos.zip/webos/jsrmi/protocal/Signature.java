
package spc.webos.jsrmi.protocal;

public class Signature {
	
	private final Class objectType;
	private final String methodName;
	private final Class[] parameters;

	public Signature(Class objectType, String methodName, Class[] parameters) {
		this.objectType = objectType;
		this.methodName = methodName;
		this.parameters = parameters;
	}
	
	public boolean equals(Object obj) {
		if (obj == null) return false;
		
		Signature that = (Signature) obj;
		if (!this.objectType.equals(that.objectType))
			return false;
		if (!this.methodName.equals(that.methodName))
			return false;
		if (this.parameters.length != that.parameters.length)
			return false;
		
		for (int i = 0; i < parameters.length; i++) {
			if (!this.parameters[i].equals(that.parameters[i])) {
				return false;
			}
		}
		
		return true;
	}

	public int hashCode() {
		int hashCode=0;
		for (int i = 0; i < parameters.length; i++) {
			hashCode += parameters[i].hashCode();
		}
		return objectType.hashCode() + methodName.hashCode() + hashCode;
	}

	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append(objectType);
		buffer.append("(");
		for (int i = 0; i < parameters.length; i++) {
			buffer.append(parameters[i].getName());
			buffer.append(",");
		}
		buffer.append(")");
		return buffer.toString();
	}
	
	
}
