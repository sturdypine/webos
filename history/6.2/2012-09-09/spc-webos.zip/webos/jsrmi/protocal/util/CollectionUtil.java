
package spc.webos.jsrmi.protocal.util;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;

public class CollectionUtil {

	public static Object toArray(Collection collection) {
		
		Object outerArray = Array.newInstance(Integer[].class, collection.size());
		
		int i = 0;
		for (Iterator iter = collection.iterator(); iter.hasNext();) {
			Object element = (Object) iter.next();
			if (element instanceof Collection) {
				Array.set(outerArray, i++, toPlatArray((Collection) element));
			}
		}

		return outerArray;
	}
	
	
	private static Object toPlatArray(Collection collection) {
		Object firstElement = collection.iterator().next();
		Object array =  Array.newInstance(firstElement.getClass(), collection.size());
		int i = 0;
		for (Iterator iter = collection.iterator(); iter.hasNext();) {
			Object element =  iter.next();
			Array.set(array, i++, element);
		}
		
		return array;
	}

}
