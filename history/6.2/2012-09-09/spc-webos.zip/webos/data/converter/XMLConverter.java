package spc.webos.data.converter;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.CompositeNode;
import spc.webos.data.DefaultNode2XML;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.data.INode;
import spc.webos.data.INode2XML;
import spc.webos.data.INodeVisitor;
import spc.webos.data.Message;
import spc.webos.data.SequenceCompositeNode;
import spc.webos.log.Log;
import spc.webos.util.StringX;

public class XMLConverter implements IMessageConverter
{
	protected SaxHandler handler = DefaultSaxHandler.getInstance();
	protected String charset = Common.CHARSET_UTF8;
	protected boolean emptyTag = true;
	protected boolean cdata = true;
	protected boolean pretty = true;
	// added by chenjs 2011-09-01���л�ʱɾ��transaction�е�local����
	protected boolean removeLocal = true;
	// added by chenjs 2012-01-01���л�ʱɾ��originalBytes��ǩ
	protected boolean removeOriginalBytes;
	protected boolean sequence = false;
	protected boolean unvalidXMLEx = true; // ���Ϸ���XMLֱ���쳣�˳�, ���򲿷ֽ���������Local��ʱ����
	protected INode2XML node2xml = DefaultNode2XML.getInstance();
	public static int SOAP_TEST_LEN = 100; // soap ���ļ��ͷ����

	protected Log log = Log.getLogger(getClass());

	public XMLConverter()
	{
	}

	public XMLConverter(boolean removeLocal)
	{
		this.removeLocal = removeLocal;
	}

	public XMLConverter(String charset)
	{
		this.charset = charset;
	}

	public void setHandler(SaxHandler handler)
	{
		this.handler = handler;
	}

	static ThreadLocal SAX_PARSER = new ThreadLocal();

	static SAXParser newSAXParser()
	{
		try
		{
			SAXParserFactory factory = SAXParserFactory.newInstance();
			factory.setValidating(false);
			factory.setNamespaceAware(false);
			// factory.setXIncludeAware(false);
			return factory.newSAXParser();
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
	}

	public static XMLReader getXMLReader(SaxHandler handler)
	{
		XMLReader parser = null;
		try
		{
			// SAXParserFactory factory = SAXParserFactory.newInstance();
			// factory.setValidating(false);
			// factory.setNamespaceAware(false);
			// // factory.setXIncludeAware(false);
			// SAXParser saxParser = factory.newSAXParser();
			// 2012-07-08 ����SAXParser����ƽ����Ҫ1.5ms, ʹ��ThreadLocal�������浱ǰ�̵߳Ľ�������
			if (SAX_PARSER.get() == null) SAX_PARSER.set(newSAXParser());
			parser = ((SAXParser) SAX_PARSER.get()).getXMLReader();
			// parser.setDTDHandler(handler);
			// parser.setEntityResolver(handler);
			parser.setErrorHandler(handler);
			parser.setContentHandler(handler);
		}
		catch (Exception e)
		{
			throw new RuntimeException("No valid sax parser!", e);
		}
		return parser;
	}

	public INode unpack(Object obj)
	{
		InputStream is = (InputStream) obj;
		ICompositeNode root = root();
		handler.setRoot(root);
		try
		{
			getXMLReader(handler).parse(new InputSource(is));
		}
		catch (Exception e)
		{
			throw new RuntimeException("Parse xml error!", e);
		}
		return root;
	}

	protected ICompositeNode root()
	{
		return sequence ? new SequenceCompositeNode() : new CompositeNode();
	}

	public void serialize(IMessage msg, OutputStream os) throws Exception
	{
		if (removeLocal || removeOriginalBytes)
		{
			ICompositeNode transaction = new CompositeNode(msg.getTransaction());
			if (removeLocal) transaction.remove(IMessage.TAG_LOCAL);
			if (removeOriginalBytes) transaction.remove(IMessage.TAG_ORIGINALBYTES);
			new Message(transaction).toXml(os, pretty, node2xml, serializeAttr());
		}
		else msg.toXml(os, pretty, node2xml, serializeAttr());
	}

	protected Map serializeAttr()
	{
		Map attr = new HashMap();
		if (!cdata) attr.put(INode2XML.ATTR_KEY_NO_CDATA, Boolean.TRUE);
		if (!emptyTag) attr.put(INode2XML.ATTR_KEY_NO_EMPTY_TAG, Boolean.TRUE);
		return attr;
	}

	public byte[] serialize(IMessage msg) throws Exception
	{
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		serialize(msg, baos);
		return baos.toByteArray();
	}

	public IMessage deserialize(byte[] buf) throws Exception
	{
		return deserialize(buf, null);
	}

	public IMessage deserialize(byte[] buf, IMessage msg) throws Exception
	{
		// modified by chenjs 2012-01-17 ֧��SOAP���Ľ���
		IMessage nmsg = isSOAP(buf) ? deserializeSOAP(buf, msg) : deserialize(buf, 0, buf.length,
				msg);
		nmsg.init();
		nmsg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, buf);
		return nmsg;
	}

	public IMessage deserializeSOAP(byte[] buf, IMessage msg) throws Exception
	{
		ICompositeNode soap = deserialize2composite(buf);
		ICompositeNode soapbody = soap.findComposite("Body", null);
		ICompositeNode transaction = getBodyFirstChild(soapbody);
		transaction.dfs(new INodeVisitor()
		{
			public boolean visitor(INode node, INode parent, String name)
			{
				if (node == null) return true;
				Map ext = node.getExt();
				if (ext == null || ext.size() == 0) return true;
				List removeKeys = new ArrayList();
				Iterator keys = ext.keySet().iterator();
				while (keys.hasNext())
				{ // added by chenjs 2012-01-01 ESB
					// XML���Ĳ�֧�������ռ�����Զ��壬ɾ���������ռ�����Զ���
					String key = keys.next().toString();
					if (key.indexOf(':') > 0) removeKeys.add(key);
				}
				for (int i = 0; i < removeKeys.size(); i++)
					ext.remove((String) removeKeys.get(i));
				node.setExt(ext);
				return true;
			}
		});
		IMessage nmsg = new Message(transaction);
		nmsg.init();
		nmsg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, buf);
		return nmsg;
	}

	protected ICompositeNode getBodyFirstChild(ICompositeNode soapBody)
	{
		String key = soapBody.keys().next().toString();
		return soapBody.findComposite(key, null);
	}

	// �ж�һ��������ESB-XML����SOAP XML, ǰ100���ֽ����Ƿ����:Envelope
	public static boolean isSOAP(byte[] xml)
	{
		byte[] hdr = new byte[xml.length < SOAP_TEST_LEN ? xml.length : SOAP_TEST_LEN];
		System.arraycopy(xml, 0, hdr, 0, hdr.length);
		return new String(hdr).contains(":Envelope");
	}

	public IMessage deserialize(byte[] buf, int offset, int len) throws Exception
	{
		return deserialize(buf, offset, len, null);
	}

	// 2012-08-16 ����unvalidXMLEx���������ƽ�����ֱ���쳣�����ǲ��ֽ���
	public IMessage deserialize(byte[] buf, int offset, int len, IMessage reqmsg) throws Exception
	{
		ICompositeNode transaction = root();
		IMessage msg = null;
		try
		{
			deserialize2composite(buf, offset, len, transaction);
			msg = new Message(transaction);
		}
		catch (Exception e)
		{
			String strxml = new String(buf, offset, len, Common.CHARSET_UTF8);
			log.warn("fail to parse strxml: " + strxml);
			if (unvalidXMLEx) throw e;

			if (StringX.containUnvalidXmlChar(strxml))
			{ // ɾ�����Ϸ��ַ�
				byte[] nbuf = StringX.removeUnvalidXmlChar(strxml).getBytes(Common.CHARSET_UTF8);
				try
				{
					transaction = root();
					deserialize2composite(nbuf, 0, nbuf.length, transaction);
					msg = new Message(transaction);
					msg.setInLocal(MsgLocalKey.LOCAL_UNVALID_XML_CHAR, Common.YES);
					msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, buf);
					return msg;
				}
				catch (Exception ee)
				{
					log.warn("fail to parse xml after removeUnvalidXmlChar!!!");
				}
			}
			msg = new Message(transaction);
			msg.setInLocal(MsgLocalKey.LOCAL_UNVALID_XML, Common.YES);
		}
		msg.init();
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, buf);
		return msg;
	}

	public ICompositeNode deserialize2composite(byte[] buf, int offset, int len) throws Exception
	{
		return deserialize2composite(buf, offset, len, root());
	}

	public ICompositeNode deserialize2composite(byte[] buf, int offset, int len, ICompositeNode root)
			throws Exception
	{
		InputStream is = new ByteArrayInputStream(buf, offset, len);
		handler.setRoot(root);
		try
		{
			InputSource input = new InputSource(is);
			input.setEncoding(charset); // modified by chenjs 2010-11-20��
			// �ṩһ���ַ����Ĳ���������ָ�����������ַ�����Ĭ��Ϊutf-8
			getXMLReader(handler).parse(input);
		}
		catch (Exception e)
		{
			log.warn("Parse xml error: offset: " + offset + ", len: " + len + ", base64 buf: ["
					+ new String(StringX.encodeBase64(buf)) + "]\n\tstr:" + new String(buf));
			throw e;
		}
		return root;
	}

	public ICompositeNode deserialize2composite(byte[] buf, ICompositeNode root) throws Exception
	{
		return deserialize2composite(buf, 0, buf.length, root);
	}

	public ICompositeNode deserialize2composite(byte[] buf) throws Exception
	{
		return deserialize2composite(buf, 0, buf.length);
	}

	public ICompositeNode deserialize2composite(InputStream is) throws Exception
	{
		return deserialize2composite(is, root());
	}

	public ICompositeNode deserialize2composite(InputStream is, ICompositeNode root)
			throws Exception
	{
		handler.setRoot(root);
		InputSource input = new InputSource(is);
		input.setEncoding(charset); // modified by chenjs 2010-11-20��
		// �ṩһ���ַ����Ĳ���������ָ�����������ַ�����Ĭ��Ϊutf-8
		getXMLReader(handler).parse(input);
		return root;
	}

	public IMessage deserialize(InputStream is) throws Exception
	{
		IMessage msg = new Message(deserialize2composite(is));
		msg.init();
		return msg;
	}

	public static XMLConverter getInstance()
	{
		return XML_CONVERTER;
	}

	public void setCharset(String charset)
	{
		this.charset = charset;
	}

	public boolean isEmptyTag()
	{
		return emptyTag;
	}

	public void setRemoveOriginalBytes(boolean removeOriginalBytes)
	{
		this.removeOriginalBytes = removeOriginalBytes;
	}

	public void setEmptyTag(boolean emptyTag)
	{
		this.emptyTag = emptyTag;
	}

	public boolean isCdata()
	{
		return cdata;
	}

	public void setCdata(boolean cdata)
	{
		this.cdata = cdata;
	}

	public String getCharset()
	{
		return charset;
	}

	public boolean isPretty()
	{
		return pretty;
	}

	public void setPretty(boolean pretty)
	{
		this.pretty = pretty;
	}

	public boolean isRemoveLocal()
	{
		return removeLocal;
	}

	public void setRemoveLocal(boolean removeLocal)
	{
		this.removeLocal = removeLocal;
	}

	public boolean isSequence()
	{
		return sequence;
	}

	public void setSequence(boolean sequence)
	{
		this.sequence = sequence;
	}

	public void setNode2xml(INode2XML node2xml)
	{
		this.node2xml = node2xml;
	}

	public void setUnvalidXMLEx(boolean unvalidXMLEx)
	{
		this.unvalidXMLEx = unvalidXMLEx;
	}

	static XMLConverter XML_CONVERTER = new XMLConverter();
}
