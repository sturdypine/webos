package spc.webos.queue.tlq;

import java.util.List;

import spc.webos.exception.AppException;
import spc.webos.log.Log;
import spc.webos.queue.QueueMessage;

import com.tongtech.tlq.base.TlqException;
import com.tongtech.tlq.base.TlqMessage;
import com.tongtech.tlq.base.TlqMsgOpt;

public class TLQAccessor
{
	public static final int CNN_EXCEPTION_SLEEP = 1; // �쳣����˯��
	static final Log log = Log.getLogger(TLQAccessor.class);

	public static void sendCluster(List<TLQCnnPool> cnnpools, String qname, QueueMessage qmsg,
			int retryTimes, int retryInterval) throws Exception
	{
		sendCluster(false, cnnpools, qname, qmsg, retryTimes, retryInterval);
	}

	// added 2012-05-12 ʹ�ö�ͨѸ��·���ͣ�
	// ��ʾֻҪ��һ��ͨ�����ͳɹ���OK��
	public static void sendCluster(boolean randomStart, List<TLQCnnPool> cnnpools, String qname,
			QueueMessage qmsg, int retryTimes, int retryInterval) throws Exception
	{
		Exception ee = null;
		// �������Ϊ��㣬ѭ��һ�鷢��
		int index = (randomStart ? ((int) (Math.random() * 1000) % cnnpools.size()) : 0);
		if (log.isDebugEnabled()) log.debug("start: " + index);
		for (int i = 0; i < cnnpools.size(); i++)
		{
			if (index >= cnnpools.size()) index = 0;
			TLQCnnPool cnnpool = cnnpools.get(index++);
			try
			{
				TLQAccessor.send(cnnpool, qname, qmsg, retryTimes, retryInterval);
				return;
			}
			catch (Exception e)
			{
				ee = e;
				log.warn("fail to put:" + cnnpool.getProps() + ", qname:" + qname + "", e);
			}
		}
		throw ee;
	}

	// all=true��ʾÿ��ͨ��������һ�Σ���һ�����ͳɹ�����ɹ�
	public static void sendAll(List<TLQCnnPool> cnnpools, String qname, QueueMessage qmsg,
			int retryTimes, int retryInterval) throws Exception
	{
		// �������Ϊ��㣬ѭ��һ�鷢��
		int index = ((int) (Math.random() * 1000000) % cnnpools.size());
		boolean fail = true;
		for (int i = 0; i < cnnpools.size(); i++)
		{
			if (index >= cnnpools.size()) index = 0;
			TLQCnnPool cnnpool = cnnpools.get(index++);
			try
			{
				TLQAccessor.send(cnnpool, qname, qmsg, retryTimes, retryInterval);
				fail = false;
			}
			catch (Exception e)
			{
				log.warn("fail to put:" + cnnpool.getProps() + ", qname:" + qname, e);
			}
		}
		if (fail) throw new Exception("Fail to sendAll ClusterTLQPut: qname:" + qname);
	}

	public static void send(TLQCnnPool cnnpool, String qname, QueueMessage qmsg, int retryTimes,
			int retryInterval) throws Exception
	{
		TLQManager tlqm = (TLQManager) cnnpool.borrow();
		try
		{
			TLQAccessor.send(tlqm, qname, qmsg, retryTimes, retryInterval);
		}
		finally
		{
			cnnpool.release(tlqm);
		}
	}

	public static void send(TLQManager tlqm, String qname, QueueMessage qmsg, int retryTimes,
			int retryInterval) throws Exception
	{
		long start = System.currentTimeMillis(), failTimes = 0;
		while (true)
		{
			try
			{
				tlqm.connect(1);

				TlqMsgOpt msgOpt = new TlqMsgOpt();
				msgOpt.QueName = qname;
				msgOpt.MsgIdFlag = 1;// ʹ���Զ���msgid

				TlqMessage tlqmsg = new TlqMessage();
				TLQMessageUtil.QMsgtoTLQMsg(qmsg, tlqmsg);

				tlqm.tlqQcu.putMessage(tlqmsg, msgOpt);

				if (log.isInfoEnabled()) log.info("put TLQ(" + qname + ")" + tlqm.props + ", cost:"
						+ (System.currentTimeMillis() - start) + ", len:"
						+ tlqmsg.getMsgData().length + ", retry(" + retryTimes + ","
						+ retryInterval + "," + failTimes + ")");
				return; // ��������
			}
			catch (Exception ex)
			{
				failTimes++;
				log.warn("err to snd TLQ queue: " + qname + ", qm: " + tlqm.props + ", retryTms:"
						+ retryTimes + ", failTms:" + failTimes + ", reason: " + ex);
				tlqm.disconnect();
				if (failTimes > retryTimes) throw ex;
				try
				{
					if (retryInterval > 0) Thread.sleep(retryInterval);
				}
				catch (Exception ee)
				{
				}
			}
		}
	}

	public static QueueMessage receive(List<TLQCnnPool> cnnpools, String qname,
			byte[] correlationId, int timeout) throws Exception
	{
		for (int i = 0; i < cnnpools.size(); i++)
		{
			TLQCnnPool cnnpool = cnnpools.get(i);
			try
			{
				return receive(cnnpool, qname, correlationId, timeout);// ����ɹ�ȡ����Ϣ�򷵻�
			}
			catch (Exception e)
			{
				// TLQ2603 = MQ2033
				if (!(e instanceof TlqException) || ((TlqException) e).getTlqErrno() != 2603) throw e;
				log.warn("cnnpool:" + cnnpool.getProps(), e);
				if (i == cnnpools.size() - 1) throw e; // �������û��ͨ���ˣ���ֱ���쳣����
			}
		}
		throw new Exception("fail to read msg from Multi channel, qname: " + qname);
	}

	public static QueueMessage receive(TLQCnnPool cnnpool, String qname, byte[] correlationId,
			int timeout) throws Exception
	{
		if (log.isDebugEnabled()) log.debug("cnn: " + cnnpool.getProps());
		TLQManager tlqm = (TLQManager) cnnpool.borrow();
		try
		{
			return receive(tlqm, qname, correlationId, timeout);
		}
		finally
		{
			cnnpool.release(tlqm);
		}
	}

	public static QueueMessage receive(TLQManager tlqm, String qname, byte[] correlationId,
			int timeout) throws Exception
	{
		long start = System.currentTimeMillis();
		QueueMessage qmsg = null;
		int failTimes = 0;
		while (failTimes < 2)
		{
			try
			{
				if (log.isDebugEnabled()) log
						.debug("start to read TLQ(" + qname + ")" + tlqm.props);
				tlqm.connect(1);
				TlqMsgOpt msgOpt = new TlqMsgOpt();
				TlqMessage tlqmsg = new TlqMessage();

				msgOpt.QueName = qname;
				msgOpt.WaitInterval = timeout * 1000;
				msgOpt.MatchOption = TlqMsgOpt.TLQMATCH_CORRMSGID; // ��������
				msgOpt.OperateType = TlqMsgOpt.TLQOT_GET;

				if (correlationId != null) tlqmsg.CorrMsgId = correlationId;
				tlqm.tlqQcu.getMessage(tlqmsg, msgOpt);
				long end = System.currentTimeMillis();
				long cost = end - tlqmsg.PutDateTime;
				if (log.isInfoEnabled()) log.info("read TLQ(" + qname + ")" + tlqm.props
						+ ", cost:" + (end - start) + ", in tlq:" + cost + ", size: "
						+ tlqmsg.MsgSize);
				return TLQMessageUtil.TLQMsgtoQMsg(tlqmsg);
			}
			catch (TlqException tlqex)
			{
				failTimes++;
				log.error("tlqex.ret==" + tlqex.getErrorCode() + "...wait to reconnect...", tlqex);
				tlqm.reconnect(1);
				continue;
			}
			catch (AppException ex)
			{
				throw ex;
			}
			catch (Exception ex)
			{
				throw new RuntimeException(ex);
			}
		}

		return qmsg;
	}

	public static TlqMessage receive(TLQManager tlqm, String qname, int timeout) throws Exception
	{
		long start = System.currentTimeMillis();
		TlqMessage tlqmsg = new TlqMessage();
		int failTimes = 0;
		while (failTimes < 2)
		{
			try
			{
				if (log.isDebugEnabled()) log
						.debug("start to read TLQ(" + qname + ")" + tlqm.props);
				tlqm.connect(1);
				TlqMsgOpt msgOpt = new TlqMsgOpt();

				msgOpt.QueName = qname;
				msgOpt.WaitInterval = timeout * 1000;
				msgOpt.OperateType = TlqMsgOpt.TLQOT_GET;

				tlqm.tlqQcu.getMessage(tlqmsg, msgOpt);
				long end = System.currentTimeMillis();
				long cost = end - tlqmsg.PutDateTime;
				if (log.isInfoEnabled()) log.info("read TLQ(" + qname + ")" + tlqm.props
						+ ", cost:" + (end - start) + ", in tlq:" + cost + ", size: "
						+ tlqmsg.MsgSize);
				return tlqmsg;
			}
			catch (TlqException tlqex)
			{
				failTimes++;
				log.error("tlqex.ret==" + tlqex.getErrorCode() + "...wait to reconnect...", tlqex);
				tlqm.reconnect(1);
				continue;
			}
			catch (AppException ex)
			{
				throw ex;
			}
			catch (Exception ex)
			{
				throw new RuntimeException(ex);
			}
		}

		return tlqmsg;
	}
}