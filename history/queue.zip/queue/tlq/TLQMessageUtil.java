package spc.webos.queue.tlq;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import spc.webos.queue.QueueMessage;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

import com.tongtech.tlq.base.TlqMessage;

/**
 * ���ڲ�QueueMessage����ת��ΪTLQMessage����
 * 
 * @author chenjs
 * 
 */
public class TLQMessageUtil
{
	public static TlqMessage QMsgtoTLQMsg(QueueMessage qmsg, TlqMessage tlqmsg) throws IOException
	{
		if (qmsg.correlationId != null) tlqmsg.CorrMsgId = qmsg.correlationId;
		if (qmsg.messageId != null) tlqmsg.MsgId = qmsg.messageId;
		if (qmsg.expirySeconds > 0) tlqmsg.Expiry = qmsg.expirySeconds; // tlq����ʱ������Ϊ��λ
		if (qmsg.priority >= 0) tlqmsg.Priority = (char) qmsg.priority;

		tlqmsg.Persistence = (char) qmsg.persistence;
		tlqmsg.MsgType = TlqMessage.BUF_MSG;
		tlqmsg.MsgSize = qmsg.buf.length;
		tlqmsg.RollbackCount = qmsg.feedback;
		tlqmsg.setMsgData(qmsg.buf);

		// ʹ���Զ����������tlqmsg
		if (!StringX.nullity(qmsg.applicationIdData)) tlqmsg.setStringProperty("applicationIdData",
				qmsg.applicationIdData);
		if (!StringX.nullity(qmsg.applicationOriginData)) tlqmsg.setStringProperty(
				"applicationOriginData", qmsg.applicationOriginData);
		if (!StringX.nullity(qmsg.putAppName)) tlqmsg.setStringProperty("putAppName",
				qmsg.putAppName);

		tlqmsg.setStringProperty("putDateTime",
				new SimpleDateFormat(SystemUtil.DF_SALL17).format(System.currentTimeMillis()));
		tlqmsg.setIntProperty("feedback", qmsg.feedback);

		return tlqmsg;
	}

	public static QueueMessage TLQMsgtoQMsg(TlqMessage tlqmsg) throws IOException, ParseException
	{
		QueueMessage qmsg = new QueueMessage();
		byte[] corrId = tlqmsg.CorrMsgId;
		if (corrId != null) qmsg.correlationId = corrId;
		byte[] msgId = tlqmsg.MsgId;
		if (msgId != null) qmsg.messageId = msgId;
		qmsg.expirySeconds = Integer.valueOf(String.valueOf((tlqmsg.Expiry - System
				.currentTimeMillis()) / 1000));
		qmsg.buf = tlqmsg.getMsgData();

		// ͨ���Զ������Բ�ȫQueueMessage
		if (!StringX.nullity(tlqmsg.getStringProperty("applicationIdData"))) qmsg.applicationIdData = tlqmsg
				.getStringProperty("applicationIdData");
		if (!StringX.nullity(tlqmsg.getStringProperty("applicationOriginData"))) qmsg.applicationOriginData = tlqmsg
				.getStringProperty("applicationOriginData");
		if (!StringX.nullity(tlqmsg.getStringProperty("putAppName"))) qmsg.putAppName = tlqmsg
				.getStringProperty("putAppName");

		qmsg.putDateTime = new SimpleDateFormat(SystemUtil.DF_SALL17).parse(tlqmsg
				.getStringProperty("putDateTime"));
		qmsg.feedback = tlqmsg.getIntProperty("feedback");

		return qmsg;
	}
}