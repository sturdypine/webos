package spc.webos.queue.tlq;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import spc.webos.constant.AppRetCode;
import spc.webos.exception.AppException;
import spc.webos.log.Log;

import com.tongtech.tlq.base.TlqConnContext;
import com.tongtech.tlq.base.TlqConnection;
import com.tongtech.tlq.base.TlqException;
import com.tongtech.tlq.base.TlqQCU;

public class TLQManager
{
	public TLQManager tlqm;
	protected TlqConnection conn = null;
	protected TlqQCU tlqQcu = null;

	public boolean keepQueue; // ����Queue��close���������
	public Map keepQueues = new HashMap(); // 2012-07-29 ����һ������ͬʱ���ֶ���򿪶���
	public Hashtable props;
	protected long createTm; // ����ʱ��
	public int holdtime = -1; //
	// ���ӵ���󱣴�ʱ�䣬��������Զ�̵�MQ����HA�������һ�������̣߳��������ڼ���������Ϣ��
	protected long lastUseTm; // ��һ��ʹ��ʱ��
	public int idletime = -1;

	public static int CNN_EXCEPTION_SLEEP = 30; // �쳣����˯��
	static final Log log = Log.getLogger(TLQManager.class);

	public TLQManager()
	{
	}

	public TLQManager(TLQCnnPool cnnpool)
	{
		this.props = cnnpool.getProps();
		this.holdtime = cnnpool.getCnnHoldTime();
		this.idletime = cnnpool.getCnnIdleTime();
	}

	public TLQManager(Hashtable props, int holdtime)
	{
		this.props = props;
		this.holdtime = holdtime;
	}

	public TLQManager(TLQManager tlqm, Hashtable props)
	{
		this.tlqm = tlqm;
		this.props = props;
	}

	public TLQManager(TLQManager tlqm, Hashtable props, int holdtime)
	{
		this.tlqm = tlqm;
		this.props = props;
		this.holdtime = holdtime;
	}

	public TLQManager(Hashtable props, int holdtime, int idletime, boolean keepQueue)
	{
		this.props = props;
		this.holdtime = holdtime;
		this.idletime = idletime;
		this.keepQueue = keepQueue;
	}

	public TLQManager(TLQManager tlqm, Hashtable props, int holdtime, int idletime)
	{
		this.tlqm = tlqm;
		this.props = props;
		this.holdtime = holdtime;
		this.idletime = idletime;
	}

	public TLQManager(TLQManager tlqm, Hashtable props, int holdtime, int idletime,
			boolean keepQueue)
	{
		this.tlqm = tlqm;
		this.props = props;
		this.holdtime = holdtime;
		this.idletime = idletime;
		this.keepQueue = keepQueue;
	}

	public void connect(int count)
	{
		if (validate()) return;
		reconnect(count);
	}

	public boolean validate()
	{
		return conn != null
				&& (holdtime <= 0 || System.currentTimeMillis() - createTm < holdtime * 1000)
				&& (idletime <= 0 || System.currentTimeMillis() - lastUseTm < idletime * 1000);
	}

	public void reconnect(int count)
	{
		if (log.isInfoEnabled()) log.info("reconnect : " + count + ", props: " + props);
		long i = 0;
		while (true)
		{
			try
			{
				disconnect();

				TlqConnContext tlqCnnCxt = new TlqConnContext();
				tlqCnnCxt.BrokerId = -1; // ����tlqCnnCxt��IP��PORT��������Գ����е�Ϊ׼
				tlqCnnCxt.HostName = (String) props.get("hostname");
				tlqCnnCxt.ListenPort = Integer.parseInt(props.get("port").toString());
				conn = new TlqConnection(tlqCnnCxt);
				tlqQcu = conn.openQCU((String) props.get("qmname"));

				createTm = System.currentTimeMillis(); // ��������ʱ��
				lastUseTm = System.currentTimeMillis();
				return;
			}
			catch (TlqException tlqex)
			{
				log.warn("tlq access error:" + props + ", failtimes:" + i + ", sleep:"
						+ CNN_EXCEPTION_SLEEP + " seconds,count:" + count, tlqex);
				Log.print();
				i++;
				if (count >= 0 && i >= count) throw new AppException(AppRetCode.PROTOCOL_TLQ(),
						new Object[] { props.toString(), tlqex.getErrorCode(), tlqex.getMessage() });
				try
				{
					Thread.sleep(CNN_EXCEPTION_SLEEP * 1000);
				}
				catch (Exception ee)
				{
				}
				if (count < 0) continue;
			}
			finally
			{
				Log.print();
			}
		}
	}

	public void disconnect()
	{
		if (conn == null) return;
		log.warn("tlqconn will disconnect:" + props);
		try
		{
			tlqQcu.close();
			conn.close();
		}
		catch (TlqException e)
		{
			log.warn("tlqQcu close:" + props, e);
		}
		finally
		{
			tlqQcu = null;
			conn = null;
			keepQueues.clear();
		}
	}
}