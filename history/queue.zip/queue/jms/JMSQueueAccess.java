package spc.webos.queue.jms;

import java.util.ArrayList;
import java.util.List;

import spc.webos.queue.AbstractQueueAccess;
import spc.webos.queue.QueueMessage;
import spc.webos.util.StringX;

public class JMSQueueAccess extends AbstractQueueAccess
{
	protected List<JMSCnnPool> cnnpools;

	public JMSQueueAccess()
	{
	}

	public JMSQueueAccess(List<JMSCnnPool> cnnpools)
	{
		this.cnnpools = cnnpools;
	}

	public JMSQueueAccess(JMSCnnPool cnnpool)
	{
		this.cnnpools = new ArrayList<JMSCnnPool>();
		this.cnnpools.add(cnnpool);
	}

	public void destroy()
	{
		if (cnnpools == null) return;
		for (int i = 0; i < cnnpools.size(); i++)
			cnnpools.get(i).destory();
	}

	public void send(String qname, QueueMessage qmsg) throws Exception
	{

		if (log.isDebugEnabled()) log.debug("sn:" + qmsg.sn + ", corId:"
				+ (qmsg.correlationId != null ? new String(qmsg.correlationId) : "")
				+ ", expiry(s): " + qmsg.expirySeconds + ", ccsid: " + qmsg.ccsid);

		JMSAccessor.sendCluster(sndRandomStart, cnnpools, qname, qmsg, retryTimes, retryInterval);
	}

	// 2012-05-12 ʹ��ͨ���б����н���
	public QueueMessage receive(String qname, byte[] correlationId, int timeout) throws Exception
	{
		QueueMessage qmsg = JMSAccessor.receive(cnnpools, qname, correlationId, timeout);
		return qmsg;
	}

	// 2012-05-16 ʹ��send, recieve��Ϸ������
	public QueueMessage execute(String reqQName, String repQName, QueueMessage qmsg, int timeout)
			throws Exception
	{
		byte[] corId = qmsg.correlationId; // ����ˮ����Ϊmq��Ϣ������
		if (log.isDebugEnabled()) log.debug("snd corId:"
				+ (qmsg.correlationId == null ? "" : new String(qmsg.correlationId)));
		if (log.isDebugEnabled()) log.debug("req:" + new String(qmsg.buf));

		// if (qmsg.expirySeconds > 0) reqMQMsg.expiry = qmsg.expirySeconds *
		// 10; // 2012-11-01
		// // ������Ϣ�ĳ�ʱʱ��
		JMSAccessor.sendCluster(sndRandomStart, cnnpools, reqQName, qmsg, timeout, timeout);

		if (StringX.nullity(repQName))
		{ // added by spc 2011-03-11 ���Ӧ�����Ϊ�գ����ʾ����Ҫ����
			log.info("repQName is null!!!");
			return null;
		}
		return receive(repQName, corId, timeout);
	}

	public void setCnnPool(JMSCnnPool cnnPool)
	{
		this.cnnpools = new ArrayList<JMSCnnPool>();
		this.cnnpools.add(cnnPool);
	}

	public void setCnnpools(List<JMSCnnPool> cnnpools)
	{
		this.cnnpools = cnnpools;
	}
}