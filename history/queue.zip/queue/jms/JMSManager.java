package spc.webos.queue.jms;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import spc.webos.constant.AppRetCode;
import spc.webos.exception.AppException;
import spc.webos.log.Log;
import spc.webos.queue.ibmmq.MQCnnPool;
import spc.webos.util.StringX;

import com.ibm.mq.MQException;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.tongtech.tlq.base.TlqConnection;
import com.tongtech.tlq.base.TlqException;
import com.tongtech.tlq.base.TlqQCU;

/**
 * JMS �������Ӷ��󣬺���������
 * 
 * @author spc
 * 
 */
public class JMSManager
{
	public JMSManager jmsm;
	protected Context ictx = null;
	protected QueueConnectionFactory qcf = null;
	protected QueueConnection conn = null;
	QueueSession sess = null;
	public boolean keepQueue; // ����Queue��close���������
	public Map keepQueues = new HashMap(); // 2012-07-29 ����һ������ͬʱ���ֶ���򿪶���
	public Hashtable props;
	protected long createTm; // ����ʱ��
	public int holdtime = -1; //
	// ���ӵ���󱣴�ʱ�䣬��������Զ�̵�MQ����HA�������һ�������̣߳��������ڼ���������Ϣ��
	protected long lastUseTm; // ��һ��ʹ��ʱ��
	public int idletime = -1;

	public static int CNN_EXCEPTION_SLEEP = 30; // �쳣����˯��
	static final Log log = Log.getLogger(JMSManager.class);

	public JMSManager()
	{
	}

	public JMSManager(JMSCnnPool cnnpool)
	{
		this.props = cnnpool.getProps();
		this.holdtime = cnnpool.getCnnHoldTime();
		this.idletime = cnnpool.getCnnIdleTime();
	}

	public JMSManager(Hashtable props, int holdtime)
	{
		this.props = props;
		this.holdtime = holdtime;
	}

	public JMSManager(JMSManager qm, Hashtable props)
	{
		this.jmsm = jmsm;
		this.props = props;
	}

	public JMSManager(JMSManager jmsm, Hashtable props, int holdtime)
	{
		this.jmsm = jmsm;
		this.props = props;
		this.holdtime = holdtime;
	}

	public JMSManager(Hashtable props, int holdtime, int idletime, boolean keepQueue)
	{
		this.props = props;
		this.holdtime = holdtime;
		this.idletime = idletime;
		this.keepQueue = keepQueue;
	}

	public JMSManager(JMSManager jmsm, Hashtable props, int holdtime, int idletime)
	{
		this.jmsm = jmsm;
		this.props = props;
		this.holdtime = holdtime;
		this.idletime = idletime;
	}

	public JMSManager(JMSManager jmsm, Hashtable props, int holdtime, int idletime,
			boolean keepQueue)
	{
		this.jmsm = jmsm;
		this.props = props;
		this.holdtime = holdtime;
		this.idletime = idletime;
		this.keepQueue = keepQueue;
	}

	/***
	 * 
	 * @param qname
	 * @param opt
	 *            0��ʾ���� 1��ʾ����
	 * @return
	 * @throws JMSException
	 */
	public QueueSession createQueueSession(String qname, int opt) throws JMSException
	{
		lastUseTm = System.currentTimeMillis();
		if (!keepQueue) return (sess = conn.createQueueSession(false, Session.AUTO_ACKNOWLEDGE));

		// 2012-08-20 ʹ��qname�ʹ򿪷�ʽopt������������, ������ʱ���һ��session��д����������
		String key = qname + '$' + opt;
		sess = (QueueSession) keepQueues.get(key);
		if (sess != null) return sess;
		sess = conn.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
		keepQueues.put(key, sess); //
		return sess;
	}

	public void closeQueueSession()
	{
		if (keepQueue || sess == null) return;
		try
		{
			log.debug("close current session...");
			sess.close();
		}
		catch (Throwable t)
		{
			log.warn("err to close session: " + props, t);
		}
		sess = null;
	}

	public void connect(int count)
	{
		if (validate()) return;
		reconnect(count);
	}

	public boolean validate()
	{
		return conn != null
				&& (holdtime <= 0 || System.currentTimeMillis() - createTm < holdtime * 1000)
				&& (idletime <= 0 || System.currentTimeMillis() - lastUseTm < idletime * 1000);
	}

	public void reconnect(int count)
	{
		if (log.isInfoEnabled()) log.info("reconnect : " + count + ", props: " + props);
		long i = 0;
		while (true)
		{
			try
			{
				disconnect();
				ictx = new InitialContext(props);
				qcf = (QueueConnectionFactory) ictx.lookup((String) props.get("ConnectionFactory"));
				conn = qcf.createQueueConnection();
				conn.start();
				createTm = System.currentTimeMillis(); // ��������ʱ��
				lastUseTm = System.currentTimeMillis();
				return;
			}
			catch (NamingException e)
			{
				log.warn("jms access error:" + props + ", failtimes:" + i + ", sleep:"
						+ CNN_EXCEPTION_SLEEP + " seconds,count:" + count, e);
				Log.print();
				i++;
				if (count >= 0 && i >= count) throw new AppException(AppRetCode.PROTOCOL_TLQ(),
						new Object[] { props.toString() });
				try
				{
					Thread.sleep(CNN_EXCEPTION_SLEEP * 1000);
				}
				catch (Exception ee)
				{
				}
				if (count < 0) continue;
			}
			catch (JMSException jmse)
			{
				log.warn("jms access error:" + props + ", failtimes:" + i + ", sleep:"
						+ CNN_EXCEPTION_SLEEP + " seconds,count:" + count, jmse);
				Log.print();
				i++;
				if (count >= 0 && i >= count) throw new AppException(AppRetCode.PROTOCOL_TLQ(),
						new Object[] { props.toString(), jmse.getErrorCode(), jmse.getMessage() });
				try
				{
					Thread.sleep(CNN_EXCEPTION_SLEEP * 1000);
				}
				catch (Exception ee)
				{
				}
				if (count < 0) continue;
			}
			finally
			{
				Log.print();
			}
		}
	}

	public void disconnect()
	{
		log.warn("jmscnn will disconnect:" + props);
		if (conn != null)
		{
			try
			{
				conn.close();
			}
			catch (Exception e)
			{
				log.warn("jms cnn close:" + props, e);
			}
			finally
			{
				sess = null;
				conn = null;
				keepQueues.clear(); // ����ر�session
			}
		}
		conn = null;
	}

}
