package spc.webos.queue.jms;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.jms.BytesMessage;
import javax.jms.JMSException;

import spc.webos.queue.QueueMessage;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

/**
 * ���ڲ�QueueMessage����ת��ΪJMS Message����
 * 
 * @author chenjs
 * 
 */
public class JMSMessageUtil
{

	public static BytesMessage QMsgtoJMSMsg(QueueMessage qmsg, BytesMessage msg)
			throws IOException, JMSException
	{
		if (qmsg.correlationId != null) msg.setJMSCorrelationIDAsBytes(qmsg.correlationId);
		if (qmsg.messageId != null)
		{
			// ʹ���Զ���MsgId
			msg.setBooleanProperty("SetMessageID", true);
			msg.setJMSMessageID(StringX.byte2hex(qmsg.messageId));
		}
		if (qmsg.expirySeconds > 0) msg.setJMSExpiration(qmsg.expirySeconds);
		else msg.setJMSExpiration(0); // jms��Ϣ0��ʾ��ʧЧ
		if (qmsg.priority >= 0) msg.setJMSPriority(qmsg.priority); // jms���ȼ�Ĭ��Ϊ4
		msg.setJMSDeliveryMode(qmsg.persistence + 1);// ������Ϣ�ĳ־û�1���ǳ־ã�2���־û�
		msg.writeBytes(qmsg.buf);

		// ʹ���Զ����������BytesMessage
		if (!StringX.nullity(qmsg.applicationIdData)) msg.setStringProperty("applicationIdData",
				qmsg.applicationIdData);
		if (!StringX.nullity(qmsg.applicationOriginData)) msg.setStringProperty(
				"applicationOriginData", qmsg.applicationOriginData);
		if (!StringX.nullity(qmsg.putAppName)) msg.setStringProperty("putAppName", qmsg.putAppName);

		msg.setStringProperty("putDateTime",
				new SimpleDateFormat(SystemUtil.DF_SALL17).format(System.currentTimeMillis()));
		msg.setIntProperty("feedback", qmsg.feedback);

		// ���ӳ�ʱ���������,ԭ���е�DeadFlag��qcu��DeadFlag��������Ϊ1
		if (qmsg.getReplyToQ() != null && qmsg.getReplyToQ().trim().length() > 0)
		{
			msg.setIntProperty("JMS_TONG_DEAD_REPORT_TYPE", new Integer(512).intValue());
			msg.setStringProperty("JMS_TONG_DEAD_REPORTQNAME", qmsg.getReplyToQ());
		}

		return msg;
	}

	public static QueueMessage JMSMsgtoQMsg(BytesMessage msg) throws IOException, JMSException,
			ParseException
	{
		QueueMessage qmsg = new QueueMessage();
		String corrId = msg.getJMSCorrelationID();
		if (corrId != null && corrId.trim().length() > 0) qmsg.correlationId = corrId.getBytes();
		String msgId = msg.getJMSMessageID();
		if (msgId != null && msgId.trim().length() > 0) qmsg.messageId = msgId.getBytes();
		int len = Integer.valueOf(String.valueOf(msg.getBodyLength()));
		byte[] bytes = new byte[len];
		msg.readBytes(bytes);
		qmsg.expirySeconds = Integer.valueOf(String.valueOf((msg.getJMSPriority() - System
				.currentTimeMillis()) / 1000)); // msg.getJMSPriority()��ʾ��ϢʧЧ����ʱ��
		qmsg.buf = bytes;

		// ͨ���Զ������Բ�ȫQueueMessage
		if (!StringX.nullity(msg.getStringProperty("applicationIdData"))) qmsg.applicationIdData = msg
				.getStringProperty("applicationIdData");
		if (!StringX.nullity(msg.getStringProperty("applicationOriginData"))) qmsg.applicationOriginData = msg
				.getStringProperty("applicationOriginData");
		if (!StringX.nullity(msg.getStringProperty("putAppName"))) qmsg.putAppName = msg
				.getStringProperty("putAppName");

		qmsg.putDateTime = new SimpleDateFormat(SystemUtil.DF_SALL17).parse(msg
				.getStringProperty("putDateTime"));
		qmsg.feedback = msg.getIntProperty("feedback");

		return qmsg;
	}
}
