package spc.esb.data.converter;

import spc.esb.data.IMessage;
import spc.esb.data.IMessageSchema;
import spc.esb.data.util.CNode2XmlNodeVisitor;
import spc.esb.data.util.MessageTraversal;
import spc.webos.constant.Common;

/**
 * ���ݱ��Ľṹ�����л�xml���ģ�ʹ֮����schema��˳���ϵ
 * 
 * @author spc
 * 
 */
public class SchemaXMLConverter extends XMLConverter2
{
	public byte[] serialize(IMessage msg) throws Exception
	{
		StringBuffer xml = new StringBuffer();
		xml.append(IMessage.XML_HDR);
		xml.append('<');
		xml.append(IMessage.TAG_ROOT);
		xml.append('>');
		xml.append('<');
		xml.append(IMessage.TAG_HEADER);
		xml.append('>');
		CNode2XmlNodeVisitor cnode2xmlNodeVisitor = pretty ? new CNode2XmlNodeVisitor(true, 1)
				: new CNode2XmlNodeVisitor();
		MessageTraversal msgTraversal = new MessageTraversal(msg.getHeader(), msgSchema
				.getMsgSchema(esbHdrSchemaCd));
		msgTraversal.dfs(cnode2xmlNodeVisitor);
		xml.append(cnode2xmlNodeVisitor.toXml());
		xml.append('<');
		xml.append('/');
		xml.append(IMessage.TAG_HEADER);
		xml.append('>');
		xml.append('<');
		xml.append(IMessage.TAG_BODY);
		xml.append('>');

		xml.append('<');
		xml.append(IMessage.TAG_REQUEST);
		xml.append('>');
		String reqMsgCd = msg.isRequestMsg() ? msg.getMsgCd() : msg.getRefMsgCd();
		cnode2xmlNodeVisitor.clear();
		msgTraversal.setRoot(msg.getRequest());
		msgTraversal.setSchema(msgSchema.getMsgSchema(reqMsgCd));
		msgTraversal.dfs(cnode2xmlNodeVisitor);
		xml.append(cnode2xmlNodeVisitor.toXml());
		xml.append('<');
		xml.append('/');
		xml.append(IMessage.TAG_REQUEST);
		xml.append('>');
		if (!msg.isRequestMsg())
		{
			xml.append('<');
			xml.append(IMessage.TAG_RESPONSE);
			xml.append('>');
			msgTraversal.setRoot(msg.getResponse());
			msgTraversal.setSchema(msgSchema.getMsgSchema(msg.getMsgCd()));
			cnode2xmlNodeVisitor.clear();
			msgTraversal.dfs(cnode2xmlNodeVisitor);
			xml.append(cnode2xmlNodeVisitor.toXml());
			xml.append('<');
			xml.append('/');
			xml.append(IMessage.TAG_RESPONSE);
			xml.append('>');
		}
		xml.append('<');
		xml.append('/');
		xml.append(IMessage.TAG_BODY);
		xml.append('>');
		xml.append('<');
		xml.append('/');
		xml.append(IMessage.TAG_ROOT);
		xml.append('>');
		return xml.toString().getBytes(charset);
	}

	public static XMLConverter getInstance()
	{
		return SCHEMA_CVT;
	}

	protected boolean pretty;
	protected String esbHdrSchemaCd = "ESBREP";
	protected IMessageSchema msgSchema;
	protected String charset = Common.CHARSET_UTF8;

	public void setMsgSchema(IMessageSchema msgSchema)
	{
		this.msgSchema = msgSchema;
	}

	public void setEsbHdrSchemaCd(String esbHdrSchemaCd)
	{
		this.esbHdrSchemaCd = esbHdrSchemaCd;
	}

	public void setPretty(boolean pretty)
	{
		this.pretty = pretty;
	}

	public void setCharset(String charset)
	{
		this.charset = charset;
	}

	static SchemaXMLConverter SCHEMA_CVT = new SchemaXMLConverter();
}
