package spc.esb.data.converter;

import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import spc.esb.data.Array2Node2XML;
import spc.esb.data.CompositeNode;
import spc.esb.data.ICompositeNode;
import spc.esb.data.IMessage;
import spc.esb.data.INode2XML;

/**
 * ��ESB-XMLת��ΪSOAP XML
 * 
 * @author chenjs
 * 
 */
public class SOAPConverter extends XMLConverter2
{
	public SOAPConverter()
	{
		node2xml = new Array2Node2XML();
	}

	public IMessage deserialize(byte[] buf, IMessage msg) throws Exception
	{
		return deserializeSOAP(buf, msg);
	}

	public void serialize(IMessage msg, OutputStream os) throws Exception
	{
		os.write(SOAP_ROOT_START_TAG);
		ICompositeNode hdr = msg.getHeader();
		hdr.toXml(os, ns, null, true, node2xml, new HashMap());
		os.write(SOAP_MID);
		// hdr.toXml(os, "soap:Header", true, node2xml);
		// ICompositeNode transaction = new CompositeNode(msg.getTransaction());
		// if (removeLocal) transaction.remove(IMessage.TAG_LOCAL);
		// Message nmsg = new Message(transaction);
		// if (nmsg.getRequest() != null && nmsg.getRequest().size() > 0)
		// nmsg.getRequest().setExt(
		// "xsi:type",
		// "esb:REQ"
		// + StringX.replaceAll(
		// msg.isRequestMsg() ? msg.getMsgCd() : msg.getRefMsgCd(), ".", ""));
		// if (!msg.isRequestMsg() && nmsg.getResponse() != null &&
		// nmsg.getResponse().size() > 0) nmsg
		// .getResponse().setExt("xsi:type",
		// "esb:REP" + StringX.replaceAll(msg.getMsgCd(), ".", ""));
		// transaction.setExt("xsi:type", null);
		// if (!StringX.nullity(nsuris)) transaction.setExt("xmlns:" + ns,
		// nsuris);
		// transaction.toXml(os, null, msg.isRequestMsg() ?
		// getRequestRootTag(msg)
		// : getResponseRootTag(msg), pretty, node2xml, serializeAttr());
		ICompositeNode body = new CompositeNode(msg.getBody());
		if (body.containsKey(IMessage.TAG_RESPONSE)) body.remove(IMessage.TAG_REQUEST);
		body.toXml(os, ns, null, true, node2xml, new HashMap());
		// msg.getBody().toXml(os, "soap:Body", true, node2xml);
		os.write(SOAP_ROOT_END_TAG);
	}

	protected Map serializeAttr()
	{
		Map attr = super.serializeAttr();
		if (usingNodeNS) attr.put(INode2XML.USING_NODE_NS, Boolean.TRUE);
		return attr;
	}

	// protected String getResponseRootTag(IMessage msg)
	// {
	// return ns + ":transaction";
	// // return ns + ':' + StringX.replaceAll(msg.getMsgCd(), ".", "") +
	// // "Response";
	// }

	// protected String getRequestRootTag(IMessage msg)
	// {
	// return ns + ":transaction";
	// }

	protected boolean usingNodeNS; // ʹ�ýڵ��Դ���ns
	protected String ns = "esb";
	protected String nsuris = "http://www.yuchengtech.com/esb/"; // �����ռ�
	final byte[] SOAP_ROOT_START_TAG = "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" xmlns:esb=\"http://www.yuchengtech.com/esb/\">\n<soap:Header>"
			.getBytes();
	final byte[] SOAP_MID = "</soap:Header>\n<soap:Body>".getBytes();
	final byte[] SOAP_ROOT_END_TAG = "</soap:Body>\n</soap:Envelope>".getBytes();

	public String getNsuris()
	{
		return nsuris;
	}

	public void setNsuris(String nsuris)
	{
		this.nsuris = nsuris;
	}

	public void setNs(String ns)
	{
		this.ns = ns;
	}

	public void setUsingNodeNS(boolean usingNodeNS)
	{
		this.usingNodeNS = usingNodeNS;
	}
}
