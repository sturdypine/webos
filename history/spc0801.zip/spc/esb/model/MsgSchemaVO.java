package spc.esb.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;
import spc.webos.util.tree.ITreeNodeValue;

/**
 * genarated by sturdypine.chen Email: sturdypine@gmail.com description:
 */
public class MsgSchemaVO implements Serializable, ITreeNodeValue
{
	public static final long serialVersionUID = 20090722L;
	// ����������Ӧ�ֶε�����
	Integer seq; // ����
	Integer parentSeq; //
	String msgCd; //
	String esbName; //
	String rcvName; //
	String ftyp; //
	String min; //
	String max; //
	String minLen; // for compatible
	String maxLen; // for compatible
	Integer deci; //
	String optional; //
	String encrypt; //
	String sig;
	String reversal;
	String iso8583; // for iso8583 ����
	String fixmsg; // added by chenjs 2011-11-10 ������������
	String cmtTag; // added by chenjs 2011-11-22 ����cmt����
	String defValue; //
	String dict;
	String fvMapId; //
	String fdesc; //
	String cvtr; //
	String ftl; //
	String validator; // ��֤��
	String pattern; // �������ʽģ��
	String tagAttr; // ��չ����, xml��ǩ����չ����
	String metaData;
	String ext1;
	String ext2;
	String ext3;
	String ext4;
	String ext5;
	String ext6;
	
	protected List attributes; // ������Ϣ

	// �ʹ�VO�����������VO����

	// �ʹ�VO�������������Sql����
	// Note: ���������Sql����ΪString, Inegter...��Java final classʱ�� ֻ��ʹ��Object����
	// ����ʱ��ֻ��ͨ��
	// Object��toString()������ʹ�á�
	public static final String TABLE = "esb_msgstruct";
	public static final String[] BLOB_FIELD = null;
	public static final String SEQ_NAME = "seq";

	public MsgSchemaVO()
	{
	}

	public MsgSchemaVO(Integer seq)
	{
		this.seq = seq;
	}

	public void setPrimary(Integer seq)
	{
		this.seq = seq;
	}

	public String primary(String delim)
	{
		StringBuffer buf = new StringBuffer();
		buf.append(this.seq);
		return buf.toString();
	}

	public Map primary()
	{
		Map m = new HashMap();
		m.put("seq", seq);
		return m;
	}

	public String table()
	{
		return TABLE;
	}

	public String[] blobFields()
	{
		return BLOB_FIELD;
	}

//	public String getKeyName()
//	{
//		return SEQ_NAME;
//	}
//
//	public Serializable getKey()
//	{
//		return seq;
//	}

	// set all properties to NULL
	public void setNULL()
	{
		this.seq = null;
		this.parentSeq = null;
		this.msgCd = null;
		this.esbName = null;
		this.rcvName = null;
		this.ftyp = null;
		this.min = null;
		this.max = null;
		this.deci = null;
		this.optional = null;
		this.encrypt = null;
		this.fvMapId = null;
		this.fdesc = null;
		this.cvtr = null;
		this.validator = null;
	}

	public boolean equals(Object o)
	{
		if (this == o) return true;
		if (!(o instanceof MsgSchemaVO)) return false;
		MsgSchemaVO obj = (MsgSchemaVO) o;
		if (!seq.equals(obj.seq)) return false;
		if (!parentSeq.equals(obj.parentSeq)) return false;
		if (!msgCd.equals(obj.msgCd)) return false;
		if (!esbName.equals(obj.esbName)) return false;
		if (!rcvName.equals(obj.rcvName)) return false;
		if (!ftyp.equals(obj.ftyp)) return false;
		if (!min.equals(obj.min)) return false;
		if (!max.equals(obj.max)) return false;
		if (!deci.equals(obj.deci)) return false;
		if (!optional.equals(obj.optional)) return false;
		if (!encrypt.equals(obj.encrypt)) return false;
		if (!fvMapId.equals(obj.fvMapId)) return false;
		if (!fdesc.equals(obj.fdesc)) return false;
		if (!cvtr.equals(obj.cvtr)) return false;
		if (!validator.equals(obj.validator)) return false;
		return true;
	}

	// ֻ����������ɢ��
	public int hashCode()
	{
		long hashCode = getClass().hashCode();
		if (seq != null) hashCode += seq.hashCode();
		return (int) hashCode;
	}

	public int compareTo(Object o)
	{
		return -1;
	}

	// set all properties to default value...
	public void init()
	{
	}

	public Integer getSeq()
	{
		return seq;
	}

	public void setSeq(Integer seq)
	{
		this.seq = seq;
	}

	public Integer getParentSeq()
	{
		return parentSeq;
	}

	public void setParentSeq(Integer parentSeq)
	{
		this.parentSeq = parentSeq;
	}

	public String getMsgCd()
	{
		return msgCd;
	}

	public void setMsgCd(String msgCd)
	{
		this.msgCd = msgCd;
	}

	public String getEsbName()
	{
		return esbName;
	}

	public void setEsbName(String esbName)
	{
		this.esbName = esbName;
	}

	public String getRcvName()
	{
		return rcvName;
	}

	public void setRcvName(String rcvName)
	{
		this.rcvName = rcvName;
	}

	public String getFtyp()
	{
		return ftyp;
	}

	public void setFtyp(String ftyp)
	{
		this.ftyp = ftyp;
	}

	public String getMin()
	{
		return StringX.nullity(minLen) ? min : minLen;
	}

	public void setMin(String min)
	{
		this.min = min;
	}

	public void setMinLen(String min)
	{
		this.min = min;
	}

	public String getMinLen()
	{
		return getMin();
	}

	public String getMaxLen()
	{
		return getMax();
	}

	public String getMax()
	{
		return StringX.nullity(maxLen) ? max : maxLen;
	}

	public void setMax(String max)
	{
		this.max = max;
	}

	public void setMaxLen(String max)
	{
		this.max = max;
	}

	public Integer getDeci()
	{
		return deci;
	}

	public void setDeci(Integer deci)
	{
		this.deci = deci;
	}

	public String getOptional()
	{
		return optional;
	}

	public void setOptional(String optional)
	{
		this.optional = optional;
	}

	public String getIso8583()
	{
		return iso8583;
	}

	public void setIso8583(String iso8583)
	{
		this.iso8583 = iso8583;
	}

	public String getCmtTag()
	{
		return cmtTag;
	}

	public void setCmtTag(String cmtTag)
	{
		this.cmtTag = cmtTag;
	}

	public String getEncrypt()
	{
		return encrypt;
	}

	public void setEncrypt(String encrypt)
	{
		this.encrypt = encrypt;
	}

	public String getSig()
	{
		return sig;
	}

	public void setSig(String sig)
	{
		this.sig = StringX.trim(sig);
	}

	public String getDefValue()
	{
		return defValue;
	}

	public void setDefValue(String defValue)
	{
		this.defValue = defValue;
	}

	public String getDict()
	{
		return dict;
	}

	public void setDict(String dict)
	{
		this.dict = dict;
	}

	public String getReversal()
	{
		return reversal;
	}

	public void setReversal(String reversal)
	{
		this.reversal = reversal;
	}

	public String getFvMapId()
	{
		return fvMapId;
	}

	public void setFvMapId(String fvMapId)
	{
		this.fvMapId = fvMapId;
	}

	public String getFdesc()
	{
		return fdesc;
	}

	public void setFdesc(String fdesc)
	{
		this.fdesc = fdesc;
	}

	public String getCvtr()
	{
		return cvtr;
	}

	public void setCvtr(String cvtr)
	{
		this.cvtr = cvtr;
	}

	public String getFtl()
	{
		return ftl;
	}

	public void setFtl(String ftl)
	{
		this.ftl = ftl;
	}

	public String getTagAttr()
	{
		return tagAttr;
	}

	public void setTagAttr(String tagAttr)
	{
		this.tagAttr = tagAttr;
	}

	public String getFixmsg()
	{
		return fixmsg;
	}

	public void setFixmsg(String fixmsg)
	{
		this.fixmsg = fixmsg;
	}

	public String getExt1()
	{
		return ext1;
	}

	public String getMetaData()
	{
		return metaData;
	}

	public void setMetaData(String metaData)
	{
		this.metaData = metaData;
	}

	public void setExt1(String ext1)
	{
		this.ext1 = ext1;
	}

	public String getExt2()
	{
		return ext2;
	}

	public void setExt2(String ext2)
	{
		this.ext2 = ext2;
	}

	public String getExt3()
	{
		return ext3;
	}

	public void setExt3(String ext3)
	{
		this.ext3 = ext3;
	}

	public String getExt4()
	{
		return ext4;
	}

	public void setExt4(String ext4)
	{
		this.ext4 = ext4;
	}

	public String getExt5()
	{
		return ext5;
	}

	public void setExt5(String ext5)
	{
		this.ext5 = ext5;
	}

	public String getExt6()
	{
		return ext6;
	}

	public void setExt6(String ext6)
	{
		this.ext6 = ext6;
	}

	public void set(MsgSchemaVO vo)
	{
		this.seq = vo.seq;
		this.parentSeq = vo.parentSeq;
		this.msgCd = vo.msgCd;
		this.esbName = vo.esbName;
		this.rcvName = vo.rcvName;
		this.ftyp = vo.ftyp;
		this.min = vo.min;
		this.max = vo.max;
		this.deci = vo.deci;
		this.optional = vo.optional;
		this.encrypt = vo.encrypt;
		this.sig = vo.sig;
		this.fvMapId = vo.fvMapId;
		this.fdesc = vo.fdesc;
		this.cvtr = vo.cvtr;
		this.validator = vo.validator;
	}

	public static long getSerialVersionUID()
	{
		return serialVersionUID;
	}

	public StringBuffer toJson()
	{
		StringBuffer buf = new StringBuffer();
		buf.append(JsonUtil.obj2json(this));
		return buf;
	}

	public void afterLoad()
	{
	}

	public void beforeLoad()
	{
	}

	public void setManualSeq(Long seq)
	{
	}

	public void destory()
	{
	}

	public String toString()
	{
		StringBuffer buf = new StringBuffer(128);
		buf.append(getClass().getName() + "(serialVersionUID=" + serialVersionUID + "):");
		buf.append(toJson());
		return buf.toString();
	}

	// treenode interface...
	public Object getId()
	{
		return seq;
	}

	public String getNodeText()
	{
		return esbName;
	}

	public Object getParentId()
	{
		return parentSeq;
	}

	public boolean isRoot()
	{
		return this.seq == null || seq.longValue() <= 0;
	}

	// treenode interface

	public String getValidator()
	{
		return validator;
	}

	public void setValidator(String validator)
	{
		this.validator = validator;
	}

	public String getPattern()
	{
		return pattern;
	}

	public void setPattern(String pattern)
	{
		this.pattern = pattern;
	}

	public List getAttributes()
	{
		return attributes;
	}

	public void setAttributes(List attributes)
	{
		this.attributes = attributes;
	}
	
	public void addAttribute(MsgSchemaVO schema)
	{
		if (attributes == null) attributes = new ArrayList();
		attributes.add(schema);
	}
}
