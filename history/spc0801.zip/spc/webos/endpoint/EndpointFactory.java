package spc.webos.endpoint;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import spc.webos.util.StringX;

/**
 * ������Դ�����, ��̬����endpoint���͡�����tcp://192.168.0.01:8080,
 * http://192.168.0.01:8080/FA/ws. Ŀǰֻ֧��tcp/httpЭ��
 * 
 * @author chenjs
 * 
 */
public class EndpointFactory
{
	public Endpoint getEndpoint(String location) throws Exception
	{
		if (StringX.nullity(location)) return null;
		location = StringX.trim(location);
		int idx = location.indexOf(":");
		String protocol = location.substring(0, idx).toLowerCase();

		// is a syn socket protocol
		if (protocol.equals("tcp")) return new TCPEndpoint(location);
		if (protocol.equals("http")) return new HttpEndpoint(location);
		if (protocol.equals("spring")) return new SpringServiceEndpoint(location); // 900_20160320
		if (protocol.equals("class"))
		{ // ʹ���Զ��������
			int index = location.indexOf(':', 8);
			String strClass = location.substring(6, index);
			String loc = location.substring(index + 1);
			Endpoint endpoint = (Endpoint) Class.forName(strClass).newInstance();
			endpoint.setLocation(loc);
			endpoint.init();
			return endpoint;
		}
		log.warn("undefined protocal: " + location);
		return null;
	}

	static EndpointFactory factory = new EndpointFactory();

	public static EndpointFactory getInstance()
	{
		return factory;
	}

	protected final Logger log = LoggerFactory.getLogger(getClass());
}
