package spc.webos.bpl;

import java.util.Map;

import spc.webos.service.Service;
import spc.webos.util.POJOUtil;

public abstract class AbstractEngine extends Service
{
	public <T> T call(String process, Map params, T pojo) throws Exception
	{
		return POJOUtil.map2pojo(call(process, params), pojo);
	}

	public <T> T call(String process, Map params, T pojo, String[] properties) throws Exception
	{
		return POJOUtil.map2pojo(call(process, params), pojo, properties);
	}

	public <T> T call(String process, Map params, T pojo, String[][] properties) throws Exception
	{
		return POJOUtil.map2pojo(call(process, params), pojo, properties);
	}

	public abstract Map call(String process, Map params) throws Exception;
}
