package spc.webos.bpl.mule;

import java.util.Map;

import org.mule.DefaultMuleMessage;
import org.mule.api.ExceptionPayload;
import org.mule.api.MuleContext;
import org.mule.api.MuleException;
import org.mule.api.MuleMessage;
import org.mule.api.client.MuleClient;
import org.mule.config.ConfigResource;
import org.mule.config.spring.SpringXmlConfigurationBuilder;
import org.mule.context.DefaultMuleContextFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.io.Resource;

import spc.webos.bpl.AbstractEngine;

public class MuleEngine extends AbstractEngine implements ApplicationContextAware
{

	public Map call(String process, Map params) throws Exception
	{
		return (Map) call(process, (Object) params);
	}

	public Object call(String process, Object obj) throws Exception
	{
		MuleClient client = mule.getClient();
		MuleMessage result = client.send("vm://" + process,
				new DefaultMuleMessage(obj, (Map<String, Object>) null, mule));
		ExceptionPayload expayload = result.getExceptionPayload();
		if (expayload != null) throw (Exception) expayload.getRootException();
		return result.getPayload();
	}

	public void init() throws Exception
	{
		if (resource == null)
		{
			log.info("load default mule.xml");
			builder = new SpringXmlConfigurationBuilder(new ConfigResource[] {
					new ConfigResource("mule", getClass().getResourceAsStream("mule.xml")) });
		}
		else
		{
			log.info("load mule:{}", resource.getFilename());
			builder = new SpringXmlConfigurationBuilder(new ConfigResource[] {
					new ConfigResource(resource.getFilename(), resource.getInputStream()) });
		}
		builder.setParentContext(spring);
		mule = new DefaultMuleContextFactory().createMuleContext(builder);
		mule.start();
		log.info("mule OK");
	}

	public void destroy()
	{
		log.info("stop mule engine...");
		try
		{
			mule.stop();
		}
		catch (MuleException e)
		{
		}
		mule.dispose();
	}

	public MuleContext getMuleContext()
	{
		return mule;
	}

	protected MuleContext mule;
	protected ApplicationContext spring;
	protected SpringXmlConfigurationBuilder builder;
	protected Resource resource;

	public void setApplicationContext(ApplicationContext cxt) throws BeansException
	{
		spring = cxt;
	}

	public void setResource(Resource resource)
	{
		this.resource = resource;
	}
}
