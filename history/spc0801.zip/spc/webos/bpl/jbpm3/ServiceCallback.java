package spc.webos.bpl.jbpm3;

import spc.webos.cache.Map2Cache;

public class ServiceCallback
{
	Map2Cache cache = new Map2Cache();

	public void put(String corId, Object v) throws Exception
	{
		cache.put(corId, v);
	}

	public void setCache(Map2Cache cache)
	{
		this.cache = cache;
	}
}
