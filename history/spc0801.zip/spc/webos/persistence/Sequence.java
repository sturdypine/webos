package spc.webos.persistence;

// 900_20160107
public class Sequence
{
	public String table;
	public String name;
	public String column;
	public Long value;

	public Sequence()
	{
	}

	public Sequence(String name, String table, String column)
	{
		this.table = table.toLowerCase();
		this.name = name;
		this.column = column.toLowerCase();
	}
}
