package spc.webos.persistence.jdbc.blob;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

import spc.webos.constant.Common;
import spc.webos.persistence.PO;
import spc.webos.util.StringX;

public abstract class AbstractBlob implements IBlob, java.io.Serializable
{
	private static final long serialVersionUID = 1L;
	protected PO vo;
	protected String fieldName;
	protected transient InputStream is;

	public PO getVo()
	{
		return vo;
	}

	public void setVo(PO vo)
	{
		this.vo = vo;
	}

	public String getFieldName()
	{
		return fieldName;
	}

	public void setFieldName(String fieldName)
	{
		this.fieldName = fieldName;
	}

	public InputStream inputStream() throws IOException
	{
		return is;
	}

	public void close()
	{
		try
		{
			if (is != null) is.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		is = null;
	}

	public byte[] bytes()
	{
		return null;
	}

	public String toString()
	{
		try
		{
			return new String(bytes(), Common.CHARSET_UTF8);
		}
		catch (UnsupportedEncodingException e)
		{
			e.printStackTrace();
		}
		return StringX.EMPTY_STRING;
	}
}
