package spc.webos.persistence.jdbc.blob;

import java.io.IOException;
import java.io.InputStream;

public interface IBlob
{
	InputStream inputStream() throws IOException;

	String base64() throws Exception;

	int length();

	void close();
}
