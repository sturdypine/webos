package spc.webos.persistence.util;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * �������ݿ��ֶβ����ִ�Сд��������Ҫͨ��Сд���PO������������
 * 
 * @author chenjs
 *
 */
public class POPropertyUtil
{
	static Logger log = LoggerFactory.getLogger(POPropertyUtil.class);
	final static Map<Class<?>, Map<String, String>> CLASS_FIELD = new ConcurrentHashMap<Class<?>, Map<String, String>>();

	/**
	 * ���Դ�Сд������´�class�л�ȡ׼ȷ��Bean������
	 * 
	 * @param clazz
	 * @param fieldName
	 * @return
	 */
	public static String getProperty(Class<?> clazz, String fieldName)
	{
		Map<String, String> field = getClazzField(clazz);
		if (field == null) return null;
		return field.get(fieldName.toLowerCase());
	}

	public static Map<String, String> getClazzField(Class<?> clazz)
	{
		// synchronized (CLASS_FIELD)
		Map<String, String> field = CLASS_FIELD.get(clazz);
		if (field != null) return field;
		field = new HashMap<String, String>();
		Class<?> nclass = clazz;
		while (!nclass.equals(Object.class))
		{
			Field[] fields = nclass.getDeclaredFields();
			for (int i = 0; fields != null && i < fields.length; i++)
			{
				if (Modifier.isStatic(fields[i].getModifiers())) continue;
				String fname = fields[i].getName();
				field.put(fname.toLowerCase(), fname);
			}
			nclass = nclass.getSuperclass();
		}
		CLASS_FIELD.put(clazz, field);
		log.info("load class:{}, fields:{}", clazz.getName(), field.keySet());
		return field;
	}

	// public static void bean2map(Object bean, Map map)
	// {
	// Field[] fields = bean.getClass().getDeclaredFields();
	// for (int i = 0; i < fields.length; i++)
	// {
	// String name = fields[i].getName();
	// if (fields[i].getModifiers() == 4) continue; // ˽�е���Ϊ�ⲿ��������
	// Object value = null;
	// try
	// {
	// Method m = bean.getClass().getDeclaredMethod(
	// "get" + Character.toUpperCase(name.charAt(0)) + name.substring(1), null);
	// value = m.invoke(bean, null);
	// }
	// catch (Exception e)
	// {
	// }
	// if (value == null) continue;
	// map.put(name, value);
	// }
	// }
}
