package spc.webos.advice.log;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanWrapperImpl;

import spc.webos.service.seq.UUID;
import spc.webos.service.seq.impl.TimeMillisUUID;
import spc.webos.util.LogUtil;
import spc.webos.util.StringX;
import spc.webos.web.common.ISessionUserInfo;

public class LogTraceAdvice
{
	protected Logger log = LoggerFactory.getLogger(getClass());
	protected UUID uuid = new TimeMillisUUID(0);

	public Object trace(ProceedingJoinPoint pjp) throws Throwable
	{
		// 1. ��ǰ�����Ƿ���������Ҫ��־׷��
		Method method = pjp.getTarget().getClass().getMethod(pjp.getSignature().getName(),
				((MethodSignature) pjp.getSignature()).getParameterTypes());
		LogTrace trace = method.getAnnotation(LogTrace.class);
		if (trace == null) return pjp.proceed();

		// 2. ��ǰ�̻߳����Ѿ���������־׷����Ϣ����ֱ�ӷ���
		if (LogUtil.getTraceNo() != null && !trace.replace()) return pjp.proceed();

		// 3. �ҵ���־׷�ٺ���Ϣ
		boolean set = LogUtil.setTraceNo(
				getTraceNo(trace, method.getParameterAnnotations(), pjp.getArgs()),
				trace.location(), trace.replace());
		try
		{
			return pjp.proceed();
		}
		finally
		{ // ����ǵ�ǰ�߳�������logutil.traceno�� ��ǰ�߳�ִ���������̻߳�����˭����˭���
			if (set) LogUtil.removeTraceNo();
		}
	}

	protected String getTraceNo(LogTrace trace, Annotation[][] annotations, Object[] args)
	{
		if (trace.value() == LogTraceNoType.SESSION_ID)
		{
			ISessionUserInfo sui = ISessionUserInfo.SUI.get();
			if (sui != null) return sui.session().getId() + "-" + sui.requestCount();
			return null;
		}
		if (trace.value() == LogTraceNoType.REQUEST_USER)
		{
			ISessionUserInfo sui = ISessionUserInfo.SUI.get();
			if (sui != null) return sui.getUserCode() + "-" + sui.requestCount();
			return null;
		}
		if (trace.value() == LogTraceNoType.AUTO) return String.valueOf(uuid.uuid());
		if (trace.value() == LogTraceNoType.PARAM) return getTraceNo(annotations, args);
		return null;
	}

	public void setWorkId(int id)
	{
		uuid = new TimeMillisUUID(id);
	}

	public void setUuid(UUID uuid)
	{
		this.uuid = uuid;
	}

	// �ҵ���һ��ע��DSParam�Ĳ���ע����Ϣ���Լ���ǰ����ֵ
	protected String getTraceNo(Annotation[][] annotations, Object[] args)
	{
		if (annotations == null) return null;
		for (int i = 0; i < args.length; i++)
			for (int j = 0; annotations[i] != null && j < annotations[i].length; j++)
				if (annotations[i][j] instanceof LogTraceParamPath)
					return getTraceNo((LogTraceParamPath) annotations[i][j], args[i]);
		return null;
	}

	protected String getTraceNo(LogTraceParamPath path, Object arg)
	{
		if (StringX.nullity(path.value())) return arg != null ? arg.toString() : null; // ���ע��·��û����ֱ��ʹ�ô˲���
		BeanWrapperImpl wrapper = new BeanWrapperImpl(false);
		wrapper.setWrappedInstance(arg);
		Object trace = wrapper.getPropertyValue(path.value());
		log.debug("LogTraceNoPath:{}, trace:{}, arg:{}", path.value(), trace, arg);
		if (trace == null) return null;
		return trace.toString();
	}
}
