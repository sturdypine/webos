package spc.webos.service.seq;

public interface ISeqNo
{
	long nextId(String name);
}
