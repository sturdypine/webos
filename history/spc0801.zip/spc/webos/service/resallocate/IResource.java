package spc.webos.service.resallocate;

public interface IResource
{
	boolean match(String key);

	String group();

	String id();
}
