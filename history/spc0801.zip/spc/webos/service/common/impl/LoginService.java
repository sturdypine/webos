package spc.webos.service.common.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import spc.webos.constant.AppRetCode;
import spc.webos.exception.AppException;
import spc.webos.model.RolePO;
import spc.webos.model.UserPO;
import spc.webos.service.Service;
import spc.webos.service.common.ILoginService;
import spc.webos.util.SpringUtil;
import spc.webos.util.StringX;
import spc.webos.web.common.ISessionUserInfo;
import spc.webos.web.common.SessionUserInfo;

@org.springframework.stereotype.Service("loginService")
public class LoginService extends Service implements ILoginService
{
	// protected Map onlineUser = new HashMap();
	protected boolean pwdMD5; // �������MD5�㷨�洢
	protected boolean singleLogin; // �Ƿ񵥵��¼
	// protected String menuTailWhere;
	static LoginService LS = new LoginService();

	public boolean isTimeout()
	{
		return ISessionUserInfo.SUI.get() == null;
	}

	public Map getServerInfo()
	{
		Map params = new HashMap();
		params.put("timeout", ISessionUserInfo.SUI.get() == null);
		params.put("sysdt", SpringUtil.getInstance().getCurrentDate("yyyyMMdd"));
		return params;
	}

	public void logout()
	{
		ISessionUserInfo sui = (ISessionUserInfo) ISessionUserInfo.SUI.get();
		if (sui == null) return;
		try
		{
			log.info("{} logout session:{}", sui.getUserCode(), sui.session().getId());
			sui.session().invalidate();
		}
		catch (Exception e)
		{
			log.error("logout", e);
		}
	}

	public void login(String user, String pwd, String verifyCode)
	{
		SessionUserInfo sui = (SessionUserInfo) ISessionUserInfo.SUI.get();
		log.info("{} login {}, session id:{}", user, verifyCode, sui.session().getId());

		UserPO userVO = new UserPO();
		userVO.setCode(user);
		userVO = (UserPO) persistence.find(userVO);
		String password = pwdMD5 ? StringX.md5(pwd.getBytes()) : pwd;
		if (userVO == null || !userVO.getPwd().equals(password))
			throw new AppException(AppRetCode.CMMN_PWD_ERR, new Object[] { user });
		userVO.setPwd(null); // ��������Ϊnull
		sui.setRoles(getUserRole(userVO));
		sui.setUser(userVO);
		// register(sui);
	}

	protected List<String> getUserRole(UserPO userVO)
	{
		String roleId = userVO.getRoleId();
		List roles = StringX.split2list(roleId, StringX.COMMA);
		List menus = new ArrayList();
		for (int i = 0; i < roles.size(); i++)
		{
			RolePO roleVO = new RolePO();
			roleVO.setId((String) roles.get(i));
			roleVO = (RolePO) persistence.find(roleVO);
			if (roleVO == null) continue;
			List menu = StringX.split2list(roleVO.getMenu(), StringX.COMMA);
			for (int j = 0; menu != null && j < menu.size(); j++)
				if (!menus.contains(menu.get(j))) menus.add(menu.get(j));
		}
		return menus;
	}

	// public List getMenus()
	// {
	// SessionUserInfo sui = (SessionUserInfo) ISessionUserInfo.SUI.get();
	// log.info("menus: {}", sui.getRoles());
	// String menuId = StringX
	// .join((String[]) sui.getRoles().toArray(new
	// String[sui.getRoles().size()]), "','");
	// Map params = new HashMap();
	// params.put(IPersistence.SELECT_ATTACH_TAIL_KEY,
	// " and classname is not null and id in('" + menuId + "') "
	// + (StringX.nullity(menuTailWhere) ? StringX.EMPTY_STRING : menuTailWhere)
	// + " order by id"); // oracle ����ʹ�� classname <>''
	// // 2010-7-16
	// return (List) persistence.get(new MenuPO(), params);
	// }

	public int update(UserPO user)
	{
		return update(user, null);
	}

	public int update(UserPO user, String oldPwd)
	{
		SessionUserInfo sui = (SessionUserInfo) ISessionUserInfo.SUI.get();
		if (sui == null)
		{
			log.warn("session is over!!!");
			return 0;
		}
		UserPO sessionUser = (UserPO) sui.getUser();
		// added by chenjs 2012-02-18 ֻ���޸ĵ�ǰ�û���Ϣ
		user.setCode(sessionUser.getCode());
		if (!StringX.nullity(oldPwd) && !StringX.nullity(user.getPwd()))
		{ // ��Ҫ�޸�����, �ȿ�ԭ�����Ƿ�ƥ��
			if (pwdMD5)
			{
				oldPwd = StringX.md5(oldPwd.getBytes());
				user.setPwd(StringX.md5(user.getPwd().getBytes()));
			}
			UserPO oldUser = (UserPO) persistence.find(new UserPO(sessionUser.getCode()));
			if (!oldUser.getPwd().equals(oldPwd)) throw new AppException(AppRetCode.CMMN_PWD_ERR);
		}
		else user.setPwd(null); // �����޸�����
		return persistence.update(user);
	}

	public int insert(UserPO user)
	{
		if (pwdMD5 && !StringX.nullity(user.getPwd()))
			user.setPwd(StringX.md5(user.getPwd().getBytes()));
		return persistence.insert(user);
	}

	public void setPwdMD5(boolean pwdMD5)
	{
		this.pwdMD5 = pwdMD5;
	}

	public void setSingleLogin(boolean singleLogin)
	{
		this.singleLogin = singleLogin;
	}

	public LoginService()
	{
	}

	public static LoginService getInstance()
	{
		return LS;
	}
}
