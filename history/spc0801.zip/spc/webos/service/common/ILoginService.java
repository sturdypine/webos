package spc.webos.service.common;

import java.util.Map;

import spc.webos.model.UserPO;

public interface ILoginService
{
//	boolean forceLogout(String userCd);

//	List onlineUser(Map params); // ������������û�sessio

	void login(String userCode, String pwd, String verifyCode);

//	void register(ISessionUserInfo sui);

	void logout();

	int update(UserPO user, String oldPwd);

	int update(UserPO user);

	int insert(UserPO user);

	// ��õ�ǰ����Ȩ�޵Ĳ˵�
//	List getMenus();

	boolean isTimeout();

	Map getServerInfo();

	// void updatePwd(String oldPwd, String newPwd);
	//
	// void updateUserInfo(UserPO vo);
}
