package spc.webos.service.timeout;

public interface ITimeoutHandlerService
{
	void doTimeout(Timeout timeout) throws Exception;
}
