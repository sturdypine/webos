package spc.webos.message;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.HierarchicalMessageSource;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.NoSuchMessageException;

public class AppMessageSource implements HierarchicalMessageSource
{
	MessageSource parent;
	Map dict;
	static AppMessageSource APP_MSG = new AppMessageSource();
	Logger log = LoggerFactory.getLogger(AppMessageSource.class);
	public final static char SEPARATOR = '/';
	public final static char MUL_SEPARATOR = ','; // ���code���������ö��ŷָ�

	public String getMessage(String code, Object[] args, String defmsg, Locale locale)
	{
		if (log.isDebugEnabled()) log.debug("msgsourc: code=" + code);
		int index = code.indexOf(SEPARATOR);
		String prefix = code.substring(0, index);
		Object messageSource = dict == null ? null : dict.get(prefix);
		if (messageSource == null) return parent == null ? new MessageFormat(defmsg).format(args)
				: parent.getMessage(code, args, defmsg, locale);
		// System.out.println("code is :" + index + "," + code);
		String msg = getMessage(messageSource, code.substring(index + 1), args, defmsg, locale);
		if (log.isDebugEnabled()) log.debug("code:" + code + ",msg:" + msg);
		// System.out.println("code:" + code + ",msg:" + msg);
		return msg;
	}

	protected String getMessage(Object messageSource, String code, Object[] args,
			String defaultMessage, Locale locale)
	{
		// System.out.println("code is:" + code + ", " +
		// messageSource.getClass());
		int index = code.indexOf(SEPARATOR);
		String prefix = index > 0 ? code.substring(0, index) : code;
		String value = null;
		if (messageSource instanceof MessageSource)
		{ // Object is MessageSource
			value = (String) ((MessageSource) messageSource).getMessage(code, args, defaultMessage,
					locale);
			// System.out.println("MultiMessageSource.code="+code+",
			// value="+value);
		}
		else if (messageSource instanceof Map)
		{ // object is Map
			Object obj = ((Map) messageSource).get(prefix);
			if (obj == null) return defaultMessage;
			if (obj instanceof String) return new MessageFormat((String) obj).format(args);
			return getMessage(obj, code.substring(index + 1), args, defaultMessage, locale);
		}
		
		if (value != null) return value;
		if (defaultMessage == null) return null; // Ĭ����ϢҲ������һ����Ϣģ��
		return new MessageFormat(defaultMessage).format(args);
	}

	public String getMessage(String code, Object[] args, Locale locale)
			throws NoSuchMessageException
	{
		return getMessage(code, args, null, locale);
	}

	public String getMessage(MessageSourceResolvable resolvable, Locale locale)
			throws NoSuchMessageException
	{
		return resolvable.getDefaultMessage();
	}

	private AppMessageSource()
	{
	}

	public static AppMessageSource getInstance()
	{
		return APP_MSG;
	}

	public void setParentMessageSource(MessageSource parent)
	{
		this.parent = parent;
	}

	public MessageSource getParentMessageSource()
	{
		return parent;
	}

	public Map getDict()
	{
		return dict;
	}

	public void setDict(Map dict)
	{
		this.dict = dict;
	}
}
