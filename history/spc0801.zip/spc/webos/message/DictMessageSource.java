package spc.webos.message;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceResolvable;

import spc.webos.persistence.IPersistence;
import spc.webos.service.common.DictDesc;
import spc.webos.service.common.IDictService;
import spc.webos.service.common.OptionMap;
import spc.webos.service.common.impl.DictService;
import spc.webos.util.StringX;

/**
 * ϵͳ�����ֵ�����Message
 * 
 * @author chen.jinsong
 * 
 */
public class DictMessageSource implements MessageSource
{
	private static final long serialVersionUID = 1L;
	private static Logger log = LoggerFactory.getLogger(DictMessageSource.class);
	protected Map dict = new ConcurrentHashMap();
	protected boolean init;
	@Resource
	protected IPersistence persistence;
	private static DictMessageSource DICT_MSG = new DictMessageSource();

	public static DictMessageSource getInstance()
	{
		return DICT_MSG;
	}

	private DictMessageSource()
	{
	}

	public void init() throws Exception
	{
		if (init)
		{
			log.warn("DictMessageSource has been init!!!");
			return;
		}
		refresh();
		init = true;
	}

	public void refresh() throws Exception
	{
		dict = new ConcurrentHashMap();
		if (dictService != null) dictService.getAllDictDescVO(dict);
		if (log.isInfoEnabled()) log.info("dict table items: " + dict.size());
		this.loadBySqlId(dict);
		if (log.isInfoEnabled()) log.info("total dict items: " + dict.size());
		this.dict = dict;
	}

	/**
	 * ���args[0]��ֵ�Ҳ�Ϊ�գ����ʾ�����ṹ�������ֵ��У���Ҫ��ʾ���׽ڵ�
	 * args[1]��ֵ�����ʾitem����Ҫʹ��MessageFormat����һ������ݽ��и�ʽ��
	 */
	public String getMessage(String code, Object[] args, String defaultMessage, Locale locale)
	{
		List path = args != null && args.length > 0 && args[0] != null
				&& ((String) args[0]).length() > 0 ? new ArrayList() : null;
		DictDesc dd = getCode(code, path);
		if (dd == null) return defaultMessage;
		if (path == null)
		{
			if (args == null || args.length < 2) return dd.toString();
			return MessageFormat.format((String) args[1], dd.getItem());
		}

		StringBuffer b = new StringBuffer();
		for (int i = 0; i < path.size(); i++)
		{
			DictDesc d = (DictDesc) path.get(i);
			if (b.length() > 0) b.append(args[0]);
			b.append(d.getName());
		}
		b.append(args[0]);
		b.append(dd);
		return b.toString();
	}

	public String getMessage(String code, Object[] args, Locale locale)
	{
		return getMessage(code, args, null, locale);
	}

	public String getMessage(MessageSourceResolvable resolvable, Locale locale)
	{
		return null;
	}

	DictDesc getCode(String code, List path)
	{
		log.debug(code);
		int index = code.indexOf(AppMessageSource.SEPARATOR);
		String prefix = code.substring(0, index);
		DictDesc dd = (DictDesc) this.dict.get(prefix);
		if (dd == null) return null;
		dd = get(dd, code.substring(index + 1), path);
		return dd;
	}

	DictDesc get(DictDesc dd, String key, List path)
	{
		int index = key.indexOf(AppMessageSource.SEPARATOR);
		if (index < 0) return dd.dfs(key, path);
		return get((DictDesc) dd.getDict().get(key.substring(0, index)), key.substring(index + 1),
				path);
	}

	// �����ݿ��л�ȡ�����ֵ���Ϣ
	protected synchronized DictDesc getDataDictDesc(String code) throws Exception
	{
		DictDesc dd = (DictDesc) this.dict.get(code);
		if (dd != null) return dd;
		dd = dictService.getDictDesc(code);
		if (dd == null) return null;
		this.dict.put(code, dd);
		return dd;
	}

	protected void loadBySqlId(Map cache)
	{
		if (dictSqlId == null) return;
		for (int j = 0; j < dictSqlId.length; j++)
		{
			List dicts = (List) persistence.query(dictSqlId[j], null);
			if (dicts == null || dicts.size() == 0) return;
			String dtype = StringX.EMPTY_STRING;
			DictDesc ddesc = null;
			OptionMap dict = null;
			for (int i = 0; i < dicts.size(); i++)
			{
				List row = (List) dicts.get(i);
				String typ = (String) row.get(row.size() - 1); // �����ֵ����һ���ֶ�Ϊ����
				if (!typ.equals(dtype))
				{
					dtype = typ;
					ddesc = new DictDesc();
					dict = new OptionMap();
					ddesc.setDict(dict);
					ddesc.setItem(new Object[] { typ, typ });
					cache.put(typ, ddesc);
				}
				DictDesc vo = new DictDesc();
				vo.setItem(row.toArray());
				dict.put(vo.getItem()[0], vo);
			}
		}
	}

	IDictService dictService = new DictService();
	protected String[] dictSqlId; // ֧�ֳ������ֶ�ģʽ�������ֵ���ṹ�ļ���: code,text,dict

	public void setDictService(IDictService dictService)
	{
		this.dictService = dictService;
	}

	public void setDictSqlId(String[] dictSqlId)
	{
		this.dictSqlId = dictSqlId;
	}

	public Map getDict()
	{
		return dict;
	}

	public void setPersistence(IPersistence persistence)
	{
		this.persistence = persistence;
	}
}
