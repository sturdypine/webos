package spc.webos.tcc;

public enum RepositoryType
{
	MEMORY, REDIS, DB
}
