package spc.webos.tcc.service;

import java.util.List;

import spc.webos.constant.AppRetCode;
import spc.webos.exception.AppException;
import spc.webos.service.Service;
import spc.webos.tcc.Transaction;

public class TccService extends Service
{
	public void doTry(ITcc tcc)
	{
		tcc.setTccStatus(Transaction.STATUS_TRIED);
		persistence.insert(tcc);
	}

	public <T> List<T> findTried2Confirm(T pojo)
	{
		((ITcc) pojo).setTccStatus(Transaction.STATUS_TRIED);
		List<T> tried = persistence.get(pojo);
		if (tried != null && tried.size() > 0) return tried;

		((ITcc) pojo).setTccStatus(null);
		List<T> all = persistence.get(pojo);
		if (all == null || all.size() == 0) throw new AppException(AppRetCode.TCC_XID_NOEXISTS,
				new Object[] { ((ITcc) pojo).getTccXid() });

		if (log.isInfoEnabled()) log
				.info("All tried tcc confirmed by:" + ((ITcc) pojo).getTccXid());
		return null;
	}

	public <T> List<T> findTried2Cancel(T pojo)
	{
		((ITcc) pojo).setTccStatus(Transaction.STATUS_TRIED);
		List<T> tried = persistence.get(pojo);
		if (tried != null && tried.size() > 0) return tried;

		if (log.isInfoEnabled()) log
				.info("No tried tcc for cancel by:" + ((ITcc) pojo).getTccXid());
		return null;
	}

	public int doConfirm(ITcc tcc)
	{
		return updateStatus(tcc, "tccStatus", Transaction.STATUS_CONFIRMED);
	}

	public int doCancel(ITcc tcc)
	{
		return updateStatus(tcc, "tccStatus", Transaction.STATUS_CANCELED);
	}

	public int updateStatus(ITcc tcc, String statusColumn, int status)
	{
		tcc.setTccStatus(status);
		int rows = persistence.update(tcc, (String[]) null, "and " + statusColumn + "="
				+ Transaction.STATUS_TRIED, false, null); // updateָ������
		if (rows == 0)
		{
			if (log.isDebugEnabled()) log.debug("updateStatus influence:0, xid:" + tcc.getTccXid()
					+ ", " + status);
			// throw new AppException(AppRetCode.TCC_STATUS_CHANGE_FAIL,
			// new Object[] { ((ITcc) tcc).getTccXid() });
		}
		return rows;
	}
}
