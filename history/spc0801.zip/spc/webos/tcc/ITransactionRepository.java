package spc.webos.tcc;

import java.io.IOException;
import java.util.Collection;

public interface ITransactionRepository
{
	String createXid();

	Transaction create(Transaction transaction) throws Exception;

	void addTerminator(Transaction transaction, Object target, String clazz, String m,
			Class[] parameterTypes, Object[] args) throws Exception;

	Transaction updateStatus(Transaction transaction);

	Transaction delete(Transaction transaction, boolean byFail) throws Exception;

	Transaction find(String xid) throws Exception;

	Collection<String> findAll() throws Exception;

	Collection<String> findAllErr() throws Exception;
}
