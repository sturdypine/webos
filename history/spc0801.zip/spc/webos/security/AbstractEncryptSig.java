package spc.webos.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractEncryptSig implements IEncrypt, ISignature
{
	public void init() throws Exception
	{
		if (IEncrypt.ENCRYPTS.containsKey(name)) log.warn("IEncrypt(" + name + ") repeated!!!");
		IEncrypt.ENCRYPTS.put(name, this);
		if (ISignature.SIGS.containsKey(name)) log.warn("ISignature(" + name + ") repeated!!!");
		ISignature.SIGS.put(name, this);
	}

	protected Logger log = LoggerFactory.getLogger(getClass());
	protected String name;

	public void setName(String name)
	{
		this.name = name;
	}
}
