package spc.webos.web.filter.security;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import spc.webos.web.common.ISessionUserInfo;
import spc.webos.web.filter.AbstractURLFilter;
import spc.webos.web.util.URLEncoder;

/**
 * ֻ��ϵͳ�Լ����ɵ�url��ַ���ܷ��ʣ��û�������������url��ַ����get��ʽ����
 * 
 * @author chenjs
 * 
 */
public class URLGetSecurityFilter extends AbstractURLFilter
{
	public void filter(ServletRequest request, ServletResponse response, FilterChain chain,
			String patternURL) throws IOException, ServletException
	{
		HttpServletRequest req = (HttpServletRequest) request;
		if (!METHOD.equalsIgnoreCase(req.getMethod()))
		{
			chain.doFilter(request, response);
			return;
		}
		ISessionUserInfo sui = null;
		try
		{
			HttpSession session = req.getSession(false);
			if (session != null) sui = (ISessionUserInfo) session
					.getAttribute(ISessionUserInfo.USER_SESSION_INFO_KEY);
		}
		catch (Exception e)
		{
		}
		String key = null;
		if (sui != null) key = sui.getUrlKey();
		if (!URLEncoder.isValidURL(req.getQueryString(), key))
		{ // URL ���Ϸ�
			reportERROR((HttpServletResponse) response, req.getQueryString());
			return;
		}
		chain.doFilter(request, response);
	}

	String errorMsg = "queryString is error";
	static final String METHOD = "GET";

	void reportERROR(HttpServletResponse res, String queryString) throws IOException
	{
		String htmlText = "<meta http-equiv=Content-Type content='text/html; charset=UTF-8'>\n";
		htmlText += "<script>";
		htmlText += "\nalert(\"" + errorMsg + "(" + queryString + ")";
		htmlText += "\");\n</script>";
		res.getWriter().print(htmlText);
	}

	public void setErrorMsg(String errorMsg)
	{
		this.errorMsg = errorMsg;
	}
}
