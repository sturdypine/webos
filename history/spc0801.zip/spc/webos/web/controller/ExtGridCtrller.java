package spc.webos.web.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;

import spc.webos.constant.Web;
import spc.webos.persistence.IPersistence;
import spc.webos.persistence.SQLItem;
import spc.webos.util.StringX;
import spc.webos.web.util.WebUtil;

public class ExtGridCtrller extends JSCallCtrller
{
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response)
			throws Exception
	{
		ModelAndView mv = new ModelAndView(extGridView);
		WebUtil.request2map(request, mv.getModel());

		// 1. �����ext�����ѯ����
		String selSql = (String) request.getParameter(Web.REQ_KEY_SQL_ID);
		// json ��ʽ�ı������ݣ�ǰ��Ҫ�����sql���
		if (!StringX.nullity(selSql)) handleSel(request, response, mv.getModel());
		// 2. ִ�з���
		else handleService(request, response, mv.getModel(),
				call(request, response, StringX.null2emptystr(request.getParameter(argsName))));
		return mv;
	}

	protected void handleService(HttpServletRequest request, HttpServletResponse response,
			Map model, Object data) throws Exception
	{
		// a. ��ȡ�ֶ�����������ݽ�����е���Ҳ��List���ͣ���Ҫָ��ÿ�е��ֶ������ܱ�ΪJson��ʽ
		model.put(Web.EXTGRID_DS_KEY, data);
	}

	protected void handleSel(HttpServletRequest request, HttpServletResponse response, Map model)
			throws Exception
	{
		List batchSQL = new ArrayList();
		String selSql = (String) request.getParameter(Web.REQ_KEY_SQL_ID);
		String sizeSql = (String) request.getParameter(Web.REQ_KEY_SIZE_SQL_ID);
		String strBatchSQL = (String) request.getParameter(Web.REQ_KEY_BATCH_SQL);
		if (!StringX.nullity(strBatchSQL))
			batchSQL = StringX.delimitedList(strBatchSQL, StringX.COMMA);
		if (!StringX.nullity(sizeSql)) batchSQL.add(sizeSql);
		if (!StringX.nullity(selSql)) batchSQL.add(selSql);
		// Ϊ��������ܣ�ֱ���ò�ѯ�����json�ַ�����ʾ, ��ĳЩ������ܲ���Ҫǿ��ת�����ڲ�ѯ������溬�ж���������
		if (!model.containsKey("SQL_CLASS"))
			model.put(IPersistence.RESULT_CLASS_PREFIX + selSql, SQLItem.RESULT_CLASS_JSON);
		// System.out.println(sizeSql+batchSQL+request.getParameter("SIZE_SQL_ID"));
		persistence.execute(batchSQL, model, model);

		if (sizeSql != null) sizeSql = sizeSql.replace('.', '_').toLowerCase();
		selSql = selSql.replace('.', '_').toLowerCase();
		if (sizeSql != null) model.put(Web.EXTGRID_DS_SIZE_KEY, model.get(sizeSql));
		model.put(Web.EXTGRID_DS_KEY, model.get(selSql));
	}

	@Resource
	protected IPersistence persistence;
	protected String extGridView = "extGridView";

	public void setPersistence(IPersistence persistence)
	{
		this.persistence = persistence;
	}

	public void setExtGridView(String extGridView)
	{
		this.extGridView = extGridView;
	}
}
