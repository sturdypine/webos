package spc.webos.web.view;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.View;

import spc.webos.constant.Common;
import spc.webos.constant.Web;
import spc.webos.util.StringX;

/**
 * ��������ext grid��ʽ������
 * 
 * @author chenjs
 *
 */
public class ExtGridView implements View
{
	protected Logger log = LoggerFactory.getLogger(getClass());

	public String getContentType()
	{
		return Common.FILE_HTML_CONTENTTYPE;
	}

	public void render(Map model, HttpServletRequest request, HttpServletResponse response)
			throws Exception
	{
		handleTable((List) model.get(Web.EXTGRID_DS_KEY), model.get(Web.EXTGRID_DS_SIZE_KEY),
				request, response);
	}

	// added by chenjs 2011-12-22 �Ƿ�Ҫ����������ҳ
	protected List paging(List rows, HttpServletRequest request)
	{
		if (StringX.nullity(request.getParameter(Web.REQ_PAGING)) || rows == null
				|| rows.size() == 0)
			return rows;
		String limit = StringX.null2emptystr(request.getParameter(Web.REQ_GRIDDS_LIMIT),
				request.getParameter(Web.REQ_GRIDDS_DEF_LIMIT));
		if (StringX.nullity(limit)) return rows;
		String start = StringX.null2emptystr(request.getParameter(Web.REQ_GRIDDS_START), "0");
		if (rows.size() <= Integer.parseInt(limit))
		{ // ���Ŀǰ�������������limit���򲻷�ҳ��ֱ�ӷ���
			if (log.isInfoEnabled())
				log.info("Fail to paging: rows size: " + rows.size() + " <= imit: " + limit);
			return rows;
		}
		List nrows = new ArrayList();
		for (int i = Integer.parseInt(start); i < rows.size()
				&& (i < Integer.parseInt(start) + Integer.parseInt(limit)); i++)
			nrows.add(rows.get(i));
		return nrows;
	}

	protected void handleTable(List data, Object totalSize, HttpServletRequest request,
			HttpServletResponse response) throws Exception
	{
		List columns = null;
		String column = (String) request.getParameter(Web.REQ_KEY_COLUMN);
		if (!StringX.nullity(column)) columns = StringX.split2list(column, StringX.COMMA);
		PrintWriter pw = response.getWriter();
		String callback = (String) request.getParameter("callback");
		if (!StringX.nullity(callback))
		{
			pw.print(callback);
			pw.print('(');
		}

		// handleTable(result, totalSize, request, response, columns);
		String v = StringX.table2extgrid(paging(data, request),
				totalSize == null ? null : totalSize.toString(), columns);
		pw.print(v);
		if (!StringX.nullity(callback)) pw.print(')');
	}
}
