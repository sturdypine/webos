package spc.webos.web.view;

import java.io.StringWriter;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.View;

import spc.webos.constant.AppRetCode;
import spc.webos.constant.Common;
import spc.webos.constant.Web;
import spc.webos.exception.AppException;
import spc.webos.util.FTLUtil;
import spc.webos.util.SpringUtil;
import spc.webos.util.StringX;
import spc.webos.web.util.WebUtil;

// import
// org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

public class ExceptionView implements View
{
	protected String contentType = Common.FILE_HTML_CONTENTTYPE;
	protected String errPage = "main/ftl/error";
	// public final static String ERR_CLASS_KEY = "ERR_CLAZZ";
	protected Logger log = LoggerFactory.getLogger(getClass());

	public ExceptionView()
	{
	}

	public ExceptionView(String errPage, String contentType)
	{
		this.errPage = errPage;
		this.contentType = contentType;
	}

	public String getContentType()
	{
		return contentType;
	}

	public void render(Map model, HttpServletRequest request, HttpServletResponse response)
	{
		Exception ex = (Exception) model.get(Common.MODEL_EXCEPTION); // SimpleMappingExceptionResolver.DEFAULT_EXCEPTION_ATTRIBUTE
		if (ex != null) log.debug("Ex", ex);
		WebUtil.request2map(request, model);
		String code, loc, uri;

		if (ex instanceof AppException)
		{
			AppException appEx = (AppException) ex;
			model.put(Web.REQ_KEY_EX_CODE, code = appEx.getCode());
			model.put(Web.REQ_KEY_EX_LOC, loc = appEx.getLocation());
			try
			{
				model.put(Web.REQ_KEY_EX_MSG, SpringUtil.APPCXT.getMessage(
						SpringUtil.RETCD_PATH + appEx.getCode(), appEx.getArgs(), null));
			}
			catch (Exception e)
			{
				model.put(Web.REQ_KEY_EX_MSG, "Undefined desc!!!");
				log.warn("Fail to get error desc for " + appEx.getCode(), e);
			}
		}
		else
		{
			model.put(Web.REQ_KEY_EX_CODE, code = AppRetCode.CMMN_UNDEF_EX);
			model.put(Web.REQ_KEY_EX_MSG, ex.toString());
			StackTraceElement[] stack = ex.getCause() != null ? ex.getCause().getStackTrace()
					: ex.getStackTrace();
			loc = stack[0].getClassName() + '.' + stack[0].getMethodName() + ':'
					+ stack[0].getLineNumber();
			model.put(Web.REQ_KEY_EX_LOC, loc);
		}
		model.put("uri", uri = request.getRequestURI());
		// response.setStatus(Web.SERVER_EXCEPTION_STATUS_CODE);
		request.setAttribute(Web.RESP_ATTR_ERROR_KEY, Boolean.TRUE);

		log.info("uri:{}, content:{}, page:{}, code:{}, loc:{}, ex:{}", uri, contentType, errPage,
				code, loc, StringX.null2emptystr(ex));
		try
		{
			response.setContentType(contentType);
			StringWriter sw = new StringWriter();
			FTLUtil.freemarker(errPage, model, sw);
			log.debug("ex response:{}", sw);
			response.getWriter().write(sw.toString());
			response.getWriter().flush();
		}
		catch (Exception e)
		{
			log.error("errPage:" + errPage, e);
		}
	}

	public void setErrPage(String errPage)
	{
		this.errPage = errPage;
	}

	public void setContentType(String contentType)
	{
		this.contentType = contentType;
	}
}
