package spc.webos.web.view;

import java.io.IOException;
import java.util.Locale;

import org.springframework.web.servlet.view.AbstractTemplateViewResolver;

import freemarker.template.Template;
import spc.webos.util.FTLUtil;

public class FreeMarkerViewResolver extends AbstractTemplateViewResolver
{

	public FreeMarkerViewResolver()
	{
		setViewClass(requiredViewClass());
	}

	/**
	 * Requires {@link FreeMarkerView}.
	 */
	protected Class requiredViewClass()
	{
		return FreeMarkerView.class;
	}
}

/**
 * 800, ����ϵͳ���ö�ȡfreemarker
 * 
 * @author chenjs
 * 
 */
class FreeMarkerView extends org.springframework.web.servlet.view.freemarker.FreeMarkerView
{
	protected Template getTemplate(String name, Locale locale) throws IOException
	{
		String sname = name.toLowerCase().substring(0, name.length() - 4);
		sname = sname.replaceAll("/ftl/", "/");
		if (FTLUtil.getInstance().getFtlCache().containsKey(sname))
		{
			if (logger.isInfoEnabled()) logger.info("ftlutil ftl:" + sname);
			return (Template) FTLUtil.getInstance().getFtlCache().get(sname);
		}
		return super.getTemplate(name, locale);
	}
}
