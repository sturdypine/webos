package spc.webos.util;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.BeanWrapperImpl;

import net.sf.cglib.beans.BeanMap;

public class POJOUtil
{
	public static Map<Object, Object> pojo2map(Object pojo, Map m)
	{
		if (m == null) m = new HashMap();
		BeanMap bm = BeanMap.create(pojo);
		for (Object key : bm.keySet())
		{
			if ("class".equals(key)) continue;
			Object v = bm.get(key);
			if (v != null) m.put(key, v);
		}
		return m;
	}

	public static Map pojo2map(Object pojo, Map m, String[] properties)
	{
		BeanWrapperImpl wrapper = new BeanWrapperImpl();
		wrapper.setWrappedInstance(pojo);
		for (String p : properties)
			if (wrapper.isReadableProperty(p))
			{
				Object v = wrapper.getPropertyValue(p);
				if (v != null) m.put(p, v);
			}
		return m;
	}

	public static Map pojo2map(Object pojo, Map m, String[][] properties)
	{
		BeanWrapperImpl wrapper = new BeanWrapperImpl();
		wrapper.setWrappedInstance(pojo);
		for (String[] p : properties)
			if (wrapper.isReadableProperty(p[0]))
			{
				Object v = wrapper.getPropertyValue(p[0]);
				if (v != null) m.put((p.length == 1 || StringX.nullity(p[1])) ? p[0] : p[1], v);
			}
		return m;
	}

	public static Map pojo2map(Object pojo, Map m, String[] sp, String[] tp)
	{
		if (sp == null) return pojo2map(pojo, m);
		if (tp == null) return pojo2map(pojo, m, sp);
		BeanWrapperImpl wrapper = new BeanWrapperImpl();
		wrapper.setWrappedInstance(pojo);
		for (int i = 0; i < sp.length; i++)
			if (wrapper.isReadableProperty(sp[i]))
			{
				Object v = wrapper.getPropertyValue(sp[i]);
				if (v != null) m.put(StringX.nullity(tp[i]) ? sp[i] : tp[i], v);
			}
		return m;
	}

	public static Map<String, String> pojo2strmap(Object pojo)
	{
		Map<String, String> m = new HashMap<String, String>();
		BeanMap bm = BeanMap.create(pojo);
		for (Object key : bm.keySet())
		{
			String k = key.toString();
			if (k.equals("class")) continue;
			Object value = bm.get(key);
			if (value == null) continue;
			m.put(k, value.toString());
		}
		return m;
	}

	public static Map map2map(Map m, String[] properties)
	{
		if (properties == null) return new HashMap(m);
		Map map = new HashMap();
		for (String p : properties)
		{
			Object v = m.get(p);
			if (v != null) map.put(p, v);
		}
		return map;
	}

	public static Map map2map(Map m, String[][] properties)
	{
		if (properties == null) return new HashMap(m);
		Map map = new HashMap();
		for (String[] p : properties)
		{
			Object v = m.get(p[0]);
			if (v == null) continue;
			map.put(p.length > 1 && !StringX.nullity(p[1]) ? p[1] : p[0], v);
		}
		return map;
	}

	public static Map<String, String> strmap(Map m)
	{
		Map<String, String> hash = new HashMap<String, String>();
		for (Object key : m.keySet())
			hash.put(key.toString(), StringX.null2emptystr(m.get(key)));
		return hash;
	}

	public static <T> T setPropertyValue(T pojo, String[] properties, Object[] value)
	{
		BeanWrapperImpl wrapper = new BeanWrapperImpl();
		wrapper.setWrappedInstance(pojo);
		for (int i = 0; i < properties.length; i++)
			wrapper.setPropertyValue(properties[i], value[i]);
		return pojo;
	}

	public static <T> T setPropertyValue(T pojo, String p, Object v)
	{
		BeanWrapperImpl wrapper = new BeanWrapperImpl();
		wrapper.setWrappedInstance(pojo);
		wrapper.setPropertyValue(p, v);
		return pojo;
	}

	public static <T> T map2pojo(Map map, T pojo)
	{
		if (map == null || map.size() == 0) return pojo;
		BeanWrapperImpl wrapper = new BeanWrapperImpl();
		wrapper.setWrappedInstance(pojo);
		for (Object key : map.keySet())
			if (wrapper.isWritableProperty((String) key))
				wrapper.setPropertyValue((String) key, map.get(key));
		return pojo;
	}

	public static <T> T map2pojo(Map map, T pojo, String[] properties)
	{
		if (map == null || map.size() == 0) return pojo;
		BeanWrapperImpl wrapper = new BeanWrapperImpl();
		wrapper.setWrappedInstance(pojo);
		for (String key : properties)
			if (wrapper.isWritableProperty((String) key))
				wrapper.setPropertyValue((String) key, map.get(key));
		return pojo;
	}

	public static <T> T map2pojo(Map map, T pojo, String[][] properties)
	{
		if (map == null || map.size() == 0) return pojo;
		if (properties == null) return map2pojo(map, pojo);
		BeanWrapperImpl wrapper = new BeanWrapperImpl();
		wrapper.setWrappedInstance(pojo);
		for (String[] key : properties)
		{
			String k = (key.length == 1 || StringX.nullity(key[1])) ? key[0] : key[1];
			if (wrapper.isWritableProperty(k)) wrapper.setPropertyValue(key[0], map.get(k));
		}
		return pojo;
	}

	public static <T> T pojo2pojo(Object source, T pojo, String[] properties)
	{
		BeanWrapperImpl sw = new BeanWrapperImpl();
		sw.setWrappedInstance(source);
		BeanWrapperImpl pw = new BeanWrapperImpl();
		pw.setWrappedInstance(pojo);
		for (String p : properties)
			pw.setPropertyValue(p, sw.getPropertyValue(p));
		return pojo;
	}

	public static <T> T pojo2pojo(Object source, T pojo, String[][] properties)
	{
		BeanWrapperImpl sw = new BeanWrapperImpl();
		sw.setWrappedInstance(source);
		BeanWrapperImpl pw = new BeanWrapperImpl();
		pw.setWrappedInstance(pojo);
		for (String[] p : properties)
			pw.setPropertyValue((p.length == 1 || StringX.nullity(p[1])) ? p[0] : p[1],
					sw.getPropertyValue(p[0]));
		return pojo;
	}
}
