package spc.webos.util;

public interface IJson
{
	StringBuffer toJson();
}
