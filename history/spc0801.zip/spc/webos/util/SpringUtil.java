package spc.webos.util;

import java.io.File;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.xml.ResourceEntityResolver;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.context.event.ContextStoppedEvent;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.ResourceLoader;

import com.google.gson.Gson;

import spc.webos.config.AppConfig;
import spc.webos.constant.AppRetCode;
import spc.webos.constant.Common;
import spc.webos.constant.Config;
import spc.webos.exception.AppException;
import spc.webos.exception.Status;
import spc.webos.message.AppMessageSource;
import spc.webos.model.BeanPO;
import spc.webos.persistence.IPersistence;
import spc.webos.util.netinfo.NetworkInfo;

/**
 * ϵͳ������
 * 
 * @author spc
 * 
 */
public final class SpringUtil implements ResourceLoaderAware, ApplicationContextAware
{
	public static ApplicationContext APPCXT; // ��ǰspring����
	public static String LOCAL_HOST_IP = "127.0.0.1"; // ����ip��ַ
	public static String MAC = null; // ��ǰ������mac��ַ
	public static String RETCD_PATH = "RETCD/"; // ��������Ϣ·��, 900 ��MSG �޸�ΪRETCD
	public static String DICT_PATH = "DICT/"; // �����ֵ���Ϣ·��
	public final static Date JVM_START_TIME = new Date(); // ��ǰjvm����������ʱ��
	public static String TEMPFILE_DIR = "classpath:tmpfile"; // ��ʱ�ļ���

	public static String PID; // ��ǰ���̺�
	public static String FTS_AGENT; // �������FTS�ļ�����ڵ�����
	public static String APPCODE = "ESB";// ϵͳӦ��ID,���������ڵ�ϵͳ���, ���ܳ���3���ַ�
	public static String JVM = "SPC"; // jvm��ʾ���е�����������൱��ģ��, ���ܳ���3���ַ�
	public static String JVMDESC = "sturdypine@icloud.com"; // JVM����
	// public static String NODE; // �ڵ�� = "0000", modified by spc

	final static Logger log = LoggerFactory.getLogger(SpringUtil.class);
	private static String autowireBeans; // 715_20141015
											// spring��������ʱ��esb_config�������Զ�װ���bean

	@PostConstruct
	public void init()
	{
	}

	public static String pid()
	{
		if (PID != null) return PID;
		String name = ManagementFactory.getRuntimeMXBean().getName();
		return PID = name.split("@")[0];
	}

	public static String getLocalHostIP()
	{
		return LOCAL_HOST_IP;
	}

	public void setApplicationContext(ApplicationContext appCxt)
	{
		APPCXT = appCxt;
	}

	public static String getMessage(String code, String defaultMessage)
	{
		return getMessage(code, null, defaultMessage, null);
	}

	public static String getMessage(String code, Object[] args, String defaultMessage)
	{
		return getMessage(code, args, defaultMessage, null);
	}

	public static String getMessage(String code, List args, String defaultMessage)
	{
		return getMessage(code, (args != null ? args.toArray() : null), defaultMessage, null);
	}

	public static String getMessage(String code, Object[] args, Locale locale)
	{
		return getMessage(code, args, null, locale);
	}

	public static String getMessage(String code, Object[] args, String def, Locale locale)
	{
		if (StringX.nullity(def)) def = StringX.getMessageFormat(args == null ? 0 : args.length);
		try
		{
			return APPCXT.getMessage(code, args, def, locale);
		}
		catch (Exception e)
		{
			log.warn("Fail to get error desc for " + code, e);
		}
		return new MessageFormat(def).format(args);
	}

	public static String getMessage(String path, String code, Object[] args, Locale locale)
	{
		String sep = StringX.COMMA;
		if (code.indexOf(sep) < 0)
			return APPCXT.getMessage(path + AppMessageSource.SEPARATOR + code, args, locale);
		// ���ڶ�ѡ
		StringBuffer buf = new StringBuffer();
		String[] ccode = StringX.split(code, sep);
		for (int i = 0; i < ccode.length; i++)
		{
			if (buf.length() > 0) buf.append(sep);
			buf.append(
					APPCXT.getMessage(path + AppMessageSource.SEPARATOR + ccode[i], args, locale));
		}
		// System.out.println(buf);
		return buf.toString();
	}

	/**
	 * ͨ���쳣����һ����Ϣ״̬
	 * 
	 * @param prefix
	 *            ��Ϣ����ǰ׺
	 * @param ex
	 *            �쳣
	 * @return
	 */
	public static Status ex2status(String prefix, Throwable ex)
	{
		Status status = new Status();
		// if (!StringX.nullity(NODE)) status.setMbrCd(NODE);
		status.setAppCd(APPCODE);
		status.setIp(SpringUtil.LOCAL_HOST_IP);
		String retCd = StringX.EMPTY_STRING;
		if (ex instanceof AppException)
		{ // ϵͳ����֪�쳣
			AppException appEx = (AppException) ex;
			if (log.isDebugEnabled())
			{
				Object[] args = appEx.getArgs();
				StringBuffer buf = new StringBuffer();
				for (int i = 0; args != null && i < args.length; i++)
					buf.append(args[i] + ",");
				log.debug("err,args:" + buf, ex);
			}
			if (appEx.getStatus() != null)
			{ // �쳣���Ѿ����б�׼���쳣��Ϣ
				if (log.isDebugEnabled()) log.debug("appEx status: " + appEx.getStatus());
				return appEx.getStatus();
			}
			retCd = appEx.getCode();
			// status.setRetCd(appEx.getCode());
			if (!StringX.nullity(appEx.getDefErrMsg()))
			{ // ���������Ĭ����Ϣ��ʹ��Ĭ��
				status.setDesc(appEx.getDefErrMsg());
			}
			else if (StringX.nullity(appEx.getCode())
					|| AppRetCode.CMM_BIZ_ERR.equals(appEx.getCode()))
			{ // ���������ͨ��ҵ�������ʹ��Ĭ����Ϣ
				retCd = AppRetCode.CMM_BIZ_ERR;
				// status.setRetCd(AppRetCode.CMM_BIZ_ERR);
				status.setDesc(appEx.getDefErrMsg());
			}
//			else if (ex instanceof MsgErrException)
//				status.setDesc(prefix + ((MsgErrException) ex).getErrors().getErrDesc());
			else if (StringX.nullity(appEx.getMsgFormat()))
			{ // ����쳣û������Ϣ����ģ���ʽʹ�ø��ݷ����뵽���ݿ���Ѱ�Ҹ�ʽ
				status.setDesc(prefix + getMessage(SpringUtil.RETCD_PATH + retCd, appEx.getArgs(),
						appEx.getDefErrMsg(), null));
			}
			else
			{ // ����쳣��ָ����msgformat
				status.setDesc(
						prefix + new MessageFormat(appEx.getMsgFormat()).format(appEx.getArgs()));
			}
			status.setLocation(JVM() + "::" + appEx.getLocation());
		}
		else
		{ // δ֪�쳣
			log.warn("undef ex, prefix:" + prefix, ex);
			retCd = (ex instanceof NullPointerException) ? AppRetCode.CMMN_NULLPOINT_EX
					: AppRetCode.CMMN_UNDEF_EX;
			String desc = ex.toString() + StringX.stackTrace(ex.getStackTrace(), 5);
			if (desc.length() > 900) desc = desc.substring(0, 900);
			if (desc.startsWith("java.lang.Exception")) desc = desc.substring(20);
			if (StringX.isContainCN(desc)) retCd = AppRetCode.CMM_BIZ_ERR; // ����쳣�к�������,����Ϊ��ͨ��ҵ�����
			status.setDesc(prefix + desc);
			status.setLocation(JVM() + "::" + AppException.getLocation(ex.getStackTrace()));
		}
		status.setRetCd(retCd);
		return status;
	}

	// ����spring����
	public static synchronized ApplicationContext load(String... files) throws Exception
	{
		if (APPCXT != null)
		{
			log.info("spring context has been loaded...");
			return APPCXT;
		}
		log.info("start to load spring context in classpath:" + Thread.currentThread()
				.getContextClassLoader().getResource(StringX.EMPTY_STRING).getFile());
		APPCXT = new ClassPathXmlApplicationContext(files);
		SpringUtil.loadAutowireBeans(); // 804_20150315 �Զ�װ��bean, MB�в����Զ�����bean
		Runtime.getRuntime().addShutdownHook(hook = new Thread()
		{
			public void run()
			{
				log.warn("ShutdownHook: jvm will halt...");
				if (SpringUtil.getInstance().APPCXT == null) return;
				try
				{
					SpringUtil.unload();
				}
				catch (Exception e)
				{
					log.warn("unload context for jvm halt...", e);
				}
			}
		});
		return APPCXT;
	}

	// 715_201011 ��̬��ǰspring context����һ��bean����
	public static String SPRING_BEAN_PREFIX = "<beans xmlns=\"http://www.springframework.org/schema/beans\" "
			+ "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:p=\"http://www.springframework.org/schema/p\" "
			+ "xmlns:context=\"http://www.springframework.org/schema/context\" xmlns:util=\"http://www.springframework.org/schema/util\" "
			+ "xsi:schemaLocation=\"http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans-3.0.xsd http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context-3.0.xsd http://www.springframework.org/schema/util http://www.springframework.org/schema/util/spring-util-3.0.xsd\">";

	static Map beanCache = new HashMap(); // 801_20150115

	// 801_20150115
	public static Map loadBeanInDB(IPersistence persistence) throws IOException
	{
		Map cache = new HashMap();
		List beans = null;
		try
		{
			beans = persistence.get(new BeanPO());
		}
		catch (Exception e)
		{
			log.info("fail to load Bean in DB:" + e);
		}
		if (beans == null) return cache;
		for (int i = 0; i < beans.size(); i++)
		{
			BeanPO vo = (BeanPO) beans.get(i);
			cache.put(vo.getId(), vo.getBean());
		}
		log.info("Bean in DB: ", cache.keySet());
		return beanCache = cache;
	}

	public static void loadXMLBean(String beanXML) throws Exception
	{
		log.info("bean xml:{}", beanXML);
		if (StringX.nullity(beanXML)) return;
		XmlBeanDefinitionReader xbdr = new XmlBeanDefinitionReader(
				(BeanDefinitionRegistry) ((ConfigurableApplicationContext) APPCXT)
						.getBeanFactory());
		xbdr.setResourceLoader(APPCXT);
		xbdr.setEntityResolver(new ResourceEntityResolver(APPCXT));
		beanXML = SPRING_BEAN_PREFIX + beanXML + "</beans>";
		xbdr.loadBeanDefinitions(new ByteArrayResource(beanXML.getBytes(Common.CHARSET_UTF8)));
	}

	public static void registerBeans()
	{ // ��Ҫ����spring�е�bean
		String[] beans = ((ConfigurableApplicationContext) APPCXT).getBeanDefinitionNames();
		for (int i = 0; i < beans.length; i++)
			APPCXT.getBean(beans[i]);
	}

	public static void loadBean(String[] location) throws Exception
	{
		log.info("bean xml location:{}", location);
		XmlBeanDefinitionReader xbdr = new XmlBeanDefinitionReader(
				(BeanDefinitionRegistry) ((ConfigurableApplicationContext) APPCXT)
						.getBeanFactory());
		xbdr.setResourceLoader(APPCXT);
		xbdr.setEntityResolver(new ResourceEntityResolver(APPCXT));
		xbdr.loadBeanDefinitions(location);
	}

	public static synchronized void loadBean(String beanId) throws Exception
	{
		log.info("load bean id:" + beanId + " in sys_bean or esb_config");
		String beanXML = (String) beanCache.get(beanId); // 801_20150115���ȼ������ݿ��������
		if (beanXML == null) beanXML = (String) AppConfig.getInstance()
				.getProperty(Config.SPRING_BEAN + "." + beanId, null);
		loadXMLBean(beanXML);
	}

	public Object loadBean(String beanId, Class clazz)
	{
		Object bean = getBean(beanId, clazz);
		if (bean != null) return bean;
		synchronized (APPCXT)
		{ // �Ӻ�ͬ���㣬�������
			bean = getBean(beanId, clazz);
			if (bean != null) return bean;
			try
			{
				loadBean(beanId);
				return getBean(beanId, clazz);
			}
			catch (Throwable t)
			{
				log.error("fail to load bean: " + beanId, t);
			}
		}
		return null;
	}

	public static void loadAutowireBeans() throws Exception
	{ // 715_20141015 �Զ�װ��bean
		log.info("load autowireBeans:" + autowireBeans);
		if (StringX.nullity(autowireBeans)) return;
		String[] beanIds = StringX.split(autowireBeans, StringX.COMMA);
		for (int i = 0; i < beanIds.length; i++)
			loadBean(beanIds[i]);
		registerBeans();
	}

	// 715 end

	static Thread hook;

	// ж��spring����
	public static synchronized void unload() throws Exception
	{
		if (APPCXT == null)
		{
			log.debug("app spring context is null!!!");
			return;
		}
		log.warn(SpringUtil.getInstance().getCurrentDate("yyyyMMddHHmmssSSS") + " JVM("
				+ SpringUtil.JVM + ") App(" + SpringUtil.APPCODE + ") spring context unload...");
		try
		{
			APPCXT.publishEvent(new ContextStoppedEvent(APPCXT));
		}
		finally
		{
			APPCXT = null;
		}
	}

	// ����jvm��Ϣ
	public static void debugJvm()
	{
		log.info("Booting JVM...webos version:" + Common.VERSION() + ", version date:"
				+ Common.VERSION_DATE() + ", webapp.root: "
				+ System.getProperty(Common.WEBAPP_ROOT_PATH_KEY));
		if (log.isDebugEnabled())
		{
			Iterator keys = System.getProperties().keySet().iterator();
			while (keys.hasNext())
			{
				String key = keys.next().toString();
				if (key.startsWith("java"))
					log.debug(key + ":" + System.getProperties().getProperty(key));
			}
		}
	}

	public static void invoke(String[] beanMethods)
	{
		log.debug("start to invoke: {}", beanMethods);
		for (int i = 0; i < beanMethods.length; i++)
		{
			int index = beanMethods[i].indexOf('.');
			String beanId = beanMethods[i].substring(0, index);
			Object target = SpringUtil.getInstance().getBean(beanId, null);
			if (target == null) continue;
			Method method = findMethod(beanMethods[i]);
			try
			{
				log.info("invoke:{}", beanMethods[i]);
				method.invoke(target, null);
			}
			catch (Exception e)
			{
				log.warn("fail to invoke: " + beanMethods[i], e);
			}
		}
	}

	public static Method findMethod(String beanMethod)
	{
		int index = beanMethod.indexOf('.');
		return findMethod(beanMethod.substring(0, index), beanMethod.substring(index + 1));
	}

	public static Method findMethod(String beanId, String method)
	{
		Object target = SpringUtil.getInstance().getBean(beanId, null);
		if (target == null) return null;
		Method[] candidates = target.getClass().getMethods();
		for (int i = 0; i < candidates.length; i++)
		{
			Method candidate = candidates[i];
			if (candidate.getName().equals(method))
			{
				Class[] paramTypes = candidate.getParameterTypes();
				if (paramTypes.length == 0) return candidate;
			}
		}
		return null;
	}

	public String getCurrentDate(String format)
	{
		return new SimpleDateFormat(format).format(getCurrentDate());
	}

	public Date getCurrentDate()
	{
		return new Date();
	}

	public static SpringUtil getInstance()
	{
		return SYSTEM_UTIL;
	}

	public static String relativePath2AbsolutePath(String dir) throws Exception
	{
		ResourceLoader resourceLoader = SYSTEM_UTIL.getResourceLoader();
		if (resourceLoader != null) return resourceLoader.getResource(StringX.null2emptystr(dir))
				.getFile().getAbsolutePath();
		return new File(Thread.currentThread().getContextClassLoader().getResource(dir).toURI())
				.getAbsolutePath();
	}

	protected Map springBeanCache = new Hashtable(200, 0.6f);

	public Object getBean(String beanId, Class clazz)
	{
		if (StringX.nullity(beanId)) return null;
		Object obj = springBeanCache.get(beanId);
		if (obj != null && (clazz == null || obj.getClass() == clazz)) return obj;
		if (APPCXT == null)
		{
			log.error("appCxt is null!!!");
			return null;
		}
		try
		{
			obj = clazz == null ? APPCXT.getBean(beanId) : APPCXT.getBean(beanId, clazz);
		}
		catch (NoSuchBeanDefinitionException nsbde)
		{
			if (log.isDebugEnabled())
				log.debug("cannot load bean in spring cxt for bean id: " + beanId
						+ (clazz != null ? ", class: " + clazz.getName() : StringX.EMPTY_STRING));
		}
		if (obj != null) springBeanCache.put(beanId, obj);
		return obj;
	}

	public void setResourceLoader(ResourceLoader resourceLoader)
	{
		this.resourceLoader = resourceLoader;
	}

	protected ResourceLoader resourceLoader;
	final static SpringUtil SYSTEM_UTIL = new SpringUtil();

	public ResourceLoader getResourceLoader()
	{
		return resourceLoader;
	}

	static
	{
		try
		{
			LOCAL_HOST_IP = NetworkInfo.getLocalHost();
			if (LOCAL_HOST_IP == null) LOCAL_HOST_IP = StringX.EMPTY_STRING;
			// ��ֹIP��ַ����
			if (LOCAL_HOST_IP.length() > 15) LOCAL_HOST_IP = LOCAL_HOST_IP.substring(0, 15);
			// MAC = NetworkInfo.getMacAddress();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public String getApp()
	{
		return APPCODE;
	}

	public void setApp(String app)
	{
		APPCODE = app;
	}

	public void setFtsAgent(String ftsAgent)
	{
		FTS_AGENT = ftsAgent;
	}

	public String getJvm()
	{
		return JVM;
	}

	public void setJvm(String jvm)
	{
		JVM = jvm;
	}

	public void setJvmDesc(String jvmDesc)
	{
		JVMDESC = jvmDesc;
	}

	// public String getNode()
	// {
	// return NODE;
	// }

	// public void setNode(String node)
	// {
	// NODE = node;
	// }

	public void setTempfileDir(String tempfileDir)
	{
		TEMPFILE_DIR = tempfileDir;
	}

	public static File getTempfileDir() throws IOException
	{
		return SYSTEM_UTIL.getResourceLoader().getResource(TEMPFILE_DIR).getFile();
	}

	public static String JVM()
	{
		return JVM;
	}

	public static String getAutowireBeans()
	{
		return autowireBeans;
	}

	public void setAutowireBeans(String autowireBeans)
	{
		SpringUtil.autowireBeans = autowireBeans;
	}

	// ------------ for json call-------------
	public static String PAR_TYPES_TAG = "types";
	public static String PAR_ARGS_TAG = "args";

	public static Object jsonCall(String service, String m, String request) throws Exception
	{
		Gson gson = new Gson();
		Object target = SpringUtil.getInstance().getBean(service, null);
		Method method = null;
		Object[] args = null;
		request = StringX.trim(request);
		if (StringX.nullity(request))
		{ // û�в���
			log.debug("no args");
			method = findMethod(target, m, 0);
		}
		else if (request.charAt(0) == '[')
		{ // is args array
			List argList = gson.fromJson(request, ArrayList.class);
			int argNum = argList == null ? 0 : argList.size();
			log.debug("find method:{} by args:{}", m, argNum);
			method = findMethod(target, m, argNum);
			args = createArgs(gson, method.getParameterTypes(), argList);
		}
		else
		{ // is map: args types & args
			Map map = gson.fromJson(request, HashMap.class);
			List argList = (List) map.get(PAR_ARGS_TAG);

			List<String> types = (List<String>) map.get(PAR_TYPES_TAG);
			Class[] parameterTypes = null;
			if (types != null && types.size() > 0)
			{
				parameterTypes = new Class[types.size()];
				for (int i = 0; i < types.size(); i++)
					parameterTypes[i] = Class.forName(types.get(i));
			}
			method = parameterTypes == null
					? findMethod(target, m, argList == null ? 0 : argList.size())
					: target.getClass().getMethod(m, parameterTypes);
			args = createArgs(gson, method.getParameterTypes(), argList);
		}

		log.debug("args:{}", args);
		try
		{
			return method.invoke(target, args);
		}
		catch (InvocationTargetException e)
		{
			log.debug("fail to invoke:{}.{} target:{}", service, m, e.getTargetException());
			throw (Exception) e.getTargetException();
		}
	}

	public static Object[] createArgs(Gson gson, Class[] paramterClass, List list)
	{
		if (list == null || list.size() == 0) return null;

		Object[] args = new Object[list.size()];
		for (int i = 0; i < list.size(); i++)
		{
			String json = gson.toJson(list.get(i));
			args[i] = gson.fromJson(json, paramterClass[i]);
		}
		return args;
	}

	public static Method findMethod(Object target, String method, int argsNum)
	{
		Method[] methods = target.getClass().getMethods();
		for (Method m : methods)
			if (m.getName().equals(method) && m.getParameterTypes().length == argsNum) return m;
		return null;
	}
}
