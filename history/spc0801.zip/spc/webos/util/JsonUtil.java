package spc.webos.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;

import net.sf.ezmorph.bean.MorphDynaBean;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import net.sf.json.processors.JsonValueProcessor;
import spc.webos.persistence.jdbc.blob.ByteArrayBlob;

public class JsonUtil
{
	static JsonUtil INSTANCE = new JsonUtil();

	public static JsonUtil getInstance()
	{
		return INSTANCE;
	}

	// 900, ������ftl�в���json����
	public static String gson(Object src)
	{
		return new Gson().toJson(src);
	}

	public static Object json2obj(String json, String clazz) throws ClassNotFoundException
	{
		return JSONObject.toBean(JSONObject.fromObject(json), Class.forName(clazz));
	}

	public static Object json2obj(String json, Class clazz)
	{
		return JSONObject.toBean(JSONObject.fromObject(json), clazz);
	}

	public static Object json2obj(String json)
	{
		if (StringX.nullity(json)) return null;
		json = StringX.trim(json, StringX.TRIM_CHAR);
		if (StringX.nullity(json)) return null;
		if (json.charAt(0) == '[')
		{
			List l = new ArrayList();
			l.addAll(JSONArray.toCollection(JSONArray.fromObject(json)));
			return dfsJsonList(l);
		}
		JSONObject jo = JSONObject.fromObject(json);
		if (jo.isEmpty() || jo.isNullObject()) return null;
		return dfsJsonMap((Map) JSONObject.toBean(jo, HashMap.class));
	}

	static List dfsJsonList(List list)
	{
		for (int i = 0; i < list.size(); i++)
		{
			Object o = list.get(i);
			if (o instanceof MorphDynaBean)
			{
				JSONObject jo = JSONObject.fromObject(o);
				list.set(i, dfsJsonMap((Map) JSONObject.toBean(jo, HashMap.class)));
			}
			else if (o instanceof Map)
			{
				list.set(i, dfsJsonMap((Map) o));
			}
			else if (o instanceof List)
			{
				list.set(i, dfsJsonList((List) o));
			}
		}
		return list;
	}

	static Map dfsJsonMap(Map m)
	{
		Iterator keys = m.keySet().iterator();
		while (keys.hasNext())
		{
			String key = keys.next().toString();
			Object v = m.get(key);
			if (v instanceof MorphDynaBean)
			{
				JSONObject jo = JSONObject.fromObject(v);
				m.put(key, dfsJsonMap((Map) JSONObject.toBean(jo, HashMap.class)));
			}
			else if (v instanceof Map)
			{
				m.put(key, dfsJsonMap((Map) v));
			}
			else if (v instanceof List)
			{
				m.put(key, dfsJsonList((List) v));
			}
		}
		return m;
	}

	public static String obj2json(Object o)
	{
		// if (o instanceof IJson) return ((IJson) o).toJson().toString(); //
		// modified by chenjs ���ݹ� �� 2010-10-18
		JsonConfig cfg = new JsonConfig();
		// added by chenjs 2011-01-01
//		cfg.registerJsonValueProcessor(AtomNode.class, JVP);
		cfg.registerJsonValueProcessor(ByteArrayBlob.class, JVP);
		return o instanceof Collection ? JSONArray.fromObject(o, cfg).toString()
				: JSONObject.fromObject(o, cfg).toString();
	}

	static JsonValueProcessor JVP = new JsonValueProcessor()
	{ // ���ڵ�ֱ�����л�Ϊstring
		public Object processArrayValue(Object paramObject, JsonConfig paramJsonConfig)
		{
			return paramObject == null ? StringX.EMPTY_STRING : paramObject.toString();
		}

		public Object processObjectValue(String paramString, Object paramObject,
				JsonConfig paramJsonConfig)
		{
			return paramObject == null ? StringX.EMPTY_STRING : paramObject.toString();
		}
	};

	/**
	 * ��һ��Map������ֵ��������Ե��ַ���json��ʽ�ĵ����ݣ�����map��key��KEY��ʾ
	 * 
	 * @param map
	 * @param tail
	 * @return
	 */
	public static List map2list(Map map, String tail)
	{
		if (map == null) return null;
		List data = new ArrayList();
		StringBuilder buf = new StringBuilder();
		Iterator keys = map.keySet().iterator();
		while (keys.hasNext())
		{
			String key = keys.next().toString();
			Object value = map.get(key);
			if (value == null || !(value instanceof Map)) continue;
			buf.setLength(0);
			buf.append("{KEY:'");
			buf.append(key);
			buf.append('\'');
			map2json((Map) value, buf);
			if (tail != null) buf.append(tail);
			buf.append('}');
			data.add(buf.toString());
		}
		return data;
	}

	public static StringBuilder map2json(Map map, StringBuilder buf)
	{
		Iterator keys = map.keySet().iterator();
		while (keys.hasNext())
		{
			String key = keys.next().toString();
			Object value = map.get(key);
			if (value == null) continue;
			if (value instanceof Map) map2json((Map) value, buf);
			buf.append(',');
			buf.append(key);
			buf.append(':');
			buf.append('\'');
			String str = value.toString();
			if (str.indexOf('\'') >= 0) str = str.replace("'", "\\'");
			if (str.indexOf('\n') >= 0) str = str.replace("\n", "\\n");
			buf.append(str);
			buf.append('\'');
		}
		return buf;
	}
}
