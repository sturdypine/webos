package spc.webos.config;

public interface Config
{
	Object getProperty(String key, Object defValue);

	void setProperty(String key, Object value);
}
