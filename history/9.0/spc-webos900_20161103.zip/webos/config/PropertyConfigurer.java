package spc.webos.config;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import spc.webos.constant.Common;
import spc.webos.constant.Config;
import spc.webos.util.StringX;

/**
 * ����springע������ʱʹ��?�ָ�����������ļ��Ҳ���ֵ��ʹ��?�����ֵ��ΪĬ��ֵ
 * 
 * @author chenjs
 *
 */
public class PropertyConfigurer extends PropertyPlaceholderConfigurer
{
	public Properties getProperties() throws IOException
	{
		return props != null ? props : super.mergeProperties();
	}

	protected Properties props;

	protected String resolvePlaceholder(String placeholder, Properties props)
	{
		int index = placeholder.indexOf(delim);
		if (index < 0) return super.resolvePlaceholder(placeholder, props);
		String defValue = placeholder.length() > index + 1 ? placeholder.substring(index + 1)
				: StringX.EMPTY_STRING;
		String value = super.resolvePlaceholder(placeholder.substring(0, index), props);
		if (value == null) value = defValue;
		return value;
	}

	protected void loadProperties(Properties props) throws IOException
	{
		super.loadProperties(props);
		PathMatchingResourcePatternResolver prpr = new PathMatchingResourcePatternResolver();
		Resource[] reses = prpr.getResources(resource);
		for (Resource res : reses)
		{
			log.info("loading properties:" + res);
			try (InputStreamReader reader = new InputStreamReader(res.getInputStream(),
					Common.CHARSET_UTF8))
			{
				props.load(reader);
			}
		}

		String workerId = System.getProperty(Config.APP_WORKERID);
		log.info("load jvm properties:{}", workerId);
		if (!StringX.nullity(workerId))
		{
			Resource res = prpr.getResource("classpath:" + workerId + ".properties");
			log.info("loading properties:" + res);
			try (InputStreamReader reader = new InputStreamReader(res.getInputStream(),
					Common.CHARSET_UTF8))
			{
				props.load(reader);
			}
		}

		this.props = props;
	}

	protected String resource = "classpath*:app*.properties";
	protected String delim = "?";
	protected Logger log = LoggerFactory.getLogger(getClass());

	public void setDelim(String delim)
	{
		this.delim = delim;
	}

	public void setResource(String resource)
	{
		this.resource = resource;
	}
}
