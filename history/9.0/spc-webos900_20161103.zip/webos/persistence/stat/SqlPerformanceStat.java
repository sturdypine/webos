package spc.webos.persistence.stat;

import java.util.HashMap;
import java.util.Map;

import spc.webos.service.Status;

public class SqlPerformanceStat implements Status
{
	String name = "SPS";
	Map sqls = new HashMap();
	static SqlPerformanceStat SPS = new SqlPerformanceStat();

	private SqlPerformanceStat()
	{
	}

	public final static SqlPerformanceStat getInstance()
	{
		return SPS;
	}

	public synchronized void add(String sqlId, String sql, int cost, boolean success)
	{
		SqlCostTime sct = (SqlCostTime) sqls.get(sqlId);
		if (sct == null)
		{
			sct = new SqlCostTime(sqlId, sql, cost, success);
			sqls.put(sqlId, sct);
		}
		else sct.add(sql, cost, success);
	}

	public Map getSqls()
	{
		return sqls;
	}

	public boolean changeStatus(Map param)
	{
		return false;
	}

	public Map checkStatus(Map param)
	{
		return sqls;
	}

	public String getName()
	{
		return name;
	}

	public void refresh() throws Exception
	{
		sqls.clear();
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public boolean needRefresh()
	{
		return false;
	}
}
