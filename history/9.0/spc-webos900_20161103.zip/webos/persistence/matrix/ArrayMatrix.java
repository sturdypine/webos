package spc.webos.persistence.matrix;

import java.util.List;

public class ArrayMatrix extends AbstractMatrix
{
	Object[][] data;

	public void allocate(int width, int height)
	{

	}

	public void expandCol(int cols)
	{

	}

	public void expandRow(int rows)
	{
		// TODO Auto-generated method stub

	}

	public Object getCell(int row, int col)
	{
		// TODO Auto-generated method stub
		return null;
	}

	public int getHeight()
	{
		// TODO Auto-generated method stub
		return 0;
	}

	public int getWidth()
	{
		// TODO Auto-generated method stub
		return 0;
	}

	public void moveCol(int start, int step)
	{
		// TODO Auto-generated method stub

	}

	public void moveRow(int start, int step)
	{
		// TODO Auto-generated method stub

	}

	public void setCell(int row, int col, Object node)
	{
		// TODO Auto-generated method stub

	}

	public IMatrix create(int rows, int cols)
	{
		// TODO Auto-generated method stub
		return null;
	}

	public Object getCol(int col)
	{
		// TODO Auto-generated method stub
		return null;
	}

	public Object getRow(int row)
	{
		// TODO Auto-generated method stub
		return null;
	}

	public List sumCol(int[] cols)
	{
		// TODO Auto-generated method stub
		return null;
	}

	public List sumRow(int[] rows)
	{
		// TODO Auto-generated method stub
		return null;
	}

}
