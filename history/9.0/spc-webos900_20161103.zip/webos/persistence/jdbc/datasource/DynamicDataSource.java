package spc.webos.persistence.jdbc.datasource;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.ConnectionPoolDataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

import com.alibaba.druid.pool.DruidDataSource;

import spc.webos.util.StringX;

/**
 * ��̬�л�����Դ��������ÿ������Դ������
 * 
 * @author chenjs
 * 
 */
public class DynamicDataSource extends AbstractRoutingDataSource implements ApplicationContextAware
{
	Logger log = LoggerFactory.getLogger(getClass());
	boolean targetDSIsNull = true;
	String defaultDS;
	private static final ThreadLocal<String> DS = new ThreadLocal<>(); // ��ǰ�̻߳�����������Դ��Ϣ

	@PostConstruct
	public void init()
	{
		String[] dses = cxt.getBeanNamesForType(ConnectionPoolDataSource.class);
		log.info("DS in spring:{}, targetDSIsNull:{}", Arrays.toString(dses), targetDSIsNull);
		if (!targetDSIsNull) return;
		Map<Object, Object> targetDataSources = new HashMap<>();
		if (dses == null || dses.length == 0)
		{
			super.setTargetDataSources(targetDataSources);
			return;
		}
		for (String ds : dses)
			targetDataSources.put(ds, cxt.getBean(ds, ConnectionPoolDataSource.class));
		super.setTargetDataSources(targetDataSources);

		if (!StringX.nullity(defaultDS))
		{ // ����Ĭ������Դ
			log.info("default DS:{}", defaultDS);
			super.setDefaultTargetDataSource(
					cxt.getBean(defaultDS, ConnectionPoolDataSource.class));
		}
	}

	public void setTargetDataSources(Map targetDataSources)
	{
		super.setTargetDataSources(targetDataSources);
		targetDSIsNull = false;
	}

	public String getCurrentDbType()
	{
		try
		{
			javax.sql.DataSource ds = determineTargetDataSource();
			if (ds instanceof DruidDataSource) return ((DruidDataSource) ds).getDbType();
		}
		catch (Exception e)
		{
		}
		return null;
	}

	public String getCurrentDbName()
	{
		try
		{
			javax.sql.DataSource ds = determineTargetDataSource();
			if (ds instanceof DruidDataSource) return ((DruidDataSource) ds).getName();
		}
		catch (Exception e)
		{
		}
		return null;
	}

	protected Object determineCurrentLookupKey()
	{
		return DS.get();
	}

	public static void current(String ds)
	{
		DS.set(ds);
	}

	public static String current()
	{
		return DS.get();
	}

	public void setDefaultDS(String defaultDS)
	{
		this.defaultDS = defaultDS;
	}

	@Override
	public void setApplicationContext(ApplicationContext arg0) throws BeansException
	{
		cxt = arg0;
	}

	ApplicationContext cxt;
}
