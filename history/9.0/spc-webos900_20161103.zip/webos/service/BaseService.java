package spc.webos.service;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import spc.webos.config.AppConfig;
import spc.webos.config.Config;
import spc.webos.persistence.IPersistence;
import spc.webos.service.seq.UUID;
import spc.webos.util.StringX;

public class BaseService implements Status
{
	@Autowired(required = false)
	protected IPersistence persistence;
	@Autowired(required = false)
	protected UUID uuid;
	@Autowired(required = false)
	protected Config config = AppConfig.getInstance();
	// protected String name;
	protected Status self = this;
	protected final Logger log = LoggerFactory.getLogger(getClass());

	private String lastVersion = StringX.EMPTY_STRING;
	protected String versionKey; //

	/**
	 * �ṩinit��������, ��spring2.0���� default-init-method
	 * 
	 */
	@PostConstruct
	public void init() throws Exception
	{
		// if (!StringX.nullity(name))
		// {
		// if (SERVICES.containsKey(name)) log.warn(name + " Service existed in
		// SERVICES!!!");
		// SERVICES.put(name, this);
		// SERVICES_PROXY.put(name, this);
		// }
		if (!StringX.nullity(versionKey))
		{
			lastVersion = (String) config.getProperty(versionKey, "");
			log.info("lastVersion:{}", lastVersion);
		}
		refresh();
	}

	// added by chenjs 2011-09-19 �޸�destory���ʷ���
	// @PreDestroy // spring context���Զ��ر�AutoCloseable
	public void close()
	{
	}

	public IPersistence getPersistence()
	{
		return persistence;
	}

	public void setPersistence(IPersistence persistence)
	{
		this.persistence = persistence;
	}

	public boolean changeStatus(Map param)
	{
		return false;
	}

	public Map checkStatus(Map param)
	{
		return new HashMap();
	}

	public void refresh() throws Exception
	{
	}

	// ����ˢ��ʱ�жϷ����Ƿ���Ҫˢ�����ݿ�
	public boolean needRefresh()
	{
		if (StringX.nullity(versionKey))
		{
			log.debug("dbVerDtKey is null!!!");
			return false;
		}
		String curVersion = (String) config.getProperty(versionKey, StringX.EMPTY_STRING);
		log.info("lastVersion:{}, curVersion:{}, key:{}", lastVersion, curVersion, versionKey);
		if (StringX.nullity(curVersion) || lastVersion.equalsIgnoreCase(curVersion)) return false;
		lastVersion = curVersion;
		return true;
	}

	public void self(Object proxyBean)
	{
		self = (Status) proxyBean;
		// if (StringX.nullity(name) || self == null) return;
		// SERVICES_PROXY.put(name, self);
		// if (!SERVICES.containsKey(name)) SERVICES.put(name, this);
	}

	public Object self()
	{
		return self;
	}

	public String getLastDBVerDt()
	{
		return lastVersion;
	}

	public void setLastDBVerDt(String lastDBVerDt)
	{
		this.lastVersion = lastDBVerDt;
	}

	public String getDbVerDtKey()
	{
		return versionKey;
	}

	public void setDbVerDtKey(String dbVerDtKey)
	{
		this.versionKey = dbVerDtKey;
	}

	public void setUuid(UUID uuid)
	{
		this.uuid = uuid;
	}

	public void setConfig(Config config)
	{
		this.config = config;
	}
}
