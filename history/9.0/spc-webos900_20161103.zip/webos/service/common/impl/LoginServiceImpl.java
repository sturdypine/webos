package spc.webos.service.common.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import spc.webos.constant.AppRetCode;
import spc.webos.exception.AppException;
import spc.webos.model.MenuPO;
import spc.webos.model.RolePO;
import spc.webos.model.UserPO;
import spc.webos.persistence.IPersistence;
import spc.webos.service.BaseService;
import spc.webos.service.common.LoginService;
import spc.webos.util.StringX;
import spc.webos.web.common.ISessionUserInfo;
import spc.webos.web.common.SessionUserInfo;

@Service("loginService")
public class LoginServiceImpl extends BaseService implements LoginService
{
	protected boolean pwdMD5 = true; // �������MD5�㷨�洢
	protected List<String> defaultServices = Arrays.asList("login.*", "extjs.*");
	protected volatile List<MenuPO> fns;

	public LoginServiceImpl()
	{
		versionKey = "status.refresh.common.login";
	}

	public boolean updatePwd(String oldPwd, String newPwd)
	{
		ISessionUserInfo sui = ISessionUserInfo.SUI.get();
		if (sui == null)
		{
			log.info("session is over!!!");
			return false;
		}
		if (StringX.nullity(oldPwd) || StringX.nullity(newPwd))
		{
			log.info("oldPwd || newPwd is empty!!!");
			return false;
		}
		UserPO user = persistence.find(new UserPO(sui.getUserCode()));
		oldPwd = pwdMD5 ? StringX.md5(oldPwd.getBytes()) : oldPwd;

		if (!oldPwd.equals(user.getPwd())) throw new AppException(AppRetCode.CMMN_PWD_ERR);

		user = new UserPO(sui.getUserCode());
		user.setPwd(pwdMD5 ? StringX.md5(newPwd.getBytes()) : newPwd);
		return persistence.update(user) > 0;
	}

	public void refresh()
	{
		fns = null; // ��յ�ǰ����
	}

	public List<MenuPO> getMenu()
	{
		if (fns == null)
		{
			Map<String, Object> params = new HashMap<>();
			params.put(IPersistence.SELECT_ATTACH_TAIL_KEY, "order by morder,mid");
			fns = persistence.get(new MenuPO(), params);
			log.info("sys fns:{}", fns.size());
		}
		List<String> roles = ISessionUserInfo.SUI.get().getRoles();
		List<MenuPO> m = new ArrayList<>();
		fns.forEach((po) -> {
			for (int i = 0; i < roles.size(); i++)
			{
				if ("*".equals(roles.get(i)) || roles.get(i).startsWith(po.getMid())
						|| "00".equals(po.treeId())
						|| (roles.get(i).endsWith("*")
								&& (po.getMid()
										.startsWith(roles.get(i).substring(0,
												roles.get(i).length() - 1))
								|| roles.get(i).substring(0, roles.get(i).length() - 1)
										.startsWith(po.getMid()))))
				{
					m.add(po);
					return;
				}
			}
		});
		return m;
	}

	public boolean isOnline()
	{
		return ISessionUserInfo.SUI.get() != null;
	}

	public boolean logout()
	{
		ISessionUserInfo sui = (ISessionUserInfo) ISessionUserInfo.SUI.get();
		if (sui == null) return false;
		// session invalidate ����filter�������
		return true;
	}

	public void login(Map<String, String> info)
	{
		String code = info.get("code");
		String pwd = info.get("password");
		String verify = info.get("verify");
		SessionUserInfo sui = (SessionUserInfo) ISessionUserInfo.SUI.get();
		log.info("{} login {}", code, verify);

		UserPO userVO = persistence.find(new UserPO(code));
		String password = pwdMD5 ? StringX.md5(pwd.getBytes()) : pwd;
		if (userVO == null || !userVO.getPwd().equalsIgnoreCase(password))
		{
			log.info("login fail:{}/{},{} != {}", code, pwd, password,
					userVO == null ? "" : userVO.getPwd());
			throw new AppException(AppRetCode.CMMN_PWD_ERR, new Object[] { code });
		}
		userVO.setPwd(null); // ��������Ϊnull
		sui.setRoles(getUserRole(userVO));
		sui.setUser(userVO);
		// ���õ�ǰ�û��ܷ��ʵķ����sql
		final List<String> services = new ArrayList<>(defaultServices);
		final List<String> sqlIds = new ArrayList<>();
		List<MenuPO> menus = getMenu();
		menus.forEach((m) -> {
			List<String> ss = StringX
					.split2list(StringX.null2emptystr(m.getService()).toLowerCase(), StringX.COMMA);
			ss.forEach((s) -> {
				if (!services.contains(s)) services.add(s);
			});
			ss = StringX.split2list(
					StringX.null2emptystr(m.getSqlId()).replace('.', '_').toLowerCase(),
					StringX.COMMA);
			ss.forEach((s) -> {
				if (!sqlIds.contains(s)) sqlIds.add(s);
			});
		});
		sui.setServices(services);
		sui.setSqlIds(sqlIds);
		log.debug("menus:{}, services:{}, sqlIds:{}", menus.size(), services, sqlIds);
	}

	protected List<String> getUserRole(UserPO userVO)
	{
		String roleId = userVO.getRoleId();
		List<String> roles = StringX.split2list(roleId, StringX.COMMA);
		List<String> menus = new ArrayList<>();
		for (int i = 0; i < roles.size(); i++)
		{
			RolePO roleVO = new RolePO();
			roleVO.setId((String) roles.get(i));
			roleVO = (RolePO) persistence.find(roleVO);
			if (roleVO == null) continue;
			List<String> menu = StringX.split2list(roleVO.getMenu(), StringX.COMMA);
			for (int j = 0; menu != null && j < menu.size(); j++)
				if (!menus.contains(menu.get(j))) menus.add(menu.get(j));
		}
		log.info("menus:{}", menus);
		return menus;
	}

	public void setDefaultServices(String defaultServices)
	{
		if (!StringX.nullity(defaultServices))
			this.defaultServices = StringX.split2list(defaultServices, ",");
	}

	public void setPwdMD5(boolean pwdMD5)
	{
		this.pwdMD5 = pwdMD5;
	}
}
