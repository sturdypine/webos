package spc.webos.service.common;

import java.util.List;
import java.util.Map;

import spc.webos.model.MenuPO;

public interface LoginService
{
	boolean updatePwd(String oldPwd, String newPwd);
	
	List<MenuPO> getMenu();

	void login(Map<String, String> login);

	boolean logout();

	boolean isOnline();
}
