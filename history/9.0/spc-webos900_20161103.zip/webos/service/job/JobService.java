package spc.webos.service.job;

import spc.webos.advice.log.LogTrace;

public interface JobService
{
	@LogTrace
	void execute() throws Exception;
}
