package spc.webos.service.job;

import spc.webos.advice.log.LogTrace;

public interface MasterSlaveJobService extends JobService
{
	@LogTrace
	void leader() throws Exception;
}
