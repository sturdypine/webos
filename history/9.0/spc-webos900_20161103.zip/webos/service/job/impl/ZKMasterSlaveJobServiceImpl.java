package spc.webos.service.job.impl;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.springframework.beans.factory.annotation.Value;

import spc.webos.advice.log.LogTrace;
import spc.webos.service.BaseService;
import spc.webos.service.job.MasterSlaveJobService;

public abstract class ZKMasterSlaveJobServiceImpl extends BaseService
		implements MasterSlaveJobService
{
	@Value("${app.job.zk.host?}")
	protected String zkHost;
	@Value("${app.job.zk.cnnTimeout?30000}")
	protected int zkCnnTimeout = 30000;
	@Value("${app.job.zk.zkRetryInterval?60000}")
	protected int zkRetryInterval = 60000;
	protected String zkPath = "/Job/LL/test";
	protected String name;

	@LogTrace(location = "job.execute")
	public void execute() throws Exception
	{
		log.info("hello, it's " + name + ", I am leader now, doing job...");
	}

	protected CuratorFramework zk() throws Exception
	{
		CuratorFramework zkcf = CuratorFrameworkFactory.builder().connectString(zkHost)
				.connectionTimeoutMs(zkCnnTimeout).canBeReadOnly(false)
				.retryPolicy(new ExponentialBackoffRetry(zkRetryInterval, 29)).defaultData(null)
				.build();
		zkcf.start();
		return zkcf;
	}

	public void setZkHost(String zkHost)
	{
		this.zkHost = zkHost;
	}

	public void setZkPath(String zkPath)
	{
		this.zkPath = zkPath;
	}

	public void setZkCnnTimeout(int zkCnnTimeout)
	{
		this.zkCnnTimeout = zkCnnTimeout;
	}

	public void setZkRetryInterval(int zkRetryInterval)
	{
		this.zkRetryInterval = zkRetryInterval;
	}

	public void setName(String name)
	{
		this.name = name;
	}
}
