package spc.webos.tcc.job.impl;

import java.util.Collection;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;

import spc.webos.service.job.impl.LeaderLatchMSJobServiceImpl;
import spc.webos.tcc.TCCRepository;
import spc.webos.tcc.Transaction;

public class DoFailTXJobServiceImpl extends LeaderLatchMSJobServiceImpl implements Runnable
{
	@Resource
	protected TCCRepository repository;
	@Value("${tcc.sleepSeconds?120}")
	protected int sleepSeconds = 120;
	protected int batchStart = 0; // ÿ����ʼ
	@Value("${tcc.batchSize?100}")
	protected int batchSize = 100;
	@Value("${tcc.group?test}")
	protected String group;
	@Value("${tcc.runDoFailTx?false}")
	protected boolean runDoFailTx;
	private Thread daemon;

	@PostConstruct
	public void init() throws Exception
	{
		name = "TCC.DoFailTX." + group;
		zkPath = "/Job/LL/TCC/" + group;
		log.info("TCC Job:{}, zkPath:{}, runDoFailTx:{}", name, zkPath, runDoFailTx);
		if (!runDoFailTx) return;
		daemon = new Thread(this);
		daemon.setDaemon(true);
		daemon.start();
	}

	@PreDestroy
	public void destroy()
	{
		if (daemon != null)
		{
			log.info("interrupt job");
			runDoFailTx = false;
			daemon.interrupt();
			daemon = null;
		}
	}

	public void run()
	{
		while (runDoFailTx)
		{
			try
			{
				Thread.sleep(sleepSeconds * 1000);
				if (runDoFailTx) leader(); // ��������ģʽִ��
			}
			catch (Exception e)
			{
				log.warn("fail to run:" + name + "," + zkPath, e);
			}
		}
	}

	public void execute() throws Exception
	{
		Collection<String> errXids = repository.findErr(batchStart, batchSize);
		if (errXids == null || errXids.size() == 0)
		{ // ����鲻��������ÿ�ʼλ��Ϊ0
			log.info("{}-{} is zero", batchStart, batchSize);
			batchStart = 0;
			return;
		}
		log.info("TCC err start:{}, xid:{}", batchStart, errXids);
		batchStart += batchSize;
		for (String xid : errXids)
			completeTx(xid);
	}

	protected void completeTx(String xid)
	{
		String status = "find";
		try
		{
			Transaction t = repository.find(xid);
			if (t.status == Transaction.STATUS_CANCEL_FAIL)
			{
				status = "Cancel " + t.proxy;
				log.info("xid:{}, {}", xid, status);
				t.cancel();
				t.status = Transaction.STATUS_CANCELED;
				// ����ִ�гɹ���������״̬����²��ɹ���������
				repository.updateStatus(t); // ֻ�޸�����״̬���Ƿ�ɾ������Դ���ڲ�����
			}
			else if (t.status == Transaction.STATUS_CONFIRM_FAIL)
			{
				status = "Confirm " + t.proxy;
				log.info("xid:{}, {}", xid, status);
				t.confirm();
				t.status = Transaction.STATUS_CONFIRMED;
				// ����ִ�гɹ���������״̬����²��ɹ���������
				repository.updateStatus(t); // ֻ�޸�����״̬���Ƿ�ɾ������Դ���ڲ�����
			}
			else log.warn("TCC({}) err status:{}", xid, t.status);
		}
		catch (Exception e)
		{
			log.info("fail to doFailTx: " + status + ":" + xid, e);
		}
	}

	public void setRepository(TCCRepository repository)
	{
		this.repository = repository;
	}

	public void setSleepSeconds(int sleepSeconds)
	{
		this.sleepSeconds = sleepSeconds;
	}

	public void setBatchStart(int batchStart)
	{
		this.batchStart = batchStart;
	}

	public void setBatchSize(int batchSize)
	{
		this.batchSize = batchSize;
	}

	public void setGroup(String group)
	{
		this.group = group;
	}

	public void setRunDoFailTx(boolean runDoFailTx)
	{
		this.runDoFailTx = runDoFailTx;
	}
}
