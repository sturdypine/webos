package spc.webos.mq.amq;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.jms.pool.PooledConnectionFactory;
import org.springframework.jms.core.JmsTemplate;

import spc.webos.mq.jms.MultiBrokerSendJmsTemplate;

public class AMQMultiBrokerJmsTemplate extends MultiBrokerSendJmsTemplate
{
	protected String[] brokers;
	protected int maxConnections = 2;

	@PostConstruct
	public void init() throws Exception
	{
		for (String broker : brokers)
		{
			log.info("broker:{}, max cnn:{}", broker, maxConnections);
			PooledConnectionFactory factory = new PooledConnectionFactory();
			factory.setMaxConnections(maxConnections);
			factory.setConnectionFactory(new ActiveMQConnectionFactory(broker));
			multiBrokerJms.add(new JmsTemplate(factory));
		}
	}

	@PreDestroy
	public void destroy()
	{
		log.info("destroy multi amq brokers:{}" + multiBrokerJms.size());
		for (JmsTemplate jms : multiBrokerJms)
			((PooledConnectionFactory) jms.getConnectionFactory()).clear();
	}

	protected String getBrokerInf(int index, JmsTemplate jms)
	{
		return brokers[index];
	}

	public void setBrokers(String[] brokers)
	{
		this.brokers = brokers;
	}

	public void setMaxConnections(int maxConnections)
	{
		this.maxConnections = maxConnections;
	}
}
