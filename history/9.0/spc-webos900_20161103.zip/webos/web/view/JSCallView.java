package spc.webos.web.view;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.View;

import com.google.gson.Gson;

import spc.webos.constant.Common;
import spc.webos.constant.Web;
import spc.webos.util.StringX;

public class JSCallView implements View
{
	protected Logger log = LoggerFactory.getLogger(getClass());
	protected String resultTag; // = "result";
	protected String successTag = "success";

	public String getContentType()
	{
		return Common.FILE_JSON_CONTENTTYPE;
	}

	public void render(Map model, HttpServletRequest request, HttpServletResponse response)
			throws Exception
	{
		Object ret = model.get(Web.SERVICE_RET_KEY);
		if (!StringX.nullity(resultTag))
		{
			Map<String, Object> retm = new HashMap<>();
			retm.put(resultTag, ret);
			retm.put(successTag, true);
			ret = retm;
		}
		response.getWriter().print(StringX.str2utf8(new Gson().toJson(ret)));
	}

	public void setResultTag(String resultTag)
	{
		this.resultTag = resultTag;
	}

	public void setSuccessTag(String successTag)
	{
		this.successTag = successTag;
	}
}
