package spc.webos.web.common;

import spc.webos.model.UserPO;

public class SessionUserInfo extends AbstractSessionUserInfo
{
	private static final long serialVersionUID = 1L;
	// ����Ա������Ϣ
	protected UserPO user;

	public String getUserCode()
	{
		return user == null ? null : user.getCode();
	}

	public String getUserName()
	{
		return user == null ? null : user.getName();
	}

	public boolean containRole(String role)
	{
		for (String r : roles)
			if (r.startsWith(role)) return true;
		return false;
	}

	public UserPO getUser()
	{
		return user;
	}

	public void setUser(UserPO user)
	{
		this.user = user;
	}
}
