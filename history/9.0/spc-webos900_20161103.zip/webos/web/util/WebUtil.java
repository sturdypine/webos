package spc.webos.web.util;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import spc.webos.constant.AppRetCode;
import spc.webos.constant.Common;
import spc.webos.exception.AppException;
import spc.webos.util.FTLUtil;
import spc.webos.util.JsonUtil;
import spc.webos.util.MethodUtil;
import spc.webos.util.SpringUtil;
import spc.webos.util.StringX;
import spc.webos.web.common.ISessionUserInfo;

public class WebUtil
{
	static Logger log = LoggerFactory.getLogger(WebUtil.class);

	public static String[] last2path(String uri)
	{
		String[] paths = StringX.split(uri, "/");
		return new String[] { paths[paths.length - 2], paths[paths.length - 1] };
	}

	public static Map<String, Object> request2map(HttpServletRequest req,
			Map<String, Object> params)
	{
		params = FTLUtil.model(params);
		Enumeration names = req.getParameterNames();
		while (names.hasMoreElements())
		{
			String paramName = names.nextElement().toString();
			String value = req.getParameter(paramName);
			if (value != null && value.length() > 0) params.put(paramName, StringX.utf82str(value));
		}

		params.put(Common.MODEL_REQUEST_KEY, req);
		params.put(Common.MODEL_APP_PATH_KEY, req.getContextPath());
		return params;
	}

	// �������еõ����и����Ĳ�����
	public static List getUploadFileNames(HttpServletRequest req)
	{
		List names = new ArrayList();
		java.util.Enumeration enu = req.getParameterNames();
		while (enu.hasMoreElements())
		{
			String name = (String) enu.nextElement();
			if (name.startsWith("file.")) names.add(name);
		}
		return names;
	}

	// ִ��һ��json������ʽ�ķ�����������BATCH_SQL��ѯ�����ظ�page or ָ��view������model
	// ִ�еķ��������S.��ͷ
	public static void invokeJsonService(HttpServletRequest req, Map params, String servicePostfix)
			throws Exception
	{
		Enumeration<String> names = req.getParameterNames();
		while (names.hasMoreElements())
		{
			String name = names.nextElement();
			if (!name.startsWith("S.")) continue;
			int idx = name.lastIndexOf('.');
			if (idx < 2) continue;
			String s = name.substring(2, idx);
			String m = name.substring(idx + 1);
			String p = req.getParameter(name);
			log.info("S. jscall:{}.{}", s, m);
			log.debug("args:{}", p);
			// �Զ�����Service��׺
			Object args = StringX.nullity(p) ? null : JsonUtil.json2obj(p);
			int argNum = getMethodArgNum(s, m, args);
			Object ret = SpringUtil.jsonCall(s + servicePostfix, m, args, argNum);
			if (ret != null) params.put(s + '_' + m, ret);
		}
	}

	public static int getMethodArgNum(String s, String m, Object requestArgs)
	{
		int argNum = -1;
		if (requestArgs == null) argNum = 0;
		else if (requestArgs instanceof List) argNum = ((List) requestArgs).size();
		else
		{ // restful style
			int idx = m.indexOf('$');
			if (idx > 0)
			{
				argNum = Integer.parseInt(m.substring(idx + 1));
				m = m.substring(0, idx);
			}
			else
			{
				Method me = MethodUtil
						.findMethod(SpringUtil.getInstance().getBean(s, null).getClass(), m, -1);
				argNum = me.getParameterCount();
			}
		}

		ISessionUserInfo sui = ISessionUserInfo.SUI.get();
		if (sui != null && !sui.containService(s + '.' + m + '$' + argNum))
		{ // ����Ѿ���¼��������鵱ǰ��½��ִ�з����Ȩ��
			log.info("unauthorized service:({}.{}), user:{}", s, m, sui.getUserCode());
			throw new AppException(AppRetCode.SERVICE_UNAUTH, new Object[] { s + '.' + m });
		}

		return argNum;
	}
}
