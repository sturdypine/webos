package spc.webos.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import spc.webos.tcc.service.TCC;

@Entity
@Table(name = "tcc_translog")
public class TccTransLogPO implements TCC, Serializable
{
	public static final long serialVersionUID = 20160905L;
	// ����������Ӧ�ֶ�
	@Id
	@Column
	protected String tccSN;
	@Column
	protected Integer tccStatus;
	@Column
	protected String tranCode;
	@Column
	protected String tranTm;
	@Column(columnDefinition = "prepare")
	protected String remark;

	public TccTransLogPO()
	{
	}

	public TccTransLogPO(String tccSN)
	{
		this.tccSN = tccSN;
	}

	public void setTccSN(String tccSN)
	{
		this.tccSN = tccSN;
	}

	public Integer getTccStatus()
	{
		return tccStatus;
	}

	public void setTccStatus(Integer tccStatus)
	{
		this.tccStatus = tccStatus;
	}

	@Override
	public String getTccSN()
	{
		return tccSN;
	}

	public String getTranCode()
	{
		return tranCode;
	}

	public void setTranCode(String tranCode)
	{
		this.tranCode = tranCode;
	}

	public String getTranTm()
	{
		return tranTm;
	}

	public void setTranTm(String tranTm)
	{
		this.tranTm = tranTm;
	}

	public String getRemark()
	{
		return remark;
	}

	public void setRemark(String remark)
	{
		this.remark = remark;
	}
}
