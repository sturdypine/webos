package spc.webos.endpoint;

import java.io.IOException;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import spc.webos.constant.AppRetCode;
import spc.webos.exception.AppException;
import spc.webos.util.StringX;

public class HttpEndpoint implements Endpoint
{
	public HttpEndpoint()
	{
	}

	public HttpEndpoint(String url)
	{
		this.url = url;
	}

	public void execute(Executable exe) throws Exception
	{
		long start = System.currentTimeMillis();
		log.info("HTTP corId:{}, timeout:{}, url:{}, len:{}", exe.getCorrelationID(), exe.timeout,
				url, (exe.request == null ? ")" : exe.request.length));

		HttpPost post = new HttpPost(url);
		post.setConfig(RequestConfig.custom().setSocketTimeout(exe.timeout * 1000)
				.setConnectTimeout(1000).build());
		// added by chenjs 2013-03--25�� ��webservice�п�����Ҫ��дsoapaction
		if (exe.reqHttpHeaders != null && !exe.reqHttpHeaders.isEmpty())
			exe.reqHttpHeaders.keySet().iterator()
					.forEachRemaining((key) -> post.setHeader(key, exe.reqHttpHeaders.get(key)));
		post.setEntity(new ByteArrayEntity(exe.request));

		try (CloseableHttpClient client = HttpClients.createDefault();
				CloseableHttpResponse response = client.execute(post))
		{
			exe.cnnSnd = true; // httpЭ��������ζ���ɹ�
			exe.httpStatus = response.getStatusLine().getStatusCode();

			// ������Ӧ��Ϣ
			exe.response = EntityUtils.toByteArray(response.getEntity());
			log.info("HTTP response status:{}, len:{}, cost:{}", exe.httpStatus,
					exe.response == null ? 0 : exe.response.length,
					(System.currentTimeMillis() - start));
			if (log.isDebugEnabled()) log.debug("response.base64:" + StringX.base64(exe.response));
		}
		catch (IOException ioe)
		{
			log.error("HTTP err:" + url + ", status:" + exe.httpStatus + ", request.base64:"
					+ (exe.request == null ? "" : StringX.base64(exe.request)), ioe);
			throw new AppException(AppRetCode.PROTOCOL_HTTP,
					new Object[] { url, new Integer(exe.httpStatus) });
		}
		// if (exe.httpStatus != HttpStatus.OK.value())
		// throw new AppException(AppRetCode.PROTOCOL_HTTP,
		// new Object[] { new Integer(exe.httpStatus) });
	}

	public void close()
	{
	}

	public void setLocation(String location) throws Exception
	{
		this.url = location;
	}

	protected String url; // ��̨url��ַ
	protected Logger log = LoggerFactory.getLogger(getClass());
}
