package spc.webos.util.tree;

public interface ITreeNodeValue
{
	Object treeId();

	Object parentTreeId();

	String treeText();

	boolean treeRoot();
}
