package spc.webos.cache;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import spc.webos.service.Status;

/**
 * @author spc
 */
public interface ICache extends Status
{
	public final static Map CACHE = new HashMap();

	void setName(String name);

	Collection getKeys();

	int size();

	Object getMessage(String key) throws Exception; // for ���ʻ�

	// ��cache�л�ȡ��ɾ��
	Object poll(Object key) throws Exception;

	Object poll(Object key, WaitWithTime wwt) throws Exception;

	Object poll(Object key, long timeout) throws Exception;

	Object get(Object key) throws Exception;

	/**
	 * @param key
	 * @param o
	 * @return true means sucess.. false means failure..
	 */
	Object put(Object key, Object o) throws Exception;

	/**
	 * ��ջ���������Ϣ
	 */
	void removeAll();

	/**
	 * ���������ĳһ�ؼ��ֵ���Ϣ
	 * 
	 * @param key
	 */
	Object remove(Object o);

	/**
	 * ��û��������
	 * 
	 * @return
	 */
	String getName();

	void put(String key, Object obj, long expireSeconds) throws Exception;

	Object get(String key, boolean browse);

	void evictExpiredElements(); // 700 2012-05-25
}
