package spc.webos.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.core.io.ResourceLoader;
import org.springframework.util.StringUtils;

import spc.webos.constant.Common;
import spc.webos.model.ConfigPO;
import spc.webos.persistence.IPersistence;
import spc.webos.util.JsonUtil;
import spc.webos.util.SpringUtil;
import spc.webos.util.StringX;

public class AppConfig implements ResourceLoaderAware
{
	public static final long serialVersionUID = 20080109L;
	private static AppConfig APP_CFG = new AppConfig();
	@javax.annotation.Resource
	protected IPersistence persistence;
	@Autowired(required = false)
	protected PropertyConfigurer propertyConfigurer;
	protected Map staticCfg = new HashMap();
	// protected String locations = "classpath*:app*.properties"; // ϵͳ��̬�������ļ�
	protected Map config = new HashMap();
	private static boolean PRODUCT = true;
	// private boolean init;
	protected String lastDBVerDt; // ��һ��ͬ�������ݿ�汾����
	protected String[] methods; // ������ݿ�汾�����仯, �򴥷��Ķ���
	static Logger log = LoggerFactory.getLogger(AppConfig.class);
	public static final char DELIM = '.';
	public static final String WEBROOT_KEY = "${" + Common.WEBAPP_ROOT_PATH_KEY + '}';
	public static final String MODULE_APP = "app";
	public static final String APP_VERSION = "app.version";
	public static final String APP_VERSION_DATE = "app.versionDate";
	public static final String DB_VERSION = "db.version";
	public static final String DB_VERSION_DATE = "db.versionDate";

	public Map getModule(String module)
	{
		return (Map) config.get(module);
	}

	public Map getConfig()
	{
		return config;
	}

	public void setProperty(String key, Object value)
	{
		setPathInMap(config, key, value);
	}

	public Object getProperty(String key, Object defValue)
	{
		if (StringX.nullity(key)) return defValue;
		int index = key.indexOf(DELIM);
		return getProperty(key.substring(0, index), key.substring(index + 1), defValue);
	}

	public Object getProperty(String module, String key, Object defValue)
	{
		// Object value = null;
		// Map moduleMap = (Map) config.get(module);
		// if (moduleMap == null) return defValue;
		return getProperty((Map) config.get(module), key, defValue);
		// value = moduleMap.get(key);
		// return value == null ? defValue : value;
	}

	protected Object getProperty(Map map, String key, Object defValue)
	{
		if (map == null || StringX.nullity(key)) return defValue;
		Object value = defValue;
		int index = key.indexOf(DELIM);
		if (index < 0)
		{
			value = map.get(key);
			return value == null ? defValue : value;
		}
		String path = key.substring(0, index);
		key = key.substring(index + 1);
		return getProperty((Map) map.get(path), key, defValue);
	}

	private AppConfig()
	{
	}

	@PostConstruct
	public void init() throws Exception
	{
		staticCfg = new HashMap();
		config = new HashMap();
		if (propertyConfigurer != null)
		{
			Properties p = propertyConfigurer.getProperties();
			log.info("loading static properties: {}", p.size());
			String webappRoot = (String) getProperty(Common.WEBAPP_ROOT_PATH_KEY,
					StringX.EMPTY_STRING);
			Iterator keys = p.keySet().iterator();
			while (keys.hasNext())
			{
				String key = keys.next().toString();
				String value = StringX.replaceAll(p.get(key).toString(), WEBROOT_KEY, webappRoot);
				setPathInMap(staticCfg, key, value);
			}
			setAll(config, staticCfg);
		}
		refresh();
	}

	public void refresh()
	{
		try
		{
			log.info("reload app config, static:{}", (staticCfg == null ? 0 : staticCfg.size()));
			Map cfg = null;
			try
			{
				cfg = loadCfg();
			}
			catch (Exception e)
			{
				log.info("fail to load ConfigPO:" + e);
			}
			if (cfg == null || cfg.size() == 0)
			{
				this.config = new HashMap();
				setAll(config, staticCfg);
				return;
			}
			setAll(cfg, staticCfg);
			this.config = cfg;
			String curDBVerDt = StringX
					.null2emptystr(getProperty(AppConfig.DB_VERSION_DATE, StringX.EMPTY_STRING));
			log.info("last db version dt:[[" + lastDBVerDt + "]], db version: "
					+ StringX.null2emptystr(getProperty(AppConfig.DB_VERSION, StringX.EMPTY_STRING))
					+ ", db version date:[[" + curDBVerDt + "]], success to load items: "
					+ cfg.size() + ", keys:" + config.keySet());
			if (log.isDebugEnabled()) log.debug("cfg:" + cfg);
			if (lastDBVerDt == null) lastDBVerDt = curDBVerDt; // ��һ���������������ݿ�ˢ��
			else if (methods != null && !curDBVerDt.equals(lastDBVerDt))
			{ // added by chenjs 2012-01-10 ������ݰ汾���ڷ����仯, �򴥷�ָ����������ִ��ͬ��
				lastDBVerDt = curDBVerDt;
				log.info("start to invoke: " + StringX.join(methods, StringX.COMMA));
				SpringUtil.invoke(methods);
			}
		}
		catch (Exception e)
		{
			log.warn("AppConfig.reload: " + e);
			log.debug("AppConfig.reload", e);
		}
		log.debug("app config:{}", config);
	}

	public static AppConfig getInstance()
	{
		return APP_CFG;
	}

	protected Map loadCfg()
	{
		ConfigPO vo = new ConfigPO();
		vo.setStatus("1");
		List list = persistence.get(vo);
		if (list == null || list.size() == 0)
		{
			log.warn("db config has no data!!!");
			return null;
		}
		log.info("db cfg items:" + list.size());
		Map cfg = new HashMap();
		for (int i = 0; i < list.size(); i++)
		{
			ConfigPO item = (ConfigPO) list.get(i);
			Map moduleMap = (Map) cfg.get(item.getModule());
			if (moduleMap == null)
			{
				moduleMap = new HashMap();
				cfg.put(item.getModule(), moduleMap);
			}
			putConf(item, moduleMap);
		}
		Map app = (Map) cfg.get(MODULE_APP);
		if (app == null)
		{
			app = new HashMap();
			cfg.put(MODULE_APP, app);
		}
		app.put("product", new Boolean(PRODUCT));
		if (log.isDebugEnabled()) log.debug("loadCfg: " + cfg);
		return cfg;
	}

	protected void putConf(ConfigPO item, Map moduleMap)
	{
		Object value = item.getValue().toString().trim();
		if (StringX.nullity(item.getModel())
				|| ConfigPO.MD_SIMPLE.equalsIgnoreCase(item.getModel()))
			value = processSimple(value.toString(), item);
		else if (ConfigPO.MD_ARRAY.equalsIgnoreCase(item.getModel()))
			value = proccessArray(value.toString(), item);
		else if (ConfigPO.MD_JSON.equalsIgnoreCase(item.getModel()))
			value = processJson(value.toString(), item);
		else
		{
			log.warn("undefined model: " + item.getModel() + ", using default simple model...");
			value = processSimple(value.toString(), item);
		}

		if (item.getName().indexOf('.') < 0)
		{
			moduleMap.put(item.getName(), value);
			return;
		}
		setPathInMap(moduleMap, item.getName(), value);
		// String[] names = StringUtils.split(item.getName(), ".");
		// Map p = moduleMap;
		// Object t;
		// for (int i = 0; i < names.length - 1; i++)
		// {
		// t = p.get(names[i]);
		// if (t == null || !(t instanceof Map))
		// {
		// t = new HashMap();
		// p.put(names[i], t);
		// }
		// p = (Map) t;
		// }
		// p.put(names[names.length - 1], value);
	}

	public static void setAll(Map m1, Map m2)
	{
		if (m2 == null || m1 == null) return;
		m1.putAll(m2);
		// Iterator keys = m2.keySet().iterator();
		// while (keys.hasNext())
		// {
		// String key = keys.next().toString();
		// Object o = m1.get(key);
		// if (o == null) m1.put(key, m2.get(key));
		// else setAll((Map) m1.get(key), (Map) m2.get(key));
		// }
	}

	public static void setPathInMap(Map m, String path, Object value)
	{
		String[] names = StringUtils.split(path, ".");
		Object t;
		for (int i = 0; i < names.length - 1; i++)
		{
			t = m.get(names[i]);
			if (t == null || !(t instanceof Map))
			{
				t = new HashMap();
				m.put(names[i], t);
			}
			m = (Map) t;
		}
		m.put(names[names.length - 1], value);
	}

	protected Object processJson(String value, ConfigPO item)
	{
		if (StringX.nullity(value)) return null;
		return JsonUtil.json2obj(value);
	}

	protected Object proccessArray(String value, ConfigPO item)
	{
		String[] arr = value.split(StringX.COMMA);
		List result = new ArrayList(arr.length);
		// for ( int i = 0; i < arr.length; i++)
		// System.out.println(arr[i]);
		for (int i = 0; i < arr.length; i++)
		{
			if (ConfigPO.TP_STRING.equalsIgnoreCase(item.getType())) result.add(arr[i]);
			else if (ConfigPO.TP_INT.equalsIgnoreCase(item.getType()))
				result.add(new Integer(arr[i]));
			else if (ConfigPO.TP_LONG.equalsIgnoreCase(item.getType()))
				result.add(new Long(arr[i]));
			else if (ConfigPO.TP_BOOL.equalsIgnoreCase(item.getType())
					|| ConfigPO.TP_BOOLEAN.equalsIgnoreCase(item.getType()))
				result.add(new Boolean(arr[i].equalsIgnoreCase(Boolean.TRUE.toString())));
			else if (ConfigPO.TP_DOUBLE.equalsIgnoreCase(item.getType()))
				result.add(new Double(arr[i]));
			else result.add(arr[i]);
		}
		return result;
	}

	protected Object processSimple(String value, ConfigPO item)
	{
		if (ConfigPO.TP_STRING.equalsIgnoreCase(item.getType())) return value;
		else if (ConfigPO.TP_BOOL.equalsIgnoreCase(item.getType())
				|| ConfigPO.TP_BOOLEAN.equalsIgnoreCase(item.getType()))
			return new Boolean(Boolean.TRUE.toString().equalsIgnoreCase(value));
		else if (ConfigPO.TP_INT.equalsIgnoreCase(item.getType())) return new Integer(value);
		else if (ConfigPO.TP_LONG.equalsIgnoreCase(item.getType())) return new Long(value);
		else if (ConfigPO.TP_DOUBLE.equalsIgnoreCase(item.getType())) return new Double(value);
		return value;
	}

	public void setPersistence(IPersistence persistence)
	{
		this.persistence = persistence;
	}

	public static boolean isProductMode()
	{
		return PRODUCT;
	}

	public boolean isProduct()
	{
		return PRODUCT;
	}

	public void setProduct(boolean product)
	{
		PRODUCT = product;
	}

	// public void setLocations(String locations)
	// {
	// this.locations = locations;
	// }

	public Map getStaticCfg()
	{
		return staticCfg;
	}

	public void setInStaticCfg(String key, Object value)
	{
		this.staticCfg.put(key, value);
		this.config.putAll(this.staticCfg);
	}

	public void setStaticCfg(Map staticCfg)
	{
		this.staticCfg.putAll(staticCfg);
	}

	public void setResourceLoader(ResourceLoader loader)
	{
		this.loader = loader;
	}

	public String[] getMethods()
	{
		return methods;
	}

	public void setMethods(String[] methods)
	{
		this.methods = methods;
	}

	public String getLastDBVerDt()
	{
		return lastDBVerDt;
	}

	protected ResourceLoader loader;
}
