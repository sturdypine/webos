package spc.webos.config;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import spc.webos.constant.Common;
import spc.webos.util.StringX;

/**
 * ����springע������ʱʹ��?�ָ�����������ļ��Ҳ���ֵ��ʹ��?�����ֵ��ΪĬ��ֵ
 * 
 * @author chenjs
 *
 */
public class PropertyConfigurer extends PropertyPlaceholderConfigurer
{
	public Properties getProperties() throws IOException
	{
		return super.mergeProperties();
	}

	protected String resolvePlaceholder(String placeholder, Properties props)
	{
		int index = placeholder.indexOf(delim);
		if (index < 0) return super.resolvePlaceholder(placeholder, props);
		String defValue = placeholder.length() > index + 1 ? placeholder.substring(index + 1)
				: StringX.EMPTY_STRING;
		String value = super.resolvePlaceholder(placeholder.substring(0, index), props);
		if (value == null) value = defValue;
		return value;
	}

	protected void loadProperties(Properties props) throws IOException
	{
		super.loadProperties(props);

		Resource[] reses = new PathMatchingResourcePatternResolver().getResources(resource);
		for (Resource res : reses)
		{
			logger.info("loading properties:" + res);
			try (InputStreamReader reader = new InputStreamReader(res.getInputStream(),
					Common.CHARSET_UTF8))
			{
				props.load(reader);
			}
		}
	}

	protected String resource = "classpath*:app*.properties";
	protected String delim = "?";

	public void setDelim(String delim)
	{
		this.delim = delim;
	}

	public void setResource(String resource)
	{
		this.resource = resource;
	}
}
