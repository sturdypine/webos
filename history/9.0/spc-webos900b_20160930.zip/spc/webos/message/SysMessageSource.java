package spc.webos.message;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.NoSuchMessageException;

import spc.webos.config.AppConfig;
import spc.webos.persistence.IPersistence;
import spc.webos.util.StringX;

/**
 * ���ϵͳsys_msg���Ĺ��ʻ��ֵ���Ϣ ϵͳ��������Ϣ��������retcode����Ҳ���Դ����config��
 * 
 * @author spc
 * 
 */
public class SysMessageSource implements MessageSource
{
	private String sqlId;
	private Map message;
	private boolean init;
	@Resource
	protected IPersistence persistence;
	static SysMessageSource SYS_MSG = new SysMessageSource();
	static Logger log = LoggerFactory.getLogger(SqlMessageSource.class);

	private SysMessageSource()
	{
	}

	public static SysMessageSource getInstance()
	{
		return SYS_MSG;
	}

	@PostConstruct
	public void init()
	{
		if (init)
		{
			log.warn("has been init!!!");
			return;
		}
		refresh();
		init = true;
	}

	public void refresh()
	{
		log.info("sys message sqlId:{}", sqlId);
		if (StringX.nullity(sqlId)) return; // ����app_config��
		Map message = new HashMap();
		List list = (List) persistence.execute(sqlId, null);
		for (int i = 0; i < list.size(); i++)
		{
			List row = (List) list.get(i); // ȡ��Model����
			String key = (String) row.get(0); // code
			String value = (String) row.get(1); // text
			message.put(key, new MessageFormat(value));
		}
		this.message = message;
		log.debug(message.toString());
	}

	public String getMessage(String code, Object[] args, String defmsg, Locale locale)
	{
		// System.out.println("code:"+code);
		if (message == null) message = AppConfig.getInstance().getModule("retcode");
		int index = code.indexOf(AppMessageSource.SEPARATOR);
		String prefix = index > 0 ? code.substring(0, index) : code;
		Object obj = message.get(prefix);
		if (obj == null)
		{
			if (defmsg == null) return null; // Ĭ����ϢҲ������һ����Ϣģ��
			return new MessageFormat(defmsg).format(args);
		}
		MessageFormat mf = (obj instanceof MessageFormat) ? (MessageFormat) obj
				: new MessageFormat(obj.toString());
		return mf.format(args);
	}

	public String getMessage(MessageSourceResolvable resolvable, Locale locale)
			throws NoSuchMessageException
	{
		return resolvable.getDefaultMessage();
	}

	public String getMessage(String code, Object[] args, Locale locale)
			throws NoSuchMessageException
	{
		return getMessage(code, args, null, locale);
	}

	public void setSqlId(String sqlId)
	{
		this.sqlId = sqlId;
	}

	public Map getMessage()
	{
		return message;
	}

	public void setPersistence(IPersistence persistence)
	{
		this.persistence = persistence;
	}

	// 800, ��Ҫ����spring��ǰ����AppConfig
	public void setAppConfig(AppConfig appConfig)
	{
	}
}
