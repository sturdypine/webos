package spc.webos.cache;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractCache implements ICache, Runnable
{
	String name;
	protected Logger log = LoggerFactory.getLogger(getClass());

	protected int sleepSeconds = 60;
	protected boolean runEvictExpired = false;
	protected Thread daemon;

	public void setName(String name)
	{
		this.name = name;
	}

	public void init() throws Exception
	{
		if (getName() != null) CACHE.put(getName(), this);
		if (runEvictExpired)
		{
			daemon = new Thread(this);
			daemon.setDaemon(true);
			daemon.start();
		}
	}

	public void destroy()
	{
		runEvictExpired = false;
		try
		{
			if (daemon != null) daemon.interrupt();
		}
		catch (Exception e)
		{
		}
		try
		{
			if (daemon != null) daemon.stop();
		}
		catch (Exception e)
		{
		}
	}

	public void run()
	{
		log.info("start daemon to runEvictExpired...");
		while (runEvictExpired)
		{
			try
			{
				Thread.sleep(sleepSeconds * 1000);
			}
			catch (Exception e)
			{
			}
			try
			{
				log.info("evictExpired...");
				this.evictExpiredElements();
			}
			catch (Exception e)
			{
			}
		}
	}

	public Object getMessage(String key) throws Exception// for ���ʻ�
	{
		return get(key);
	}

	public synchronized Object poll(Object key, long timeout) throws Exception
	{
		return poll(key, new CacheWaitWithTime(key, timeout));
	}

	public synchronized Object poll(Object key, WaitWithTime wwt) throws Exception
	{
		wwt.setTarget(this);
		Object v = null;
		while (v == null)
		{
			while (wwt.condition())
				wwt.timeWait();
			v = get(key);
			remove(key);
		}
		return v;
	}

	public Object poll(Object key) throws Exception
	{
		Object v = get(key);
		remove(key);
		return v;
	}

	public String getName()
	{
		return name;
	}

	public boolean changeStatus(Map param)
	{
		return false;
	}

	public Map checkStatus(Map param)
	{
		Map status = new HashMap();
		status.put("name", name);
		status.put("clazz", getClass());
		return status;
	}

	public void refresh() throws Exception
	{
	}

	public void evictExpiredElements()
	{
	}
}
