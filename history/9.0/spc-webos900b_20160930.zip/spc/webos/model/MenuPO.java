package spc.webos.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import spc.webos.util.tree.ITreeNodeValue;

@Entity
@Table(name = "sys_menu")
public class MenuPO implements Serializable, ITreeNodeValue
{
	public static final long serialVersionUID = 20160101L;
	@Id
	@Column
	String id;
	@Column
	String text;
	@Column
	String parentId;
	@Column
	String win;
	@Column
	String js;
	@Column
	String config;
	@Column
	Integer morder;
	@Column
	String service;
	@Column
	String sqlId;

	public MenuPO()
	{
	}

	public MenuPO(String id)
	{
		this.id = id;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getText()
	{
		return text;
	}

	public void setText(String text)
	{
		this.text = text;
	}

	public String getParentId()
	{
		return parentId;
	}

	public void setParentId(String parentId)
	{
		this.parentId = parentId;
	}

	public String getWin()
	{
		return win;
	}

	public void setWin(String win)
	{
		this.win = win;
	}

	public String getJs()
	{
		return js;
	}

	public void setJs(String js)
	{
		this.js = js;
	}

	public String getConfig()
	{
		return config;
	}

	public void setConfig(String config)
	{
		this.config = config;
	}

	public Integer getMorder()
	{
		return morder;
	}

	public void setMorder(Integer morder)
	{
		this.morder = morder;
	}

	public String getService()
	{
		return service;
	}

	public void setService(String service)
	{
		this.service = service;
	}

	public String getSqlId()
	{
		return sqlId;
	}

	public void setSqlId(String sqlId)
	{
		this.sqlId = sqlId;
	}

	@Override
	public String getNodeText()
	{
		return text;
	}

	@Override
	public boolean isRoot()
	{
		return id.equals("00");
	}
}
