package spc.webos.tcc.service;

/**
 * TCCԭ�ӷ�����ˮ��¼
 * 
 * @author chenjs
 *
 */
public interface TCC
{
	String getTccSN();

	Integer getTccStatus();

	void setTccStatus(Integer status);
}
