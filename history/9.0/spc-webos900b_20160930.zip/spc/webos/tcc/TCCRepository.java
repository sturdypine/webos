package spc.webos.tcc;

import java.util.Collection;

public interface TCCRepository
{
	String createXid();

	Transaction create(Transaction transaction) throws Exception;

	Terminator addTerminator(Transaction transaction, TCCTransactional tcc, String tid, int seq,
			Object target, String clazz, String m, Class[] parameterTypes, Object[] args)
					throws Exception;

	Transaction updateStatus(Transaction transaction);

	Terminator updateStatus(Terminator terminator);

	Transaction delete(Transaction transaction, boolean byFail) throws Exception;

	Transaction find(String xid) throws Exception;

	Collection<String> findAll(int from, int limit) throws Exception;

	Collection<String> findErr(int from, int limit) throws Exception;
}
