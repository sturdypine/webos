package spc.webos.service.common;

import java.util.Map;

public interface LoginService
{
	void login(Map<String, String> login);

	boolean logout();

	boolean isTimeout();

	Map<String, Object> getServerInfo();
}
