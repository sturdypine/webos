package spc.webos.service.common.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.time.FastDateFormat;
import org.springframework.stereotype.Service;

import spc.webos.constant.AppRetCode;
import spc.webos.exception.AppException;
import spc.webos.model.MenuPO;
import spc.webos.model.RolePO;
import spc.webos.model.UserPO;
import spc.webos.service.BaseService;
import spc.webos.service.common.LoginService;
import spc.webos.service.common.SystemtService;
import spc.webos.util.StringX;
import spc.webos.web.common.ISessionUserInfo;
import spc.webos.web.common.SessionUserInfo;

@Service("loginService")
public class LoginServiceImpl extends BaseService implements LoginService
{
	protected boolean pwdMD5 = true; // �������MD5�㷨�洢
	@Resource
	protected SystemtService systemtService;
	protected List<String> defaultServices = Arrays.asList("login.*", "extjs.*");

	public LoginServiceImpl()
	{
		name = "login";
	}

	public boolean isTimeout()
	{
		return ISessionUserInfo.SUI.get() == null;
	}

	public Map<String, Object> getServerInfo()
	{
		Map<String, Object> params = new HashMap<>();
		params.put("timeout", ISessionUserInfo.SUI.get() == null);
		params.put("sysdt", FastDateFormat.getInstance("yyyyMMdd").format(new Date()));
		return params;
	}

	public boolean logout()
	{
		ISessionUserInfo sui = (ISessionUserInfo) ISessionUserInfo.SUI.get();
		if (sui == null) return false;
		// session invalidate ����filter�������
		return true;
	}

	public void login(Map<String, String> info)
	{
		String code = info.get("code");
		String pwd = info.get("password");
		String verify = info.get("verify");
		SessionUserInfo sui = (SessionUserInfo) ISessionUserInfo.SUI.get();
		log.info("{} login {}", code, verify);

		UserPO userVO = persistence.find(new UserPO(code));
		String password = pwdMD5 ? StringX.md5(pwd.getBytes()) : pwd;
		if (userVO == null || !userVO.getPwd().equalsIgnoreCase(password))
		{
			log.info("login fail:{}/{},{} != {}", code, pwd, password,
					userVO == null ? "" : userVO.getPwd());
			throw new AppException(AppRetCode.CMMN_PWD_ERR, new Object[] { code });
		}
		userVO.setPwd(null); // ��������Ϊnull
		sui.setRoles(getUserRole(userVO));
		sui.setUser(userVO);
		// ���õ�ǰ�û��ܷ��ʵķ����sql
		final List<String> services = new ArrayList<>(defaultServices);
		final List<String> sqlIds = new ArrayList<>();
		List<MenuPO> menus = systemtService.getMenu();
		menus.forEach((m) -> {
			List<String> ss = StringX.split2list(m.getService(), StringX.COMMA);
			ss.forEach((s) -> {
				if (!services.contains(s.toLowerCase())) services.add(s.toLowerCase());
			});
			ss = StringX.split2list(m.getSqlId(), StringX.COMMA);
			ss.forEach((s) -> {
				if (!sqlIds.contains(s.toLowerCase())) sqlIds.add(s.toLowerCase());
			});
		});
		sui.setServices(services);
		sui.setSqlIds(sqlIds);
		log.debug("menus:{}, services:{}, sqlIds:{}", menus.size(), services, sqlIds);
	}

	protected List<String> getUserRole(UserPO userVO)
	{
		String roleId = userVO.getRoleId();
		List<String> roles = StringX.split2list(roleId, StringX.COMMA);
		List<String> menus = new ArrayList<>();
		for (int i = 0; i < roles.size(); i++)
		{
			RolePO roleVO = new RolePO();
			roleVO.setId((String) roles.get(i));
			roleVO = (RolePO) persistence.find(roleVO);
			if (roleVO == null) continue;
			List<String> menu = StringX.split2list(roleVO.getMenu(), StringX.COMMA);
			for (int j = 0; menu != null && j < menu.size(); j++)
				if (!menus.contains(menu.get(j))) menus.add(menu.get(j));
		}
		log.info("menus:{}", menus);
		return menus;
	}

	public void setDefaultServices(String defaultServices)
	{
		if (!StringX.nullity(defaultServices))
			this.defaultServices = StringX.split2list(defaultServices, ",");
	}

	public void setPwdMD5(boolean pwdMD5)
	{
		this.pwdMD5 = pwdMD5;
	}
}
