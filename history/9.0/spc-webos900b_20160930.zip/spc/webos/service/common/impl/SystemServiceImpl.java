package spc.webos.service.common.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.time.FastDateFormat;
import org.springframework.stereotype.Service;

import spc.webos.config.AppConfig;
import spc.webos.message.DictMessageSource;
import spc.webos.message.SqlMessageSource;
import spc.webos.message.SysMessageSource;
import spc.webos.model.MenuPO;
import spc.webos.persistence.IPersistence;
import spc.webos.service.BaseService;
import spc.webos.service.common.SystemtService;
import spc.webos.util.FTLUtil;
import spc.webos.web.common.ISessionUserInfo;

@Service("systemService")
public class SystemServiceImpl extends BaseService implements SystemtService
{
	protected List<MenuPO> fns;

	public List<MenuPO> getMenu()
	{
		List<String> roles = ISessionUserInfo.SUI.get().getRoles();
		if (fns == null)
		{
			Map<String, Object> params = new HashMap<>();
			params.put(IPersistence.SELECT_ATTACH_TAIL_KEY, "order by morder,id");
			fns = persistence.get(new MenuPO(), params);
			log.info("sys fns:{}", fns.size());
		}
		List<MenuPO> m = new ArrayList<>();
		fns.forEach((po) -> {
			for (int i = 0; i < roles.size(); i++)
			{
				if ("*".equals(roles.get(i)) || roles.get(i).startsWith(po.getId())
						|| "00".equals(po.getId())
						|| (roles.get(i).endsWith("*")
								&& (po.getId()
										.startsWith(roles.get(i).substring(0,
												roles.get(i).length() - 1))
								|| roles.get(i).substring(0, roles.get(i).length() - 1)
										.startsWith(po.getId()))))
				{
					m.add(po);
					return;
				}
			}
		});
		return m;
	}

	public String getCurrentDate(String format)
	{
		return FastDateFormat.getInstance(format).format(getCurrentDate());
	}

	public Date getCurrentDate()
	{
		return new Date();
	}

	public void refreshFTLInDB()
	{
		FTLUtil.getInstance().loadFTLInDB();
	}

	public void refreshSQLInDB() throws Exception
	{
		persistence.loadSQLInDB();
	}

	public void refreshConfig() throws Exception
	{
		AppConfig.getInstance().refresh();
	}

	// ˢ��ϵͳ���ݿ��ֵ����ݵ��ڴ�
	public void refreshDict() throws Exception
	{
		DictMessageSource.getInstance().refresh();
	}

	// ˢ��ϵͳ�Ĺ��ʻ�ת����Ϣ���ڴ�
	public void refreshSysMsg() throws Exception
	{
		SysMessageSource.getInstance().refresh();
	}

	public void refreshSqlMsg(List sqls) throws Exception
	{
		Iterator keys = null;
		if (sqls != null && sqls.size() > 0) keys = sqls.iterator();
		else keys = SqlMessageSource.SQL_MSG.keySet().iterator();
		while (keys.hasNext())
		{
			SqlMessageSource ms = (SqlMessageSource) SqlMessageSource.SQL_MSG.get(keys.next());
			if (ms != null) ms.refresh();
		}
	}
}
