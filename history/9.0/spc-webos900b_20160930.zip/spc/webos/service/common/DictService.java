package spc.webos.service.common;

import java.util.Map;

/**
 * @author chenjs
 */
public interface DictService
{
	void getAllDictDescVO(Map cache) throws Exception;
}
