
package spc.webos.service.common;

import java.util.List;
import java.util.Map;

import spc.webos.exception.AppException;

/**
 * �˽ӿ���Ҫ��Ϊ��֧��rpc(dubbo)�������
 * 
 * @author chenjs
 *
 */
public interface PersistenceService
{
	List<Integer> update(List<List<Object>> po) throws AppException;

	int update(String clazz, Map<String, Object> map) throws AppException;

	List<Integer> insert(List<List<Object>> po) throws AppException;

	int insert(String clazz, Map<String, Object> map) throws AppException;

	List<Integer> delete(List<List<Object>> po) throws AppException;

	int delete(String clazz, Map<String, Object> map) throws AppException;

	Map<String, Object> find(String clazz, Map<String, Object> map) throws AppException;

	List<Map<String, Object>> get(String clazz, Map<String, Object> map) throws AppException;

	Object execute(String sqlId, Map<String, Object> params);

	Object execute(String[] sqlId, Map<String, Object> params, Map<String, Object> result);

	<T> T find(T po);

	<T> List<T> get(T po);

	int delete(Object po);

	int insert(Object po);

	int update(Object po);
}
