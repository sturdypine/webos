package spc.webos.service.job.impl;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.recipes.leader.LeaderSelector;
import org.apache.curator.framework.recipes.leader.LeaderSelectorListener;
import org.apache.curator.framework.state.ConnectionState;
import org.springframework.stereotype.Service;

import spc.webos.advice.log.LogTrace;
import spc.webos.service.job.MasterSlaveJobService;

@Service("leaderSelectorMSJobService")
public class LeaderSelectorMSJobServiceImpl extends ZKMasterSlaveJobServiceImpl
{
	public LeaderSelectorMSJobServiceImpl()
	{
		name = "LeaderSelectorJobServiceImpl";
		zkPath = "/Job/LS/test";
	}

	protected LeaderSelectorMSJobServiceImpl(String zkHost, String zkPath)
	{
		this();
		this.zkHost = zkHost;
		this.zkPath = zkPath;
	}

	protected LeaderSelectorMSJobServiceImpl(String zkPath)
	{
		this();
		this.zkPath = zkPath;
	}

	@LogTrace(location = "lsjob.leader")
	public void leader() throws Exception
	{
		log.info("invoke job: {}, zkHost:{}, zkPath:{}", name, zkHost, zkPath);
		CuratorFramework zk = zk();
		if (zk.checkExists().forPath(zkPath) == null)
			zk.create().creatingParentsIfNeeded().forPath(zkPath, "MSJob".getBytes());

		final LeaderSelector leader = new LeaderSelector(zk, zkPath, new LeaderSelectorListener()
		{
			public void takeLeadership(CuratorFramework client) throws Exception
			{
				log.info("{} job start, I'm leader...", name);
				try
				{
					((MasterSlaveJobService) self).execute();
					log.info("{} job finish...", name);
				}
				catch (Exception e)
				{
					log.info(name + " job fail", e);
				}
				finally
				{
					// leader.close(); // �ر��߳�
				}
			}

			public void stateChanged(CuratorFramework client, ConnectionState newState)
			{
			}
		});
		leader.autoRequeue();
		leader.start();
	}
}
