package spc.webos.service.job.impl;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.recipes.leader.LeaderLatch;
import org.springframework.stereotype.Service;

import spc.webos.advice.log.LogTrace;
import spc.webos.service.job.MasterSlaveJobService;

/**
 * ͨ��zookeeper��ȷ������ģʽ��̨����
 * 
 * @author chenjs
 *
 */
@Service("leaderLatchMSJobService")
public class LeaderLatchMSJobServiceImpl extends ZKMasterSlaveJobServiceImpl
{
	public LeaderLatchMSJobServiceImpl()
	{
		name = "LeaderLatchJobServiceImpl";
		zkPath = "/Job/LL/test";
	}

	protected LeaderLatchMSJobServiceImpl(String zkHost, String zkPath)
	{
		this();
		this.zkHost = zkHost;
		this.zkPath = zkPath;
	}

	protected LeaderLatchMSJobServiceImpl(String zkPath)
	{
		this();
		this.zkPath = zkPath;
	}

	@LogTrace(location = "lljob.leader")
	public void leader() throws Exception
	{
		log.info("invoke job: {}, zkHost:{}, zkPath:{}", name, zkHost, zkPath);
		CuratorFramework zk = zk();
		if (zk.checkExists().forPath(zkPath) == null)
			zk.create().creatingParentsIfNeeded().forPath(zkPath, "MSJob".getBytes());
		LeaderLatch latch = new LeaderLatch(zk, zkPath);
		latch.start();
		latch.await();
		log.info("{} job start, I'm leader...", name);
		try
		{
			((MasterSlaveJobService) self).execute();
			log.info("{} job success to finish...", name);
		}
		catch (Exception e)
		{
			log.warn(name + " job ex:", e);
		}
		finally
		{
			latch.close();
			zk.close();
		}
	}
}
