package spc.webos.service.job.impl;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.springframework.beans.factory.annotation.Value;

import spc.webos.advice.log.LogTrace;
import spc.webos.service.BaseService;
import spc.webos.service.job.MasterSlaveJobService;

public abstract class ZKMasterSlaveJobServiceImpl extends BaseService
		implements MasterSlaveJobService
{
	@Value("${app.job.zk.host?}")
	protected String zkHost;
	protected String zkPath = "/Job/LL/test";

	@LogTrace(location = "job.execute")
	public void execute() throws Exception
	{
		log.info("hello, it's " + name + ", I am leader now, doing job...");
	}

	protected CuratorFramework zk() throws Exception
	{
		CuratorFramework zkcf = CuratorFrameworkFactory.builder().connectString(zkHost)
				.connectionTimeoutMs(30000).canBeReadOnly(false)
				.retryPolicy(new ExponentialBackoffRetry(60000, 29)).defaultData(null).build();
		zkcf.start();
		return zkcf;
	}

	public void setZkHost(String zkHost)
	{
		this.zkHost = zkHost;
	}

	public void setZkPath(String zkPath)
	{
		this.zkPath = zkPath;
	}
}
