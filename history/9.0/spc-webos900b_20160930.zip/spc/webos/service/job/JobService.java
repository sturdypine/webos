package spc.webos.service.job;

public interface JobService
{
	void execute() throws Exception;
}
