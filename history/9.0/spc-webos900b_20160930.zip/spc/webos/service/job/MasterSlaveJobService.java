package spc.webos.service.job;

public interface MasterSlaveJobService extends JobService
{
	void leader() throws Exception;
}
