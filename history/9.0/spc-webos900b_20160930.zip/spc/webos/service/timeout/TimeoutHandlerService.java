package spc.webos.service.timeout;

public interface TimeoutHandlerService
{
	void doTimeout(Timeout timeout) throws Exception;
}
