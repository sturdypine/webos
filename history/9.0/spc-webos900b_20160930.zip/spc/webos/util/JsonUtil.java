package spc.webos.util;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.FastDateFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser.Feature;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.google.gson.Gson;

import spc.webos.constant.AppRetCode;
import spc.webos.exception.Status;

public class JsonUtil
{
	protected static Logger log = LoggerFactory.getLogger(JsonUtil.class);
	static JsonUtil INSTANCE = new JsonUtil();

	public static JsonUtil getInstance()
	{
		return INSTANCE;
	}

	// 900, ������ftl�в���json����
	public static String gson(Object src)
	{
		return new Gson().toJson(src);
	}

	public static Object gson2obj(String json, String clazz) throws ClassNotFoundException
	{
		return gson2obj(json, Class.forName(clazz));
	}

	public static Object gson2obj(String json, Class clazz)
	{
		return new Gson().fromJson(json, clazz);
	}

	public static Object gson2obj(String json)
	{
		if (StringX.nullity(json)) return null;
		json = StringX.trim(json, StringX.TRIM_CHAR);
		if (StringX.nullity(json)) return null;
		if (json.charAt(0) == '[') { return new Gson().fromJson(json, ArrayList.class);
		// List l = new ArrayList();
		// l.addAll(JSONArray.toCollection(JSONArray));
		// return dfsJsonList(l);
		}
		return new Gson().fromJson(json, HashMap.class);
		// JSONObject jo = JSONObject.fromObject(json);
		// if (jo.isEmpty() || jo.isNullObject()) return null;
		// return dfsJsonMap((Map) JSONObject.toBean(jo, HashMap.class));
	}

	public static Object json2obj(String json, Class clazz)
	{
		ObjectMapper mapper = new ObjectMapper();
		// �������л�jsonʱ��δ֪���Ի�����ķ����л�����ϣ��������ǽ���δ֪���Դ�Ϸ����л����ܣ�
		// ��Ϊ������json����10�����ԣ������ǵ�bean��ֻ������2�����ԣ�����8�����Խ�������
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		// ��jsonӳ�䵽java���󣬵õ�country�����Ϳ��Ա�������,��������������ݣ���˵������Ϳ�����
		try
		{
			return mapper.readValue(json, clazz);
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
	}

	public static Object json2obj(String json)
	{
		if (StringX.nullity(json)) return null;
		json = StringX.trim(json, StringX.TRIM_CHAR);
		if (StringX.nullity(json)) return null;
		ObjectMapper m = new ObjectMapper();
		m.configure(Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
		m.configure(Feature.ALLOW_SINGLE_QUOTES, true);
		try
		{
			if (json.charAt(0) == '[') return m.readValue(json, ArrayList.class);
			return m.readValue(json, HashMap.class);
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
	}

	public static String obj2json(Object o)
	{
		ObjectMapper mapper = new ObjectMapper();
		// �������û��ֵ����ôJson�ǻᴦ���ģ�int����Ϊ0��String����Ϊnull������Ϊ[]������������Կ��Ժ��Կ�ֵ����
		mapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
		try
		{
			return mapper.writeValueAsString(o);
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
	}

	public static String obj2json(Object o, Class... clazz)
	{
		ObjectMapper mapper = new ObjectMapper();
		// �������û��ֵ����ôJson�ǻᴦ���ģ�int����Ϊ0��String����Ϊnull������Ϊ[]������������Կ��Ժ��Կ�ֵ����
		mapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
		SimpleModule module = new SimpleModule();
		JsonSerializer<Object> js = new JsonSerializer<Object>()
		{
			public void serialize(Object value, JsonGenerator jgen, SerializerProvider provider)
					throws IOException, JsonProcessingException
			{
				jgen.writeString(value.toString());
			}
		};
		for (Class c : clazz)
			module.addSerializer(c, js);
		mapper.registerModule(module);
		try
		{
			return mapper.writeValueAsString(o);
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
	}

	// for json call service
	// ����һ������soap/json��ʽ�ı��� �����Ӧ���ĸ�ʽ��esb soapһ��
	// {Header:{sndDt:'20160808', sndTm:'0909009', msgCd:'', seqNb:'',
	// sndAppCd:'',
	// refSndAppCd:'', refSndDt:'', refMsgCd:'', refSeqNb:'', replyToQ:'',
	// status:{retcd:'',...} },
	// Body:[...]}
	public static Map<String, Object> soap(String sndAppCd, String msgCd, String seqNb,
			String replyToQ, String replyMsgCd, Object args)
	{
		Map<String, Object> soap = new HashMap<>();
		soap.put(TAG_BODY, args);
		Map<String, String> header = new HashMap<>();
		soap.put(TAG_HEADER, header);
		// set snd info
		String dt = FastDateFormat.getInstance("yyyyMMddHHmmssSSS").format(new Date());
		header.put(TAG_HEADER_SNDAPP, sndAppCd);
		header.put(TAG_SNDDT, dt.substring(0, 8));
		header.put(TAG_SNDTM, dt.substring(8));
		header.put(TAG_HEADER_MSGCD, msgCd);
		if (!StringX.nullity(replyToQ)) header.put(TAG_HEADER_REPLYTOQ, replyToQ);
		if (!StringX.nullity(replyMsgCd)) header.put(TAG_HEADER_REPLYMSGCD, replyMsgCd);
		header.put(TAG_HEADER_SN, seqNb);
		return soap;
	}

	public static Map<String, Object> jsonRequest(Map<String, Object> soap, String appCd,
			boolean response) throws Exception
	{
		Map<String, Object> header = (Map<String, Object>) soap.get(TAG_HEADER);
		String sndAppCd = (String) header.get(TAG_HEADER_SNDAPP);
		String sndDt = (String) header.get(TAG_SNDDT);
		String seqNb = (String) header.get(TAG_HEADER_SN);
		String msgCd = (String) header.get(TAG_HEADER_MSGCD);
		Status status;
		log.info("JS request snd:{},{},{}, msgCd:{}", sndAppCd, sndDt, seqNb, msgCd);
		try
		{
			int idx = msgCd.lastIndexOf(".");
			Class<?> service = Class.forName(msgCd.substring(0, idx), false,
					Thread.currentThread().getContextClassLoader());
			Object ret = SpringUtil.jsonCall(service, msgCd.substring(idx + 1),
					JsonUtil.obj2json(soap.get(TAG_BODY)));
			soap.put(TAG_BODY, ret);
			status = new Status(AppRetCode.SUCCESS, null, null, appCd, SpringUtil.LOCAL_HOST_IP);
		}
		catch (Exception e)
		{
			soap.remove(TAG_BODY);
			status = SpringUtil.ex2status("", e);
		}
		// ֪ͨ�౨�ĺ�Ӧ���౨�����践��
		if (!response) return soap;

		// ����Ӧ��refXXX��Ϣ
		header.put(TAG_HEADER_REFMSGCD, msgCd);
		header.put(TAG_HEADER_REFSNDAPP, sndAppCd);
		header.put(TAG_HEADER_REFSNDDT, sndDt);
		header.put(TAG_HEADER_REFSNDSN, seqNb);
		// set status
		header.put(TAG_HEADER_STATUS, status);
		
		// set snd info
		String dt = FastDateFormat.getInstance("yyyyMMddHHmmssSSS").format(new Date());
		header.put(TAG_HEADER_SNDAPP, appCd);
		header.put(TAG_SNDDT, dt.substring(0, 8));
		header.put(TAG_SNDTM, dt.substring(8));
		header.remove(TAG_HEADER_SN); // ɾ��ԭ��ˮ����Ϣ
		String replyMsgCd = (String) header.get(TAG_HEADER_REPLYMSGCD);
		header.remove(TAG_HEADER_REPLYMSGCD);
		header.remove(TAG_HEADER_MSGCD);
		if (!StringX.nullity(replyMsgCd)) header.put(TAG_HEADER_MSGCD, replyMsgCd);

		return soap;
	}

	public static Object jsonResponse(Map<String, Object> soap) throws Exception
	{
		Map<String, Object> header = (Map<String, Object>) soap.get(TAG_HEADER);
		Map<String, String> s = (Map<String, String>) header.get(TAG_HEADER_STATUS);
		String sndAppCd = (String) header.get(TAG_HEADER_SNDAPP);
		String sndDt = (String) header.get(TAG_SNDDT);
		String seqNb = (String) header.get(TAG_HEADER_SN);
		String msgCd = (String) header.get(TAG_HEADER_MSGCD);
		String refSeqNb = (String) header.get(TAG_HEADER_REFSNDSN);
		log.info("JS response snd:{},{},{}, msgCd:{}, refsn:{},retcd:{}", sndAppCd, sndDt, seqNb,
				msgCd, refSeqNb, s == null ? "" : s.get("retCd"));

		int idx = msgCd.lastIndexOf(".");
		Class<?> service = Class.forName(msgCd.substring(0, idx), false,
				Thread.currentThread().getContextClassLoader());
		Object target = SpringUtil.APPCXT.getBean(service);
		Method m = target.getClass().getMethod(msgCd.substring(idx + 1), Map.class, Map.class,
				Object.class);
		return m.invoke(target, soap, s, soap.get(TAG_BODY));
	}

	public static String TAG_HEADER = "Header";

	public static String TAG_SNDDT = "sndDt"; // ��������yyyyMMdd
	public static String TAG_SNDTM = "sndTm"; // ����ʱ��HHmmss
	public static String TAG_HEADER_MSGCD = "msgCd"; // ���ı��
	public static String TAG_HEADER_SN = "seqNb"; // ������ˮ�ţ�����Ψһ��ˮ
	public static String TAG_HEADER_SNDAPP = "sndAppCd"; // ����Ӧ�ñ��
	public static String TAG_HEADER_RCVAPP = "rcvAppCd"; // ����Ӧ�ñ��

	public static String TAG_HEADER_REFMSGCD = "refMsgCd"; // �ο����ı��
	public static String TAG_HEADER_REFSNDAPP = "refSndAppCd"; // �ο�����Ӧ�ñ��
	public static String TAG_HEADER_REFSNDDT = "refSndDt"; // �ο�����ʱ��
	public static String TAG_HEADER_REFSNDSN = "refSeqNb"; // �ο���ˮ��
	public static String TAG_HEADER_REPLYTOQ = "replyToQ"; // 700 Ӧ�����
	public static String TAG_HEADER_REPLYMSGCD = "replyMsgCd"; // ����msgCd =
	public static String TAG_HEADER_STATUS = "status";

	public static String TAG_BODY = "Body";
}
