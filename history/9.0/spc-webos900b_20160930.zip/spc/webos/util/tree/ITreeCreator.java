package spc.webos.util.tree;

public interface ITreeCreator
{
	void insertChild(TreeNode parent, TreeNode current);
}
