package spc.webos.web.common;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.http.HttpSession;

public abstract class AbstractSessionUserInfo implements ISessionUserInfo, Serializable, Cloneable
{
	private static final long serialVersionUID = 1L;
	protected String loginIP; // ��½��IP
	protected Date loginDt; // ��½ʱ��
	protected Date lastVisitDt; // ��һ�η��ʷ�����ʱ��
	protected String verifyCode;

	protected transient Map<String, TransientInSession> transientParams = new HashMap<String, TransientInSession>();
	protected Map<String, Serializable> permanence = new HashMap<String, Serializable>();
	protected String urlKey; // ����ǩ��GET��ʽ��url����ֹ�ͻ����Լ�����
	protected String uri;

	protected List<String> roles; // ��Ȩ�Ľ�ɫID
	protected List<String> services; // ��Ȩ�ܷ��ʵķ���
	protected List<String> sqlIds; // ��Ȩ�ܷ��ʵ�sqlId

	protected transient HttpSession session; // ��ǰ�û���session
	protected AtomicInteger requestCount = new AtomicInteger(0);

	// ����һ��request���������ڲ������� Ҳ����ͳ�Ƶ�ǰ�û����������
	public void request(HttpSession session, String uri)
	{
		this.session = session;
		requestCount.incrementAndGet();
		this.uri = uri;
	}

	// �ͻ��˶��߳�����ʱ�����ܵ�ǰ�̶߳�ζ�ȡ�����в�һ��
	public int requestCount()
	{
		return requestCount.get();
	}

	public void setInPermanence(String key, Serializable value)
	{
		permanence.put(key, value);
	}

	public Object getInPermanence(String key)
	{
		return permanence.get(key);
	}

	public void setTransientInSession(String key, TransientInSession tis)
	{
		transientParams.put(key, tis);
	}

	public void setTransientInSession(String key, Serializable value)
	{
		transientParams.put(key, new TransientInSession(value));
	}

	public Object getTransient(String key)
	{
		TransientInSession tis = transientParams.get(key);
		return tis == null ? null : tis.value();
	}

	public TransientInSession getTransientInSession(String key)
	{
		return transientParams.get(key);
	}

	public void setVerifyCode(String verifyCode)
	{
		this.verifyCode = verifyCode;
	}

	public String getVerifyCode()
	{
		return this.verifyCode;
	}

	public String getLoginIP()
	{
		return loginIP;
	}

	public void setLoginIP(String loginIP)
	{
		this.loginIP = loginIP;
	}

	public boolean containSqlId(String s, Map param)
	{
		if (sqlIds == null) return true;
		return isAuth(sqlIds, s.replace('.', '_'));
	}

	public boolean containService(String s)
	{
		if (services == null) return true;
		return isAuth(services, s);
	}

	protected boolean isAuth(List<String> auth, String s)
	{
		s = s.toLowerCase();
		for (String ss : auth)
		{
			if (ss.equals(s)
					|| (ss.endsWith("*") && s.startsWith(ss.substring(0, ss.length() - 1))))
				return true;
		}
		return false;
	}

	public void removeExpiredTransient()
	{
		if (transientParams == null) transientParams = new HashMap<String, TransientInSession>();
		if (this.transientParams.size() == 0) return;
		long currentTimeMillis = System.currentTimeMillis();
		for (String key : transientParams.keySet())
		{
			TransientInSession tis = getTransientInSession(key);
			if (tis.isExpired(currentTimeMillis)) transientParams.remove(key);
		}
	}

	public String getUrlKey()
	{
		return urlKey;
	}

	public HttpSession session()
	{
		return session;
	}

	public Date getLoginDt()
	{
		return this.loginDt;
	}

	public void setLoginDt(Date loginDate)
	{
		this.loginDt = loginDate;
	}

	public Map<String, TransientInSession> getTransientParams()
	{
		return transientParams;
	}

	public Date getLastVisitDt()
	{
		return lastVisitDt;
	}

	public void setLastVisitDt(Date lastVisitDt)
	{
		this.lastVisitDt = lastVisitDt;
	}

	public Map<String, Serializable> getPermanence()
	{
		return permanence;
	}

	public void setUrlKey(String urlKey)
	{
		this.urlKey = urlKey;
	}

	public AtomicInteger getRequestCount()
	{
		return requestCount;
	}

	public void setRequestCount(AtomicInteger requestCount)
	{
		this.requestCount = requestCount;
	}

	public String getUri()
	{
		return uri;
	}

	public void setUri(String uri)
	{
		this.uri = uri;
	}

	public List<String> getRoles()
	{
		return roles;
	}

	public void setRoles(List<String> roles)
	{
		this.roles = roles;
	}

	public List<String> getServices()
	{
		return services;
	}

	public void setServices(List<String> services)
	{
		this.services = services;
	}

	public List<String> getSqlIds()
	{
		return sqlIds;
	}

	public void setSqlIds(List<String> sqlIds)
	{
		this.sqlIds = sqlIds;
	}
}
