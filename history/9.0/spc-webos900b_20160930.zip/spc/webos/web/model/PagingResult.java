package spc.webos.web.model;

import java.util.List;

/**
 * ��ҳ������ݣ� ����ǰ�˱����ҳ��ʾ
 * 
 * @author chenjs
 *
 */
public class PagingResult
{
	public int total;
	public List data;

	public PagingResult()
	{
	}

	public PagingResult(int total, List data)
	{
		this.total = total;
		this.data = data;
	}

	public PagingResult(List data)
	{
		this.total = data == null ? 0 : data.size();
		this.data = data;
	}
}
