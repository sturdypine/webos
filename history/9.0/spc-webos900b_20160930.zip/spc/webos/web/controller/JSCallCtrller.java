package spc.webos.web.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.google.gson.Gson;

import spc.webos.constant.AppRetCode;
import spc.webos.constant.Common;
import spc.webos.constant.Web;
import spc.webos.exception.AppException;
import spc.webos.util.FileUtil;
import spc.webos.util.SpringUtil;
import spc.webos.util.StringX;
import spc.webos.web.common.ISessionUserInfo;
import spc.webos.web.util.WebUtil;

/**
 * ���κ�һ�������е�spring����©Ϊjson����
 * 
 * @version 9.0.0
 * @author chenjs
 * 
 */
public class JSCallCtrller implements Controller
{
	protected Logger log = LoggerFactory.getLogger(getClass());
	protected String charset = Common.CHARSET_UTF8;

	protected String viewName = "jsCallView";
	protected String servicePostfix = "Service";
	protected String viewPostfix = "View"; // spring id��view��ͳһ��׺��
	protected String argsName = "args";

	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response)
			throws Exception
	{
		ModelAndView mv = new ModelAndView(viewName);
		if (request.getMethod().equalsIgnoreCase(Web.POST_METHOD))
		{ // post method�� ����Ϊ����body
			mv.getModel().put(Web.SERVICE_RET_KEY, call(request, response,
					new String(FileUtil.is2bytes(request.getInputStream(), false), charset)));
		}
		else
		{ // get method, ��������Ϊargs=???
			String view = request.getParameter(Web.REQ_KEY_VIEW_TYPE);
			if (!StringX.nullity(view)) mv.setViewName(view + viewPostfix); // url����ָ��view
			mv.getModel().put(Web.SERVICE_RET_KEY,
					call(request, response, StringX.null2emptystr(request.getParameter(argsName))));
		}
		log.debug("view:{}", mv.getViewName());
		return mv;
	}

	protected Object call(HttpServletRequest request, HttpServletResponse response, String args)
			throws Exception
	{
		String[] m = WebUtil.last2path(request.getRequestURI());
		ISessionUserInfo sui = ISessionUserInfo.SUI.get();
		if (sui != null)
		{ // ����Ѿ���¼��������鵱ǰ��½��ִ�з����Ȩ��
			int argNum = getArgNum(args);
			if (!sui.containService(m[0] + '.' + m[1] + '#' + argNum))
			{
				log.info("unauthorized service:({}.{}#{}), user:{}", m[0], m[1], argNum,
						sui.getUserCode());
				throw new AppException(AppRetCode.SERVICE_UNAUTH,
						new Object[] { m[0] + '.' + m[1] + '#' + argNum });
			}
		}
		if (!StringX.nullity(servicePostfix) && !m[0].endsWith(servicePostfix))
			m[0] += servicePostfix;
		return SpringUtil.jsonCall(m[0], m[1], args);
	}

	public static int getArgNum(String args)
	{
		Gson gson = new Gson();
		args = StringX.trim(args);
		if (StringX.nullity(args)) return 0; // û�в���
		if (args.charAt(0) == '[')
		{ // is args array
			List argList = gson.fromJson(args, ArrayList.class);
			return argList == null ? 0 : argList.size();
		}
		// is map: args types & args
		Map<String, Object> map = gson.fromJson(args, HashMap.class);
		List argList = (List) map.get(SpringUtil.PAR_ARGS_TAG);
		return argList == null ? 1 : argList.size();
	}

	public void setServicePostfix(String servicePostfix)
	{
		this.servicePostfix = servicePostfix;
	}

	public void setCharset(String charset)
	{
		this.charset = charset;
	}

	public void setArgsName(String argsName)
	{
		this.argsName = argsName;
	}

	public void setViewPostfix(String viewPostfix)
	{
		this.viewPostfix = viewPostfix;
	}

	public void setViewName(String viewName)
	{
		this.viewName = viewName;
	}
}
