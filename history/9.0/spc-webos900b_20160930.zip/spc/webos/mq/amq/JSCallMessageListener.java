package spc.webos.mq.amq;

import java.util.Map;

import javax.annotation.Resource;
import javax.jms.BytesMessage;
import javax.jms.Message;
import javax.jms.MessageListener;

import org.apache.activemq.command.ActiveMQQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.core.JmsTemplate;

import spc.webos.constant.Common;
import spc.webos.service.seq.UUID;
import spc.webos.util.JsonUtil;
import spc.webos.util.LogUtil;
import spc.webos.util.SpringUtil;
import spc.webos.util.StringX;;

public class JSCallMessageListener implements MessageListener
{
	public void onMessage(Message msg)
	{
		boolean set = false;
		byte[] buf = null;
		String corMsgId = null, queue = null;
		try
		{
			queue = msg.getJMSDestination().toString().replaceAll("/", "");
			corMsgId = msg.getJMSCorrelationID();
			set = LogUtil.setTraceNo(corMsgId, queue, true);
			buf = new byte[(int) ((BytesMessage) msg).getBodyLength()];
			((BytesMessage) msg).readBytes(buf);

			Map<String, Object> soap = (Map<String, Object>) JsonUtil
					.gson2obj(new String(buf, charset));
			Map<String, Object> header = (Map<String, Object>) soap.get(JsonUtil.TAG_HEADER);
			String refSeqNb = (String) header.get(JsonUtil.TAG_HEADER_REFSNDSN);
			if (StringX.nullity(refSeqNb))
			{ // ������
				log.info("JS request:{},{}, len:{}", corMsgId, queue, buf.length);
				doRequest((BytesMessage) msg, soap);
			}
			else
			{ // Ӧ����
				log.info("JS response:{},{}, len:{}", corMsgId, queue, buf.length);
				JsonUtil.jsonResponse(soap);
			}
		}
		catch (Exception e)
		{
			log.warn("ex:: msgId:" + corMsgId + ", buf:" + buf == null ? "" : new String(buf), e);
		}
		finally
		{
			if (set) LogUtil.removeTraceNo();
		}
	}

	protected void doRequest(BytesMessage msg, Map<String, Object> soap) throws Exception
	{
		Map<String, Object> header = (Map<String, Object>) soap.get(JsonUtil.TAG_HEADER);
		String replyToQ = (String) header.get(JsonUtil.TAG_HEADER_REPLYTOQ);
		String replyMsgCd = (String) header.get(JsonUtil.TAG_HEADER_REPLYMSGCD);
		boolean response = !StringX.nullity(replyToQ);
		JsonUtil.jsonRequest(soap, SpringUtil.APPCODE, response);
		if (!response)
		{
			log.info("replyToQ is empty");
			return;
		}

		header.put(JsonUtil.TAG_HEADER_SN, String.valueOf(uuid.uuid()));
		String json = JsonUtil.obj2json(soap);
		final byte[] buf = json.getBytes(Common.CHARSET_UTF8);
		log.debug("response json:{}", json);
		log.info("AMQ send: {}, replyCd:{}, corId:{},  len:{}", replyToQ, replyMsgCd,
				msg.getJMSCorrelationID(), buf.length);
		jms.send(new ActiveMQQueue(replyToQ), (s) -> {
			BytesMessage m = s.createBytesMessage();
			m.setJMSCorrelationID(msg.getJMSCorrelationID());
			m.writeBytes(buf);
			return m;
		});
	}

	protected Logger log = LoggerFactory.getLogger(getClass());
	protected String charset = Common.CHARSET_UTF8;
	@Resource
	protected UUID uuid;
	@Resource
	protected JmsTemplate jms;

	public void setCharset(String charset)
	{
		this.charset = charset;
	}

	public void setUuid(UUID uuid)
	{
		this.uuid = uuid;
	}

	public void setJms(JmsTemplate jms)
	{
		this.jms = jms;
	}
}
