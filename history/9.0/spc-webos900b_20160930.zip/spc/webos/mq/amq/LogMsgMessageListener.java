package spc.webos.mq.amq;

import java.util.concurrent.atomic.AtomicLong;

import javax.jms.BytesMessage;
import javax.jms.Message;
import javax.jms.MessageListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import spc.webos.constant.Common;

/**
 * ��ӡ�յ�����Ϣ
 * 
 * @author chenjs
 *
 */
public class LogMsgMessageListener implements MessageListener
{
	protected Logger log = LoggerFactory.getLogger(getClass());
	final AtomicLong count = new AtomicLong(0);

	public void onMessage(Message msg)
	{
		try
		{
			byte[] buf = new byte[(int) ((BytesMessage) msg).getBodyLength()];
			((BytesMessage) msg).readBytes(buf);
			log.info("thread:{},{}, id:{}, body:{}", Thread.currentThread().getName(),
					count.incrementAndGet(), msg.getJMSCorrelationID(),
					new String(buf, Common.CHARSET_UTF8));
		}
		catch (Exception e)
		{
			log.warn("onMessage:", e);
		}
	}
}
