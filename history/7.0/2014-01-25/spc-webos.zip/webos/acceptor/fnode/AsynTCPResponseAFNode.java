package spc.webos.acceptor.fnode;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;

import spc.webos.acceptor.SocketMessage;
import spc.webos.cache.ICache;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.flownode.impl.SendResponseAFNode;
import spc.webos.util.StringX;
import spc.webos.util.http.HTTPHeader;
import spc.webos.util.http.HTTPUtil;

/**
 * �����첽����TCPӦ����
 * 
 * @author chenjs
 * 
 */
public class AsynTCPResponseAFNode extends SendResponseAFNode
{
	protected void send(IMessage msg) throws Exception
	{
		try
		{
			SocketMessage smsg = (SocketMessage) msg2sndobj(msg);
			if (smsg == null) return;
			send(msg, smsg);
			msg.setInLocal(MsgLocalKey.SND_BUF, Boolean.TRUE);
		}
		catch (Exception e)
		{
			if (logex) log.warn("ERR to snd response", e);
			else throw e;
		}
	}

	protected void send(IMessage msg, SocketMessage smsg) throws Exception
	{
		if (smsg.repmsg == null || smsg.repmsg.length == 0)
		{
			log.warn("smsg.repmsg is null or len is 0!!!");
			return;
		}
		if (log.isInfoEnabled()) log
				.info("snd len: " + smsg.repmsg.length + ", " + smsg.dhl.hdrLen);
		if (smsg.dhl.hdrLen > 0)
		{
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			if (autoSndLenHdr) baos.write(smsg.dhl.lenBytes(smsg.repmsg.length));
			baos.write(createSndContent(smsg));
			if (smsg.endFlag) baos.write('\0');
			send(smsg, baos.toByteArray(), false);
		}
		else
		{
			// if (autoSndLenHdr && smsg.dhl.hdrLen > 0) send(smsg,
			// lenBytes(smsg), false);
			send(smsg, createSndContent(smsg), false);
			// added by spc 2011-05-03 ����н�����־���ͽ�����־
			if (smsg.endFlag) send(smsg, new byte[] { '\0' }, false);
		}
		smsg.nbc.flush();
		if (!smsg.longCnn || smsg.dhl.hdrLen <= 0)
		{
			log.info("nbc close");
			smsg.nbc.close();
		}
	}

	protected byte[] createSndContent(SocketMessage smsg) throws Exception
	{
		if (smsg.reqHttpHdr == null) return smsg.repmsg;
		HTTPHeader hdr = smsg.repHttpHdr;
		if (hdr == null) hdr = new HTTPHeader();
		if (smsg.defRepHttpHdrParams != null)
		{ // �����Ĭ�ϵ�httpͷ���������ڵ�ǰͷ��Ϣ�����ϼ��ϡ�
			if (hdr.params == null || hdr.params.size() == 0) hdr.params = smsg.defRepHttpHdrParams;
			else
			{
				Map params = new HashMap(smsg.defRepHttpHdrParams);
				params.putAll(hdr.params);
				hdr.params = params;
			}
		}
		return HTTPUtil.packResponse(hdr, smsg.repmsg);
	}

	// protected byte[] lenBytes(SocketMessage smsg)
	// {
	// // modified by chenjs 2012-11-25 ����containHdrLenSelf���Կ���
	// int hdrlen = smsg.repmsg.length + (smsg.containHdrLenSelf ? smsg.hdrLen :
	// 0);
	// if (smsg.hdrLenBinary) return NumberX.int2bytes(hdrlen, smsg.hdrLen);
	// String strLen = StringX.int2str(String.valueOf(hdrlen), smsg.hdrLen);
	// // added by chenjs 2011-06-25
	// // Ϊ�˼�����ǰTCPResponse���ܣ�ֻҪһ���ط�����len2bcd����Ϊ��Ҫlen2bcd
	// return smsg.len2bcd ? EBCDUtil.gbk2bcd(strLen) : strLen.getBytes();
	// }

	protected void send(SocketMessage smsg, byte[] buf, boolean autoFlush) throws Exception
	{
		if (isTrace(smsg.localPort) && log.isInfoEnabled()) log.info("trace snd bytes base64: "
				+ new String(StringX.encodeBase64(buf)) + "\n\t\tstr:\n" + new String(buf));
		else if (log.isDebugEnabled()) log.debug("snd bytes base64: "
				+ new String(StringX.encodeBase64(buf)) + "\n\t\tstr:\n" + new String(buf));
		smsg.nbc.write(buf);
		if (autoFlush) smsg.nbc.flush();
		if (log.isInfoEnabled()) log.info("suc to snd nbc: " + buf.length + ", flush:" + autoFlush
				+ ", remote:" + smsg.nbc.getRemoteAddress());
	}

	protected Object msg2sndobj(IMessage msg) throws Exception
	{
		Object[] obj = (Object[]) cache.poll(msg.getRefMsgSn());
		if (obj == null) obj = (Object[]) cache.poll(msg.getRefSeqNb());
		if (obj == null)
		{
			log.warn("Fail to poll cache: " + msg.getRefMsgSn() + ", " + msg.getRefSeqNb()
					+ ", keys:" + cache.getKeys());
			return null;
		}
		SocketMessage smsg = (SocketMessage) obj[0];
		IMessageConverter converter = (IMessageConverter) obj[1]; // ��ȡ������MessageConverter
		smsg.repmsg = converter.serialize(msg);
		return smsg;
	}

	protected boolean isSend(IMessage msg)
	{
		if (msg.getLocal().containsKey(MsgLocalKey.NO_RETURN))
		{
			log.info("no return flag has been set!!!");
			return false;
		}
		if (msg.getLocal().containsKey(MsgLocalKey.LOCAL_ACCESS4LOCAL))
		{
			log.info("LOCAL_ACCESS4LOCAL flag has been set!!!");
			return false;
		}
		return true;
	}

	protected ICache cache; // ���ڴ洢�첽��������Ӧ��ͨ����Ϣ
	protected boolean logex = true; // �����־�쳣��˵������ʧ�ܣ������̲����׳��쳣, Ĭ��Ϊtrue
	protected boolean autoSndLenHdr = true;

	// protected boolean sndLenWithBuf = true; // added by chenjs 2011-11-03,
	// true����ߺܶ�����

	public void setLogex(boolean logex)
	{
		this.logex = logex;
	}

	public void setAutoSndLenHdr(boolean autoSndLenHdr)
	{
		this.autoSndLenHdr = autoSndLenHdr;
	}

	public void setCache(ICache cache)
	{
		this.cache = cache;
	}
}