package spc.webos.acceptor.fnode;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import spc.webos.acceptor.SocketMessage;
import spc.webos.config.AppConfig;
import spc.webos.constant.Common;
import spc.webos.constant.Config;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.endpoint.Endpoint;
import spc.webos.endpoint.EndpointFactory;
import spc.webos.endpoint.Executable;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

/**
 * ͨ�������ĵĳ��ȣ�ʹ�õ�������������
 * 
 * @author chenjs
 * 
 */
public class ShieldTCPResponseAFNode extends TCPResponseAFNode
{
	protected Object msg2sndobj(IMessage msg) throws Exception
	{
		int delay = (Integer) AppConfig.getInstance().getProperty(Config.SHIELD_DELAY, -1);
		if (delay > 0)
		{
			log.info("start to sleep " + delay + " ms!!!");
			Thread.sleep(delay);
		}
		SocketMessage smsg = (SocketMessage) msg
				.getInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_SOCKETMSG);
		if (fixmsg != null)
		{ // ���ع̶����ݣ����ڽ������
			smsg.repmsg = fixmsg;
			return smsg;
		}

		Map shields = AppConfig.isProductMode() ? this.shields : loadShields(); // ������ģʽÿ�ζ���������
		byte[] response = (byte[]) shields.get(smsg.localPort + "." + smsg.reqmsg.length);

		// ����Χƥ��
		Iterator keys = shields.keySet().iterator();
		while (keys.hasNext())
		{
			String key = keys.next().toString();
			if (key.indexOf('-') > 0 && key.startsWith(smsg.localPort + "."))
			{
				int idx1 = key.indexOf('.');
				int idx2 = key.indexOf('-');
				int l1 = Integer.parseInt(key.substring(idx1 + 1, idx2));
				int l2 = Integer.parseInt(key.substring(idx2 + 1));
				if (smsg.reqmsg.length >= l1 && smsg.reqmsg.length <= l2)
				{
					response = (byte[]) shields.get(key);
					break;
				}
			}
		}

		if (response == null) response = (byte[]) shields.get(String.valueOf(smsg.reqmsg.length));
		if (log.isInfoEnabled()) log.info("request len:" + smsg.reqmsg.length + ", response len:"
				+ (response == null ? 0 : response.length) + ", local port:" + smsg.localPort);
		Endpoint endpoint = (Endpoint) shields.get("e" + smsg.localPort);
		if (endpoint != null)
		{ // ���õ�������
			Executable exe = new Executable();
			exe.request = response;
			exe.withoutReturn = true;
			endpoint.execute(exe);
			return null;
		}

		smsg.repmsg = response;
		return smsg;
	}

	public void init() throws Exception
	{
		if (AppConfig.isProductMode()) shields = loadShields();
	}

	protected Map loadShields() throws Exception
	{
		Map shields = new HashMap();
		if (StringX.nullity(location)) return shields;
		Properties p = new Properties();
		p.load(SystemUtil.getInstance().getResourceLoader().getResource(location).getInputStream());
		java.util.Enumeration<Object> keys = p.keys();
		while (keys.hasMoreElements())
		{
			String key = keys.nextElement().toString().toLowerCase();
			String value = p.getProperty(key);
			if (StringX.nullity(value)) continue;
			if (key.startsWith("b")) shields.put(key.substring(1), StringX.decodeBase64(value)); // base64
			else if (key.startsWith("h")) shields.put(key.substring(1), StringX.hex2byte(value)); // hex
			else if (key.startsWith("u")) shields.put(key.substring(1),
					value.getBytes(Common.CHARSET_UTF8)); // utf8
			else if (key.startsWith("e")) shields.put(key, EndpointFactory.getInstance()
					.getEndpoint(value)); // simplex endpoint
		}
		if (log.isInfoEnabled()) log.info("shields:" + shields.keySet());
		return shields;
	}

	protected byte[] fixmsg; // ���ع̶������ݣ�����F5�ȵĽ������
	protected String location;
	protected Map shields = new HashMap();

	public void setLocation(String location)
	{
		this.location = location;
	}

	public void setFixmsg(byte[] fixmsg)
	{
		this.fixmsg = fixmsg;
	}

	public void setFixmsg(String fixmsg)
	{
		this.fixmsg = StringX.decodeBase64(fixmsg);
	}
}
