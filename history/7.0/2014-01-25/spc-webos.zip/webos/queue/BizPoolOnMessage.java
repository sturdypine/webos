package spc.webos.queue;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import spc.webos.log.Log;
import spc.webos.util.StringX;

/**
 * ��������������MQ��ȡ�̡߳����ɴ�����ҵ���̳߳ؽ��д���
 * 
 * @author chenjs
 * 
 */
public class BizPoolOnMessage implements IOnMessage
{
	protected Log log = Log.getLogger(getClass());
	protected ExecutorService bizpool;
	protected IOnMessage onMessage;

	public BizPoolOnMessage(int size, IOnMessage onMessage)
	{
		bizpool = Executors.newFixedThreadPool(size);
		this.onMessage = onMessage;
	}

	public BizPoolOnMessage()
	{
	}

	public void onMessage(Object obj, AccessTPool pool, AbstractReceiverThread thread)
			throws Exception
	{
		log.debug("add OnMessage thread...");
		bizpool.execute(new BizThread(this, obj, pool, thread));
	}

	public void init() throws Exception
	{
	}

	public void destroy()
	{
		log.warn("destroy thread pool, isShutdown:" + bizpool.isShutdown());
		if (!bizpool.isShutdown()) bizpool.shutdown();
	}

	public void setOnMessage(IOnMessage onMessage)
	{
		this.onMessage = onMessage;
	}

	public void setPoolSize(int size)
	{
		bizpool = Executors.newFixedThreadPool(size);
	}
}

class BizThread implements Runnable
{
	BizPoolOnMessage bizPoolOnMessage;
	Object obj;
	AccessTPool pool;
	AbstractReceiverThread thread;

	public BizThread(BizPoolOnMessage bizPoolOnMessage, Object obj, AccessTPool pool,
			AbstractReceiverThread thread)
	{
		this.bizPoolOnMessage = bizPoolOnMessage;
		this.obj = obj;
		this.pool = pool;
		this.thread = thread;
	}

	public void run()
	{
		Log log = bizPoolOnMessage.log;
		if (!StringX.nullity(pool.getLogName())) Log.start(pool.getLogName());
		long start = System.currentTimeMillis();
		String str = "OnMessage thread(" + Thread.currentThread().getName() + ","
				+ thread.getName();
		try
		{
			if (log.isDebugEnabled()) log.debug(str + ") start...");
			bizPoolOnMessage.onMessage.onMessage(obj, pool, thread);
			log.info(str + ") over, cost:" + (System.currentTimeMillis() - start));
		}
		catch (Throwable t)
		{
			log.warn(str + ") fail:", t);
		}
		finally
		{
			Log.print();
		}
	}
}