package spc.webos.queue.ibmmq;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import spc.webos.endpoint.ESB;
import spc.webos.queue.AbstractCnnPool;
import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;

import com.ibm.mq.MQC;

public class MQCnnPool extends AbstractCnnPool
{
	public MQCnnPool()
	{
		this.autoIncrease = true;
	}

	public MQCnnPool(int max, Hashtable props)
	{
		this.max = max;
		this.props = props;
		this.autoIncrease = true;
	}

	public MQCnnPool(int max, Hashtable props, int cnnHoldTime)
	{
		this.max = max;
		this.props = props;
		this.cnnHoldTime = cnnHoldTime;
		this.autoIncrease = true;
	}

	public MQCnnPool(int max, Hashtable props, int cnnHoldTime, int cnnIdleTime)
	{
		this.max = max;
		this.props = props;
		this.cnnHoldTime = cnnHoldTime;
		this.cnnIdleTime = cnnIdleTime;
		this.autoIncrease = true;
	}

	public MQCnnPool(int max, Hashtable props, int cnnHoldTime, int cnnIdleTime,
			boolean autoIncrease)
	{
		this.max = max;
		this.props = props;
		this.cnnHoldTime = cnnHoldTime;
		this.cnnIdleTime = cnnIdleTime;
		this.autoIncrease = autoIncrease;
	}

	public MQCnnPool(int max, Hashtable props, int cnnHoldTime, int cnnIdleTime,
			boolean autoIncrease, long waitTime)
	{
		this.max = max;
		this.props = props;
		this.cnnHoldTime = cnnHoldTime;
		this.cnnIdleTime = cnnIdleTime;
		this.autoIncrease = autoIncrease;
		this.waitTime = waitTime;
	}

	public void init() throws Exception
	{
		Object ccsid = props.get(MQC.CCSID_PROPERTY);
		if (ccsid instanceof String) props.put(MQC.CCSID_PROPERTY, new Integer((String) ccsid));
		Object port = props.get(MQC.PORT_PROPERTY);
		if (port instanceof String) props.put(MQC.PORT_PROPERTY, new Integer((String) port));
		// 2012-08-15 ���û���ṩͨ����ʹ��ϵͳĬ��ͨ��
		if (!props.containsKey(MQC.CHANNEL_PROPERTY)) props.put(MQC.CHANNEL_PROPERTY,
				MQManager.SYS_DEF_CHL);

		// 2012-07-29 ���û���ṩͨ����ʹ��ϵͳĬ��ͨ��
		if (!props.containsKey(MQC.CHANNEL_PROPERTY)) props.put(MQC.CHANNEL_PROPERTY,
				MQManager.SYS_DEF_CHL);
		// 2012-10-28 ʹ�ô����Կ��Ա�֤ÿ��MQ����ʹ�õ�����socket���ӣ����ǹ����ײ�����
		if (!props.containsKey(MQC.SHARING_CONVERSATIONS_PROPERTY)) props.put(
				MQC.SHARING_CONVERSATIONS_PROPERTY, 1);

		try
		{ // added by chenjs 2011-12-28 ����MQ����ʧ�����쳣��ʽ��ӡ��־����Ӱ������
			super.init();
		}
		catch (Exception e)
		{
			log.error("MQCnnPool init: " + props, e);
		}
	}

	public Object newIntance()
	{ // modified by spc 2010-08-18, �޸����ӳص����ӣ���ÿ�����Ӿ��г�ʱʱ��
		// return Accessor.connect(null, props, 1);
		if (log.isInfoEnabled()) log.info("new mqm: " + props + ", keepQueue: " + keepQueue);
		MQManager qm = new MQManager(props, cnnHoldTime, cnnIdleTime, keepQueue);
		qm.connect(1);
		return qm;
		// return new MQManager(Accessor.connect(null, props, 0), props,
		// cnnHoldTime, cnnIdleTime,
		// keepQueue);
	}

	public boolean release(Object obj)
	{
		MQManager mq = (MQManager) obj;
		if (!super.release(mq)) mq.disconnect();
		return true;
	}

	public synchronized void destory()
	{
		if (log.isInfoEnabled()) log.info("destroy MQ pool(" + name + ") : " + pool.size());
		for (int i = 0; i < pool.size(); i++)
			((MQManager) pool.get(i)).disconnect();
		pool.clear();
	}

	public static MQCnnPool createChl(String chl) throws Exception
	{
		return createChl((Map) JsonUtil.json2obj(chl));
	}

	public static MQCnnPool createChl(Map channel) throws Exception
	{
		MQCnnPool cnnpool = new MQCnnPool();
		String maxCnnNum = StringX.null2emptystr(channel.get(ESB.MAXCNN_KEY));
		String cnnHoldTime = StringX.null2emptystr(channel.get(ESB.CNNHOLDTIME_KEY));
		String cnnIdleTime = StringX.null2emptystr(channel.get(ESB.CNNIDLETIME_KEY));
		String keepQueue = StringX.null2emptystr(channel.get(ESB.KEEPQUEUE_KEY));
		String name = StringX.null2emptystr(channel.get("name"));
		if (!StringX.nullity(name)) cnnpool.setName(name);

		if (!StringX.nullity(maxCnnNum)) cnnpool.setMax(Integer.parseInt(maxCnnNum));
		else cnnpool.setMax(1);
		if (!StringX.nullity(cnnHoldTime)) cnnpool.setCnnHoldTime(Integer.parseInt(cnnHoldTime));
		if (!StringX.nullity(cnnIdleTime)) cnnpool.setCnnIdleTime(Integer.parseInt(cnnIdleTime));
		if (!StringX.nullity(keepQueue)) cnnpool.setKeepQueue(Boolean.TRUE.toString()
				.equalsIgnoreCase(keepQueue));

		cnnpool.setProps(new Hashtable((Map) channel.get("channel")));
		cnnpool.setBorrowOnInit(false);
		cnnpool.init();
		return cnnpool;

	}

	public static List<MQCnnPool> createChlList(String chl) throws Exception
	{
		List channels = (List) JsonUtil.json2obj(chl);
		List<MQCnnPool> cnnpools = new ArrayList<MQCnnPool>();
		for (int i = 0; i < channels.size(); i++)
			cnnpools.add(createChl((Map) channels.get(i)));
		return cnnpools;
	}
}
