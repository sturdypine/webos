package spc.webos.web.controller;

import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;

public class ExtComboCtrller extends ExtGridCtrller
{
	protected void handleTable(Collection data, Object totalSize, HttpServletRequest request,
			HttpServletResponse response) throws Exception
	{
		response.getOutputStream().write(StringX.str2utf8(JsonUtil.obj2json(data)).getBytes());
	}
}
