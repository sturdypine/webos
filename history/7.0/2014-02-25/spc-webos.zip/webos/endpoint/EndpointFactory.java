package spc.webos.endpoint;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import spc.webos.log.Log;
import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;

/**
 * ������Դ�����, ��̬����endpoint���͡�����tcp://192.168.0.01:8080,
 * http://192.168.0.01:8080/FA/ws. Ŀǰֻ֧��tcp/httpЭ��
 * 
 * @author chenjs
 * 
 */
public class EndpointFactory
{
	public Endpoint getEndpoint(String location) throws Exception
	{
		if (StringX.nullity(location)) return null;
		location = StringX.trim(location);
		String[] locs = location.split(",|;");
		if (locs.length > 1)
		{ // ˵���Ǽ�Ⱥģʽ
			List endpoints = new ArrayList();
			for (int i = 0; i < locs.length; i++)
			{
				Endpoint endpoint = getEndpoint(locs[i]);
				if (endpoint != null) endpoints.add(endpoint);
			}
			if (endpoints.size() == 0) return null;
			if (endpoints.size() == 1) return (Endpoint) endpoints.get(0);
			return new ClusterEndpoint(endpoints);
		}
		int idx = location.indexOf(":");
		String protocol = location.substring(0, idx).toLowerCase();
		if (protocol.equals("tcp"))
		{ // is a tcp protocol
			TCPEndpoint endpoint = new TCPEndpoint(location);
			endpoint.init();
			return endpoint;
		}
		if (protocol.equals("atcp")) return new AsynTCPEndpoint(location);
		if (protocol.equals("http")) return new HttpEndpoint(location);
		if (protocol.equals("udp"))
		{
			UDPEndpoint endpoint = new UDPEndpoint(location);
			endpoint.init();
			return endpoint;
		}
		if (protocol.equals("class"))
		{ // ʹ���Զ��������
			int index = location.indexOf(':', 8);
			String strClass = location.substring(6, index);
			String loc = location.substring(index + 1);
			Endpoint endpoint = (Endpoint) Class.forName(strClass).newInstance();
			endpoint.setLocation(loc);
			endpoint.init();
			return endpoint;
		}
		if (protocol.equals("esb"))
		{ // 2012-10-24 ����YC.ESBЭ��
			ESB esb = new ESB();
			esb.init((Map) JsonUtil.json2obj(location.substring(location.indexOf('{'))));
			return esb;
		}
		if (protocol.equals("cics"))
		{
			CICSEndpoint cics = new CICSEndpoint();
			cics.setLocation(location);
			cics.init();
			return cics;
		}

		log.warn("undefined protocal: " + location);
		return null;
	}

	static EndpointFactory factory = new EndpointFactory();

	public static EndpointFactory getInstance()
	{
		return factory;
	}

	protected Log log = Log.getLogger(EndpointFactory.class);
}
