package spc.webos.endpoint;

import spc.webos.data.IMessage;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.exception.AppException;
import spc.webos.flownode.MessageFlow;
import spc.webos.util.SystemUtil;

public class DefaultTCPCallback implements ITCPCallback
{
	protected MessageFlow msgflow;
	protected IMessage msg;
	protected IMessageConverter converter;

	public DefaultTCPCallback(IMessage msg, MessageFlow msgflow, IMessageConverter converter)
	{
		this.msg = msg;
		this.msgflow = msgflow;
		this.converter = converter;
	}

	public void response(Executable exe, AsynTCPEndpoint endpoint, String ip, int port)
			throws Throwable
	{
		IMessage repmsg = converter.deserialize(exe.getResponse(), msg);
		if (repmsg != msg)
		{
			msg.setTransaction(repmsg.getTransaction());
			msg.getLocal().putAll(repmsg.getLocal());
		}
		if (msgflow != null) msgflow.execute(msg);
	}

	public void fail(Executable exe, AsynTCPEndpoint endpoint, String ip, int port,
			AppException appEx) throws Throwable
	{
		IMessage repmsg = converter.deserialize(exe.getResponse(), msg);
		if (repmsg != msg)
		{
			msg.setTransaction(repmsg.getTransaction());
			msg.getLocal().putAll(repmsg.getLocal());
		}
		msg.setStatus(SystemUtil.ex2status(msg.getFixedErrDesc(), appEx));
		if (msgflow != null) msgflow.execute(msg);
	}
}
