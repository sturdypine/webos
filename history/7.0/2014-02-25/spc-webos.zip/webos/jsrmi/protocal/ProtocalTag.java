package spc.webos.jsrmi.protocal;

public interface ProtocalTag {

	public static final String TAG_BOOLEAN = "b";
	public static final String TAG_DATE = "D";
	public static final String TAG_INT = "i";
	public static final String TAG_LONG = "L";
	public static final String TAG_NULL = "null";
	public static final String TAG_STRING = "s";
	public static final String TAG_LENGTH = "length";
	public static final String TAG_TYPE = "t";
	public static final String TAG_LIST = "l";
	public static final String TAG_MAP = "m";
	public static final String TAG_DOUBLE = "d";
	public static final String TAG_REPLY = "res";
	public static final String TAG_REF = "r";
	public static final String TAG_CALL = "req";
	public static final String TAG_FAULT = "fault";
	public static final String TAG_METHOD = "M";
	
}
