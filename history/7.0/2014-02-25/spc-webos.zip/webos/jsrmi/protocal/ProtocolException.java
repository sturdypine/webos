
package spc.webos.jsrmi.protocal;

public class ProtocolException extends RuntimeException {

	private static final long serialVersionUID = 4532061712982896057L;

	public ProtocolException() {
		super();
	}

	public ProtocolException(String message, Throwable cause) {
		super(message, cause);
	}

	public ProtocolException(String message) {
		super(message);
	}

	public ProtocolException(Throwable cause) {
		super(cause);
	}
	
}
