package spc.webos.jsrmi.service;

import java.io.InputStream;
import java.io.Writer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;

import spc.webos.config.AppConfig;
import spc.webos.jsrmi.request.RequestContext;
import spc.webos.log.Log;
import spc.webos.model.JsrmiLogVO;
import spc.webos.persistence.IPersistence;
import spc.webos.web.common.ISessionUserInfo;

/**
 * ����aop��ʽ��¼jsrmi����־
 * 
 * @author sturdypine.chen
 * 
 */
public class JsrmiLoggerAdvice implements MethodInterceptor
{
	// static ClassObjectPool sqlPool = new ClassObjectPool(StringBuffer.class);
	static PathMatcher pathMatcher = new AntPathMatcher();
	static Map methodMap;
	Map methodCacheMap = new HashMap();
	static final int REQ_LOG = 1;
	static final int RES_LOG = 2;
	static Log log = Log.getLogger(JsrmiLoggerAdvice.class);

	public Object invoke(MethodInvocation mi) throws Throwable
	{
		if (methodMap == null) methodMap = (Map) AppConfig.getInstance().getProperty("jsrmi",
				"log", null);
		if (methodMap == null) { return mi.proceed(); }
		HttpServletRequest req = RequestContext.getContext().getHttpRequest();
		String pathInfo = req.getPathInfo();
		char delim = '/';
		int end = pathInfo.indexOf(delim, 1);
		// System.out.println("advice.pathInfo.s=" + end + "," + pathInfo);
		if (end > 0 && end < pathInfo.length()) end = pathInfo.indexOf(delim, end + 1);
		// System.out.println("advice.pathInfo.s=" + end + "," + pathInfo);
		if (end < 0 || end > pathInfo.length()) end = pathInfo.length();

		pathInfo = pathInfo.substring(1, end);
		// System.out.println("advice.pathInfo=" + pathInfo);
		int logType = getLogType(pathInfo);
		// System.out.println(pathInfo + "," + logType);
		if (0 == logType) { return mi.proceed(); }

		JsrmiLogVO jsrmiLogVO = new JsrmiLogVO();
		jsrmiLogVO.setIp(req.getRemoteAddr());
		jsrmiLogVO.setUri(pathInfo);
		long cur = System.currentTimeMillis();
		jsrmiLogVO.setStartTime(new Long(cur));
		Date curDt = new Date(cur);
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		DateFormat dfTime = new SimpleDateFormat("HHmmss");
		jsrmiLogVO.setDt(new Integer(df.format(curDt)));
		jsrmiLogVO.setTime(new Integer(dfTime.format(curDt)));

		// System.out.println("JsrmiLoggerAdvice..."+pathInfo);
		Object[] args = mi.getArguments();
		StringBuffer buf1 = null, buf2 = null;
		if ((logType & REQ_LOG) > 0)
		{
			buf1 = new StringBuffer();
			buf1.setLength(0);
			args[1] = new JsrmiInputStream((InputStream) args[1], buf1);
		}
		if ((logType & RES_LOG) > 0)
		{
			buf2 = new StringBuffer();
			buf2.setLength(0);
			args[2] = new JsrmiWriter((Writer) args[2], buf2);
		}
		Object ret = null;
		ret = mi.getMethod().invoke(mi.getThis(), mi.getArguments());
		if ((logType & REQ_LOG) > 0) jsrmiLogVO.setReq(((JsrmiInputStream) args[1]).getContent()
				.toString());
		if ((logType & RES_LOG) > 0) jsrmiLogVO.setRes(((JsrmiWriter) args[2]).getContent()
				.toString());
		try
		{

			jsrmiLogVO.setEndTime(new Long(System.currentTimeMillis()));
			ISessionUserInfo sui = (ISessionUserInfo) ISessionUserInfo.SUI.get();
			if (sui != null) jsrmiLogVO.setUserCode(sui.getUserCode());
			// System.out.println(jsrmiLogVO);
			persistence.insert(jsrmiLogVO);
		}
		catch (Exception e)
		{
			log.error("JsrmiLoggerAdvice.invoke", e);
		}

		// System.out.println(((JsrmiInputStream)args[1]).getContent());
		// System.out.println(((JsrmiWriter)args[2]).getContent());
		// Object ret = mi.proceed();
		return ret;
	}

	// public int getLogType(String pathInfo)
	// {
	// Iterator keys = methodMap.keySet().iterator();
	// while (keys.hasNext())
	// {
	// String key = (String) keys.next();
	// // System.out.println(key+","+ pathInfo.toLowerCase());
	// // System.out.println(pathMatcher.match("/loginservice/*",
	// // pathInfo.toLowerCase()));
	// if (pathMatcher.match(key, pathInfo.toLowerCase())) return ((Integer)
	// methodMap
	// .get(key)).intValue();
	// }
	// return 0;
	// }

	public synchronized int getLogType(String pathInfo)
	{
		Integer type = (Integer) methodCacheMap.get(pathInfo);
		if (type != null) return type.intValue();
		int maxLen = 0;
		Iterator keys = methodMap.keySet().iterator();
		while (keys.hasNext())
		{
			String key = (String) keys.next();
			if (pathMatcher.match(key, pathInfo.toLowerCase()))
			{
				if (key.length() > maxLen)
				{
					type = ((Integer) methodMap.get(key));
					maxLen = key.length();
				}
			}
		}
		if (type == null) type = new Integer(0);
		methodCacheMap.put(pathInfo, type);
		return type.intValue();
	}

	IPersistence persistence;

	public void setPersistence(IPersistence persistence)
	{
		this.persistence = persistence;
	}
}
