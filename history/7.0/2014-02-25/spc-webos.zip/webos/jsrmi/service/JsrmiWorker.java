package spc.webos.jsrmi.service;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.io.Writer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import spc.webos.log.Log;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import spc.webos.jsrmi.request.AbstractRequestWorker;
import spc.webos.jsrmi.request.RequestContext;
import spc.webos.jsrmi.request.RequestWorker;
import spc.webos.jsrmi.request.ValidationException;
import spc.webos.jsrmi.service.invoker.ServiceInvoker;

public class JsrmiWorker extends AbstractRequestWorker implements RequestWorker
{
	static ServiceInvoker serviceInvoker;
	private static final Log LOGGER = Log.getLogger(JsrmiWorker.class);

	public void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws IOException
	{
		LOGGER.debug("invoking jsrmi worker");

		String requestService = getWorkerRelativePath();
		ServiceRepository repository = ServiceRepositoryUtil
				.getServiceRepository(RequestContext.getContext()
						.getServletContext());
		Object service = repository.get(requestService);
//		System.out.println(requestService+":"+service.getClass().getName());
		response.setHeader("content-type", "text/xml;charset=utf-8");
		InputStream is = request.getInputStream();
		Writer w = response.getWriter();
		try
		{
			if (serviceInvoker == null)
			{
				ApplicationContext cxt = WebApplicationContextUtils
						.getWebApplicationContext(RequestContext.getContext()
								.getServletContext());
				serviceInvoker = (ServiceInvoker) cxt.getBean("jsrmiInvoker");
			}
			serviceInvoker.invoke(service, is, w);
		}
		catch (Throwable ex)
		{
			LOGGER.error("An exception occured when invoking a service: ", ex);
			StringWriter writer = new StringWriter();
			writer.write(ex.toString());
			// System.out.println(ex);
			// ex.printStackTrace(new PrintWriter(writer));
			// StringBuffer faultString = new StringBuffer();
			// faultString.append("An exception occured when invoking a service.
			// \n");
			// faultString.append(writer.toString());
//			ex.printStackTrace();
//			LOGGER.error("", ex);
			throw new ServiceInvocationException(writer.toString(), ex);
		}
//		System.out.println(requestService+"  over..");
	}

	public void validate() throws ValidationException
	{
		if (!RequestContext.getContext().getHttpRequest().getMethod().equals(
				"POST")) { throw new ValidationException(
				"Buffalo worker support POST only!"); }
	}

	public void validate(HttpServletRequest request,
			HttpServletResponse response) throws ValidationException
	{
		if (!request.getMethod().equals("POST")) { throw new ValidationException(
				"Buffalo worker support POST only!"); }
	}

}
