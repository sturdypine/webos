package spc.webos.jsrmi.service;

public interface ServiceRepository {
	
	/**
	 * The default service properties file location
	 */
	public static final String DEFAULT_SERVICES = "/buffalo-service.properties";
	
	/**
	 * The key for servlet context
	 */
	public static final String WEB_CONTEXT_KEY =  ServiceRepository.class + "_WEB_KEY";
	
	/**
	 * Register a service to repository
	 * 
	 * @param serviceId the service key
	 * @param serviceName the service name
	 * @param factoryId the factory id
	 */
	public void register(String serviceId, String serviceName , String factoryId);
	
	/**
	 * Get the service instance from repository
	 * @param serviceId the service key
	 * @return service instance
	 */
	public Object get(String serviceId);
	
}
