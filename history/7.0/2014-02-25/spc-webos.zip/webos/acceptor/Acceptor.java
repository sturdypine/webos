package spc.webos.acceptor;

import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Map;

import spc.webos.buffer.IBuffer;
import spc.webos.config.AppConfig;
import spc.webos.constant.Config;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.flownode.MessageFlow;
import spc.webos.thread.DaemonThread;
import spc.webos.util.StringX;
import spc.webos.util.bytes.DefaultHeadLength;

public abstract class Acceptor extends DaemonThread
{
	protected boolean f5; // ��F5�������ʱ�������־
	protected boolean longCnn; // �Ƿ�֧�ֿͻ��˳�����
	private boolean trace; // 700 ��info��־������ٵײ����緢���ֽ���Ϣ
	protected IMessageConverter converter;
	protected int port;
	protected boolean simplex; // �첽����ʱ�Ƿ���Ҫ����Ӧ���ģ���Ϊ���������ǵ���ģʽ,simplex
	protected String logScript; // �߳���־�ű�, ���ڱ���ʽ�ж�
	protected String logName; // ��־��
	protected LinkedList handlers = new LinkedList(); // ������ǰ���ӵ��߳�

	// protected int hdrLen = 8;
	// protected boolean containHdrLenSelf; // 2012-11-26 chenjs ��Щģʽ����ͷ��Ϣ�������ȱ���
	// protected boolean hdrLenBinary = false; // ���ȱ�ʾΪ������, Ĭ����ASC��
	// protected boolean len2bcd;
	protected DefaultHeadLength dhl = new DefaultHeadLength();

	protected IBuffer reqbuf; // ����buffer
	protected IBuffer repbuf; // Ӧ��buffer
	protected MessageFlow msgFlow; // ָ���������ĵ���Ϣ��
	protected boolean endFlag;
	protected ISecurity security;
	protected int maxbytes;
	protected byte endFlagChar = '\0';
	protected boolean endFlagOpen; // 2013-12-10 ʹ��cnn��open״̬�ж�������
	protected boolean http = false; // �Ƿ�ʹ��HTTP����
	protected Map defRepHttpHdrParams;
	public static final Map ACCEPTORS = new Hashtable(); // ������HashMap����Ϊ�����ӣ�Ҳ��ɾ��

	// 2012-12-12 chenjs ������ͷ���ȵĴ������뵽Acceptor��
	public int length(byte[] lenBytes)
	{
		return dhl.length(lenBytes);

		// added by chenjs 2011-06-25 ֧�����붨��ͷ�ĳ�����ϢΪ������ģʽ
		// modified by chenjs 2012-11-25 ����containHdrLenSelf�����ж�
		// if (isHdrLenBinary()) return NumberX.bytes2int(lenBytes)
		// - (isContainHdrLenSelf() ? getHdrLen() : 0);
		// return new Integer(isLen2bcd() ? EBCDUtil.bcd2gbk(lenBytes) : new
		// String(lenBytes).trim())
		// .intValue() - (isContainHdrLenSelf() ? getHdrLen() : 0);
	}

	public synchronized void addHandler(DaemonThread handler)
	{
		handlers.add(handler);
	}

	public synchronized void removeHandler(DaemonThread handler)
	{
		handlers.remove(handler);
	}

	// ǿ����ֹ��ص����д����߳�
	public void interruptAll()
	{
		if (handlers == null || handlers.size() == 0) return;
		for (int i = 0; i < handlers.size(); i++)
		{
			try
			{
				DaemonThread t = (DaemonThread) handlers.get(i);
				log.warn("start to interrupt thread " + t.getName());
				t.interrupt();
			}
			catch (Exception e)
			{
			}
		}
	}

	public void init() throws Exception
	{
		super.init();
		if (StringX.nullity(getName())) setName("TCP." + port);
		if (ACCEPTORS.containsKey(getName())) log.warn("ACCEPTOR(" + getName()
				+ ") has been exist!!!" + ACCEPTORS.keySet());
		ACCEPTORS.put(getName(), this);
	}

	public int getPort()
	{
		return port;
	}

	public void setPort(int port)
	{
		this.port = port;
	}

	public boolean simplex()
	{
		return simplex;
	}

	public IMessageConverter getConverter()
	{
		return converter;
	}

	public void setConverter(IMessageConverter converter)
	{
		this.converter = converter;
	}

	public void setSimplex(boolean simplex)
	{
		this.simplex = simplex;
	}

	public String getLogScript()
	{
		return logScript;
	}

	public void setLogScript(String logScript)
	{
		this.logScript = logScript;
	}

	public String getLogName()
	{
		return logName;
	}

	public void setLogName(String logName)
	{
		this.logName = logName;
	}

	public LinkedList getHandlers()
	{
		return handlers;
	}

	public ISecurity getSecurity()
	{
		return security;
	}

	public void setSecurity(ISecurity security)
	{
		this.security = security;
	}

	public int getHdrLen()
	{
		return dhl.hdrLen;
	}

	public void setHdrLen(int hdrLen)
	{
		dhl.hdrLen = hdrLen;
	}

	public IBuffer getReqbuf()
	{
		return reqbuf;
	}

	public void setReqbuf(IBuffer reqbuf)
	{
		this.reqbuf = reqbuf;
	}

	public IBuffer getRepbuf()
	{
		return repbuf;
	}

	public void setRepbuf(IBuffer repbuf)
	{
		this.repbuf = repbuf;
	}

	public MessageFlow getMsgFlow()
	{
		return msgFlow;
	}

	public void setMsgFlow(MessageFlow msgFlow)
	{
		this.msgFlow = msgFlow;
	}

	public boolean isEndFlag()
	{
		return endFlag;
	}

	public void setEndFlag(boolean endFlag)
	{
		this.endFlag = endFlag;
	}

	public boolean isSimplex()
	{
		return simplex;
	}

	public boolean isLen2bcd()
	{
		return dhl.len2bcd;
	}

	public void setLen2bcd(boolean len2bcd)
	{
		dhl.len2bcd = len2bcd;
	}

	public boolean isHdrLenBinary()
	{
		return dhl.hdrLenBinary;
	}

	public void setHdrLenBinary(boolean hdrLenBinary)
	{
		dhl.hdrLenBinary = hdrLenBinary;
	}

	public void setMaxbytes(int maxbytes)
	{
		this.maxbytes = maxbytes;
	}

	public byte getEndFlagChar()
	{
		return endFlagChar;
	}

	public void setEndFlagChar(byte endFlagChar)
	{
		this.endFlagChar = endFlagChar;
	}

	public void setEndFlagChar(int endFlagChar)
	{
		this.endFlagChar = (byte) endFlagChar;
	}

	public int getMaxbytes()
	{
		return maxbytes;
	}

	public boolean isContainHdrLenSelf()
	{
		return dhl.containHdrLenSelf;
	}

	public void setContainHdrLenSelf(boolean containHdrLenSelf)
	{
		dhl.containHdrLenSelf = containHdrLenSelf;
	}

	public boolean isHttp()
	{
		return http;
	}

	public void setHttp(boolean http)
	{
		this.http = http;
	}

	public void setDefRepHttpHdrParams(Map defRepHttpHdrParams)
	{
		this.defRepHttpHdrParams = defRepHttpHdrParams;
	}

	public Map getDefRepHttpHdrParams()
	{
		return defRepHttpHdrParams;
	}

	public DefaultHeadLength getDhl()
	{
		return dhl;
	}

	public void setDhl(DefaultHeadLength dhl)
	{
		this.dhl = dhl;
	}

	public boolean isTrace(int port)
	{
		if (trace || (Boolean) AppConfig.getInstance().getProperty(Config.TCP_TRACE, Boolean.FALSE)) return true;
		return (Boolean) AppConfig.getInstance().getProperty(Config.TCP_TRACE + "_" + port,
				Boolean.FALSE);
	}

	public void setTrace(boolean trace)
	{
		this.trace = trace;
	}

	public boolean isEndFlagOpen()
	{
		return endFlagOpen;
	}

	public void setEndFlagOpen(boolean endFlagOpen)
	{
		this.endFlagOpen = endFlagOpen;
	}

	public boolean isF5()
	{
		return f5;
	}

	public void setF5(boolean f5)
	{
		this.f5 = f5;
	}

	public boolean isLongCnn()
	{
		return longCnn;
	}

	public void setLongCnn(boolean longCnn)
	{
		this.longCnn = longCnn;
	}
}
