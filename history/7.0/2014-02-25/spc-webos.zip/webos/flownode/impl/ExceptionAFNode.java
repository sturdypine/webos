package spc.webos.flownode.impl;

import spc.webos.data.IMessage;
import spc.webos.data.validator.MessageErrors;
import spc.webos.exception.AppException;
import spc.webos.exception.MsgErrException;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.SystemUtil;

/**
 * �쳣�����ڵ㣬����ǰ������ִ�е��쳣���д���
 * 
 * @author spc
 * 
 */
public class ExceptionAFNode extends AbstractFNode
{
	static ExceptionAFNode exFNode = new ExceptionAFNode();
	protected boolean logex; // �Ƿ�����쳣

	public ExceptionAFNode()
	{
	}

	public static ExceptionAFNode getInstance()
	{
		return exFNode;
	}

	public Object execute(IMessage msg, IFlowContext cxt)
	{
		setEx(msg, msg.getEx());
		return null;
	}

	public void setEx(IMessage msg, Throwable t)
	{
		if (logex) log.warn("logex", t);
		msg.setStatus(SystemUtil.ex2status(msg.getFixedErrDesc(), t));
		if (t instanceof MsgErrException)
		{ // ����쳣Ϊ���Ĵ������ͣ� ��Ѵ�����Ϣ���뵽Ӧ������
			MsgErrException msgerr = (MsgErrException) t;
			MessageErrors errors = msgerr.getErrors();
			if (errors.getErrorCount() > 0) msg.setResponse(errors.toCNode());
		}
		else if (!logex && !(t instanceof AppException)) log.warn("undefined ex:", t);
	}

	public void setLogex(boolean logex)
	{
		this.logex = logex;
	}
}
