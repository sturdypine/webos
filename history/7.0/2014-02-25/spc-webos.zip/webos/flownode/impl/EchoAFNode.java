package spc.webos.flownode.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.data.Status;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.SystemUtil;

public class EchoAFNode extends AbstractFNode
{
	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		msg.setInResponse("echo", "this is echo info from server");
		msg.setInResponse(Status.IP(), SystemUtil.LOCAL_HOST_IP);
		msg.setInResponse(Status.APPCD(), SystemUtil.APP);
		msg.setInResponse(Status.NODE(), SystemUtil.NODE);
		msg.setInResponse("jvm", SystemUtil.JVM);
		msg.setInResponse("echoTm", new SimpleDateFormat(SystemUtil.DF_ALL23).format(new Date()));

		return null;
	}
}
