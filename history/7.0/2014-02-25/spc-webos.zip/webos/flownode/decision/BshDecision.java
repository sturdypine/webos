package spc.webos.flownode.decision;

import spc.webos.cache.Map2Cache;
import spc.webos.data.IMessage;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.StringX;
import bsh.Interpreter;

public class BshDecision extends AbstractDecision
{
	private static final long serialVersionUID = 1L;

	public String decide(IMessage msg, IFlowContext cxt) throws Exception
	{
		Interpreter i = getInterpreter(bsh);
		synchronized (i)
		{ // 702_20140121��֤�̰߳�ȫ
			i.set("msg", msg);
			i.eval("String _transition = fun(msg);");
			String transition = StringX.trim((String) i.get("_transition"));
			if (log.isInfoEnabled()) log.info("transition:" + transition);
			return transition;
		}
	}

	protected String bsh;

	static Map2Cache interpreters = new Map2Cache(24 * 3600, 500);

	public static synchronized Interpreter getInterpreter(String script) throws Exception
	{
		Interpreter i = (Interpreter) interpreters.get(script);
		if (i != null) return i;
		i = new Interpreter();
		i.eval("import spc.webos.data.IMessage;String fun(IMessage msg){" + script + "}");
		interpreters.put(script, i);
		return i;
	}

	public String getBsh()
	{
		return bsh;
	}

	public void setBsh(String bsh)
	{
		this.bsh = StringX.removeBshAnnotation(bsh);
	}
}