package spc.webos.flownode.action;

import spc.webos.data.IMessage;
import spc.webos.flownode.IFlowContext;

/**
 * �첽���ýڵ��Ľ�������
 * 
 * @author spc
 * 
 */
public interface IAfterAsynCall
{
	void after(IMessage parent, IMessage msg, IFlowContext cxt) throws Exception;
}
