package spc.webos.flownode.action;

import spc.webos.config.AppConfig;
import spc.webos.constant.Config;
import spc.webos.constant.MsgKey;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.CompositeNode;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.data.Message;
import spc.webos.data.Status;
import spc.webos.flownode.IFlowContext;
import spc.webos.model.BPELNodeVO;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

public abstract class AbstractCreateMsgAsynCallAction extends TargetFNodeAction implements
		IAfterAsynCall
{
	private static final long serialVersionUID = 1L;

	protected void before(IMessage parent, IMessage submsg, IFlowContext cxt) throws Exception
	{
		BPELNodeVO nodeVO = new BPELNodeVO();
		submsg.getMsg().toObject(nodeVO);
		nodeVO.setNode(name);
		nodeVO.setMsgSn(submsg.getMsgSn());
		nodeVO.setRefMsgSn(parent.getMsgSn());
		nodeVO.setFailAbort(failAbort);
		nodeVO.setStatus(Status.STATUS_UNDERWAY);
		nodeVO.setTmStamp(SystemUtil.getInstance().getCurrentDate(SystemUtil.DF_SALL17));

		parent.setInLocal(MsgLocalKey.LOCAL_LAST_NODE, nodeVO);
	}

	public void after(IMessage parent, IMessage submsg, IFlowContext cxt) throws Exception
	{
	}

	protected IMessage newMessage(IMessage parent)
	{ // default new msg info...
		IMessage nsubmsg = new Message();
		nsubmsg.init();
		nsubmsg.setInLocal(MsgLocalKey.LOCAL_PARENT_MSG, parent);
		String dt = SystemUtil.getInstance().getCurrentDate(SystemUtil.DF_SALL17);
		String sn = (SystemUtil.JVM + SystemUtil.getTimeSN(8) + SystemUtil.random(7)).substring(0,
				15);
		// nsubmsg.setVersion(IMessage.HEADER_VERSION_1_0);
		String replyToQ = (String) AppConfig.getInstance().getProperty(Config.JBPM3_REPLYTOQ, null);
		if (StringX.nullity(replyToQ)) nsubmsg.setSndAppCd(appCd);
		else
		{ // 701_20140102 ��ʹ��jbpm3���ݷ����������ģ�����ʹ��ԭϵͳ����, ͨ��replyToQ����Ӧ����
			nsubmsg.setSndAppCd(parent.getSndApp());
			nsubmsg.setReplyToQ(replyToQ);
		}
		nsubmsg.setSndDt(dt.substring(0, 8));
		nsubmsg.setSndTm(dt.substring(8, 17));
		nsubmsg.setSeqNb(sn);
		nsubmsg.setCallType(IMessage.CALLTYP_ASYN);
		nsubmsg.setMsgCd(StringX.nullity(msgCd) ? name : msgCd);
		if (!StringX.nullity(SystemUtil.NODE)) nsubmsg.setSndNode(SystemUtil.NODE);

		// 2012-06-12 ����������Ϣ�����ӽ���ext/bpl��
		ICompositeNode bpl = new CompositeNode();
		bpl.set(MsgKey.BPL_PMSGSN, parent.getMsgSn());
		bpl.set(MsgKey.BPL_NODE_NAME, name);
		bpl.set(MsgKey.BPL_FAIL_ABORT, failAbort);
		bpl.set(MsgKey.BPL_PSNDAPPCD, parent.getSndApp());
		bpl.set(MsgKey.BPL_PSNDMBRCD, parent.getSndNode());
		nsubmsg.setInHeaderExt(MsgKey.EXT_BPL, bpl);

		return nsubmsg;
	}

	protected String failAbort = "0"; // �첽�ڵ�ʧ������ֹ����ִ��, chenjs
	// 2012-09-09���̽���Ĭ�ϲ��Զ����ƽڵ�ʧ��״̬
	protected String appCd = "JBPM3";
	protected String msgCd;

	public String getFailAbort()
	{
		return failAbort;
	}

	public void setFailAbort(String failAbort)
	{
		this.failAbort = failAbort;
	}

	public String getAppCd()
	{
		return appCd;
	}

	public void setAppCd(String appCd)
	{
		this.appCd = appCd;
	}

	public String getMsgCd()
	{
		return msgCd;
	}

	public void setMsgCd(String msgCd)
	{
		this.msgCd = msgCd;
	}
}
