package spc.webos.queue;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.core.io.ResourceLoader;
import org.springframework.util.ResourceUtils;

import spc.webos.constant.MsgLocalKey;
import spc.webos.data.BlobMsgHeader;
import spc.webos.data.IMessage;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.data.converter.XMLConverter2;
import spc.webos.log.Log;
import spc.webos.util.SystemUtil;

/**
 * ͨ������ͷ��ϵͳ�д���һ���ļ�������
 * 
 * @author spc
 * 
 */
public class DefaultBlobMessageCreator implements IBlobMessageCreator
{
	protected String baseDir = ResourceLoader.CLASSPATH_URL_PREFIX;
	protected String pathTemplate = "${msg.header.msg.sndDt}/${msg.header.msg.sndMbrCd?default('')}${msg.header.msg.sndAppCd}/${msg.header.msg.msgCd}/${msg.header.msg.seqNb}";
	protected IMessageConverter messageConverter = XMLConverter2.getInstance();
	protected Log log = Log.getLogger(getClass());

	public File create(BlobMsgHeader header, IMessage firstXML) throws Exception
	{
		if (log.isDebugEnabled()) log.debug(header.toCNode(null));
		ResourceLoader loader = SystemUtil.getInstance().getResourceLoader();
		File parent = loader != null ? new File(loader.getResource(baseDir).getFile(), getPath(
				header, firstXML)) : new File(ResourceUtils.getFile(baseDir), getPath(header,
				firstXML));
		if (!parent.exists()) parent.mkdirs();
		if (log.isInfoEnabled()) log.info("blob creator parent file: " + parent.getAbsolutePath());
		return parent;
	}

	public IMessage create(BlobMsgHeader header, List targetFiles) throws Exception
	{
		IMessage msg = header.toMessage();
		if (log.isDebugEnabled()) log.debug("blob xml: " + msg.toXml(true));
		msg.setInLocal(MsgLocalKey.BLOB_FILES, targetFiles);
		if (log.isInfoEnabled()) log.info("target files:" + targetFiles);
		return msg;
	}

	protected String getPath(BlobMsgHeader header, IMessage firstXML) throws Exception
	{
		IMessage msg = firstXML == null ? header.toMessage() : firstXML;
		msg.init();
		Map root = new HashMap();
		root.put("blobhdr", header);
		return SystemUtil.freemarker(pathTemplate, SystemUtil.freemarker(root, msg));
	}

	public void setPathTemplate(String pathTemplate)
	{
		this.pathTemplate = pathTemplate;
	}

	public void setBaseDir(String baseDir)
	{
		this.baseDir = baseDir;
	}

	public void setMessageConverter(IMessageConverter messageConverter)
	{
		this.messageConverter = messageConverter;
	}
}
