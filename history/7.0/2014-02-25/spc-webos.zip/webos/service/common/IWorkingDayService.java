package spc.webos.service.common;

import java.util.List;

public interface IWorkingDayService
{
	boolean isHoliday(String dt);

	void setHoliday(List dts);

	void setWorkingDay(List dts);
}
