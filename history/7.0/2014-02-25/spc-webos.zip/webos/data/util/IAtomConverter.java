package spc.webos.data.util;

import java.util.HashMap;
import java.util.Map;

import spc.webos.data.IAtomNode;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.model.MsgSchemaVO;

public interface IAtomConverter
{
	IAtomNode converter(IMessage msg, IAtomNode src, MsgSchemaVO schema, boolean esb2rcv,
			ICompositeNode pnode, String path, ICompositeNode tpnode) throws Exception;

	final static Map CONVERTERS = new HashMap();
}
