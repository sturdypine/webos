package spc.webos.resallocate.fnode;

import spc.webos.data.IMessage;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.resallocate.service.IResourcePoolService;

public class RefreshAFNode extends AbstractFNode
{
	protected IResourcePoolService resourcePoolService;

	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		resourcePoolService.refresh();
		return null;
	}

	public void setResourcePoolService(IResourcePoolService resourcePoolService)
	{
		this.resourcePoolService = resourcePoolService;
	}
}
