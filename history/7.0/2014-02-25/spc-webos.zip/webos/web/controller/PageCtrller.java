package spc.webos.web.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ResourceLoaderAware;
import org.springframework.core.io.ResourceLoader;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import spc.webos.constant.Common;
import spc.webos.constant.Web;
import spc.webos.log.Log;
import spc.webos.persistence.IPersistence;
import spc.webos.persistence.Persistence;
import spc.webos.util.StringX;
import spc.webos.web.util.WebUtil;

public class PageCtrller implements Controller, ResourceLoaderAware
{
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response)
			throws Exception
	{
		String page;
		String uri = request.getRequestURI();
		int index = StringX.lastIndexOf(uri, '/', 2);
		page = uri.substring(index + 1);
		index = page.indexOf('/');
		// viewName������һ���ģ�壬Ҳ������bean name����msView
		if (index > 0) page = page.substring(0, index) + '/' + viewType + '/'
				+ page.substring(index + 1);
		// System.out.println(viewName);
		ModelAndView mv = new ModelAndView(page);
		Map params = WebUtil.request2map(request, mv.getModel());
		params.put(Web.REQ_KEY_VIEW_NAME_SKEY, page);
		addCommonObj(params, request);
		// 1. ִ�з���
		WebUtil.invokeService(request, null, params);

		String batchSQL = (String) request.getParameter(Web.REQ_KEY_BATCH_SQL);
		if (batchSQL != null && batchSQL.length() > 0) persistence.execute(StringUtils
				.delimitedListToStringArray(batchSQL, StringX.COMMA), params, params);
		String download = request.getParameter(Web.REQ_KEY_DOWNLOAD);
		if (!StringX.nullity(download))
		{
			if (download.length() < 3) mv.setViewName(Web.REQ_MSVIEW_NAME); // Ĭ����msView����
			else mv.setViewName(download);
			params.put(Web.REQ_KEY_TEMPLATE_ID, page);
		}
		String contentType = request.getParameter(Common.MODEL_HTTP_CONTENT_TYPE);
		if (!StringX.nullity(contentType)) response.setContentType(Common
				.getContentType(contentType));
		return mv;
	}

	protected void addCommonObj(Map model, HttpServletRequest request)
	{
		if (contextParam != null) model.put(Common.MODEL_CXT_KEY, contextParam);
	}

	protected Object contextParam;
	protected ResourceLoader resourceLoader;
	protected String viewType = Common.TEMPLATE_TYPE_FTL; // ftl, jsp, vm
	// etc...
	// ǰ�˴���Ĵ����������ݵķ�������gridds����Ĵ����������ݵķ���
	protected IPersistence persistence = Persistence.getInstance();
	protected Log log = Log.getLogger(getClass());

	public void setPersistence(IPersistence persistence)
	{
		this.persistence = persistence;
	}

	public void setResourceLoader(ResourceLoader resourceLoader)
	{
		this.resourceLoader = resourceLoader;
	}

	public void setContextParam(Object contextParam)
	{
		this.contextParam = contextParam;
	}

	public void setViewType(String viewType)
	{
		this.viewType = viewType;
	}
}
