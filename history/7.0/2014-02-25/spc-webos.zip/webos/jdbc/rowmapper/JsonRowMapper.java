package spc.webos.jdbc.rowmapper;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.jdbc.support.JdbcUtils;

import spc.webos.persistence.SQLItem;
import spc.webos.util.SystemUtil;

public class JsonRowMapper extends AbstractRowMapper
{
	ResultSetMetaData rsmd;
	String[] columnName;

	public String[] getColumnName()
	{
		return columnName;
	}

	public ResultSetMetaData getResultSetMetaData()
	{
		return rsmd;
	}

	public JsonRowMapper(String charsetDB)
	{
		this.charsetDB = charsetDB;
	}

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		rsmd = rs.getMetaData();
		int columnCount = rsmd.getColumnCount();
		StringBuffer row = new StringBuffer(64);
		row.append('{');
		SQLItem item = SQLItem.getCurrentItem();
		ApplicationContext cxt = SystemUtil.getInstance().getAppCxt();
		for (int i = 1; i <= columnCount; i++)
		{
			String key = rsmd.getColumnName(i).toLowerCase();
			Object v = JdbcUtils.getResultSetValue(rs, i);
			if (v == null) continue;
			if (isConverter(key)) v = converter(key, v); // �ֶ���Ҫת��
			try
			{
				if ((v instanceof String)) v = v.toString().trim();
				if ((v instanceof String) && charsetDB != null) v = new String(v.toString()
						.getBytes(charsetDB));
			}
			catch (Exception e)
			{
				throw new RuntimeException("Error in coverting to Charset(" + charsetDB
						+ "), value=" + v, e);
			}
			if (row.length() > 2) row.append(',');
			row.append(key);

			row.append(":'");
			String str = null;
			if (item != null && cxt != null && item.dict != null)
			{ // ���ڴ������ֵ�ת��
				String vv = null;
				String d = (String) item.dict.get(key);
				if (d != null) vv = SystemUtil.getMessage(d, (String) v, null, null);
				str = (vv != null ? vv : v.toString());
			}
			else str = v.toString().trim();
			if (str.indexOf('\'') >= 0) str = str.replace("'", "\\'");
			if (str.indexOf('\n') >= 0) str = str.replace("\n", "\\n");
			row.append(str);
			row.append('\'');
		}
		row.append('}');
		// System.out.println("row = "+row);
		return row;
	}

	String charsetDB;
}
