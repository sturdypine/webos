package spc.webos.queue.tlq;

import java.util.ArrayList;
import java.util.List;

import spc.webos.queue.AbstractQueueAccess;
import spc.webos.queue.QueueMessage;
import spc.webos.util.StringX;

public class TLQQueueAccess extends AbstractQueueAccess
{
	protected List<TLQCnnPool> cnnpools;

	public TLQQueueAccess()
	{
	}

	public TLQQueueAccess(List<TLQCnnPool> cnnpools)
	{
		this.cnnpools = cnnpools;
	}

	public TLQQueueAccess(TLQCnnPool cnnpool)
	{
		this.cnnpools = new ArrayList<TLQCnnPool>();
		this.cnnpools.add(cnnpool);
	}

	public void destroy()
	{
		if (cnnpools == null) return;
		for (int i = 0; i < cnnpools.size(); i++)
			cnnpools.get(i).destory();
	}

	public void send(String qname, QueueMessage qmsg) throws Exception
	{
		if (log.isDebugEnabled()) log.debug("sn:" + qmsg.sn + ", corId:"
				+ (qmsg.correlationId != null ? new String(qmsg.correlationId) : "")
				+ ", expiry(s): " + qmsg.expirySeconds + ", ccsid: " + qmsg.ccsid);

		TLQAccessor.sendCluster(sndRandomStart, cnnpools, qname, qmsg, retryTimes, retryInterval);
	}

	public QueueMessage receive(String qname, byte[] correlationId, int timeout) throws Exception
	{
		QueueMessage qmsg = TLQAccessor.receive(cnnpools, qname, correlationId, timeout);
		return qmsg;
	}

	public QueueMessage execute(String reqQName, String repQName, QueueMessage qmsg, int timeout)
			throws Exception
	{
		byte[] corId = qmsg.correlationId; // ����ˮ����Ϊmq��Ϣ������
		if (log.isDebugEnabled()) log.debug("snd corId:"
				+ (qmsg.correlationId == null ? "" : new String(qmsg.correlationId)));
		if (log.isDebugEnabled()) log.debug("req:" + new String(qmsg.buf));

		TLQAccessor.sendCluster(sndRandomStart, cnnpools, reqQName, qmsg, timeout, timeout);

		if (StringX.nullity(repQName))
		{ // added by spc 2011-03-11 ���Ӧ�����Ϊ�գ����ʾ����Ҫ����
			if (log.isInfoEnabled()) log.info("repQName is null!!!");
			return null;
		}
		return receive(repQName, corId, timeout);
	}

	public void setCnnPool(TLQCnnPool cnnPool)
	{
		this.cnnpools = new ArrayList<TLQCnnPool>();
		this.cnnpools.add(cnnPool);
	}

	public void setCnnpools(List<TLQCnnPool> cnnpools)
	{
		this.cnnpools = cnnpools;
	}
}