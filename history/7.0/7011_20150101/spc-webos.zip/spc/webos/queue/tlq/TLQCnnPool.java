package spc.webos.queue.tlq;

import java.util.Hashtable;

import spc.webos.queue.AbstractCnnPool;

public class TLQCnnPool extends AbstractCnnPool
{
	protected Hashtable props;
	protected int cnnHoldTime = -1; // ���ӱ��ֵ����ʱ�䣬 -1��ʾ���޳�
	protected int cnnIdleTime = -1;

	public TLQCnnPool()
	{
		this.autoIncrease = true;
	}

	public TLQCnnPool(int max, Hashtable props)
	{
		this.max = max;
		this.props = props;
		this.autoIncrease = true;
	}

	public TLQCnnPool(int max, Hashtable props, int cnnHoldTime)
	{
		this.max = max;
		this.props = props;
		this.cnnHoldTime = cnnHoldTime;
		this.autoIncrease = true;
	}

	public TLQCnnPool(int max, Hashtable props, int cnnHoldTime, int cnnIdleTime)
	{
		this.max = max;
		this.props = props;
		this.cnnHoldTime = cnnHoldTime;
		this.cnnIdleTime = cnnIdleTime;
		this.autoIncrease = true;
	}

	public TLQCnnPool(int max, Hashtable props, int cnnHoldTime, int cnnIdleTime,
			boolean autoIncrease)
	{
		this.max = max;
		this.props = props;
		this.cnnHoldTime = cnnHoldTime;
		this.cnnIdleTime = cnnIdleTime;
		this.autoIncrease = autoIncrease;
	}

	public TLQCnnPool(int max, Hashtable props, int cnnHoldTime, int cnnIdleTime,
			boolean autoIncrease, long waitTime)
	{
		this.max = max;
		this.props = props;
		this.cnnHoldTime = cnnHoldTime;
		this.cnnIdleTime = cnnIdleTime;
		this.autoIncrease = autoIncrease;
		this.waitTime = waitTime;
	}

	public Object newIntance()
	{
		return new TLQManager(props, cnnHoldTime, cnnIdleTime, keepQueue);
	}

	public boolean release(Object obj)
	{
		TLQManager tlqm = (TLQManager) obj;
		if (!super.release(tlqm)) tlqm.disconnect();
		return true;
	}

	public synchronized void destory()
	{
		log.warn("start to destory tlq pool(" + name + ") : " + pool.size());
		for (int i = 0; i < pool.size(); i++)
			((TLQManager) pool.get(i)).disconnect();
		pool.clear();
	}
}
