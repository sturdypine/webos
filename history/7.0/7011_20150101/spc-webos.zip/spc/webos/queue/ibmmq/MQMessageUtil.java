package spc.webos.queue.ibmmq;

import java.io.IOException;

import spc.webos.queue.QueueMessage;
import spc.webos.util.StringX;

import com.ibm.mq.MQMessage;

/**
 * ���ڲ�QueueMessage����ת��ΪMQMessage����
 * 
 * @author chenjs
 * 
 */
public class MQMessageUtil
{
	public static QueueMessage createQMsg(MQMessage mqmsg, String qname) throws IOException
	{
		QueueMessage qmsg = new QueueMessage();
		qmsg.qname = qname;
		if (mqmsg == null) return qmsg;
		qmsg.mqmsg = mqmsg;
		qmsg.ccsid = mqmsg.characterSet;
		qmsg.correlationId = mqmsg.correlationId;
		qmsg.messageId = mqmsg.messageId;
		qmsg.putAppName = mqmsg.putApplicationName;
		qmsg.putDateTime = mqmsg.putDateTime.getTime();
		qmsg.buf = new byte[mqmsg.getMessageLength()];
		qmsg.feedback = mqmsg.feedback;
		qmsg.applicationIdData = mqmsg.applicationIdData;
		qmsg.applicationOriginData = mqmsg.applicationOriginData;
		qmsg.persistence = mqmsg.persistence;
		qmsg.replyToQ = mqmsg.replyToQueueName;
		qmsg.replyToQMgr = mqmsg.replyToQueueManagerName;
		((MQMessage) qmsg.mqmsg).readFully(qmsg.buf);
		qmsg.createTm = System.currentTimeMillis();
		return qmsg;
	}

	public static QueueMessage createQMsg(MQMessage mqmsg, byte[] buf, String qname)
			throws IOException
	{
		QueueMessage qmsg = new QueueMessage();
		qmsg.qname = qname;
		if (mqmsg == null) return qmsg;
		qmsg.mqmsg = mqmsg;
		qmsg.buf = buf;
		qmsg.ccsid = mqmsg.characterSet;
		qmsg.feedback = mqmsg.feedback;
		qmsg.applicationIdData = mqmsg.applicationIdData;
		qmsg.applicationOriginData = mqmsg.applicationOriginData;
		qmsg.correlationId = mqmsg.correlationId;
		qmsg.messageId = mqmsg.messageId;
		qmsg.putAppName = mqmsg.putApplicationName;
		qmsg.putDateTime = mqmsg.putDateTime.getTime();
		qmsg.persistence = mqmsg.persistence;
		qmsg.replyToQ = mqmsg.replyToQueueName;
		qmsg.replyToQMgr = mqmsg.replyToQueueManagerName;
		qmsg.createTm = System.currentTimeMillis();
		return qmsg;
	}

	public static MQMessage toMQMessage(QueueMessage qmsg, MQMessage mqmsg) throws IOException
	{
		if (qmsg.correlationId != null) mqmsg.correlationId = qmsg.correlationId;
		if (qmsg.messageId != null) mqmsg.messageId = qmsg.messageId;
		if (qmsg.expirySeconds > 0) mqmsg.expiry = qmsg.expirySeconds * 10;
		if (!StringX.nullity(qmsg.applicationIdData)) mqmsg.applicationIdData = qmsg.applicationIdData;
		if (!StringX.nullity(qmsg.applicationOriginData)) mqmsg.applicationOriginData = qmsg.applicationOriginData;
		if (!StringX.nullity(qmsg.putAppName)) mqmsg.putApplicationName = qmsg.putAppName;
		if (!StringX.nullity(qmsg.replyToQ)) mqmsg.replyToQueueName = qmsg.replyToQ;
		if (!StringX.nullity(qmsg.replyToQMgr)) mqmsg.replyToQueueManagerName = qmsg.replyToQMgr;
		mqmsg.persistence = qmsg.persistence;
		mqmsg.feedback = qmsg.feedback;

		// added by chenjs 2011-05-11 ������Ϣ�����ȼ�����
		if (qmsg.priority >= 0) mqmsg.priority = qmsg.priority;
		if (qmsg.ccsid > 0) mqmsg.characterSet = qmsg.ccsid;
		mqmsg.write(qmsg.buf);
		return mqmsg;
	}
}
