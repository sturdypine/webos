package spc.webos.queue.ibmmq;

import java.util.Hashtable;

import spc.webos.queue.AccessTPool;
import spc.webos.queue.AccessThread;
import spc.webos.thread.DaemonThread;

public class MQAccessTPool extends AccessTPool
{
	// protected IBlobMessageCreator creator;
	// protected int waitInterval = -1;
	// modified by spc, ���ȴ�ʱ������Ϊ1s
	// public static final int DEFAULT_WAIT_INTERVAL = 1000; //
	// һ���߳�Ϊһ�����з����Ĭ�ϵȴ�ʱ��Ϊ1.5��
	// public static final int DEFAULT_MUL_WAIT_INTERVAL = 200; //
	// �����߳���Ϊһ��buf����ʱ���ȴ�ʱ��Ϊ200����

	public MQAccessTPool()
	{
	}

	public MQAccessTPool(int rw, int size, Hashtable props, String bufferName)
	{
		this.rw = rw;
		this.size = size;
		this.props = props;
		this.bufferName = bufferName;
	}

	public DaemonThread borrow()
	{
		if (msgIdCache != null && msgBuf != null) return new ConditionReceiverThread(this, props,
				msgBuf, msgIdCache);
		if (AccessThread.RW_READ == rw)
		{
			if (creator == null) return new ReceiverThread(this, props, bufferName, buf, qname,
					onMessage, messageId);
			return new BlobReceiverThread(this, props, buf, qname, creator, onMessage);
		}
		return new SenderThread(this, props, buf, qname, msgIdCache);
	}
}
