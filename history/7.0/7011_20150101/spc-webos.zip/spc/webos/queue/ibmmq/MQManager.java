package spc.webos.queue.ibmmq;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import spc.webos.constant.AppRetCode;
import spc.webos.exception.AppException;
import spc.webos.log.Log;
import spc.webos.util.StringX;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;

/**
 * MQ �������Ӷ��󣬺���������
 * 
 * @author chenjs
 * 
 */
public class MQManager
{
	public MQQueueManager qm;
	public MQQueue queue;

	public boolean keepQueue; // ����Queue��close���������
	public Map keepQueues = new HashMap(); // 2012-07-29 ����һ������ͬʱ���ֶ���򿪶���

	public Hashtable[] props; // 700 2013-05-05 ��������ѡ��
	protected int cur = 0; // 700 2013-05-05
	protected long createTm; // ����ʱ��
	public int holdtime = -1; //
	// ���ӵ���󱣴�ʱ�䣬��������Զ�̵�MQ����HA�������һ�������̣߳��������ڼ���������Ϣ��
	protected long lastUseTm; // ��һ��ʹ��ʱ��
	public int idletime = -1;

	public static final int MQ_OK = 0;
	public static final int MQ_CONNECTION_BROKER = -1;
	public static final int MQ_TIME_OUT = 1;
	public static final int MQ_UNKNOW_EXCEPTION = 2;
	public static int CNN_EXCEPTION_SLEEP = 30; // �쳣����˯��
	public static String SYS_DEF_CHL = "SYSTEM.DEF.SVRCONN";
	// public static final String QM_NAME = "qmName";
	public static final String HOST = "host";
	static final Log log = Log.getLogger(MQManager.class);

	public MQManager()
	{
	}

	public MQManager(MQCnnPool cnnpool)
	{
		this.props = createAllProps(cnnpool.getProps());
		this.holdtime = cnnpool.getCnnHoldTime();
		this.idletime = cnnpool.getCnnIdleTime();
	}

	public MQManager(Hashtable props, int holdtime)
	{
		this.props = createAllProps(props);
		this.holdtime = holdtime;
	}

	public MQManager(MQQueueManager qm, Hashtable props)
	{
		this.qm = qm;
		this.props = createAllProps(props);
	}

	public MQManager(MQQueueManager qm, Hashtable props, int holdtime)
	{
		this.qm = qm;
		this.props = createAllProps(props);
		this.holdtime = holdtime;
	}

	public MQManager(MQQueueManager qm, Hashtable props, int holdtime, int idletime)
	{
		this.qm = qm;
		this.props = createAllProps(props);
		this.holdtime = holdtime;
		this.idletime = idletime;
	}

	public MQManager(MQQueueManager qm, Hashtable props, int holdtime, int idletime,
			boolean keepQueue)
	{
		this.qm = qm;
		this.props = createAllProps(props);
		this.holdtime = holdtime;
		this.idletime = idletime;
		this.keepQueue = keepQueue;
	}

	public MQManager(Hashtable props, int holdtime, int idletime, boolean keepQueue)
	{
		this.props = createAllProps(props);
		this.holdtime = holdtime;
		this.idletime = idletime;
		this.keepQueue = keepQueue;
	}

	protected Hashtable[] createAllProps(Hashtable props)
	{
		// 2012-07-29 ���û���ṩͨ����ʹ��ϵͳĬ��ͨ��
		if (!props.containsKey(MQC.CHANNEL_PROPERTY)) props.put(MQC.CHANNEL_PROPERTY, SYS_DEF_CHL);
		// 2012-10-28 ʹ�ô����Կ��Ա�֤ÿ��MQ����ʹ�õ�����socket���ӣ����ǹ����ײ�����
		if (!props.containsKey(MQC.SHARING_CONVERSATIONS_PROPERTY)) props.put(
				MQC.SHARING_CONVERSATIONS_PROPERTY, 1);

		String host = StringX.null2emptystr(props.get(HOST));
		if (StringX.nullity(host)) return new Hashtable[] { props };
		props.remove(HOST);
		String[] hosts = StringX.split(host, StringX.COMMA);
		Hashtable[] ps = new Hashtable[hosts.length];
		for (int i = 0; i < hosts.length; i++)
		{
			String[] hp = StringX.split(hosts[i], ":");
			Hashtable p = new Hashtable(props);
			p.put(MQC.HOST_NAME_PROPERTY, hp[0]);
			p.put(MQC.PORT_PROPERTY, new Integer(hp[1]));
			ps[i] = p;
		}
		return ps;
	}

	public Hashtable getCurrentProps()
	{
		return props[cur];
	}

	public MQQueue accessQueue(String qname, int opt) throws MQException
	{
		lastUseTm = System.currentTimeMillis();
		if (!keepQueue) return (queue = qm.accessQueue(qname, opt));

		// 2012-08-20 ʹ��qname�ʹ򿪷�ʽopt������������, ������ʱ���һ�����ж�д����������
		String key = qname + '$' + opt;
		queue = (MQQueue) keepQueues.get(key);
		if (queue != null) return queue;
		queue = qm.accessQueue(qname, opt);
		keepQueues.put(key, queue); // MQManagerֻ����һ���߳�ʹ�ã���������sync
		return queue;
		// return (keepQueue && queue != null) ? queue : (queue =
		// qm.accessQueue(qname, opt));
	}

	public void connect(int count)
	{
		if (validate()) return;
		// if (qm != null
		// && (holdtime <= 0 || System.currentTimeMillis() - createTm < holdtime
		// * 1000)) return;
		reconnect(count);
	}

	public boolean validate()
	{
		long cur = System.currentTimeMillis();
		return qm != null && (holdtime <= 0 || cur - createTm < holdtime * 1000)
				&& (idletime <= 0 || cur - lastUseTm < idletime * 1000);
	}

	protected MQQueueManager createMQQueueManager() throws MQException
	{
		if (props.length == 1) return new MQQueueManager(null, props[0]); // qmname
		for (cur = 0; cur < props.length; cur++)
		{
			try
			{
				if (log.isInfoEnabled()) log.info("createMQQueueManager: " + props[cur]);
				return new MQQueueManager(null, props[cur]);
			}
			catch (MQException mqex)
			{
				log.warn("MQ err:: props: " + props[cur] + ", ex:" + mqex);
				if (cur == props.length - 1) throw mqex;
			}
		}
		log.warn("Exe unreachable code!!!");
		throw new RuntimeException("Err to create MQ!!!");
	}

	public void reconnect(int count)
	{
		long i = 0;
		// 2012-05-11 MQ���ӿ��Բ��ṩ���й�������, ֻ��Ҫchannel, ip, port
		// String qmname = StringX.null2emptystr(props.get(QM_NAME));
		while (true)
		{
			try
			{
				disconnect();
				// qm = new MQQueueManager(null, props); // qmname
				qm = createMQQueueManager();
				createTm = System.currentTimeMillis(); // ��������ʱ��
				lastUseTm = System.currentTimeMillis();
				return;
			}
			catch (MQException mqex)
			{
				log.warn("MQ access err::failtimes:" + i + ", sleep:" + CNN_EXCEPTION_SLEEP
						+ " seconds, count:" + count, mqex);
				Log.print();
				i++;
				if (count >= 0 && i >= count) throw new AppException(AppRetCode.PROTOCOL_MQ(),
						new Object[] { props.toString(), String.valueOf(mqex.reasonCode),
								String.valueOf(mqex.completionCode) });
				if (count < 0)
				{
					try
					{ // ֻ������Ϊ-1����������ģʽ�²�ʹ��˯�߻���
						Thread.sleep(CNN_EXCEPTION_SLEEP * 1000);
					}
					catch (Exception ee)
					{
					}
					continue;
				}
			}
			finally
			{
				Log.print();
			}
		}
	}

	public void commit() throws MQException
	{
		if (qm != null) qm.commit();
	}

	public void backout() throws MQException
	{
		if (qm != null) qm.backout();
	}

	public void closeQueue()
	{
		if (keepQueue || queue == null) return;
		try
		{
			log.debug("close current queue...");
			queue.close();
		}
		catch (Throwable t)
		{
			log.warn("err to close queue: " + props, t);
		}
		queue = null;
	}

	public void disconnect()
	{
		if (qm == null)
		{
			log.debug("mqm(null) will disconnect!!!");
			return;
		}
		if (log.isInfoEnabled()) log.info("mqm will disconnect: " + getCurrentProps());
		// try
		// { // ����ر�queue, �رն��й������������Զ��رն�������
		// if (queue != null) queue.close();
		// }
		// catch (Throwable t)
		// {
		// }
		try
		{ // ����ʹ��disconnect�ر�����, close���ܹر�
			qm.disconnect();
		}
		catch (Throwable t)
		{
			log.warn("fail to discnn:: " + getCurrentProps(), t);
		}
		finally
		{
			qm = null;
			queue = null;
			keepQueues.clear(); // ����ر�queue, �رն��й������������Զ��رն�������
		}
	}

	public static int handleMQException(MQException e)
	{
		int ret = MQ_UNKNOW_EXCEPTION;
		if (e.completionCode == MQException.MQCC_OK && e.reasonCode == MQException.MQRC_NONE) ret = MQ_OK;
		else if (e.completionCode == MQException.MQCC_FAILED)
		{
			switch (e.reasonCode)
			{
				case MQException.MQRC_NO_MSG_AVAILABLE:
					ret = MQ_TIME_OUT;
					break;
				case MQException.MQRC_CONNECTION_BROKEN:
				case MQException.MQRC_Q_MGR_NAME_ERROR:
				case MQException.MQRC_Q_MGR_NOT_AVAILABLE:
				case MQException.MQRC_SECURITY_ERROR:
				case MQException.MQRC_CONNECTION_STOPPING:
					ret = MQ_CONNECTION_BROKER;
					break;
				default:
					ret = MQ_UNKNOW_EXCEPTION;
			}
		}
		return ret;
	}
}
