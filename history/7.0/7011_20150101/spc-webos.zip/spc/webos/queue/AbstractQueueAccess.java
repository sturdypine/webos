package spc.webos.queue;

import spc.webos.log.Log;

public abstract class AbstractQueueAccess implements IQueueAccess
{
	protected Log log = Log.getLogger(getClass());
	protected int retryTimes = 1;
	protected int retryInterval = 0;
	protected boolean sndRandomStart = false;
	protected boolean matchCorId = true; // 2012-05-30, ĳЩ�������ܲ���ʱ��FA����ƥ�佻��

	public int getRetryTimes()
	{
		return retryTimes;
	}

	public void setRetryTimes(int retryTimes)
	{
		this.retryTimes = retryTimes;
	}

	public int getRetryInterval()
	{
		return retryInterval;
	}

	public void setRetryInterval(int retryInterval)
	{
		this.retryInterval = retryInterval;
	}

	public boolean isSndRandomStart()
	{
		return sndRandomStart;
	}

	public void setSndRandomStart(boolean sndRandomStart)
	{
		this.sndRandomStart = sndRandomStart;
	}

	public boolean isMatchCorId()
	{
		return matchCorId;
	}

	public void setMatchCorId(boolean matchCorId)
	{
		this.matchCorId = matchCorId;
	}
}
