package spc.webos.queue;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import spc.webos.buffer.IBuffer;
import spc.webos.cache.ICache;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.flownode.MessageFlow;
import spc.webos.thread.ThreadPool;
import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;

public abstract class AccessTPool extends ThreadPool
{
	// ���������ȡ�߳�ʹ��
	protected ICache msgIdCache;
	protected IBuffer msgBuf;
	protected IMessageConverter converter;
	protected MessageFlow msgFlow;
	protected IAsynSenderListener asynSenderListener = DefaultAsynSenderListener.getInstance();
	protected int cnnHoldTime = -1; // ���ӱ��ֵ����ʱ�䣬 -1��ʾ���޳�

	protected IBlobMessageCreator creator;
	protected int waitInterval = -1;
	protected int rw = AccessThread.RW_READ;

	// 700 2013-08-27 ����֧��һ���̶߳�ȡ�������
	protected String bufferName;
	protected IBuffer buf;
	// protected List bufferNames;
	// protected List bufs = new ArrayList();
	protected String qname;
	// protected Map buf2queueMapping; // ����buffer���Ͷ�������ͬ����Ҫӳ��
	protected IOnMessage onMessage = new DefaultOnMessage();
	protected byte[] messageId; // 701,2013-09-12 ������msgIdƥ���ȡ��Ϣ

	protected Hashtable props;
	protected boolean correlation = false; // ���Ϊtrue��ʾ�Ӷ����л�õ���Ϣ����Ҫ��messageId��Ϊ������
	protected boolean expiry = false; // �Ƿ��͵���Ϣ������Ϣ��ʱ����
	public final static int DEFAULT_EXPIRY = 120; // Ĭ����Ϣ��ʱʱ��Ϊ120��
	public static final int DEFAULT_WAIT_INTERVAL = 1000; // һ���߳�Ϊһ�����з����Ĭ�ϵȴ�ʱ��Ϊ1.5��
	public static final int DEFAULT_MUL_WAIT_INTERVAL = 200; // �����߳���Ϊһ��buf����ʱ���ȴ�ʱ��Ϊ200����

	public boolean isExpiry()
	{
		return expiry;
	}

	public void setExpiry(boolean expiry)
	{
		this.expiry = expiry;
	}

	public void init() throws Exception
	{
		if (!StringX.nullity(bufferName)) buf = (IBuffer) IBuffer.BUFFERS.get(bufferName);
		if (buf == null && StringX.nullity(qname)) log.warn("buf is null by: " + bufferName);
		// if (bufs.size() <= 0)
		// {
		// for (int i = 0; bufferNames != null && i < bufferNames.size(); i++)
		// {
		// String name = (String) bufferNames.get(i);
		// IBuffer buf = (IBuffer) IBuffer.BUFFERS.get(name);
		// if (buf == null) continue;
		// bufs.add(buf);
		// }
		// if (bufs.size() == 0 && msgBuf == null) { throw new
		// RuntimeException("AccessTPool("
		// + getName() + ") has no bufs or msgBuf is null!!!"); }
		// }
		super.init();
	}

	public boolean isCorrelation()
	{
		return correlation;
	}

	public void setCorrelation(boolean correlation)
	{
		this.correlation = correlation;
	}

	public int getRw()
	{
		return rw;
	}

	public void setRw(int rw)
	{
		this.rw = rw;
	}

	public String getBufferName()
	{
		return bufferName;
	}

	public void setBufferName(String bufferName)
	{
		this.bufferName = bufferName;
	}

	public void setBufferNames(List bufferNames)
	{
		this.bufferName = (String) bufferNames.get(0);
	}

	public Hashtable getProps()
	{
		return props;
	}

	public String getQname()
	{
		return qname;
	}

	public void setQname(String qname)
	{
		this.qname = qname;
	}

	public void setBuf2queueMapping(Map buf2queueMapping)
	{
		// this.buf2queueMapping = buf2queueMapping;
		qname = buf2queueMapping.values().iterator().next().toString();
	}

	public void setProps(Hashtable props)
	{
		this.props = props;
	}

	public void setBuf(IBuffer buf)
	{
		this.buf = buf;
	}

	public void setMsgIdCache(ICache msgIdCache)
	{
		this.msgIdCache = msgIdCache;
	}

	public void setMsgBuf(IBuffer msgBuf)
	{
		this.msgBuf = msgBuf;
	}

	public void setConverter(IMessageConverter converter)
	{
		this.converter = converter;
	}

	public IAsynSenderListener getAsynSenderListener()
	{
		return asynSenderListener;
	}

	public void setAsynSenderListener(IAsynSenderListener asynSenderListener)
	{
		this.asynSenderListener = asynSenderListener;
	}

	public IMessageConverter getConverter()
	{
		return converter;
	}

	public int getCnnHoldTime()
	{
		return cnnHoldTime;
	}

	public void setCnnHoldTime(int cnnHoldTime)
	{
		this.cnnHoldTime = cnnHoldTime;
	}

	public MessageFlow getMsgFlow()
	{
		return msgFlow;
	}

	public void setMsgFlow(MessageFlow msgFlow)
	{
		this.msgFlow = msgFlow;
	}

	public IBlobMessageCreator getCreator()
	{
		return creator;
	}

	public void setCreator(IBlobMessageCreator creator)
	{
		this.creator = creator;
	}

	public int getWaitInterval()
	{
		return waitInterval;
	}

	public void setWaitInterval(int waitInterval)
	{
		this.waitInterval = waitInterval;
	}

	public IBuffer getMsgBuf()
	{
		return msgBuf;
	}

	public IBuffer getBuf()
	{
		return buf;
	}

	public IOnMessage getOnMessage()
	{
		return onMessage;
	}

	public void setOnMessage(IOnMessage onMessage)
	{
		this.onMessage = onMessage;
	}

	public void setLocation(String location)
	{
		setLocation((Map) JsonUtil.json2obj(location));
	}

	public void setLocation(Map m)
	{
		if (m.containsKey("name")) setName((String) m.get("name"));
		setSize(Integer.parseInt(StringX.null2emptystr(m.get("size"), "1")));
		if (m.containsKey("logName")) setLogName((String) m.get("logName"));
		setRw(Integer.parseInt(StringX.null2emptystr(m.get("rw"), "0")));
		if (m.containsKey("qname")) setQname((String) m.get("qname"));
		setProps(new Hashtable((Map) m.get("props")));
	}

	public byte[] getMessageId()
	{
		return messageId;
	}

	public void setMessageId(byte[] messageId)
	{
		this.messageId = messageId;
	}

	public void setMessageId(String messageId)
	{
		this.messageId = messageId.getBytes();
	}
}
