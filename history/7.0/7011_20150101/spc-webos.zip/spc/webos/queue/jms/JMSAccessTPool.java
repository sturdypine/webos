package spc.webos.queue.jms;

import java.util.Hashtable;

import spc.webos.queue.AccessTPool;
import spc.webos.queue.AccessThread;
import spc.webos.thread.DaemonThread;

public class JMSAccessTPool extends AccessTPool
{
	public JMSAccessTPool()
	{
	}

	public JMSAccessTPool(int rw, int size, Hashtable props, String bufferName)
	{
		this.rw = rw;
		this.size = size;
		this.props = props;
		this.bufferName = bufferName;
	}

	public DaemonThread borrow()
	{
		if (AccessThread.RW_READ == rw) { return new JMSReceiverThread(this, props, buf, qname); }
		return null;
	}
}
