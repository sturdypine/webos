package spc.webos.queue.jms;

import java.util.Enumeration;
import java.util.List;

import javax.jms.BytesMessage;
import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.QueueBrowser;
import javax.jms.QueueReceiver;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;

import spc.webos.constant.AppRetCode;
import spc.webos.exception.AppException;
import spc.webos.log.Log;
import spc.webos.queue.QueueMessage;

public class JMSAccessor
{
	protected static Log log = Log.getLogger(JMSAccessor.class);
	public static final int CNN_EXCEPTION_SLEEP = 1; // �쳣����˯��

	public static void sendCluster(boolean randomStart, List<JMSCnnPool> cnnpools, String qname,
			QueueMessage qmsg, int retryTimes, int retryInterval) throws Exception
	{
		Exception ee = null;
		// �������Ϊ��㣬ѭ��һ�鷢��
		int index = (randomStart ? ((int) (Math.random() * 1000) % cnnpools.size()) : 0);
		if (log.isDebugEnabled()) log.debug("start: " + index);
		for (int i = 0; i < cnnpools.size(); i++)
		{
			if (index >= cnnpools.size()) index = 0;
			JMSCnnPool cnnpool = cnnpools.get(index++);
			try
			{
				JMSAccessor.send(cnnpool, qname, qmsg, retryTimes, retryInterval);
				return;
			}
			catch (Exception e)
			{
				ee = e;
				log.warn("fail to put:" + cnnpool.getProps() + ", qname:" + qname, e);
			}
		}
		throw ee;
	}

	public static void send(JMSCnnPool cnnPool, String qname, QueueMessage qmsg, int retryTimes,
			int retryInterval) throws Exception
	{
		JMSManager jmsm = (JMSManager) cnnPool.borrow();
		QueueSender sender = null;
		QueueSession sess = null;
		int failTimes = 0;
		Queue queue = null;
		while (true)
		{
			try
			{
				jmsm.connect(1);
				queue = (Queue) jmsm.ictx.lookup(qname);
				sess = jmsm.conn.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
				sender = sess.createSender(queue);
				BytesMessage msg = sess.createBytesMessage();
				JMSMessageUtil.QMsgtoJMSMsg(qmsg, msg);
				sender.setTimeToLive(msg.getJMSExpiration() * 1000);// ���ó�ʱʱ�䵥λ����
				sender.setDeliveryMode(DeliveryMode.NON_PERSISTENT);// ���������ߵ�DeliveryModeΪ�ǳ־ã�Ĭ���ǳ־û������DeliveryModeΪ�־û�������Ϣһ���ǳ־û��������߷ǳ־û��Ż�ȡ��Ϣ�����־û�����
				sender.send(msg);

				return;
			}
			catch (Exception ex)
			{
				failTimes++;
				log.warn("err to snd jms queue: " + queue.getQueueName() + jmsm.props
						+ ", retryTms:" + retryTimes + ", failTms:" + failTimes + ", reason: " + ex);
				jmsm.disconnect();
				if (failTimes > retryTimes) throw ex;
				try
				{
					if (retryInterval > 0) Thread.sleep(retryInterval);
				}
				catch (Exception ee)
				{
				}
			}
			finally
			{
				try
				{
					if (sender != null) sender.close();
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
				try
				{
					if (sess != null) sess.close();
				}
				catch (JMSException e)
				{
					e.printStackTrace();
				}
				cnnPool.release(jmsm);
			}
		}

	}

	// 2012-05-16 ͨ����ͨ����ĳ�����л�ȡ��Ϣ������ͨ��QM_GW_IN, QM_GW_OUT��ȡrep.nbs��Ϣ
	public static QueueMessage receive(List<JMSCnnPool> cnnpools, String qname,
			byte[] correlationId, int timeout) throws Exception
	{
		for (int i = 0; i < cnnpools.size(); i++)
		{
			JMSCnnPool cnnpool = cnnpools.get(i);
			try
			{
				return receive(cnnpool, qname, correlationId, timeout);
			}
			catch (Exception e)
			{
				// ���MQ�쳣��2033û����Ϣ�򷵻�
				if ((e instanceof AppException) && (((AppException) e).getCode() == "2033")) throw e;
				log.warn("cnnpool:" + cnnpool.getProps(), e);
				if (i == cnnpools.size() - 1) throw e; // �������û��ͨ���ˣ���ֱ���쳣����
			}
		}
		throw new Exception("fail to read msg from Multi channel, qname: " + qname);
	}

	public static QueueMessage receive(JMSCnnPool cnnpool, String qname, byte[] correlationId,
			int timeout) throws Exception
	{
		if (log.isDebugEnabled()) log.debug("cnn: " + cnnpool.getProps());
		JMSManager jmsm = (JMSManager) cnnpool.borrow();
		try
		{
			if (correlationId == null) return JMSMessageUtil.JMSMsgtoQMsg(receive(jmsm, qname,
					timeout));
			else return receive(jmsm, qname, correlationId, timeout);
		}
		finally
		{
			cnnpool.release(jmsm);
		}
	}

	public static QueueMessage receive(JMSManager jmsm, String qname, byte[] correlationId,
			int timeout) throws Exception
	{
		long start = System.currentTimeMillis(), failTimes = 0;
		QueueReceiver receiver = null;
		BytesMessage message = null;
		QueueMessage qmsg = null;
		QueueSession sess = null;
		Queue queue = null;
		while (failTimes < 2)
		{
			try
			{
				jmsm.connect(1);
				String selector = null;
				if (correlationId != null) selector = "JMSCorrelationID='"
						+ new String(correlationId) + "'";
				queue = (Queue) jmsm.ictx.lookup(qname);
				sess = jmsm.conn.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);

				if (selector != null) receiver = sess.createReceiver(queue, selector);
				else receiver = sess.createReceiver(queue);

				message = (BytesMessage) receiver.receive(timeout * 1000);
				if (message == null) throw new AppException(AppRetCode.PROTOCOL_TLQ(),
						new Object[] { qname, "2033", "no msg" });
				else
				{
					if (log.isInfoEnabled()) log.info("read JMS (" + queue.getQueueName()
							+ "), cost:" + (System.currentTimeMillis() - start) + ", len:"
							+ message.getBodyLength());
					qmsg = JMSMessageUtil.JMSMsgtoQMsg(message);
				}
				return qmsg;
			}
			catch (JMSException jmsex)
			{
				failTimes++;
				log.error("jmse.ret==-1...wait to reconnect...", jmsex);
				jmsm.reconnect(1);
				continue;
			}
			catch (AppException ex)
			{
				throw ex;
			}
			catch (Exception ex)
			{
				throw new RuntimeException(ex);
			}
			finally
			{
				try
				{
					if (receiver != null) receiver.close();
				}
				catch (JMSException e)
				{
					e.printStackTrace();
				}
				try
				{
					if (sess != null) sess.close();
				}
				catch (JMSException e)
				{
					e.printStackTrace();
				}
			}
		}

		return qmsg;
	}

	public static BytesMessage receive(JMSManager jmsm, String qname, int timeout) throws Exception
	{
		long start = System.currentTimeMillis(), failTimes = 0;
		QueueReceiver receiver = null;
		BytesMessage message = null;
		QueueSession sess = null;
		Queue queue = null;
		while (failTimes < 2)
		{
			try
			{
				jmsm.connect(1);
				queue = (Queue) jmsm.ictx.lookup(qname);
				sess = jmsm.conn.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
				receiver = sess.createReceiver(queue);
				message = (BytesMessage) receiver.receive(timeout * 1000);
				if (message == null) throw new AppException(AppRetCode.PROTOCOL_TLQ(),
						new Object[] { queue.getQueueName(), "2033", "2033" });
				else
				{
					if (log.isInfoEnabled()) log.info("read JMS (" + queue.getQueueName()
							+ "), cost:" + (System.currentTimeMillis() - start) + ", len:"
							+ message.getBodyLength());
				}

				return message;
			}
			catch (JMSException jmsex)
			{
				failTimes++;
				log.error("mqe.ret==-1...wait to reconnect...", jmsex);
				jmsm.reconnect(1);
				continue;
			}
			catch (AppException ex)
			{
				throw ex;
			}
			catch (Exception ex)
			{
				throw new RuntimeException(ex);
			}
			finally
			{
				try
				{
					if (receiver != null) receiver.close();
				}
				catch (JMSException e)
				{
					e.printStackTrace();
				}
				try
				{
					if (sess != null) sess.close();
				}
				catch (JMSException e)
				{
					e.printStackTrace();
				}
			}

		}
		return message;
	}

	public static boolean clearAll(JMSCnnPool cnnPool, String qname) throws Exception
	{
		JMSManager jmsm = (JMSManager) cnnPool.borrow();
		QueueSession sess = null;
		BytesMessage msg = null;
		Queue queue = null;
		QueueReceiver receiver = null;

		try
		{
			jmsm.connect(1);
			queue = (Queue) jmsm.ictx.lookup(qname);
			sess = jmsm.conn.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);

			receiver = sess.createReceiver(queue);
			Message message = receiver.receive();

			while (message != null)
			{
				msg = (BytesMessage) message;
				byte[] msgInfo = new byte[Long.valueOf(msg.getBodyLength()).intValue()];
				msg.readBytes(msgInfo);
				message = receiver.receive();
			}

			return true;
		}
		catch (JMSException jmse)
		{
			log.error("clearAll error,qname: " + qname, jmse);
			jmsm.disconnect();
			return false;
		}
		finally
		{
			try
			{
				if (receiver != null) receiver.close();
			}
			catch (JMSException e)
			{
				e.printStackTrace();
			}
			try
			{
				if (sess != null) sess.close();
			}
			catch (JMSException e)
			{
				e.printStackTrace();
			}

			cnnPool.release(jmsm);
		}
	}

	public static int browseAll(JMSCnnPool cnnPool, String qname) throws Exception
	{
		int msgnum = 0;
		JMSManager jmsm = (JMSManager) cnnPool.borrow();
		QueueSession sess = null;
		Queue queue = null;
		QueueBrowser browser = null;
		try
		{
			jmsm.connect(1);
			queue = (Queue) jmsm.ictx.lookup(qname);
			sess = jmsm.conn.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);

			browser = sess.createBrowser(queue);

			if (log.isInfoEnabled()) log.info("browseAll Queue: " + qname);

			Enumeration enumeration = browser.getEnumeration();

			while (enumeration.hasMoreElements())
			{
				Object obj = enumeration.nextElement();

				BytesMessage msg = (BytesMessage) obj;
				byte[] msgInfo = new byte[(int) msg.getBodyLength()];
				msg.readBytes(msgInfo);

				msgnum++;
			}
		}
		catch (JMSException jmse)
		{
			log.warn("browseAll Queue: " + qname + " error: " + jmse.getErrorCode());
			jmsm.disconnect();
			throw jmse;
		}
		finally
		{
			try
			{
				if (browser != null) browser.close();
			}
			catch (JMSException e)
			{
				e.printStackTrace();
			}
			try
			{
				if (sess != null) sess.close();
			}
			catch (JMSException e)
			{
				e.printStackTrace();
			}

			cnnPool.release(jmsm);
		}
		return msgnum;
	}

	public static QueueMessage browse(JMSCnnPool cnnPool, String qname, byte[] correlationId,
			byte[] msgId) throws Exception
	{
		JMSManager jmsm = (JMSManager) cnnPool.borrow();
		try
		{
			return browse(jmsm, qname, correlationId, msgId);
		}
		finally
		{
			cnnPool.release(jmsm);
		}
	}

	public static QueueMessage browse(JMSManager jmsm, String qname, byte[] correlationId,
			byte[] msgId) throws Exception
	{
		QueueSession sess = null;
		Queue queue = null;
		QueueBrowser browser = null;
		BytesMessage msg = null;
		try
		{
			jmsm.connect(1);
			queue = (Queue) jmsm.ictx.lookup(qname);
			sess = jmsm.conn.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);

			String selector = "JMSCorrelationID='" + new String(correlationId) + "'";
			if (msgId != null) selector += " AND JMSMessageID='" + new String(msgId) + "'";

			browser = sess.createBrowser(queue, selector);
			Enumeration enumeration = browser.getEnumeration();

			if (log.isInfoEnabled()) log.info("start to browse TLQ====" + qname + ",selector===="
					+ selector);

			int count = 0;
			while (enumeration.hasMoreElements())
			{
				Object obj = enumeration.nextElement();

				msg = (BytesMessage) obj;
				byte[] msgInfo = new byte[(int) msg.getBodyLength()];
				msg.readBytes(msgInfo);

				count++;
			}
			if (log.isInfoEnabled()) log.info("end to browse TLQ,count====" + count);

			return msg == null ? null : JMSMessageUtil.JMSMsgtoQMsg(msg);
		}
		catch (JMSException jmse)
		{
			log.warn("browse Queue: " + qname + ",correlationId = " + correlationId + ",error: "
					+ jmse.getErrorCode());
			jmsm.disconnect();
			throw jmse;
		}
		finally
		{
			try
			{
				if (browser != null) browser.close();
			}
			catch (JMSException e)
			{
				e.printStackTrace();
			}
			try
			{
				if (sess != null) sess.close();
			}
			catch (JMSException e)
			{
				e.printStackTrace();
			}
		}
	}
}