package spc.webos.queue.jms;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Hashtable;

import javax.jms.BytesMessage;
import javax.jms.JMSException;

import spc.webos.buffer.IBuffer;
import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.data.util.MessageUtil;
import spc.webos.exception.AppException;
import spc.webos.queue.AbstractReceiverThread;
import spc.webos.queue.AccessTPool;
import spc.webos.queue.QueueMessage;
import spc.webos.thread.ThreadPool;
import spc.webos.util.SystemUtil;

public class JMSReceiverThread extends AbstractReceiverThread
{
	protected JMSManager jmsm;

	public JMSReceiverThread()
	{
		super();
	}

	public JMSReceiverThread(ThreadPool pool, Hashtable props, IBuffer buf, String qname)
	{
		super();
		this.pool = pool;
		this.props = props;
		this.buf = buf;
		this.qname = qname;
	}

	public void release()
	{
		super.release();
		jmsm.disconnect();
	}

	public void init() throws Exception
	{
		super.init();
		if (((JMSAccessTPool) pool).getWaitInterval() > 0) timeout = ((JMSAccessTPool) pool)
				.getWaitInterval();
		else timeout = JMSAccessTPool.DEFAULT_WAIT_INTERVAL; // if (bufs.size()
																// == 1)
		// else timeout = JMSAccessTPool.DEFAULT_MUL_WAIT_INTERVAL;
		if (jmsm == null) jmsm = new JMSManager(props, ((AccessTPool) pool).getCnnHoldTime());
		refresh();
	}

	public void refresh() throws Exception
	{
		super.refresh();
		jmsm.reconnect(-1);
	}

	public Object receive(String qname) throws Exception
	{
		QueueMessage qmsg = receiveJMSMQMessage(qname);
		if (qmsg == null) return null;
		IMessageConverter converter = ((AccessTPool) getPool()).getConverter();
		if (converter == null) return qmsg;

		IMessage msg = converter.deserialize(qmsg.buf);
		msg.setCorrelationID(qmsg.correlationId);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_QMSG, qmsg); // ���������Ϣ��ԭʼ��Ϣ
		msg.setInLocal(MsgLocalKey.ACCEPTOR_PROTOCOL, Common.ACCEPTOR_PROTOCOL_QUEUE_MQ);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, qmsg.buf);
		if (((AccessTPool) getPool()).getMsgFlow() != null) msg.setInLocal(
				MsgLocalKey.LOCAL_MSG_MSGFLOW, ((AccessTPool) getPool()).getMsgFlow());
		return msg;
	}

	public QueueMessage receiveJMSMQMessage(String qname)
	{
		BytesMessage msg = null;
		QueueMessage qmsg;
		try
		{
			jmsm.connect(-1);
			msg = JMSAccessor.receive(jmsm, qname, timeout);
			qmsg = JMSMessageUtil.JMSMsgtoQMsg(msg);
			if (log.isDebugEnabled())
			{
				byte[] header = MessageUtil.getHeader(qmsg.buf);
				log.debug("read buf size: " + qmsg.buf.length + ", header: "
						+ (header != null ? new String(header) : "null") + "\nbuf in utf-8:"
						+ new String(qmsg.buf, Common.CHARSET_UTF8));
			}
		}
		catch (AppException ex)
		{
			return null;
		}
		catch (JMSException ex)
		{

			log.error("tlqe.ret==-1...wait to reconnect..." + qname + ", thread will sleep:"
					+ JMSAccessor.CNN_EXCEPTION_SLEEP + " seconds!!!", ex);
			jmsm.disconnect();
			try
			{ // ����Ϣʧ�ܿ����Ƕ��й���������ʧ�ܣ� Ҳ�����Ƕ��й�������û�ж���(���������һ��ֻ�ڿ���ʱ�ڣ�����û���ö�)
				Thread.sleep(JMSAccessor.CNN_EXCEPTION_SLEEP * 1000);
			}
			catch (Exception e)
			{
			}
			return null;
		}
		catch (Exception e)
		{
			log.error("read qName:" + qname + " mq message", e);
			return null;
		}

		try
		{
			if (((JMSAccessTPool) pool).isCorrelation()) qmsg.correlationId = msg
					.getJMSCorrelationIDAsBytes(); // ���ù�����
			else qmsg.correlationId = msg.getJMSMessageID().getBytes(); // ���ù�����
			if (log.isInfoEnabled()) log.info("inQTm:"
					+ new SimpleDateFormat(SystemUtil.DF_SALL17).format(msg.getJMSTimestamp())
					+ ",corId:\n" + new String(msg.getJMSCorrelationID()) + ", t: " + getName());
			return qmsg;
		}
		catch (Exception e)
		{
			try
			{
				log.error("in utf-8:" + new String(qmsg.buf, Common.CHARSET_UTF8), e);
			}
			catch (UnsupportedEncodingException e1)
			{
				log.warn("UnsupportedEncodingException for utf-8", e1);
			}
		}
		return qmsg;
	}
}
