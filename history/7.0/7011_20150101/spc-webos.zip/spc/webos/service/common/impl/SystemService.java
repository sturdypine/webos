package spc.webos.service.common.impl;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.statistics.StatisticsGateway;
import spc.webos.cache.ExtTreeCache;
import spc.webos.cache.ICache;
import spc.webos.config.AppConfig;
import spc.webos.constant.Web;
import spc.webos.message.DictMessageSource;
import spc.webos.message.SqlMessageSource;
import spc.webos.message.SysMessageSource;
import spc.webos.service.Service;
import spc.webos.service.common.ISystemtService;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;
import spc.webos.util.tree.ExtTreeNode;
import spc.webos.util.tree.TreeNode;

public class SystemService extends Service implements ISystemtService
{
	public String ftl(String ftl, Map params) throws Exception
	{
		return SystemUtil.freemarker(ftl, params);
	}

	public String freemarker(String id, Map params) throws Exception
	{
		return SystemUtil.freemarker(id, params, new StringWriter()).toString();
	}

	public String getCurrentDate(String format)
	{
		return SystemUtil.getInstance().getCurrentDate(format);
	}

	public String getCurrentDate()
	{
		return SystemUtil.getInstance().getCurrentDate(SystemUtil.DF_SALL17);
	}

	public String getSn()
	{
		return SystemUtil.getInstance().genSN(32);
	}

	public String getSn(int num)
	{
		return SystemUtil.getInstance().genSN(num);
	}

	public String getTimeSN()
	{
		return SystemUtil.getInstance().getTimeSN();
	}

	public void refreshConfig() throws Exception
	{
		AppConfig.getInstance().refresh();
	}

	// ˢ��ϵͳ���ݿ��ֵ����ݵ��ڴ�
	public void refreshDict() throws Exception
	{
		DictMessageSource.getInstance().refresh();
	}

	// ˢ��ϵͳ�Ĺ��ʻ�ת����Ϣ���ڴ�
	public void refreshSysMsg() throws Exception
	{
		SysMessageSource.getInstance().refresh();
	}

	public void refreshSqlMsg(List sqls) throws Exception
	{
		Iterator keys = null;
		if (sqls != null && sqls.size() > 0) keys = sqls.iterator();
		else keys = SqlMessageSource.SQL_MSG.keySet().iterator();
		while (keys.hasNext())
		{
			SqlMessageSource ms = (SqlMessageSource) SqlMessageSource.SQL_MSG.get(keys.next());
			if (ms != null) ms.refresh();
		}
	}

	public void removeFromCache(String cacheName, List keys)
	{
		ICache cache = (ICache) ICache.CACHE.get(cacheName);
		if (cache == null || keys == null) return;
		for (int i = 0; i < keys.size(); i++)
			cache.remove(keys.get(i));
	}

	// �õ�ϵͳ�����������Ϣ
	public List getEhcacheManagerInfo(Map params)
	{
		List info = new ArrayList();
		String[] cacheNames = cacheManager.getCacheNames();
		for (int i = 0; i < cacheNames.length; i++)
		{
			Cache cache = cacheManager.getCache(cacheNames[i]);
			CacheConfiguration c = cache.getCacheConfiguration();
			Map row = new HashMap();
			StatisticsGateway stat = cache.getStatistics();
			row.put("name", cacheNames[i]);
			row.put("hits", new Long(stat.cacheHitCount()));
			row.put("misses", new Long(stat.cacheMissCount()));
			row.put("expire", new Long(stat.cacheExpiredCount()));
			row.put("memory", new Integer(c.getMaxElementsInMemory()));
			row.put("disk", new Integer(c.getMaxElementsOnDisk()));
			row.put("idle", new Long(c.getTimeToIdleSeconds()));
			info.add(row);
		}
		return info;
	}

	// �õ�ĳ�����建���е���Ϣ
	public List getEhcacheInfo(Map params)
	{
		String name = (String) params.get("name");
		Cache cache = cacheManager.getCache(name);
		List keys = cache.getKeys();
		if (keys == null) return null;
		List result = new ArrayList(keys.size());
		for (int i = 0; i < keys.size(); i++)
		{
			Map row = new HashMap();
			row.put("key", keys.get(i));
			result.add(row);
		}
		return result;
	}

	public TreeNode getSysFns()
	{
		// ���ǵ�ϵͳ���ܷǹ���������,ֻ��ϵͳ����Աʹ��,���Բ����浽�ڴ���
		// String treeId = "sysfns";
		// ExtTreeNode node = (ExtTreeNode) extTreeCache.get(treeId);
		// if (node != null) return node;
		ExtTreeNode node = new ExtTreeNode();
		List res = (List) persistence.execute("common.sysfns", null);
		node.createTree(res);
		List leafs = new ArrayList();
		ExtTreeNode.leafs(node, leafs);
		for (int i = 0; i < leafs.size(); i++)
		{
			ExtTreeNode n = (ExtTreeNode) leafs.get(i);
			Map attr = n.getAttributes();
			String opers = (String) attr.get("operation");
			if (opers == null || opers.length() == 0) opers = "S";
			for (int j = 0; j < opers.length(); j++)
			{
				String oper = String.valueOf(opers.charAt(j));
				n.insertChild(new ExtTreeNode(n.getId() + "/" + oper, SystemUtil.getInstance()
						.getAppCxt().getMessage("DICT/operations/" + oper, null, null),
						Boolean.FALSE));
			}
		}
		// System.out.println(333);
		// extTreeCache.put(treeId, node);
		// System.out.println(node.toJson());
		return node;
	}

	public TreeNode getExtTree(Map param)
	{
		if (!(param instanceof HashMap)) param = new HashMap(param);
		ExtTreeNode node = new ExtTreeNode();
		node.createTree((List) persistence.execute((String) param.get(Web.REQ_KEY_SQL_ID), param));
		return node;
	}

	public String getExtTreeJson(Map param)
	{
		TreeNode node = getExtTree(param);
		String str = node != null ? node.toJson().toString() : StringX.EMPTY_STRING;
		return str;
	}

	public void removeTrees(List treesId)
	{
		if (treesId == null || treesId.size() == 0) return;
		for (int i = 0; i < treesId.size(); i++)
			extTreeCache.remove((String) treesId.get(i));
	}

	public Map getTrees()
	{
		Map trees = new HashMap();
		if (extTreeCache == null) return trees;
		Iterator keys = extTreeCache.getTreesSql().keySet().iterator();
		while (keys.hasNext())
		{
			String key = keys.next().toString();
			trees.put(key, extTreeCache.get(key));
		}
		return trees;
	}

	public TreeNode getLogDirTree(Map param) throws Exception
	{
		return new ExtTreeNode().createTree(SystemUtil.getInstance().getResourceLoader()
				.getResource(logdir).getFile(), StringX.EMPTY_STRING);
	}

	String logdir = "/logs";
	ExtTreeCache extTreeCache;
	CacheManager cacheManager;

	public void setCacheManager(CacheManager cacheManager)
	{
		this.cacheManager = cacheManager;
	}

	public void setExtTreeCache(ExtTreeCache extTreeCache)
	{
		this.extTreeCache = extTreeCache;
	}

	public void setLogdir(String logdir)
	{
		this.logdir = logdir;
	}
}
