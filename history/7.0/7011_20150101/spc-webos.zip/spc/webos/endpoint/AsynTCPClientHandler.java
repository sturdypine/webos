package spc.webos.endpoint;

import java.io.IOException;
import java.nio.BufferUnderflowException;
import java.nio.channels.ClosedChannelException;

import org.xsocket.MaxReadSizeExceededException;
import org.xsocket.connection.IConnectHandler;
import org.xsocket.connection.IDataHandler;
import org.xsocket.connection.IDisconnectHandler;
import org.xsocket.connection.INonBlockingConnection;

import spc.webos.constant.AppRetCode;
import spc.webos.exception.AppException;
import spc.webos.log.Log;
import spc.webos.util.FileUtil;
import spc.webos.util.StringX;
import spc.webos.util.http.HTTPHeader;
import spc.webos.util.http.HTTPUtil;

public class AsynTCPClientHandler implements IDataHandler, IConnectHandler, IDisconnectHandler
{
	Executable exe;
	AsynTCPEndpoint endpoint;
	String ip;
	int port;

	public AsynTCPClientHandler(AsynTCPEndpoint endpoint, Executable exe, String ip, int port)
	{
		this.endpoint = endpoint;
		this.exe = exe;
		this.ip = ip;
		this.port = port;
	}

	public boolean onConnect(INonBlockingConnection nbc) throws IOException,
			BufferUnderflowException, MaxReadSizeExceededException
	{
		if (endpoint.log.isDebugEnabled()) endpoint.log.debug("suc to cnn: "
				+ nbc.getRemoteAddress());
		return true;
	}

	public boolean onDisconnect(INonBlockingConnection nbc) throws IOException
	{
		Log log = endpoint.log;
		if (!StringX.nullity(endpoint.logName)) Log.start(endpoint.logName);
		if (log.isDebugEnabled()) log.debug("discnn: " + ip + ":" + port);
		try
		{ // �������û��ӳ������³���onDiscnn������ǳ�ʱ���µ�
			if (exe.resTime == 0)
			{
				log.warn("Timeout:" + exe.getTimeout() + "::" + ip + ":" + port + ", sn:"
						+ (exe.reqmsg != null ? exe.reqmsg.getMsgSn() : ""));
				if (exe.callback != null) exe.callback.fail(
						exe,
						endpoint,
						ip,
						port,
						new AppException(AppRetCode.PROTOCOL_SOCKET(), new Object[] {
								String.valueOf(ip), String.valueOf(port) }));
			}
		}
		catch (Throwable e)
		{
			log.warn("callback fail", e);
		}
		finally
		{
			try
			{ // ��ǰ�����Ѿ��ϵ����ͷ�����
				if (endpoint.maxCnn > 0) endpoint.releaseCnn();
			}
			catch (Exception e)
			{
			}
			try
			{
				nbc.close();
			}
			catch (IOException e)
			{
			}
			Log.print();
		}
		return false;
	}

	public boolean onData(INonBlockingConnection nbc) throws IOException, BufferUnderflowException,
			ClosedChannelException, MaxReadSizeExceededException
	{
		Log log = endpoint.log;
		if (!StringX.nullity(endpoint.logName)) Log.start(endpoint.logName);
		int available = nbc.available();
		if (log.isDebugEnabled()) log.debug("onData available:" + available);
		if (available <= 0) return false;
		try
		{
			if (endpoint.longCnn) longCnn(nbc);
			else shortCnn(nbc);
		}
		catch (Throwable e)
		{
			log.warn("fail read:" + ip + ":" + port + ", longCnn:" + endpoint.longCnn, e);
		}
		finally
		{
			Log.print();
		}
		return true;
	}

	// �����ӵ�Ӧ��ģʽ
	protected void shortCnn(INonBlockingConnection nbc) throws Throwable
	{
		Log log = endpoint.log;
		try
		{
			byte[] response = nbc.readBytesByLength(nbc.available());
			exe.resTime = System.currentTimeMillis();
			if (log.isInfoEnabled()) log.info("asyn response len:" + response.length);
			if (endpoint.trace && log.isInfoEnabled()) log.info("asyn response:"
					+ new String(response) + "\nbase64:" + StringX.base64(response));
			else if (log.isDebugEnabled()) log.debug("asyn response:" + new String(response)
					+ "\nbase64:" + StringX.base64(response));
			if (endpoint.len <= 0) exe.response = response;
			else
			{ // ȥ�����Ȳ���
				byte[] lenBytes = FileUtil.arraycopy(response, 0, endpoint.len);
				if (log.isInfoEnabled()) log.info("hdrlen:" + endpoint.length(lenBytes));
				exe.response = FileUtil.arraycopy(response, endpoint.len, response.length
						- endpoint.len);
			}

			if (endpoint.http)
			{
				HTTPHeader header = new HTTPHeader();
				exe.response = HTTPUtil.unpackResponse(exe.response, header);
				exe.repHttpHeaders = header.params;
				if (header.statusCode != 200)
				{
					log.warn("HTTP statusCode=" + header.statusCode);
					exe.callback.fail(exe, endpoint, ip, port,
							new AppException(AppRetCode.PROTOCOL_HTTP(),
									new Object[] { new Integer(header.statusCode) }));
					return;
				}
			}

			if (exe.callback != null && exe.response != null) exe.callback.response(exe, endpoint,
					ip, port);
			else log.warn("callback or response is null !!!");
		}
		finally
		{
			try
			{
				nbc.close();
			}
			catch (IOException e)
			{
			}
		}
	}

	protected void longCnn(INonBlockingConnection nbc) throws Throwable
	{
		Log log = endpoint.log;
		while (nbc.available() > 0)
		{
			exe.response = readBytesByLength(nbc, endpoint.len);
			if (exe.callback != null && exe.response != null) exe.callback.response(exe, endpoint,
					ip, port);
			else log.warn("callback or response is null !!!");
		}
	}

	protected byte[] readBytesByLength(INonBlockingConnection nbc, int len) throws Exception
	{
		Log log = endpoint.log;
		byte[] lenBytes = nbc.readBytesByLength(endpoint.len);
		int hdrLen = endpoint.length(lenBytes);
		if (log.isInfoEnabled()) log.info("long hdrlen:" + hdrLen);
		byte[] response = nbc.readBytesByLength(hdrLen);
		if (log.isInfoEnabled()) log.info("long asyn response len:" + response.length + ","
				+ new String(lenBytes));
		if (log.isDebugEnabled()) log.debug("long asyn response:" + new String(response)
				+ "\nbase64:" + StringX.base64(response));
		return response;
	}
}
