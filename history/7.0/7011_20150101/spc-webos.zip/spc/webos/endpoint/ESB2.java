package spc.webos.endpoint;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import spc.webos.cache.ICache;
import spc.webos.cache.Map2Cache;
import spc.webos.data.IMessage;
import spc.webos.data.converter.XMLConverter2;
import spc.webos.log.Log;
import spc.webos.queue.AbstractReceiverThread;
import spc.webos.queue.AccessTPool;
import spc.webos.queue.IOnMessage;
import spc.webos.queue.IQueueAccess;
import spc.webos.queue.QueueMessage;
import spc.webos.queue.ibmmq.MQAccessTPool;
import spc.webos.queue.ibmmq.MQCnnPool;
import spc.webos.queue.ibmmq.QueueAccess;
import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

public class ESB2 implements Endpoint
{
	protected IQueueAccess access;
	protected String reqQName = "REQ";
	protected String replyToQ;
	protected String jvm = StringX.EMPTY_STRING;
	protected boolean matchMsgId = true;
	protected int timeout = 60;
	protected List<AccessTPool> accessPools;
	protected ICache cache = new Map2Cache(60);
	protected IOnMessage onMessage = new ESB2OnMessage(this);
	protected Log log = Log.getLogger(getClass());
	protected static ESB2 esb2 = new ESB2();

	private ESB2()
	{
	}

	public static ESB2 getInstance()
	{
		return esb2;
	}

	public void init() throws Exception
	{
		// 701,2013-09-12 ����������ṩreplyToQ, ���첽��ȡ�߳��Ե�ǰjvm���ƥ���ȡmessageId��Ϣ
		String messageId = StringX.ZEROS + jvm;
		messageId = messageId.substring(messageId.length() - 24);
		for (int i = 0; accessPools != null && i < accessPools.size(); i++)
		{
			AccessTPool pool = accessPools.get(i);
			pool.setQname(replyToQ);
			if (StringX.nullity(pool.getName())) pool.setName(replyToQ + "::" + i);
			if (matchMsgId) pool.setMessageId(messageId);
			pool.setOnMessage(onMessage);
			pool.init();
			pool.startAll();
		}
	}

	public String getSeqNb()
	{
		return getSeqNb(15);
	}

	public String getSeqNb(int len)
	{
		String seqNb = SystemUtil.random(24) + SystemUtil.getTimeSN(8) + jvm;
		return seqNb.substring(seqNb.length() - len);
	}

	public void execute(Executable exe) throws Exception
	{
		String corId = new String(exe.correlationID);
		int timeout = exe.timeout > 0 ? exe.timeout : this.timeout;
		if (log.isInfoEnabled()) log.info("reqQ:" + reqQName + ", replyToQ:" + replyToQ + ",jvm:"
				+ jvm + ", timeout:" + timeout + ", return:" + exe.isWithoutReturn() + ", corId:"
				+ corId);
		QueueMessage reqqmsg = new QueueMessage(exe.request, exe.correlationID, exe.messageId,
				timeout, reqQName);
		reqqmsg.replyToQ = replyToQ;
		access.send(reqQName, reqqmsg);
		if (exe.isWithoutReturn()) return;
		QueueMessage qmsg = (QueueMessage) cache.poll(corId, exe.timeout * 1000);
		exe.setResponse(qmsg.buf);
		exe.setResTime(System.currentTimeMillis());
	}

	public IMessage execute(IMessage msg) throws Exception
	{
		return execute(msg, timeout, true);
	}

	public IMessage execute(IMessage msg, int timeout) throws Exception
	{
		return execute(msg, timeout, true);
	}

	public IMessage execute(IMessage msg, int timeout, boolean withoutReturn) throws Exception
	{
		Executable exe = new Executable();
		exe.request = XMLConverter2.getInstance().serialize(msg);
		exe.correlationID = msg.getMQCorId().getBytes();
		exe.timeout = timeout;
		exe.withoutReturn = withoutReturn;
		execute(exe);
		if (withoutReturn) return null;
		return XMLConverter2.getInstance().deserialize(exe.response);
	}

	public void destory()
	{
		access.destroy();

		for (int i = 0; accessPools != null && i < accessPools.size(); i++)
			accessPools.get(i).asynStopAll();

		cache.removeAll();
	}

	public Endpoint clone() throws CloneNotSupportedException
	{
		throw new CloneNotSupportedException();
	}

	public IQueueAccess getAccess()
	{
		return access;
	}

	public void setAccess(IQueueAccess access)
	{
		this.access = access;
	}

	public String getReqQName()
	{
		return reqQName;
	}

	public void setReqQName(String reqQName)
	{
		this.reqQName = reqQName;
	}

	public String getReplyToQ()
	{
		return replyToQ;
	}

	public void setReplyToQ(String replyToQ)
	{
		this.replyToQ = replyToQ;
	}

	public List<AccessTPool> getAccessPools()
	{
		return accessPools;
	}

	public void setAccessPools(List<AccessTPool> accessPools)
	{
		this.accessPools = accessPools;
	}

	public void setAccessPools(String accessPools)
	{
		this.accessPools = createATPool(accessPools);
	}

	public static List<AccessTPool> createATPool(String strPools)
	{
		List list = (List) JsonUtil.json2obj(strPools);
		List<AccessTPool> accessPools = new ArrayList<AccessTPool>();
		for (int i = 0; i < list.size(); i++)
		{
			MQAccessTPool pool = new MQAccessTPool();
			pool.setLocation((Map) list.get(i));
			accessPools.add(pool);
		}
		return accessPools;
	}

	public ICache getCache()
	{
		return cache;
	}

	public void setCache(ICache cache)
	{
		this.cache = cache;
	}

	public IOnMessage getOnMessage()
	{
		return onMessage;
	}

	public void setOnMessage(IOnMessage onMessage)
	{
		this.onMessage = onMessage;
	}

	public void setAccess(String chl) throws Exception
	{
		access = new QueueAccess(createChl(chl));
	}

	public static List<MQCnnPool> createChl(String chl) throws Exception
	{
		List channels = (List) JsonUtil.json2obj(chl);
		List<MQCnnPool> cnnpools = new ArrayList<MQCnnPool>();
		for (int i = 0; i < channels.size(); i++)
		{
			Map channel = (Map) channels.get(i);
			MQCnnPool cnnpool = new MQCnnPool();
			String maxCnnNum = StringX.null2emptystr(channel.get(ESB.MAXCNN_KEY));
			String cnnHoldTime = StringX.null2emptystr(channel.get(ESB.CNNHOLDTIME_KEY));
			String cnnIdleTime = StringX.null2emptystr(channel.get(ESB.CNNIDLETIME_KEY));
			String keepQueue = StringX.null2emptystr(channel.get(ESB.KEEPQUEUE_KEY));
			String name = StringX.null2emptystr(channel.get("name"));
			if (!StringX.nullity(name)) cnnpool.setName(name);

			if (!StringX.nullity(maxCnnNum)) cnnpool.setMax(Integer.parseInt(maxCnnNum));
			else cnnpool.setMax(1);
			if (!StringX.nullity(cnnHoldTime)) cnnpool
					.setCnnHoldTime(Integer.parseInt(cnnHoldTime));
			if (!StringX.nullity(cnnIdleTime)) cnnpool
					.setCnnIdleTime(Integer.parseInt(cnnIdleTime));
			if (!StringX.nullity(keepQueue)) cnnpool.setKeepQueue(Boolean.TRUE.toString()
					.equalsIgnoreCase(keepQueue));

			cnnpool.setProps(new Hashtable((Map) channel.get("channel")));
			cnnpool.setBorrowOnInit(false);
			cnnpool.init();
			cnnpools.add(cnnpool);
		}
		return cnnpools;
	}

	public String getJvm()
	{
		return jvm;
	}

	public void setJvm(String jvm)
	{
		this.jvm = jvm;
	}

	public int getTimeout()
	{
		return timeout;
	}

	public void setTimeout(int timeout)
	{
		this.timeout = timeout;
	}

	public boolean isMatchMsgId()
	{
		return matchMsgId;
	}

	public void setMatchMsgId(boolean matchMsgId)
	{
		this.matchMsgId = matchMsgId;
	}
}

class ESB2OnMessage implements IOnMessage
{
	protected Log log = Log.getLogger(getClass());
	protected ESB2 esb2;

	public ESB2OnMessage(ESB2 esb2)
	{
		this.esb2 = esb2;
	}

	public void onMessage(Object obj, AccessTPool pool, AbstractReceiverThread thread)
			throws Exception
	{
		QueueMessage qmsg = (QueueMessage) obj;
		String corId = new String(qmsg.correlationId);
		if (log.isInfoEnabled()) log.info("response corId:" + corId + ", len:" + qmsg.buf.length
				+ ", cache size:" + esb2.cache.size());
		esb2.cache.put(corId, qmsg);
	}
}
