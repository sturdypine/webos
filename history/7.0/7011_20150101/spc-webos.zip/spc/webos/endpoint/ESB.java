package spc.webos.endpoint;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.BlobMsgHeader;
import spc.webos.data.IBlobMsgHeader;
import spc.webos.data.ICompositeNode;
import spc.webos.data.IMessage;
import spc.webos.data.Message;
import spc.webos.data.Status;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.data.converter.XMLConverter;
import spc.webos.data.converter.XMLConverter2;
import spc.webos.data.util.MessageUtil;
import spc.webos.data.validator.IMessageValidator;
import spc.webos.data.validator.MessageErrors;
import spc.webos.exception.MsgErrException;
import spc.webos.log.Log;
import spc.webos.queue.DefaultBlobMessageCreator;
import spc.webos.queue.IBlobMessageCreator;
import spc.webos.queue.IBlobQueueAccess;
import spc.webos.queue.IQueueAccess;
import spc.webos.queue.QueueMessage;
import spc.webos.queue.ibmmq.BlobQueueAccess;
import spc.webos.queue.ibmmq.MQCnnPool;
import spc.webos.queue.jms.JMSCnnPool;
import spc.webos.queue.jms.JMSQueueAccess;
import spc.webos.security.ISignature;
import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

/**
 * Ϊ ESB����jvm halt�¼� ΪESB api�ṩ��ʱδȡ�߱��ĵĽӿ�
 * 
 * @author spc
 * 
 */
public class ESB implements Endpoint
{
	protected String appCd = "ESB"; // ��ǰ����ϵͳ��ţ� 3λ
	protected String node; // �ڵ�
	protected String jvm; // ͬһӦ��ϵͳ�е�jvm��ţ�3λ

	protected String version = "1.0"; // xml���ĵİ汾��
	protected int maxCnnNum = 10;
	protected Hashtable props;
	protected String reqQName = "REQ";
	protected String blobReqQName = "REQ.BLOB";
	protected String repQPrefix = "REP.";
	protected boolean nodeRepQPostfix = true; // true ��ʾ��Ա������м�REP.NNS.0000
	protected String synRepQPostfix = ""; // added by chenjs. 2011-12-06, for
											// ncc ͬ��Ӧ�������.SYN��β
	protected int defTimeout = 60; // ƽ̨Ĭ�ϳ�ʱʱ��
	protected int cnnHoldTime = -1; // ���ӱ��ֵ����ʱ�䣬 -1��ʾ���޳�
	protected int cnnIdleTime = -1; // ���ӱ��ֵ����ʱ�䣬 -1��ʾ���޳�
	protected int cnnRetryTimes = 1; // ���ӷ����쳣ʱ�����Դ���
	protected int expirySeconds = 50; // 2012-11-01 ���ncc MQ��Ⱥ�ӳٷ������⣬������Ϣ�г�ʱʱ��
	protected boolean shortCnn; // 2013-01-15 chenjs, ��Щ���ǰ����Ҫʹ�ö�����ģʽ
	protected long waitTime;
	protected boolean cnnAutoIncrease = true;
	protected IMessageValidator validator;

	// protected MQCnnPool mqCnnPool;
	protected IQueueAccess access;
	protected IBlobMessageCreator creator = new DefaultBlobMessageCreator();
	protected IMessageConverter converter = new XMLConverter2(false);
	protected ISignature signature;

	private boolean init = false;
	private static long LAST_TIME = 0; // ��һ��ˮ�ŵ�ʱ��(����)
	private final static ESB esb = new ESB();
	static Log log = Log.getLogger(ESB.class);

	public final static String QMTYPE_JMS = "JMS";
	public final static String QMTYPE_MQ = "MQ";
	public final static String QMTYPE_KEY = "QMType";
	public final static String SHORTCNN_KEY = "shortCnn";
	public final static String APPCD_KEY = "appCd";
	public final static String NODE_KEY = "node";
	public final static String MAXCNN_KEY = "maxCnnNum";
	public final static String REQQNM_KEY = "reqQName";
	public final static String TIMEOUT_KEY = "timeout";
	public final static String EXPIRY_KEY = "expirySeconds";
	public final static String CNNHOLDTIME_KEY = "cnnHoldTime";
	public final static String CNNIDLETIME_KEY = "cnnIdleTime";
	public final static String KEEPQUEUE_KEY = "keepQueue";
	public final static String BORROWONINIT_KEY = "borrowOnInit";
	public final static String JVM_KEY = "jvm";
	public final static String JVM_BLOB_BASEDIR = "blobDir";
	public final static String JVM_BLOB_PATH = "blobPath";

	// jms���

	public void send(InputStream is, IBlobMsgHeader header) throws Exception
	{
		send(blobReqQName, is, header, null);
	}

	public void send(String qname, InputStream is, IBlobMsgHeader header, byte[] correlationId)
			throws Exception
	{
		if (log.isInfoEnabled()) log.info("send blob msg:" + header.toCNode(null).toString());
		((IBlobQueueAccess) access).send(qname, is, header, false, correlationId);
	}

	public void send(File[] files, boolean[] gzip, IBlobMsgHeader header) throws Exception
	{
		send(blobReqQName, files, gzip, header, null);
	}

	public void send(String qname, File[] files, boolean[] gzip, IBlobMsgHeader header,
			byte[] correlationId) throws Exception
	{
		if (log.isInfoEnabled()) log.info("send blob msg:" + header.toCNode(null).toString());
		((IBlobQueueAccess) access).send(qname, files, gzip, header, false, correlationId);
	}

	public IMessage receive(String qname, int timeout, byte[] correlationId) throws Exception
	{
		return ((IBlobQueueAccess) access).receive(qname, null, false, timeout, correlationId);
	}

	public IMessage receive(String qname, IBlobMessageCreator blob, int timeout,
			byte[] correlationId) throws Exception
	{
		return ((IBlobQueueAccess) access).receive(qname, blob, false, timeout, correlationId);
	}

	public void notice(IMessage msg) throws Exception
	{
		applyESBHdr(msg);
		if (log.isInfoEnabled()) log.info("notice msg sn:" + msg.getMsgSn());
		validate(msg);
		access.send(reqQName, new QueueMessage(msg, converter.serialize(msg)));
	}

	public void execute(Executable exe) throws Exception
	{
		String reqQNm = StringX.nullity(exe.reqQName) ? reqQName : exe.reqQName;
		String repQNm = exe.repQName;
		byte[] corId = exe.correlationID;
		if (log.isInfoEnabled()) log.info("shortCnn:" + shortCnn + ", reqQ:" + reqQNm + ", repQ:"
				+ repQNm + ", timeout:" + exe.timeout + ", return:" + exe.isWithoutReturn()
				+ ", corId:" + (corId == null ? "" : new String(corId)));
		if (corId == null || StringX.nullity(repQNm))
		{ // 2013-02-20 ���û����дcorId, ��ôĬ�Ͻ���xml���ģ����л�ȡcorId
			IMessage msg = XMLConverter2.getInstance().deserialize(exe.request);
			if (corId == null) corId = msg.getMQCorId().getBytes();
			if (StringX.nullity(repQNm)) repQNm = repQPrefix + msg.getSndApp() + synRepQPostfix;
			if (log.isInfoEnabled()) log.info("by xml:: corId: " + new String(corId) + ", repQNm: "
					+ repQNm);
		}
		if (signature != null)
		{ // 2013-06-15 ����signature����
			Map params = new HashMap();
			params.put("buf", exe.request);
			byte[] body = MessageUtil.getBody(exe.request);
			String sig = signature.sign(null, body, params);
			exe.request = MessageUtil.addSignature2(exe.request, sig.getBytes());
		}

		try
		{ // 2012-11-01 �޸� expirySeconds
			if (exe.isWithoutReturn()) access.send(reqQNm, new QueueMessage(exe.request, corId,
					exe.messageId, expirySeconds, reqQNm));
			else
			{
				QueueMessage qmsg = access.execute(reqQNm, repQNm, new QueueMessage(exe.request,
						corId, exe.messageId, expirySeconds, reqQNm), exe.timeout <= 0 ? defTimeout
						: exe.timeout);
				exe.setResponse(qmsg.buf);
				exe.setResTime(System.currentTimeMillis());
				if (signature != null)
				{ // 2013-06-20 ������֤ǩ����Ϣ
					Map params = new HashMap();
					params.put("buf", qmsg.buf);
					signature.unsign(null, new String(MessageUtil.getSignature2(exe.response)),
							MessageUtil.getBody(exe.response), params);
				}
			}
		}
		finally
		{
			if (shortCnn && access != null) access.destroy();
		}
	}

	public Endpoint clone() throws CloneNotSupportedException
	{
		throw new CloneNotSupportedException();
	}

	public IMessage execute(IMessage msg) throws Exception
	{
		// �����鱨��ʱ�����ò�ͬ���ĵ���Ӧʱ��
		String timeout = StringX.null2emptystr(msg.getInLocal(MsgLocalKey.LOCAL_RESPONSE_TIMEOUT),
				String.valueOf(defTimeout));
		return execute(msg, Integer.parseInt(timeout));
	}

	protected String getRepQName(String sndNode, String sndApp)
	{
		if (nodeRepQPostfix) return repQPrefix + sndApp
				+ (StringX.nullity(sndNode) ? StringX.EMPTY_STRING : '.' + sndNode)
				+ synRepQPostfix;
		return repQPrefix + (StringX.nullity(sndNode) ? StringX.EMPTY_STRING : sndNode + '.')
				+ sndApp + synRepQPostfix;
	}

	public IMessage execute(IMessage msg, int timeout) throws Exception
	{
		String sndNode = StringX.null2emptystr(msg.getMsg().get(IMessage.TAG_HEADER_MSG_SNDNODE),
				StringX.EMPTY_STRING).trim();
		String repQName = getRepQName(sndNode, msg.getSndApp());
		// + msg.getMsg().get(IMessage.TAG_HEADER_MSG_SNDAPP).toString() :
		// "REP." + sndNode
		// + '.' + msg.getMsg().get(IMessage.TAG_HEADER_MSG_SNDAPP).toString();
		return execute(msg, reqQName, repQName, timeout);
	}

	public IMessage execute(IMessage msg, String reqQNm, String repQNm, int timeout)
			throws Exception
	{
		if (log.isInfoEnabled()) log.info("shortCnn: " + shortCnn + ", reqQ:" + reqQNm + ", repQ:"
				+ repQNm + ", timeout:" + timeout);
		// added by spc. 2011-05-03 ���������û��������ˮ��, �������ڣ�����ʱ�䣬���Զ�����
		if (msg.isSynCall() && StringX.nullity(msg.getSeqNb()))
		{
			String sn = SystemUtil.getTimeSN(8) + SystemUtil.random(7);
			if (!StringX.nullity(jvm)) sn = (jvm + sn).substring(0, 15);
			msg.setSeqNb(sn);
		}
		if (msg.isSynCall() && StringX.nullity(msg.getSndDt()) && msg.getSeqNb().length() <= 16)
		{ // �����ˮ�Ŵ���16λ����Ҫƥ�����ڣ�MQ��ƥ������д��ǰϵͳ���ں�ʱ��, ��IPAndPortMsgConverterʹ��
			String dt = SystemUtil.getInstance().getCurrentDate(SystemUtil.DF_SALL17);
			msg.setSndDt(dt.substring(0, 8));
			msg.setSndTm(dt.substring(8, 17));
		}
		// added by spc. 2011-05-03 end

		applyESBHdr(msg);
		validate(msg);
		String corId = msg.getMQCorId();
		msg.setCorrelationID(corId.getBytes()); // ��Ϣ������Ҳ������ˮ��

		byte[] reqbuf = converter.serialize(msg);
		if (signature != null)
		{
			Map params = new HashMap();
			params.put("msg", msg);
			params.put("buf", reqbuf);
			byte[] body = MessageUtil.getBody(reqbuf);
			String sig = signature.sign(null, body, params);
			reqbuf = MessageUtil.addSignature2(reqbuf, sig.getBytes());
		}
		try
		{
			if (!msg.isSynCall())
			{ // added by spc 2011-03-11 ������첽���ã�����Ҫ���ܷ�����Ϣ
				access.send(reqQNm, new QueueMessage(msg, reqbuf));
				if (log.isInfoEnabled()) log.info("ASYN call ESB...msgSN:" + msg.getMsgSn());
				return msg;
			}
			QueueMessage qmsg = access.execute(reqQNm, repQNm, new QueueMessage(msg, reqbuf,
					expirySeconds), timeout <= 0 ? defTimeout : timeout);
			// log.info("1");
			// 2012-07-05 ����ʱ����2-3ms
			IMessage repmsg = converter.deserialize(qmsg.buf);
			// log.info("2");
			if (log.isDebugEnabled()) log.debug("rep msg:" + repmsg.toXml(true));
			validate(repmsg);
			if (signature != null)
			{ // 2013-06-20 ������֤ǩ����Ϣ
				Map params = new HashMap();
				params.put("msg", repmsg);
				params.put("buf", qmsg.buf);
				signature.unsign(null, new String(MessageUtil.getSignature2(qmsg.buf)),
						MessageUtil.getBody(qmsg.buf), params);
			}
			return repmsg;
		}
		finally
		{
			if (shortCnn && access != null) access.destroy(); // ����Ƕ����ӣ���ÿ�ν�������
		}
	}

	public void send(IMessage msg) throws Exception
	{
		try
		{
			access.send(reqQName, new QueueMessage(msg, converter.serialize(msg)));
		}
		finally
		{
			if (shortCnn && access != null) access.destroy(); // ����Ƕ����ӣ���ÿ�ν�������
		}
	}

	public IMessage recieve(IMessage msg, int timeout) throws Exception
	{
		String sndNode = StringX.null2emptystr(msg.getMsg().get(IMessage.TAG_HEADER_MSG_SNDNODE),
				StringX.EMPTY_STRING).trim();
		String repQName = getRepQName(sndNode, msg.getSndApp());
		// String repQName = repQPrefix + msg.getSndApp()
		// + (StringX.nullity(sndNode) ? StringX.EMPTY_STRING : '.' + sndNode)
		// + synRepQPostfix;
		try
		{
			QueueMessage qmsg = access.receive(repQName, msg.getMQCorId().getBytes(),
					timeout <= 0 ? defTimeout : timeout);
			IMessage repmsg = converter.deserialize(qmsg.buf);
			if (log.isDebugEnabled()) log.debug("rep msg:" + repmsg.toXml(true));
			return repmsg;
		}
		finally
		{
			if (shortCnn && access != null) access.destroy(); // ����Ƕ����ӣ���ÿ�ν�������
		}
	}

	public void validate(IMessage msg)
	{
		if (validator == null) return;
		String msgCd = msg.getMsgCd();
		if (!msg.isRequestMsg())
		{
			Status s = msg.getStatus();
			if (s != null && s.isFail()) return; // Ӧ�������������У�鱨����
		}
		MessageErrors errors = new MessageErrors(msg);
		errors = validator.validate(msg, errors);
		if (log.isDebugEnabled()) log.debug("check errors:" + errors.toCNode());
		if (errors.getErrorCount() > 0) throw new MsgErrException(errors);
	}

	public static ESB getInstance()
	{
		return esb;
	}

	public synchronized void init() throws Exception
	{
		if (init)
		{
			log.debug("ESB  client has been inited!!!");
			return;
		}
		log.info("ESB  client  init...webos version:" + Common.VERSION() + ",  version date:"
				+ Common.VERSION_DATE());
		// if (resQName == null) resQName = "REP." + node + '.' + appCd;
		if (access == null)
		{
			log.info("maxCnnNum:" + maxCnnNum + ",props:" + props + ",node:" + node + ",appCd:"
					+ appCd);
			MQCnnPool mqCnnPool = new MQCnnPool(maxCnnNum, props, cnnHoldTime, cnnIdleTime,
					cnnAutoIncrease, waitTime);
			// chenjs 2012-08-22 ��ESB������Ĭ���Ա���Queue��״̬����ESB����
			mqCnnPool.setKeepQueue(true);
			mqCnnPool.setName("ESB.GW.MQ");
			mqCnnPool.init();
			access = new BlobQueueAccess(mqCnnPool, creator);
			((BlobQueueAccess) access).setRetryTimes(cnnRetryTimes);
		}

		init = true;
		// ��jvmֹͣʱ���ͷ�ESB�е��߳���, �����û�logoff����jvm down��
		Runtime.getRuntime().addShutdownHook(new Thread()
		{
			public void run()
			{
				log.warn("ESB client will stop because jvm will halt...");
				destory();
			}
		});
		log.info("ESB  client init successfully...");
	}

	public void destory()
	{
		log.info("ESB client shutdown...");
		try
		{
			if (access != null) access.destroy();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		init = false;
		log.info("ESB client shutdown successfully...");
	}

	public BlobMsgHeader newBlobMsgHeader()
	{
		return (BlobMsgHeader) newBlobMsgHeader(new BlobMsgHeader());
	}

	public IBlobMsgHeader newBlobMsgHeader(IBlobMsgHeader header)
	{
		String dt = SystemUtil.getInstance().getCurrentDate(SystemUtil.DF_SALL14);
		String sn = SystemUtil.getTimeSN(8) + SystemUtil.random(7);
		if (!StringX.nullity(jvm)) sn = (jvm + sn).substring(0, 15);
		header.setSeqNb(sn);
		header.setSndAppCd(appCd);
		if (!StringX.nullity(node)) header.setSndMbrCd(node);
		header.setSndDt(dt.substring(0, 8));
		header.setSndTm(dt.substring(8, 14));
		return header;
	}

	public void applyESBHdr(IMessage msg)
	{
		msg.getHeader().applyIf(newMessage().getHeader());
	}

	public Message newMessage()
	{
		Message msg = new Message();
		msg.setVersion(version);

		String dt = SystemUtil.getInstance().getCurrentDate(SystemUtil.DF_SALL17);
		String sn = SystemUtil.getTimeSN(8) + SystemUtil.random(7);
		if (!StringX.nullity(jvm)) sn = (jvm + sn).substring(0, 15);
		ICompositeNode cnode = msg.getMsg();
		cnode.set(IMessage.TAG_HEADER_MSG_SNDAPP, appCd);
		cnode.set(IMessage.TAG_SNDDT, dt.substring(0, 8));
		// modified by spc 2010-12-03. ���ӷ���ʱ��λ��
		cnode.set(IMessage.TAG_SNDTM, dt.substring(8, 17));
		cnode.set(IMessage.TAG_HEADER_MSG_SN, sn);
		if (!StringX.nullity(node)) cnode.set(IMessage.TAG_HEADER_MSG_SNDNODE, node);
		return msg;
	}

	public void init(String esbconfig) throws Exception
	{
		esbconfig = StringX.trim(esbconfig);
		if (log.isDebugEnabled()) log.debug("esbconfig: " + esbconfig);
		if (esbconfig.startsWith("{"))
		{ // chenjs 2013-1-15 �����µ�json��ʽ����
			init((Map) JsonUtil.json2obj(esbconfig));
			return;
		}

		Hashtable params = (Hashtable) StringX.str2map(esbconfig, esbconfig.indexOf('&') >= 0 ? "&"
				: "#", new Hashtable());

		String shortCnn = StringX.null2emptystr(params.get(SHORTCNN_KEY));
		String appCd = StringX.null2emptystr(params.get(APPCD_KEY));
		String node = StringX.null2emptystr(params.get(NODE_KEY));
		String reqQName = StringX.null2emptystr(params.get(REQQNM_KEY));
		String timeout = StringX.null2emptystr(params.get(TIMEOUT_KEY));
		String expiry = StringX.null2emptystr(params.get(EXPIRY_KEY));
		String jvm = StringX.null2emptystr(params.get(JVM_KEY));
		if (!StringX.nullity(jvm)) setJvm(jvm);
		if (!StringX.nullity(shortCnn)) setShortCnn(new Boolean(shortCnn));
		if (!StringX.nullity(appCd)) setAppCd(appCd);
		if (!StringX.nullity(node)) setNode(node);
		if (!StringX.nullity(reqQName)) setReqQName(reqQName);
		if (!StringX.nullity(timeout)) setDefTimeout(Integer.parseInt(timeout));
		if (!StringX.nullity(expiry)) setExpirySeconds(Integer.parseInt(expiry));

		String blobDir = (String) params.get(JVM_BLOB_BASEDIR);
		String blobPath = (String) params.get(JVM_BLOB_PATH);
		if (!StringX.nullity(blobDir) && (getCreator() instanceof DefaultBlobMessageCreator)) ((DefaultBlobMessageCreator) ESB
				.getInstance().getCreator()).setBaseDir(blobDir);
		if (!StringX.nullity(blobPath) && (getCreator() instanceof DefaultBlobMessageCreator)) ((DefaultBlobMessageCreator) ESB
				.getInstance().getCreator()).setPathTemplate(blobPath);

		// ��һ���ӳ�������Ϣ
		String maxCnnNum = StringX.null2emptystr(params.get(MAXCNN_KEY));
		String cnnHoldTime = StringX.null2emptystr(params.get(CNNHOLDTIME_KEY));
		String cnnIdleTime = StringX.null2emptystr(params.get(CNNIDLETIME_KEY));
		if (!StringX.nullity(maxCnnNum)) ESB.getInstance()
				.setMaxCnnNum(Integer.parseInt(maxCnnNum));
		if (!StringX.nullity(cnnHoldTime)) setCnnHoldTime(Integer.parseInt(cnnHoldTime));
		if (!StringX.nullity(cnnIdleTime)) setCnnIdleTime(Integer.parseInt(cnnIdleTime));

		Hashtable qmProps = new Hashtable(params);
		qmProps.remove(APPCD_KEY);
		qmProps.remove(NODE_KEY);
		qmProps.remove(MAXCNN_KEY);
		qmProps.remove(TIMEOUT_KEY);
		qmProps.remove(CNNHOLDTIME_KEY);
		qmProps.remove(CNNIDLETIME_KEY);
		qmProps.remove(REQQNM_KEY);
		qmProps.remove(JVM_KEY);
		qmProps.remove(JVM_BLOB_BASEDIR);
		qmProps.remove(JVM_BLOB_PATH);
		setProps(qmProps);

		init();
		log.info("ESB endpoint init successfully:: esbconfig: " + esbconfig);
	}

	public void init(Map esbconfig) throws Exception
	{
		if (log.isDebugEnabled()) log.debug("esbconfig: " + esbconfig);
		String qmType = StringX.null2emptystr(esbconfig.get(QMTYPE_KEY));
		String shortCnn = StringX.null2emptystr(esbconfig.get(SHORTCNN_KEY));
		String appCd = StringX.null2emptystr(esbconfig.get(APPCD_KEY));
		String node = StringX.null2emptystr(esbconfig.get(NODE_KEY));
		String reqQName = StringX.null2emptystr(esbconfig.get(REQQNM_KEY));
		String timeout = StringX.null2emptystr(esbconfig.get(TIMEOUT_KEY));
		String expiry = StringX.null2emptystr(esbconfig.get(EXPIRY_KEY));
		String jvm = (String) esbconfig.get(JVM_KEY);
		if (!StringX.nullity(jvm)) setJvm(jvm);
		if (!StringX.nullity(shortCnn)) setShortCnn(new Boolean(shortCnn));
		if (!StringX.nullity(appCd)) setAppCd(appCd);
		if (!StringX.nullity(node)) setNode(node);
		if (!StringX.nullity(reqQName)) setReqQName(reqQName);
		if (!StringX.nullity(timeout)) setDefTimeout(Integer.parseInt(timeout));
		if (!StringX.nullity(expiry)) setExpirySeconds(Integer.parseInt(expiry));

		String blobDir = (String) esbconfig.get(JVM_BLOB_BASEDIR);
		String blobPath = (String) esbconfig.get(JVM_BLOB_PATH);
		if (!StringX.nullity(blobDir) && (getCreator() instanceof DefaultBlobMessageCreator)) ((DefaultBlobMessageCreator) getCreator())
				.setBaseDir(blobDir);
		if (!StringX.nullity(blobPath) && (getCreator() instanceof DefaultBlobMessageCreator)) ((DefaultBlobMessageCreator) getCreator())
				.setPathTemplate(blobPath);

		// ��Ⱥͨ��
		List channels = (List) esbconfig.get("channels");
		if (QMTYPE_JMS.equalsIgnoreCase(qmType))
		{ // JMS
			List<JMSCnnPool> cnnpools = new ArrayList<JMSCnnPool>(channels.size());
			for (int i = 0; i < channels.size(); i++)
			{
				Map channel = (Map) channels.get(i);
				JMSCnnPool cnnpool = new JMSCnnPool();
				String maxCnnNum = StringX.null2emptystr(channel.get(MAXCNN_KEY));
				String cnnHoldTime = StringX.null2emptystr(channel.get(CNNHOLDTIME_KEY));
				String cnnIdleTime = StringX.null2emptystr(channel.get(CNNIDLETIME_KEY));
				String keepQueue = StringX.null2emptystr(channel.get(KEEPQUEUE_KEY));
				String borrowOnInit = StringX.null2emptystr(channel.get(BORROWONINIT_KEY));
				if (isShortCnn()) cnnpool.setMax(1); // ���������ӳ�Ĭ��ֻ����һ��
				else if (!StringX.nullity(maxCnnNum)) cnnpool.setMax(Integer.parseInt(maxCnnNum));
				if (!StringX.nullity(cnnHoldTime)) cnnpool.setCnnHoldTime(Integer
						.parseInt(cnnHoldTime));
				if (!StringX.nullity(cnnIdleTime)) cnnpool.setCnnIdleTime(Integer
						.parseInt(cnnIdleTime));
				if (!StringX.nullity(keepQueue)) cnnpool.setKeepQueue(new Boolean(keepQueue));
				cnnpool.setProps(new Hashtable((Map) channel.get("channel")));
				if (StringX.nullity(borrowOnInit)) cnnpool.setBorrowOnInit(false); // Ĭ��Ϊ���������ӣ�ʹ�ù����й���
				else cnnpool.setBorrowOnInit(new Boolean(borrowOnInit));

				cnnpool.init();
				cnnpools.add(cnnpool);
			}
			setAccess(new JMSQueueAccess(cnnpools));
		}
		else
		{ // MQ
			List<MQCnnPool> cnnpools = new ArrayList<MQCnnPool>(channels.size());
			for (int i = 0; i < channels.size(); i++)
			{
				Map channel = (Map) channels.get(i);
				MQCnnPool cnnpool = new MQCnnPool();
				String maxCnnNum = StringX.null2emptystr(channel.get(MAXCNN_KEY));
				String cnnHoldTime = StringX.null2emptystr(channel.get(CNNHOLDTIME_KEY));
				String cnnIdleTime = StringX.null2emptystr(channel.get(CNNIDLETIME_KEY));
				String keepQueue = StringX.null2emptystr(channel.get(KEEPQUEUE_KEY));
				String borrowOnInit = StringX.null2emptystr(channel.get(KEEPQUEUE_KEY));

				if (isShortCnn()) cnnpool.setMax(1); // ���������ӳ�Ĭ��ֻ����һ��
				else if (!StringX.nullity(maxCnnNum)) cnnpool.setMax(Integer.parseInt(maxCnnNum));
				if (!StringX.nullity(cnnHoldTime)) cnnpool.setCnnHoldTime(Integer
						.parseInt(cnnHoldTime));
				if (!StringX.nullity(cnnIdleTime)) cnnpool.setCnnIdleTime(Integer
						.parseInt(cnnIdleTime));
				if (!StringX.nullity(keepQueue)) cnnpool.setKeepQueue(new Boolean(keepQueue));

				cnnpool.setProps(new Hashtable((Map) channel.get("channel")));
				if (isShortCnn()) cnnpool.setBorrowOnInit(false); // ������ģʽ���Ӷ������ӳ�
				cnnpool.init();
				cnnpools.add(cnnpool);
			}
			setAccess(new BlobQueueAccess(cnnpools, creator));
		}
		init();
		log.info("ESB init successfully:: esbconfig: " + esbconfig);
	}

	public void setMaxCnnNum(int maxCnnNum)
	{
		this.maxCnnNum = maxCnnNum;
	}

	public String getAppCd()
	{
		return appCd;
	}

	public void setAppCd(String appCd)
	{
		this.appCd = appCd;
	}

	public String getJvm()
	{
		return jvm;
	}

	public void setJvm(String jvm)
	{
		this.jvm = jvm; // �Ϊ�����ַ�
	}

	public void setVersion(String version)
	{
		this.version = version;
	}

	public void setConverter(XMLConverter converter)
	{
		this.converter = converter;
	}

	public void setProps(Hashtable props)
	{
		this.props = props;
	}

	public ESB()
	{
	}

	public ESB(String esbconfig) throws Exception
	{
		this((Map) JsonUtil.json2obj(esbconfig));
	}

	public ESB(Map esbconfig) throws Exception
	{
		init(esbconfig);
	}

	public ESB(int maxCnnNum, Hashtable props, boolean cnnAutoIncrease, long waitTime)
	{
		this.waitTime = waitTime;
		this.cnnAutoIncrease = cnnAutoIncrease;
		this.maxCnnNum = maxCnnNum;
		this.props = props;
	}

	public void setReqQName(String reqQName)
	{
		this.reqQName = reqQName;
	}

	public void setNode(String node)
	{
		this.node = node;
	}

	public void setDefTimeout(int defTimeout)
	{
		this.defTimeout = defTimeout;
	}

	public IQueueAccess getAccess()
	{
		return access;
	}

	public String getReqQName()
	{
		return reqQName;
	}

	public void setRepQPrefix(String repQPrefix)
	{
		this.repQPrefix = repQPrefix;
	}

	public boolean isShortCnn()
	{
		return shortCnn;
	}

	public void setShortCnn(boolean shortCnn)
	{
		this.shortCnn = shortCnn;
	}

	public String getSynRepQPostfix()
	{
		return synRepQPostfix;
	}

	public void setSynRepQPostfix(String synRepQPostfix)
	{
		this.synRepQPostfix = synRepQPostfix;
	}

	public void setAccess(IQueueAccess access)
	{
		this.access = access;
	}

	public void setQueueAccess(IQueueAccess access)
	{
		this.access = access;
	}

	public void setBlobReqQName(String blobReqQName)
	{
		this.blobReqQName = blobReqQName;
	}

	public IMessageValidator getValidator()
	{
		return validator;
	}

	public IMessageConverter getConverter()
	{
		return converter;
	}

	public void setConverter(IMessageConverter converter)
	{
		this.converter = converter;
	}

	public void setValidator(IMessageValidator validator)
	{
		this.validator = validator;
	}

	public void setCnnHoldTime(int cnnHoldTime)
	{
		this.cnnHoldTime = cnnHoldTime;
	}

	public void setSignature(ISignature signature)
	{
		this.signature = signature;
	}

	public int getCnnIdleTime()
	{
		return cnnIdleTime;
	}

	public void setCnnIdleTime(int cnnIdleTime)
	{
		this.cnnIdleTime = cnnIdleTime;
	}

	public IBlobMessageCreator getCreator()
	{
		return creator;
	}

	public void setCreator(IBlobMessageCreator creator)
	{
		this.creator = creator;
	}

	public void setCnnRetryTimes(int cnnRetryTimes)
	{
		this.cnnRetryTimes = cnnRetryTimes;
	}

	public void setWaitTime(long waitTime)
	{
		this.waitTime = waitTime;
	}

	public void setCnnAutoIncrease(boolean cnnAutoIncrease)
	{
		this.cnnAutoIncrease = cnnAutoIncrease;
	}

	public boolean isNodeRepQPostfix()
	{
		return nodeRepQPostfix;
	}

	public void setNodeRepQPostfix(boolean nodeRepQPostfix)
	{
		this.nodeRepQPostfix = nodeRepQPostfix;
	}

	public int getExpirySeconds()
	{
		return expirySeconds;
	}

	public void setExpirySeconds(int expirySeconds)
	{
		this.expirySeconds = expirySeconds;
	}
}
