package spc.webos.flownode.impl;

import spc.webos.data.IMessage;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;

public class BlankAFNode extends AbstractFNode
{
	public BlankAFNode()
	{
		name = "blank";
	}

	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		log.info("Blank...");
		return null;
	}
}
