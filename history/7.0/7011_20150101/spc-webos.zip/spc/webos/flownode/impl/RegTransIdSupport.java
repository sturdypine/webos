package spc.webos.flownode.impl;

import java.util.Map;
import java.util.regex.Pattern;

import spc.webos.data.IMessage;
import spc.webos.flownode.ISupport;

/**
 * �������������ʽƥ��ģʽ
 * 
 * @author spc
 * 
 */
public class RegTransIdSupport implements ISupport
{
	public boolean support(IMessage msg)
	{
		String msgCd = msg.getMsgCd();
		for (int i = 0; i < regs.length; i++)
		{
			if (regs[i].startsWith("-")
					&& Pattern.compile(regs[i].substring(1)).matcher(msgCd)
							.matches()) return false; // ��֧�ֵĽ������������ʽ
			if (Pattern.compile(regs[i]).matcher(msgCd).matches()) return true;
		}
		return false;
	}

	public void init() throws Exception
	{
		if (name != null) SUPPORT.put(name, this);
	}

	String[] regs;
	String name;

	public void setRegs(String[] regs)
	{
		this.regs = regs;
	}

	public boolean changeStatus(Map param)
	{
		return false;
	}

	public Map checkStatus(Map param)
	{
		return null;
	}

	public String getName()
	{
		return name;
	}

	public void refresh() throws Exception
	{
	}

	public void setName(String name)
	{
		this.name = name;
	}
}
