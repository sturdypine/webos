package spc.webos.flownode.impl;

import spc.webos.constant.MQAttributes;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.data.converter.XMLConverter2;
import spc.webos.flownode.AbstractFNode;
import spc.webos.flownode.IFlowContext;
import spc.webos.queue.IQueueAccess;
import spc.webos.queue.QueueMessage;
import spc.webos.security.ISignature;
import spc.webos.util.StringX;

public class QueuePutAFNode extends AbstractFNode
{
	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		String qname = StringX.nullity(this.qname) ? (String) msg
				.getInLocal(MQAttributes.SEND_QNAME) : this.qname;
		if (StringX.nullity(qname))
		{
			log.warn("target qname is null!!!");
			return null;
		}

		Object mqmsg = getQMessage(msg, cxt);
		String[] qnames = StringX.split(qname, StringX.COMMA);
		for (int i = 0; i < qnames.length; i++)
		{
			String qn = StringX.trim(qnames[i]);
			if (StringX.nullity(qn)) continue;
			try
			{
				send(qn, mqmsg);
				if (log.isDebugEnabled()) log.debug("suc to put Q: " + qn);
			}
			catch (Exception e)
			{
				if (logex) log.warn("err to put MQ: " + qn, e);
				else
				{
					log.warn("fail to put MQ " + qn);
					throw e;
				}
			}
		}
		return null;
	}

	protected void send(String qname, Object qmsg) throws Exception
	{
		queueAccess.send(qname, (QueueMessage) qmsg);
	}

	protected Object getQMessage(IMessage msg, IFlowContext cxt) throws Exception
	{
		QueueMessage qmsg = (QueueMessage) msg.getInLocal(MsgLocalKey.MQPUT_QMSG_KEY);
		if (qmsg != null) return qmsg;
		// send current msg
		qmsg = new QueueMessage(converter.serialize(msg));
		if (msg.getCorrelationID() != null)
		{
			qmsg.correlationId = msg.getCorrelationID();
			if (log.isDebugEnabled()) log.debug("correlationId in msg: "
					+ new String(qmsg.correlationId));
		}
		else
		{
			qmsg.correlationId = msg.getMQCorId().getBytes();
			if (log.isDebugEnabled()) log.debug("correlationId: " + new String(qmsg.correlationId));
		}
		if (msg.getExpirySeconds() > 0) qmsg.expirySeconds = msg.getExpirySeconds();
		return qmsg;
	}

	protected IMessageConverter converter = XMLConverter2.getInstance();
//	protected int retryTimes = 1, retryInterval = 100;
	protected String qname;
	protected IQueueAccess queueAccess;
	protected boolean logex = true; // ��������쳣��־��MQPUT�ڵ㽫����throw exeption
	protected ISignature signature;

	public void setConverter(IMessageConverter converter)
	{
		this.converter = converter;
	}

	public String getQname()
	{
		return qname;
	}

	public void setQname(String qname)
	{
		this.qname = qname;
	}

	public void setLogex(boolean logex)
	{
		this.logex = logex;
	}

	public void setQueueAccess(IQueueAccess queueAccess)
	{
		this.queueAccess = queueAccess;
	}

	public void setSignature(ISignature signature)
	{
		this.signature = signature;
	}
}
