package spc.webos.flownode.impl;

import java.util.Map;

import spc.webos.buffer.IBuffer;
import spc.webos.config.AppConfig;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.MessageAttr;
import spc.webos.flownode.IFlowContext;
import spc.webos.util.StringX;

/**
 * ����Ϣ�ŵ�ָ����buffer��
 * 
 * @author spc
 * 
 */
public class Msg2BufferAFNode extends SendResponseAFNode
{
	protected IBuffer buf;
	protected String bufName;
	protected String msgAttrMdl = "msgattr";

	public Object execute(IMessage msg, IFlowContext cxt) throws Exception
	{
		if (msg.getAttr() == null)
		{
			Map attr = AppConfig.getInstance().getModule(msgAttrMdl);
			String strAttr = attr == null ? null : (String) attr.get(msg.getMsgCd());
			if (!StringX.nullity(strAttr))
			{
				msg.setAttr(new MessageAttr(strAttr));
				if (log.isInfoEnabled()) log.info("AppConfig(" + msgAttrMdl + ") msgCd("
						+ msg.getMsgCd() + ") attr:[" + strAttr + "]");
			}
		}
		if (buf != null && !msg.getLocal().containsKey(MsgLocalKey.LOCAL_REP_BUFFER)) msg
				.setInLocal(MsgLocalKey.LOCAL_REP_BUFFER, buf);
		if (!StringX.nullity(bufName)
				&& !msg.getLocal().containsKey(MsgLocalKey.LOCAL_REP_BUFFER_NAME)) msg.setInLocal(
				MsgLocalKey.LOCAL_REP_BUFFER_NAME, bufName);
		super.execute(msg, cxt);
		return null;
	}

	// protected void send(IMessage msg) throws Exception
	// {
	// IBuffer repBuf = (IBuffer)
	// msg.getLocal().get(MsgLocalKey.LOCAL_REP_BUFFER); // ��ǰ�����Ƿ�ָ����Ӧ��buffer
	// if (buf == null && bufName != null) buf = (IBuffer)
	// IBuffer.BUFFERS.get(bufName);
	// if (repBuf == null) repBuf = buf; // �����ǰ����û��ָ��Ӧ��buffer����ʹ�����õ�Ĭ��buffer
	//
	// if (log.isInfoEnabled()) log.info("send msg to buf: " + repBuf.getName()
	// + ", buf.size:"
	// + repBuf.size());
	// if (converter != null)
	// {
	// repBuf.put(new QueueMessage(msg, converter.serialize(msg),
	// msg.getMsgSn(), msg
	// .getCorrelationID(), null));
	// }
	// else repBuf.put(msg);
	// msg.setInLocal(MsgLocalKey.SND_BUF, Boolean.TRUE);
	// }

	public void setBuf(IBuffer buf)
	{
		this.buf = buf;
	}

	public void setMsgAttrMdl(String msgAttrMdl)
	{
		this.msgAttrMdl = msgAttrMdl;
	}

	public void setBufName(String bufName)
	{
		this.bufName = bufName;
	}
}
