package spc.webos.buffer;

import java.util.LinkedList;
import java.util.List;

public class CommonBuffer extends AbstractBuffer
{
	LinkedList queue = new LinkedList();

	public CommonBuffer()
	{
	}

	public CommonBuffer(String name)
	{
		this(name, DEFAULT_CAP);
	}

	public CommonBuffer(String name, int cap)
	{
		this.name = name;
		this.cap = cap;
	}

	public int size()
	{
		return queue.size();
	}

	public synchronized Object[] toArray()
	{
		return queue.toArray();
	}

	public synchronized List removeAll()
	{
		LinkedList q = queue;
		queue = new LinkedList();
		notifyAll();
		return q;
	}

	public void add(Object v)
	{
		queue.add(v);
	}

	public void addFirst(Object v)
	{
		queue.addFirst(v);
	}

	public Object pollFromBuf()
	{
		return queue.poll();
	}
}
