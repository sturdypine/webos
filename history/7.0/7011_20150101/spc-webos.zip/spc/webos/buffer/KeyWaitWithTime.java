package spc.webos.buffer;

import spc.webos.cache.WaitWithTime;

public class KeyWaitWithTime extends WaitWithTime
{
	String key;

	public KeyWaitWithTime(Object target, String key, long timeout)
	{
		this.target = target;
		this.key = key;
		this.timeout = timeout;
	}

	public KeyWaitWithTime(String key, long timeout)
	{
		this(null, key, timeout);
	}

	public boolean condition()
	{
		return ((MsgCacheBuffer) target).get(key) == null;
	}
}
