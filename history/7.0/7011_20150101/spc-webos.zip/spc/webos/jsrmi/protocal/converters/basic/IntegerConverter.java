package spc.webos.jsrmi.protocal.converters.basic;

import java.math.BigInteger;

import spc.webos.jsrmi.protocal.ProtocalTag;
import spc.webos.jsrmi.protocal.converters.Converter;

public class IntegerConverter extends AbstractBasicConverter implements Converter
{
	protected String getType()
	{
		return ProtocalTag.TAG_INT;
	}

	public boolean canConvert(Class clazz)
	{
		if (clazz == null) return false;
		return clazz.equals(int.class) || clazz == long.class || clazz == Long.class
				|| clazz.equals(Integer.class) || clazz.equals(short.class)
				|| clazz.equals(Short.class) || clazz.equals(byte.class)
				|| clazz.equals(Byte.class);
	}

	public Object fromString(String string)
	{
		return Integer.valueOf(string);
	}
}
