
package spc.webos.jsrmi.protocal.util;

public class ClassFieldNamePair {
	private final Class type;
	private final String fieldName;

	public ClassFieldNamePair(Class type, String fieldName) {
		this.type = type;
		this.fieldName = fieldName;
	}

	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		ClassFieldNamePair that = (ClassFieldNamePair) obj;

		return this.type.equals(that.type)
				&& this.fieldName.equals(that.fieldName);
	}

	public int hashCode() {
		return this.type.hashCode() + this.fieldName.hashCode();
	}
}
