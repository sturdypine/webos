
package spc.webos.jsrmi.protocal.io;

public class StreamException extends RuntimeException {

	private static final long serialVersionUID = -1262255394454503153L;

	public StreamException() {
		super();
	}

	public StreamException(String message, Throwable cause) {
		super(message, cause);
	}

	public StreamException(String message) {
		super(message);
	}

	public StreamException(Throwable cause) {
		super(cause);
	}
	
}
