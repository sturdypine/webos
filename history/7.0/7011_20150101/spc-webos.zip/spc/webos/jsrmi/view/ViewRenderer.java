package spc.webos.jsrmi.view;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import spc.webos.jsrmi.view.impl.BeautifulPathResolver;

public class ViewRenderer {

	public void render(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		
		String info = request.getPathInfo();
		PathResolver resolver = new BeautifulPathResolver(info);
		
		String service = resolver.getRequestService();
		String[] params = resolver.getParameters();
		
		if (service.equals("view")) {
			
			new JspViewRender().render(params, request, response);
		}
		
	}
}
