package spc.webos.jsrmi.service;

public class ServiceCreationFailException extends RuntimeException {

	private static final long serialVersionUID = -8751690886216464063L;

	public ServiceCreationFailException() {
		super();
	}

	public ServiceCreationFailException(String message, Throwable cause) {
		super(message, cause);
	}

	public ServiceCreationFailException(String message) {
		super(message);
	}

	public ServiceCreationFailException(Throwable cause) {
		super(cause);
	}
	
}
