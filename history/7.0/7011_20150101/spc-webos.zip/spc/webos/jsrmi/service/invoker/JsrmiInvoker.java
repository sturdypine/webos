package spc.webos.jsrmi.service.invoker;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import spc.webos.constant.Common;
import spc.webos.exception.AppException;
import spc.webos.jsrmi.protocal.JsrmiCall;
import spc.webos.jsrmi.protocal.JsrmiProtocal;
import spc.webos.jsrmi.protocal.Signature;
import spc.webos.jsrmi.service.ServiceInvocationException;
import spc.webos.log.Log;
import spc.webos.util.FileUtil;

public class JsrmiInvoker implements ServiceInvoker
{

	private Map methodCache = new HashMap();
	private static JsrmiInvoker instance;
	static final Log log = Log.getLogger(JsrmiInvoker.class);

	private JsrmiInvoker()
	{
	}

	public static JsrmiInvoker getInstance()
	{
		if (instance == null)
		{
			instance = new JsrmiInvoker();
		}
		return instance;
	}

	/**
	 * Invoke the service. Note: this method is for appserver
	 * 
	 * @param service
	 * @param inputStream
	 * @param outputStream
	 */
	public void invoke(Object service, InputStream inputStream, Writer writer)
	{
		if (log.isDebugEnabled())
		{
			try
			{
				byte[] buf = FileUtil.is2bytes(inputStream);
				log.debug("jsrmi request xml:" + new String(buf, Common.CHARSET_UTF8));
				inputStream = new ByteArrayInputStream(buf);
			}
			catch (Exception e)
			{
				log.warn("debug jsrmi request xml:", e);
			}
		}
		// try
		// {
		// int ch = inputStream.read();
		// StringBuffer strBuf = new StringBuffer();
		// while (ch != -1)
		// {
		// strBuf.append((char)ch);
		// ch = inputStream.read();
		// }
		// System.out.println("Call: "+strBuf);
		// }
		// catch (Exception e){e.printStackTrace();}
		JsrmiCall call = JsrmiProtocal.getInstance().unmarshall(inputStream);
		if (log.isDebugEnabled())
		{
			log.debug("service = " + service.getClass() + ", methodName=" + call.getMethodName());
			Object[] args = call.getArguments();
			if (args != null) for (int i = 0; i < args.length; i++)
				log.debug("param class(" + i + "), clazz: " + args[i].getClass() + ", value: "
						+ args[i].toString());
			// log.debug(message)
		}
		Signature signature = new Signature(service.getClass(), call.getMethodName(),
				call.getArgumentTypes());

		Method method = lookupMethod(service, call, signature);
		// if (methodCache.get(signature) != null)
		// {
		// method = (Method) methodCache.get(signature);
		// }
		// else
		// {
		// method = lookupMethod(service, call, signature);
		// }

		if (method == null) throw new ServiceInvocationException(("cannot find the method " + call
				+ " for " + service.getClass().getName()));

		Object result = null;
		try
		{
			if (log.isDebugEnabled()) log.debug("service=" + service + ",method="
					+ method.getName() + "," + call.getArguments());
			result = method.invoke(service, call.getArguments());
			log.debug(result);
		}
		catch (InvocationTargetException e)
		{
			result = e.getTargetException();
			Throwable t = e.getTargetException();
			if (!(t instanceof AppException) || ((AppException) t).isSysLevel())
			{
				log.error("JsrmiInvoker:", t);
			}
			// if (result instanceof RuntimeException) throw (RuntimeException)
			// result;
			// else throw new RuntimeException(e);
		}
		catch (Exception e)
		{
			throw new ServiceInvocationException(e);
		}

		JsrmiProtocal.getInstance().marshall(result, writer);
	}

	public void invoke(Object service, Reader reader, Writer writer)
	{
		JsrmiCall call = JsrmiProtocal.getInstance().unmarshall(reader);
		Signature signature = new Signature(service.getClass(), call.getMethodName(),
				call.getArgumentTypes());
		Method method = lookupMethod(service, call, signature);
		// if (methodCache.get(signature) != null)
		// {
		// method = (Method) methodCache.get(signature);
		// }
		// else
		// {
		// method = lookupMethod(service, call, signature);
		// }

		if (method == null) { throw new ServiceInvocationException(("cannot find the method "
				+ call + " for " + service.getClass().getName())); }

		Object result = null;
		try
		{
			result = method.invoke(service, call.getArguments());
		}
		catch (IllegalArgumentException e)
		{
			throw new ServiceInvocationException(e);
		}
		catch (IllegalAccessException e)
		{
			throw new ServiceInvocationException(e);
		}
		catch (InvocationTargetException e)
		{
			result = e.getTargetException();
		}

		JsrmiProtocal.getInstance().marshall(result, writer);
	}

	public synchronized Method lookupMethod(Object service, JsrmiCall call, Signature signature)
	{
		// System.out.println("service="+service+",signature="+signature);
		Method m = (Method) methodCache.get(signature);
		if (m != null) return m;

		Method[] methods = service.getClass().getMethods();
		List matchedResults = new ArrayList();
		for (int i = 0; i < methods.length; i++)
		{
			Method method = methods[i];
			if (method.getName().equals(call.getMethodName()))
			{
				Class[] parameterTypes = method.getParameterTypes();
				int matched = 0, weight = 0;
				if (parameterTypes.length == call.getArguments().length)
				{
					for (int j = 0; j < parameterTypes.length; j++)
					{
						int matchWeight = parameterAssignable(parameterTypes[j],
								call.getArguments()[j].getClass());
						if (matchWeight > 0)
						{
							matched++;
							weight += matchWeight;
						}
					}
				}
				if (matched == parameterTypes.length)
				{
					methodCache.put(signature, method);
					matchedResults.add(new MatchedResult(weight, method));
				}
			}
		}

		if (matchedResults.size() == 0)
		{
			return null;
		}
		else if (matchedResults.size() == 1)
		{
			methodCache.put(signature, ((MatchedResult) matchedResults.get(0)).getMethod());
			return ((MatchedResult) matchedResults.get(0)).getMethod();
		}
		else
		{
			Collections.sort(matchedResults);
			methodCache.put(signature, ((MatchedResult) matchedResults.get(0)).getMethod());
			return ((MatchedResult) matchedResults.get(0)).getMethod();
		}

	}

	private int parameterAssignable(Class targetType, Class sourceType)
	{
		if (targetType.equals(sourceType)) return 6;
		if (targetType.isPrimitive())
		{
			// System.out.println("targetType="+targetType);
			Class clazz = getWrapperClass(targetType);
			if (clazz == null)
			{
				log.warn("primitive class is null by " + targetType.getName());
				return 0;
			}
			if (clazz.equals(sourceType)) return 5;
			else if (Number.class.isAssignableFrom(clazz)
					&& Number.class.isAssignableFrom(sourceType)) return 4;
		}
		if (targetType.isAssignableFrom(sourceType)) return 3;

		return 0;
	}

	private Class getWrapperClass(Class primitiveClass)
	{
		return (Class) PRIMITIVE_CLASS.get(primitiveClass);
	}

	public static Map PRIMITIVE_CLASS = new HashMap();
	static
	{
		PRIMITIVE_CLASS.put(int.class, Integer.class);
		PRIMITIVE_CLASS.put(long.class, Integer.class);
		PRIMITIVE_CLASS.put(double.class, Double.class);
		PRIMITIVE_CLASS.put(float.class, Double.class);
		PRIMITIVE_CLASS.put(boolean.class, Boolean.class);
	}

}
