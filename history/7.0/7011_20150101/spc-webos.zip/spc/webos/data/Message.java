package spc.webos.data;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

import spc.webos.constant.MsgLocalKey;
import spc.webos.data.converter.NodeConverterFactory;
import spc.webos.data.converter.XMLConverter;
import spc.webos.data.converter.XMLConverter2;
import spc.webos.flownode.IDelayTask;
import spc.webos.util.StringX;

public class Message extends AbstractMessage
{
	private static final long serialVersionUID = 1L;
	protected ICompositeNode transaction;
	protected ICompositeNode header;
	protected ICompositeNode request;
	protected ICompositeNode response;
	protected MessageAttr attr; // ��ǰ��������
	protected MessageAttr refAttr; // ��ǰ�ο���������
	protected byte[] correlationID;
	protected int expirySeconds;
	protected long start; // ��ʼ����ʱ��
	protected long end; // ��������ʱ��

	// ����ʹ��
	protected Map local = new HashMap(); // ��Ϣ���ı��ػ���
	protected boolean containExFnode; // �Ƿ����쳣������
	protected Throwable ex; // �����е��쳣
	protected boolean exitFlow = false; // �Ƿ�������ֹ����

	public String getOriginalBytesPlainStr()
	{
		return StringX.trim(StringX.null2emptystr(transaction.get(IMessage.TAG_ORIGINALBYTES)));
	}

	public void setOriginalBytesPlainStr(String original)
	{
		if (!StringX.nullity(original)) transaction.set(IMessage.TAG_ORIGINALBYTES, original);
		else transaction.remove(IMessage.TAG_ORIGINALBYTES);
	}

	public MessageAttr getAttr()
	{
		return attr;
	}

	public void setAttr(MessageAttr attr)
	{
		this.attr = attr;
	}

	public MessageAttr getRefAttr()
	{
		return refAttr;
	}

	public void setRefAttr(MessageAttr refAttr)
	{
		this.refAttr = refAttr;
	}

	public String getVersion()
	{
		return StringX.trim(StringX.null2emptystr(findInHeader(IMessage.TAG_HEADER_VERSION)));
	}

	public void setVersion(String version)
	{
		setInHeader(Message.TAG_HEADER_VERSION, version);
	}

	public long getStart()
	{
		return start;
	}

	public void setStart(long start)
	{
		this.start = start;
	}

	public long getEnd()
	{
		return end;
	}

	public void setEnd(long end)
	{
		this.end = end;
	}

	public String getSndDt()
	{
		return StringX.trim(StringX.null2emptystr(getMsg().get(IMessage.TAG_SNDDT)));
	}

	public void setSndDt(String sndDt)
	{
		getMsg().set(TAG_SNDDT, sndDt);
	}

	public String getSndTm()
	{
		return StringX.trim(StringX.null2emptystr(getMsg().get(IMessage.TAG_SNDTM)));
	}

	public void setSndTm(String sndTm)
	{
		getMsg().set(TAG_SNDTM, sndTm);
	}

	public String getRcvAppSN()
	{
		return StringX.trim(StringX.null2emptystr(getMsg().get(IMessage.TAG_HEADER_MSG_RCVAPPSN)));
	}

	public void setRcvAppSN(String rcvAppSN)
	{
		getMsg().set(TAG_HEADER_MSG_RCVAPPSN, rcvAppSN);
	}

	public String getSeqNb()
	{
		return StringX.trim(StringX.null2emptystr(getMsg().get(IMessage.TAG_HEADER_MSG_SN)));
	}

	public void setSeqNb(String seqNb)
	{
		getMsg().set(TAG_HEADER_MSG_SN, seqNb);
	}

	public String getRefSndDt()
	{
		return StringX.trim(StringX.null2emptystr(getMsg().get(IMessage.TAG_HEADER_MSG_REFSNDDT)));
	}

	public void setRefSndDt(String refSndDt)
	{
		getMsg().set(TAG_HEADER_MSG_REFSNDDT, refSndDt);
	}

	public void setRefSndNode(String refSndNode)
	{
		getMsg().set(TAG_HEADER_MSG_REFSNDNODE, refSndNode);
	}

	public void setRefSndApp(String refSndApp)
	{
		getMsg().set(TAG_HEADER_MSG_REFSNDAPP, refSndApp);
	}

	public void setRcvNode(String rcvNode)
	{
		getMsg().set(TAG_HEADER_MSG_RCVNODE, rcvNode);
	}

	public void setSndNode(String sndNode)
	{
		getMsg().set(TAG_HEADER_MSG_SNDNODE, sndNode);
	}

	public void setSndAppCd(String sndAppCd)
	{
		getMsg().set(TAG_HEADER_MSG_SNDAPP, sndAppCd);
	}

	public void setRcvAppCd(String rcvAppCd)
	{
		getMsg().set(TAG_HEADER_MSG_RCVAPP, rcvAppCd);
	}

	public String getRefSeqNb()
	{
		return StringX.trim(StringX.null2emptystr(getMsg().get(IMessage.TAG_HEADER_MSG_REFSNDSN)));
	}

	public void setRefSeqNb(String refSeqNb)
	{
		getMsg().set(TAG_HEADER_MSG_REFSNDSN, refSeqNb);
	}

	public String getSndNode()
	{
		return StringX.trim(StringX.null2emptystr(getMsg().get(IMessage.TAG_HEADER_MSG_SNDNODE)));
	}

	public String getRcvNode()
	{
		return StringX.trim(StringX.null2emptystr(getMsg().get(IMessage.TAG_HEADER_MSG_RCVNODE)));
	}

	public String getSndApp()
	{
		return StringX.trim(StringX.null2emptystr(getMsg().get(IMessage.TAG_HEADER_MSG_SNDAPP)));
	}

	public String getRefSndApp()
	{
		return StringX.trim(StringX.null2emptystr(getMsg().get(IMessage.TAG_HEADER_MSG_REFSNDAPP)));
	}

	public String getRcvApp()
	{
		return StringX.trim(StringX.null2emptystr(getMsg().get(IMessage.TAG_HEADER_MSG_RCVAPP)));
	}

	public String getRefSndNode()
	{
		return StringX
				.trim(StringX.null2emptystr(getMsg().get(IMessage.TAG_HEADER_MSG_REFSNDNODE)));
	}

	public String getReplyToQ()
	{
		return StringX.trim(StringX.null2emptystr(getMsg().get(IMessage.TAG_HEADER_MSG_REPLYTOQ)));
	}

	public void setReplyToQ(String replyToQ)
	{
		getMsg().set(TAG_HEADER_MSG_REPLYTOQ, replyToQ);
	}

	public String getSignature()
	{
		// IAtomNode node = (IAtomNode)
		// transaction.getNode(IMessage.TAG_SIGNATURE);
		// String sig = node == null ? StringX.EMPTY_STRING :
		// StringX.trim(node.toString());
		// 700 2013-05-09 ǩ����Ϣ������header
		String sig = StringX.null2emptystr(findInHeader(IMessage.TAG_SIGNATURE));
		// added by chenjs 2011-11-10. ȥ��ǩ����Ϣ�е�\t, \n, �ո�
		return StringX.replaceAll(StringX.replaceAll(StringX.replaceAll(sig, "\t", ""), "\n", ""),
				" ", "");
	}

	public void setSignature(String signature)
	{
		setInHeader(Message.TAG_SIGNATURE, signature); // ��signature������header��
		// transaction.set(Message.TAG_SIGNATURE, signature);
	}

	public String getLocation()
	{
		return StringX.null2emptystr(transaction.getNode(IMessage.TAG_LOCATION));
	}

	public void setLocation(String location)
	{
		transaction.set(Message.TAG_LOCATION, location);
	}

	public void setCn2utf8(boolean cn2utf8)
	{
		setInHeader(TAG_CN2UTF8, cn2utf8 ? AtomNode.TRUE : AtomNode.FALSE);
	}

	// ������������
	public boolean isCn2utf8()
	{
		return ((IAtomNode) header.find(TAG_HEADER, TAG_CN2UTF8, INode.TYPE_BOOL, AtomNode.FALSE))
				.booleanValue();
	}

	public byte[] getCorrelationID()
	{
		return correlationID;
	}

	public void setCorrelationID(byte[] correlationID)
	{
		this.correlationID = correlationID;
	}

	public int getExpirySeconds()
	{
		return expirySeconds;
	}

	public void setExpirySeconds(int expirySeconds)
	{
		this.expirySeconds = expirySeconds;
	}

	// for local
	public void addDelayTask(IDelayTask delayTask)
	{
		if (delayTask == null) return;
		List list = getDelayTask();
		if (!list.contains(delayTask)) list.add(delayTask);
	}

	public List getDelayTask()
	{
		List tasks = (List) getInLocal(MsgLocalKey.LOCAL_DELAY_TASKS);
		if (tasks == null) setInLocal(MsgLocalKey.LOCAL_DELAY_TASKS, tasks = new ArrayList());
		return tasks;
	}

	public Object getBplVariable(String key)
	{
		Map variables = (Map) (getInLocal(MsgLocalKey.LOCAL_BPL_VARIABLES));
		if (variables != null) return variables.get(key);
		return null;
	}

	public void setBplVariable(String key, Object value)
	{
		Map variables = (Map) (getInLocal(MsgLocalKey.LOCAL_BPL_VARIABLES));
		if (variables != null) variables.put(key, value);
	}

	public void removeBplVariable(String key)
	{
		Map variables = (Map) getInLocal(MsgLocalKey.LOCAL_BPL_VARIABLES);
		if (variables != null) variables.remove(key);
	}

	public Object getMQAttribute(String key)
	{
		Map variables = (Map) (getInLocal(MsgLocalKey.LOCAL_MQ_ATTRIBUTE));
		if (variables != null) return variables.get(key);
		return null;
	}

	public void setMQAttribute(String key, Object value)
	{
		Map variables = (Map) (getInLocal(MsgLocalKey.LOCAL_MQ_ATTRIBUTE));
		if (variables != null) variables.put(key, value);
	}

	public void removeMQAttribute(String key)
	{
		Map variables = (Map) getInLocal(MsgLocalKey.LOCAL_MQ_ATTRIBUTE);
		if (variables != null) variables.remove(key);
	}

	public Object getMBAttribute(String key)
	{
		Map variables = (Map) (getInLocal(MsgLocalKey.LOCAL_MB_ATTRIBUTE));
		if (variables != null) return variables.get(key);
		return null;
	}

	public void setMBAttribute(String key, Object value)
	{
		Map variables = (Map) (getInLocal(MsgLocalKey.LOCAL_MB_ATTRIBUTE));
		if (variables != null) variables.put(key, value);
	}

	public void removeMBAttribute(String key)
	{
		Map variables = (Map) getInLocal(MsgLocalKey.LOCAL_MB_ATTRIBUTE);
		if (variables != null) variables.remove(key);
	}

	public String getRefMsgCd()
	{
		return StringX.trim(StringX.null2emptystr(getMsg().getNode(TAG_HEADER_MSG_REFMSGCD)));
	}

	public void setRefMsgCd(String refMsgCd)
	{
		getMsg().set(TAG_HEADER_MSG_REFMSGCD, refMsgCd);
	}

	public String getMsgCd()
	{
		return StringX.trim(String.valueOf(getMsg().get(TAG_HEADER_MSG_CD)));
	}

	public void setMsgCd(String msgCd)
	{
		if (header == null) return;
		getMsg().set(TAG_HEADER_MSG_CD, msgCd);
	}

	public String getCallType()
	{
		String callType = StringX.trim(StringX.null2emptystr(getMsg().getNode(
				TAG_HEADER_MSG_REFCALLTYP)));
		if (!StringX.nullity(callType)) return callType; // Ϊ�˼�����ǰ�еµ����������ʹ��refcalltype��2013-08-10
		// 700 2013-06-01 ����refcalltype
		return StringX.trim(StringX.null2emptystr(getMsg().getNode(TAG_HEADER_CALLTYPE)));
	}

	public void setCallType(String callType)
	{
		getMsg().set(TAG_HEADER_CALLTYPE, callType);
	}

	public String getRefCallType()
	{
		return StringX.trim(StringX.null2emptystr(getMsg().getNode(TAG_HEADER_MSG_REFCALLTYP)));
	}

	public void setRefCallType(String callType)
	{
		if (StringX.nullity(callType)) getMsg().remove(TAG_HEADER_MSG_REFCALLTYP);
		else getMsg().set(TAG_HEADER_MSG_REFCALLTYP, callType);
	}

	public void setSn(String sn)
	{
		if (header == null) return;
		getMsg().set(TAG_HEADER_MSG_SN, sn);
	}

	public void mustContain(Collection paths)
	{
		if (paths == null) return;
		Iterator p = paths.iterator();
		while (p.hasNext())
		{
			String path = (String) p.next();
			transaction.find(StringX.EMPTY_STRING, path, INode.TYPE_UNDEFINED, false);
		}
	}

	public void mustContain(String[] paths)
	{
		if (paths == null) return;
		for (int i = 0; i < paths.length; i++)
			transaction.find(StringX.EMPTY_STRING, paths[i], INode.TYPE_UNDEFINED, false);
	}

	public void setStatus(Status status)
	{
		header.set(IMessage.TAG_HEADER_STATUS, status);
	}

	// �������� end

	// msg, pnt, esb(request,response)
	public ICompositeNode getHeaderExt()
	{
		INode ext = header.find(TAG_HEADER_EXT);
		// 700, chenjs 2013-09-22 ���Ϊ���򴴽�һ��headerext����
		if (ext == null) return header.create(TAG_HEADER_EXT);
		if (ext instanceof ICompositeNode) return (ICompositeNode) ext;
		try
		{
			return XMLConverter2.getInstance().deserialize2composite(
					StringX.decodeBase64(ext.toString().getBytes()));
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
	}

	public void setHeaderExt(ICompositeNode hdrExt)
	{
		header.set(TAG_HEADER_EXT, hdrExt);
	}

	public String getHeaderExtStr()
	{
		return StringX.null2emptystr(header.findAtom(TAG_HEADER_EXT, null));
	}

	public void setHeaderExt(String hdrExt)
	{
		header.set(TAG_HEADER_EXT, hdrExt);
	}

	public void setInHeaderExt(String key, Object val)
	{
		header.create(TAG_HEADER_EXT).set(key, val);
	}

	public INode findInHeaderExt(String key)
	{
		return header.create(TAG_HEADER_EXT).find(key);
	}

	public ICompositeNode getMsg()
	{
		return header.create(TAG_HEADER_MSG);
	}

	public ICompositeNode setMsg(ICompositeNode msg)
	{
		return (ICompositeNode) header.set(TAG_HEADER_MSG, msg);
	}

	public ICompositeNode getMsgLocal()
	{
		return transaction.create(TAG_LOCAL);
	}

	public ICompositeNode setMsgLocal(ICompositeNode local)
	{
		if (local == null || local.size() == 0)
		{
			transaction.remove(TAG_LOCAL);
			return null;
		}
		return (ICompositeNode) transaction.set(TAG_LOCAL, local);
	}

	// public ICompositeNode getPnt()
	// {
	// return header.create(TAG_HEADER_PNT);
	// }
	//
	// public ICompositeNode setPnt(ICompositeNode pnt)
	// {
	// return (ICompositeNode) header.set(TAG_HEADER_PNT, pnt);
	// }

	// msg, pnt, esb(request,response) end...

	public void setTransaction(InputStream is)
	{
		try
		{
			transaction = XMLConverter.getInstance().deserialize(is).getTransaction();
			init();
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
	}

	public void setTransaction(ICompositeNode transaction)
	{
		this.transaction = transaction;
		if (transaction != null) init();
	}

	public INode find(String path)
	{
		return transaction.find(path);
	}

	public IAtomNode findAtom(String path, IAtomNode def)
	{
		return transaction.findAtom(path, def);
	}

	public IArrayNode findArray(String path, IArrayNode def)
	{
		return transaction.findArray(path, def);
	}

	public ICompositeNode findComposite(String path, ICompositeNode def)
	{
		return transaction.findComposite(path, def);
	}

	public INode findIgnoreCase(String path)
	{
		return transaction.findIgnoreCase(path);
	}

	public INode find(String parentPath, ICompositeNode parent, String path, byte type,
			boolean canNull)
	{
		return parent.find(parentPath, path, type, canNull);
	}

	public void init()
	{
		if (transaction == null) transaction = new CompositeNode();
		header = (ICompositeNode) transaction.find(TAG_HEADER);
		if (header == null) header = transaction.create(TAG_HEADER);
		request = (ICompositeNode) transaction.findComposite(PATH_REQUEST, new CompositeNode());
		// if (request == null) request = transaction.create(PATH_REQUEST);
		transaction.set(PATH_REQUEST, request); // added by chenjs 2011-12-30 ����

		response = (ICompositeNode) transaction.findComposite(PATH_RESPONSE, new CompositeNode());
		// if (response == null) response = transaction.create(PATH_RESPONSE);
		transaction.set(PATH_RESPONSE, response); // added by chenjs
													// 2011-12-30 ����

		if (!local.containsKey(MsgLocalKey.LOCAL_MQ_ATTRIBUTE)) local.put(
				MsgLocalKey.LOCAL_MQ_ATTRIBUTE, new HashMap());
		if (!local.containsKey(MsgLocalKey.LOCAL_MB_ATTRIBUTE)) local.put(
				MsgLocalKey.LOCAL_MB_ATTRIBUTE, new HashMap());
		if (!local.containsKey(MsgLocalKey.LOCAL_BPL_VARIABLES)) local.put(
				MsgLocalKey.LOCAL_BPL_VARIABLES, new HashMap());
	}

	public Map getLocal()
	{
		return local;
	}

	public void clearLocal()
	{
		local.clear();
	}

	public Object getInLocal(String key)
	{
		return local.get(key);
	}

	public Object getInLocal(String key, Object obj)
	{
		Object o = local.get(key);
		if (o == null) return o;
		if (o instanceof INode) NodeConverterFactory.getInstance().pack((INode) o, obj, null);
		return o;
	}

	public void setInLocal(String key, Object value)
	{
		local.put(key, value);
	}

	public ICompositeNode getHeader()
	{
		return header;
	}

	public ICompositeNode setBody(ICompositeNode body)
	{
		if (body == null)
		{
			transaction.remove(TAG_BODY);
			return null;
		}
		transaction.set(TAG_BODY, body);
		return body;
	}

	public ICompositeNode getBody()
	{
		return (ICompositeNode) transaction.get(TAG_BODY);
	}

	public ICompositeNode getRequest()
	{
		return request;
	}

	public ICompositeNode getResponse()
	{
		return response;
	}

	public INode findInHeader(String path)
	{
		return header.find(path);
	}

	public Object getInHeader(String path)
	{
		return header.get(path);
	}

	public INode findInRequest(String path)
	{
		return getRequest().find(path);
	}

	public IAtomNode findAtomInRequest(String path, IAtomNode def)
	{
		return getRequest().findAtom(path, def);
	}

	public IArrayNode findArrayInRequest(String path, IArrayNode def)
	{
		return getRequest().findArray(path, def);
	}

	public ICompositeNode findCompositeInRequest(String path, ICompositeNode def)
	{
		return getRequest().findComposite(path, def);
	}

	public IAtomNode findAtomInResponse(String path, IAtomNode def)
	{
		return getResponse().findAtom(path, def);
	}

	public IArrayNode findArrayInResponse(String path, IArrayNode def)
	{
		return getResponse().findArray(path, def);
	}

	public ICompositeNode findCompositeInResponse(String path, ICompositeNode def)
	{
		return getResponse().findComposite(path, def);
	}

	public Object getInRequest(String path)
	{
		return getRequest().get(path);
	}

	public INode findInResponse(String path)
	{
		return getResponse().find(path);
	}

	public Object getInResponse(String path)
	{
		return getResponse().get(path);
	}

	public void setInHeader(String key, Object value)
	{
		header.set(key, value);
	}

	public void setInRequest(String key, Object value)
	{
		getRequest().set(key, value);
	}

	public void setInResponse(String key, Object value)
	{
		getResponse().set(key, value);
		setResponse(response);
	}

	public void clearRequest()
	{
		if (getRequest() != null) getRequest().clear();
	}

	public void clearHeader()
	{
		((ICompositeNode) (transaction.find(TAG_HEADER))).clear();
	}

	public String toString()
	{
		return toXml(true);
	}

	public ICompositeNode getTransaction()
	{
		return transaction;
	}

	public Throwable getEx()
	{
		return ex;
	}

	public void setEx(Throwable ex)
	{
		this.ex = ex;
	}

	public ICompositeNode createInResponse(String path)
	{
		return getResponse().create(path);
	}

	public ICompositeNode createInResquest(String path)
	{
		return getRequest().create(path);
	}

	public ICompositeNode createInHeader(String path)
	{
		return header.create(path);
	}

	public boolean isContainExFnode()
	{
		return containExFnode;
	}

	public void setContainExFnode(boolean containExFnode)
	{
		this.containExFnode = containExFnode;
	}

	public boolean isExitFlow()
	{
		return exitFlow;
	}

	public void setExitFlow(boolean exitFlow)
	{
		this.exitFlow = exitFlow;
	}

	public Object findInHeader(String path, Object target)
	{
		return header.find(path, target);
	}

	public Object findInRequest(String path, Object target)
	{
		return getRequest().find(path, target);
	}

	public Object findInResponse(String path, Object target)
	{
		return getResponse().find(path, target);
	}

	public ICompositeNode setHeader(ICompositeNode header)
	{
		this.header = header;
		transaction.set(TAG_HEADER, header);
		return header;
	}

	public ICompositeNode setRequest(ICompositeNode request)
	{
		this.request = request;
		transaction.set(PATH_REQUEST, request);
		return request;
	}

	public ICompositeNode setResponse(ICompositeNode response)
	{
		this.response = response;
		transaction.set(PATH_RESPONSE, response);
		return response;
	}

	public Message()
	{
		this(new CompositeNode());
	}

	public Message(ICompositeNode transaction)
	{
		this.transaction = transaction;
		init();
	}

	public Message(byte[] xml)
	{
		this(new ByteArrayInputStream(xml, 0, xml.length));
	}

	public Message(byte[] xml, boolean gzip) throws IOException
	{
		this(
				gzip ? (InputStream) (new GZIPInputStream(new ByteArrayInputStream(xml, 0,
						xml.length)))
						: (InputStream) (new ByteArrayInputStream(xml, 0, xml.length)));
	}

	public Message(byte[] xml, int start, int len)
	{
		this(new ByteArrayInputStream(xml, start, len));
	}

	public Message(InputStream is)
	{
		try
		{
			transaction = XMLConverter.getInstance().deserialize(is).getTransaction();
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
		finally
		{
			try
			{
				is.close();
			}
			catch (Exception e)
			{
			}
		}
		init();
	}

	public IMessage newInstance()
	{
		Message msg = new Message();
		msg.init();
		return msg;
	}
}
