package spc.webos.data.converter;

import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.Message;
import spc.webos.data.util.MessageUtil;
import spc.webos.log.Log;
import spc.webos.util.StringX;

/**
 * ��־ģ�����XML������Ϣ��Ϊ�����ESB�����ܣ�����Ҫ����xml���ĵ�body���֣�ֻ����ͷ����
 * 
 * @author spc
 * 
 */
public class HeaderXMLConverter implements IMessageConverter
{
	public IMessage deserialize(byte[] buf) throws Exception
	{
		return deserialize(buf, null);
	}

	public IMessage deserialize(byte[] buf, IMessage reqmsg) throws Exception
	{
		Message msg = new Message();
		if (XMLConverter.isSOAP(buf)) msg.setHeader(XMLConverter.getInstance()
				.deserialize2composite(MessageUtil.getSOAPHeader(buf)));
		else msg.setTransaction(XMLConverter.getInstance().deserialize2composite(
				MessageUtil.removeBody(buf)));
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, buf);
		return msg;
	}

	public byte[] serialize(IMessage msg) throws Exception
	{
		String originalBytes = msg.getOriginalBytesPlainStr();
		if (!StringX.nullity(originalBytes))
		{ // ��ǰ����fixmsg����ʱ��AsynESBCall�ڵ�ʹ�ô����л����������л�ʱ��Ҫ��ȫ���ķ��뵽REQ����
			log.info("originalBytes.len=" + originalBytes.length());
			return XMLConverter2.getInstance().serialize(msg);
		}
		byte[] xml = (byte[]) msg.getInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES);
		if (xml != null) return xml;
		log.info("cannot find LOCAL_ORIGINAL_REQ_BYTES !!!");
		return XMLConverter2.getInstance().serialize(msg);
	}

	public IMessage deserialize(byte[] buf, int offset, int len) throws Exception
	{
		return deserialize(buf, offset, len, null);
	}

	public IMessage deserialize(byte[] buf, int offset, int len, IMessage reqmsg) throws Exception
	{
		return null;
	}

	public HeaderXMLConverter()
	{
	}

	protected Log log = Log.getLogger(getClass());
	static HeaderXMLConverter HXC = new HeaderXMLConverter();

	public static IMessageConverter getInstance()
	{
		return HXC;
	}
}
