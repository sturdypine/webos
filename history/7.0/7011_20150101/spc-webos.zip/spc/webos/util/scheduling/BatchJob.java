package spc.webos.util.scheduling;

import spc.webos.log.Log;
import spc.webos.util.SystemUtil;

/**
 * ͳһ����ģʽ�ĺ�̨���񣬽���һ������
 * 
 * @author chenjs
 * 
 */
public class BatchJob
{
	protected final Log log = Log.getLogger(getClass());
	protected String[] methods;

	public void job()
	{
		SystemUtil.invoke(methods);
		// for (int i = 0; i < method.size(); i++)
		// {
		// try
		// {
		// if (log.isInfoEnabled()) log.info("start to execute job: " +
		// methods[i]);
		// ((Method) method.get(i)).invoke(target.get(i), null);
		// if (log.isInfoEnabled()) log.info("success to execute job: " +
		// methods[i]);
		// }
		// catch (Exception e)
		// {
		// log.warn("fail to execute job: " + methods[i], e);
		// }
		// }
	}

	public void init() throws Exception
	{
	}

	public void setMethods(String[] methods)
	{
		this.methods = methods;
	}
}
