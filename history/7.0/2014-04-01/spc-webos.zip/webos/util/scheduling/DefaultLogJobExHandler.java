package spc.webos.util.scheduling;

import java.lang.reflect.InvocationTargetException;

import spc.webos.log.Log;

public class DefaultLogJobExHandler implements IJobExceptionHandler
{
	protected Log log = Log.getLogger(getClass());

	public void handle(MethodInvokingJobDetail invoker, Throwable t)
	{
		log.warn(
				"object:" + invoker.getObject().getClass() + ", method:"
						+ invoker.getTargetMethod(),
				(t instanceof InvocationTargetException) ? ((InvocationTargetException) t)
						.getTargetException() : t);
	}

	static DefaultLogJobExHandler handler = new DefaultLogJobExHandler();

	private DefaultLogJobExHandler()
	{
	}

	public static DefaultLogJobExHandler getInstance()
	{
		return handler;
	}
}
