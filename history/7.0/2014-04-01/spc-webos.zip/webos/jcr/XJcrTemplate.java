package spc.webos.jcr;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.Row;
import javax.jcr.query.RowIterator;

import org.apache.jackrabbit.JcrConstants;
import org.apache.jackrabbit.api.JackrabbitNodeTypeManager;
import org.springframework.util.StringUtils;
import org.springmodules.jcr.JcrCallback;
import org.springmodules.jcr.JcrTemplate;

import spc.webos.constant.Common;
import spc.webos.log.Log;
import spc.webos.util.FileUtil;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;
import freemarker.template.Configuration;
import freemarker.template.Template;

public class XJcrTemplate extends JcrTemplate implements IXJcrTemplate
{
	public int delete(String uuid, String[] fileNames) throws Exception
	{
		Session session = getSession();
		Node arnode = null;
		try
		{
			arnode = session.getNodeByUUID(uuid);
		}
		catch (Exception e)
		{
		}
		if (arnode == null) return 0;
		int count = 0;
		NodeIterator child = arnode.getNodes();
		while (child.hasNext())
		{
			Node fileNode = child.nextNode();
			if (StringX.contain(fileNames, fileNode.getName(), true))
			{
				fileNode.remove();
				count++;
			}
		}
		save();
		return count;
	}

	public boolean update(Archive archive) throws Exception
	{
		Session session = getSession();
		Node arnode = null;
		try
		{
			arnode = session.getNodeByUUID(archive.getUuid());
		}
		catch (Exception e)
		{
		}
		if (arnode == null) return false;
		archive2node(archive, arnode);
		NodeIterator child = arnode.getNodes();
		while (child.hasNext())
			child.nextNode().remove();
		File[] files = archive.getFiles();
		for (int i = 0; files != null && i < files.length; i++)
		{
			File file = files[i];
			addFileNode(arnode, file);
		}
		save();
		return true;
	}

	public List getArchivesByPath(String path) throws Exception
	{
		List archives = new ArrayList();
		Node n = getRootNode().getNode(path);
		return archives;
	}

	public void deleteByUUID(final String uuid)
	{
		execute(new JcrCallback()
		{
			public Object doInJcr(Session session) throws IOException, RepositoryException
			{
				Node n = session.getNodeByUUID(uuid);
				if (n != null) n.remove();
				return null;
			}
		});
		save();
	}

	public Archive getArchive(String uuid, boolean file) throws Exception
	{
		return getArchive(uuid, file, null);
	}

	public Archive getArchive(String uuid, boolean file, String[] fileNames) throws Exception
	{
		Session session = getSession();
		Node node = null;
		try
		{
			node = session.getNodeByUUID(uuid);
		}
		catch (Exception e)
		{
		}
		if (node == null) return null;
		Archive archive = new Archive();
		node2archive(node, archive);

		if (!file) return archive;
		File parent = new File(tempdir, getTimeSN());
		if (!parent.exists()) parent.mkdirs();
		NodeIterator child = node.getNodes();
		List files = new ArrayList();
		while (child.hasNext())
		{
			Node fileNode = child.nextNode();
			Node res = fileNode.getNode(JcrConstants.JCR_CONTENT);

			if (fileNames == null || StringX.contain(fileNames, fileNode.getName(), true))
			{
				File f = new File(parent, fileNode.getName());
				FileUtil.is2os(res.getProperty(JcrConstants.JCR_DATA).getStream(),
						new FileOutputStream(f), true, true);
				files.add(f);
			}
		}
		archive.setFiles((File[]) files.toArray(new File[files.size()]));
		return archive;
	}

	public String insert(Archive archive) throws Exception
	{
		Node parent = createPath(archive.getPath());
		if (parent.hasNode(archive.getId()))
		{
			if (log.isInfoEnabled()) log.info("node has been exist: path:" + archive.getPath()
					+ ", id:" + archive.getId());
			return null;
		}
		if (parent.hasNode(archive.getId()))
		{
			if (log.isInfoEnabled()) log.info(archive.getId() + " exists in path:"
					+ archive.getPath());
			Node n = parent.getNode(archive.getId());
			if (n != null) n.remove();
		}
		Node arnode = parent.addNode(archive.getId(), "spc:archive");
		archive2node(archive, arnode);
		File[] files = archive.getFiles();
		for (int i = 0; files != null && i < files.length; i++)
		{
			File file = files[i];
			addFileNode(arnode, file);
		}
		String uuid = arnode.getUUID();
		save();
		return uuid;
	}

	protected void archive2node(Archive archive, Node node) throws RepositoryException
	{
		node.setProperty("spc:id", archive.getId());
		node.setProperty("spc:author", archive.getAuthor());
		node.setProperty("spc:title", archive.getTitle());
		node.setProperty("spc:summary", archive.getSummary());
		node.setProperty("spc:content", archive.getContent());
		node.setProperty("spc:createDt", archive.getCreateDt());
		node.setProperty("spc:createTm", archive.getCreateTm());
		node.setProperty("spc:ext1", archive.getExt1());
		node.setProperty("spc:ext2", archive.getExt2());
		node.setProperty("spc:ext3", archive.getExt3());
	}

	protected void node2archive(Node node, Archive archive) throws RepositoryException
	{
		archive.setPath(node.getPath());
		archive.setUuid(node.getUUID());
		archive.setId(node.getProperty("spc:id").getString());
		archive.setAuthor(node.getProperty("spc:author").getString());
		archive.setTitle(node.getProperty("spc:title").getString());
		archive.setContent(node.getProperty("spc:content").getString());
		archive.setSummary(node.getProperty("spc:summary").getString());
		archive.setCreateDt(node.getProperty("spc:createDt").getString());
		archive.setCreateTm(node.getProperty("spc:createTm").getString());
		archive.setExt1(node.getProperty("spc:ext1").getString());
		archive.setExt2(node.getProperty("spc:ext2").getString());
		archive.setExt3(node.getProperty("spc:ext3").getString());
	}

	protected Archive getResultItem(Row row) throws RepositoryException
	{
		String path = row.getValue("jcr:path").getString();
		Node file = (Node) getItem(path);
		Node arnode = file.getParent();
		Archive archive = new Archive();
		node2archive(arnode, archive);
		String excerpt = row.getValue("rep:excerpt(jcr:content)").getString();
		excerpt = StringUtils.replace(StringUtils.replace(excerpt, "<strong>",
				"<font color=#ff0a0a><strong>"), "</strong>", "</strong></font>");
		archive.setExcerpt(excerpt);
		archive.setFileName(file.getName());
		return archive;
	}

	public String getStatement(Archive archive, SearchCommand command) throws Exception
	{
		Map root = new HashMap();
		root.put("command", command);
		root.put("archive", archive);
		String xpath = SystemUtil.freemarker(searchTemplate, root);
		if (log.isInfoEnabled()) log.info("jcr xpath is:" + xpath);
		return xpath;
	}

	public List search(Archive archive, SearchCommand command) throws Exception
	{
		List result = new ArrayList();
		RowIterator rows = query(getStatement(archive, command), Query.XPATH).getRows();

		command.setTotal((int) rows.getSize());
		long start = command.getPage() * command.getPageSize();
		int index = 0;
		rows.skip(start);
		while (rows.hasNext() && index < command.getPageSize())
		{
			Row row = rows.nextRow();
			result.add(getResultItem(row));
			index++;
		}
		return result;
	}

	/**
	 * 
	 * @param node
	 * @param name
	 * @param type
	 *            JcrConstants.NT_UNSTRUCTURED
	 * @return
	 * @throws RepositoryException
	 */
	protected Node getNode(Node node, String name, String type) throws RepositoryException
	{
		if (node.hasNode(name)) return node.getNode(name);
		else return node.addNode(name, type);
	}

	protected Node createPath(String path) throws RepositoryException
	{
		return createPath(null, path);
	}

	protected Node createPath(Node root, String path) throws RepositoryException
	{
		if (root == null) root = getRootNode();
		String name = StringX.trim(path, PATH_TRIM_CHAR);
		int index = path.indexOf('/');
		if (index > 0) name = path.substring(0, index);
		Node node = root.hasNode(name) ? root.getNode(name) : root.addNode(name,
				JcrConstants.NT_UNSTRUCTURED);
		return index > 0 ? createPath(node, path.substring(index + 1)) : node;
	}

	protected Node addFileNode(Node folder, File file) throws RepositoryException, IOException
	{
		String fileName = file.getName();
		Node fileNode = folder.addNode(fileName, JcrConstants.NT_FILE);
		Node resNode = fileNode.addNode(JcrConstants.JCR_CONTENT, JcrConstants.NT_RESOURCE);
		resNode.setProperty(JcrConstants.JCR_MIMETYPE, Common.getContentType(file.getName()));
		InputStream is = null;
		try
		{
			resNode.setProperty(JcrConstants.JCR_DATA, is = new FileInputStream(file));
		}
		finally
		{
			if (is != null) is.close();
		}
		resNode.setProperty(JcrConstants.JCR_LASTMODIFIED, Calendar.getInstance());
		return resNode;
	}

	/**
	 * ��ʼ��������Դ���ڵ������
	 * 
	 * @throws Exception
	 */
	// public void init() throws Exception
	// {
	// if (nodeTypes == null) return;
	// NodeTypeDef[] types = NodeTypeReader.read(nodeTypes.getInputStream());
	// Session session = getSession();
	// NodeTypeRegistry reg = ((NodeTypeManagerImpl)
	// session.getWorkspace().getNodeTypeManager())
	// .getNodeTypeRegistry();
	// System.out.println("NodeTypeRegistry: " + types.length);
	// for (int j = 0; j < types.length; j++)
	// {
	// NodeTypeDef def = types[j];
	// reg.getNodeTypeDef(def.getName());
	// System.out.println("NodeTypeRegistry: " + def.getName());
	// }
	// session.logout();
	// }
	public void init() throws Exception
	{
		if (searchTemplate == null) searchTemplate = new Template(
				"JCR_SEARCH_XPATH",
				new StringReader(
						"/jcr:root/${archive.path}//element(*, nt:file)[jcr:contains(jcr:content, '${command.key}')]/rep:excerpt(.)"),
				new Configuration());
		tempdir = SystemUtil.getInstance().getResourceLoader().getResource(tempDir).getFile();
		if (!tempdir.exists()) tempdir.mkdirs();
		if (nodeTypes == null) return;
		Session session = getSession();
		JackrabbitNodeTypeManager nodeTypeManager = (JackrabbitNodeTypeManager) session
				.getWorkspace().getNodeTypeManager();
		Iterator keys = nodeTypes.keySet().iterator();
		while (keys.hasNext())
		{
			String key = keys.next().toString();
			if (nodeTypeManager.hasNodeType(key)) continue;
			nodeTypeManager.registerNodeTypes(SystemUtil.getInstance().getResourceLoader()
					.getResource(nodeTypes.get(key).toString()).getInputStream(),
					JackrabbitNodeTypeManager.TEXT_X_JCR_CND);
		}
	}

	public synchronized static String getTimeSN()
	{
		long time = System.currentTimeMillis();
		if (time <= LAST_TIME) time = LAST_TIME + 1; // �����ǰʱ�����һʱ����ͬһ���룬�������������һ����
		LAST_TIME = time;
		return String.valueOf(time);
	}

	Template searchTemplate;
	Map nodeTypes;
	File tempdir;
	String tempDir;
	private static long LAST_TIME = 0;
	public static final String TEMP_DIR = "_tempdir_";
	static final char[] PATH_TRIM_CHAR = new char[] { '\\', '/', ' ', '\t', '\n' };
	static Log log = Log.getLogger(XJcrTemplate.class);

	public void setTempDir(String tempDir)
	{
		this.tempDir = tempDir;
	}

	public void setNodeTypes(Map nodeTypes)
	{
		this.nodeTypes = nodeTypes;
	}

	public void setSearchTemplate(String searchTemplate) throws IOException
	{
		this.searchTemplate = new Template(
				"JCR_SEARCH",
				new StringReader(
						"/jcr:root/${archive.path}//element(*, nt:file)[jcr:contains(jcr:content, '${command.key}')]/rep:excerpt(.)"),
				new Configuration());
	}
}
