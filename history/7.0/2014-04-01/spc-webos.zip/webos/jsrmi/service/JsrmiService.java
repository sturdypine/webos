package spc.webos.jsrmi.service;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import spc.webos.jsrmi.request.RequestContext;


public class JsrmiService {
	
	/**
	 * Get the request context.
	 * @return request context
	 */
	public ServletContext getContext() {
		return RequestContext.getContext().getServletContext();
	}
	
	/**
	 * Get the http servlet request
	 * @return the HttpServletRequest
	 */
	public HttpServletRequest getRequest() {
		return RequestContext.getContext().getHttpRequest();
	}
	
	/**
	 * Get the http session object for your persistence usage.
	 * @return http session object
	 */
	public HttpSession getSession() {
		return RequestContext.getContext().getHttpSession();
	}
	
}
