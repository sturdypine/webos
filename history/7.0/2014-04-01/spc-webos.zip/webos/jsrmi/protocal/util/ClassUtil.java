package spc.webos.jsrmi.protocal.util;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.NotWritablePropertyException;

import spc.webos.jsrmi.protocal.InitializeObjectFailedException;
import spc.webos.jsrmi.protocal.TypeNotFoundException;
import spc.webos.log.Log;
import spc.webos.util.BeanPropertyUtil;

public class ClassUtil
{
	static Log log = Log.getLogger(ClassUtil.class);
	private static Map fieldCache = new HashMap();
	static BeanWrapperImpl wrapper = new BeanWrapperImpl(true);

	public static Object newInstanceOfType(String className)
	{
		Object result = null;
		try
		{
			result = Class.forName(className).newInstance();
		}
		catch (InstantiationException e)
		{
			throw new InitializeObjectFailedException("fail to initialize type: " + className, e);
		}
		catch (IllegalAccessException e)
		{
			throw new InitializeObjectFailedException("fail to initialize type: " + className, e);
		}
		catch (ClassNotFoundException e)
		{
			throw new TypeNotFoundException("no such type: " + className, e);
		}
		return result;

	}

	public static void setFieldValue(Object obj, String property, Object value)
	{
		Class type = obj.getClass();
		// �����������Ĵ�Сд, modified by spc 2010-06-11
		String p = BeanPropertyUtil.getProperty(type, property);
		property = p == null ? property : p;
		// BeanWrapperImpl wrapper = new BeanWrapperImpl(true);
		wrapper.setWrappedInstance(obj);
		try
		{ // modified by spc 2011-01-08
			wrapper.setPropertyValue(property, value);
		}
		catch (NotWritablePropertyException nwpe)
		{
			if (log.isInfoEnabled()) log.info("Cannot find field [" + property + "] for " + type);
		}
		// Field field = null;
		// ClassFieldNamePair pair = new ClassFieldNamePair(type, property);
		// if (log.isDebugEnabled()) log.debug("property: " + property +
		// ", value: " + value);
		// if (fieldCache.get(pair) == null)
		// {
		// field = (Field) getFieldMap(type).get(property);
		// if (field != null)
		// {
		// fieldCache.put(pair, field);
		// }
		// else
		// {
		// if (log.isInfoEnabled()) log.info("Cannot find field [" + property +
		// "] for "
		// + type);
		// return;
		// // throw new AccessFieldException("Cannot find field
		// // ["+property+"] for " + type);
		// }
		// }
		// else
		// {
		// field = (Field) fieldCache.get(pair);
		// }
		//
		// try
		// {
		// try
		// {
		// field.set(obj, value);
		// if (log.isDebugEnabled()) log.debug("success to property, field: " +
		// field);
		// }
		// catch (IllegalArgumentException ex)
		// {
		// field.set(obj, convertValue(value, field.getType()));
		// }
		// }
		// catch (SecurityException e)
		// {
		// throw new spc.webos.jsrmi.protocal.AccessFieldException(e);
		// }
		// catch (IllegalAccessException e)
		// {
		// throw new spc.webos.jsrmi.protocal.AccessFieldException(e);
		// }
	}

	private static HashMap getFieldMap(Class cl)
	{
		HashMap fieldMap = new HashMap();
		for (; cl != null; cl = cl.getSuperclass())
		{
			Field[] fields = cl.getDeclaredFields();
			for (int i = 0; i < fields.length; i++)
			{
				Field field = fields[i];
				if (Modifier.isTransient(field.getModifiers())
						|| Modifier.isStatic(field.getModifiers())) continue;
				field.setAccessible(true);
				fieldMap.put(field.getName(), field);
			}
		}

		return fieldMap;
	}

	private static Object convertValue(Object value, Class targetType)
	{
		if (value.getClass().equals(targetType)) return value;
		if (targetType == String.class) return value.toString();
		// ����ǿ��ַ���, ��Ŀ������ֲ����ַ����򷵻�null, modified by spc 2010-02-10
		if (value instanceof String && (value.toString().length() == 0)) return null;
		if (targetType == Long.class) return new Long(value.toString());
		if (targetType == Integer.class) return new Integer(value.toString());
		if (targetType == Short.class) return new Short(value.toString());
		if (targetType == Float.class) return new Float(value.toString());
		if (targetType == Double.class) return new Double(value.toString());
		if (targetType == BigDecimal.class) return new BigDecimal(value.toString());
		if (targetType == BigInteger.class) return new BigInteger(value.toString());
		if (targetType.isArray() && Collection.class.isAssignableFrom(value.getClass()))
		{
			Collection collection = (Collection) value;
			Object array = Array.newInstance(targetType.getComponentType(), collection.size());
			int i = 0;
			for (Iterator iter = collection.iterator(); iter.hasNext();)
			{
				Object val = iter.next();
				Array.set(array, i++, val);
			}

			return array;
		}

		throw new IllegalArgumentException("Cannot convert from " + value.getClass().getName()
				+ " to " + targetType);
	}
}
