package spc.webos.jsrmi.protocal.converters.basic;

import java.util.Date;

import spc.webos.jsrmi.protocal.ProtocalTag;
import spc.webos.jsrmi.protocal.converters.Converter;
import spc.webos.jsrmi.protocal.io.MarshallingContext;
import spc.webos.jsrmi.protocal.io.StreamWriter;
import spc.webos.jsrmi.protocal.util.DateUtil;

public class DateConverter extends AbstractBasicConverter implements Converter {

	public boolean canConvert(Class value) {
		if (value == null)
			return false;
		return value.equals(Date.class);
	}

	public void marshal(Object value, MarshallingContext context, StreamWriter streamWriter) {
		long time = ((Date) value).getTime();
		streamWriter.startNode(ProtocalTag.TAG_DATE);
		streamWriter.setValue(DateUtil.toUTCString(time));
		streamWriter.endNode();
	}

	public Object fromString(String string) {
		return DateUtil.fromUTCString(string);
	}

}
