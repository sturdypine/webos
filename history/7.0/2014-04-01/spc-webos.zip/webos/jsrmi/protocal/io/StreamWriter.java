
package spc.webos.jsrmi.protocal.io;


public interface StreamWriter {
	
	void startNode(String name);

    void setValue(String text);

    void endNode();

    void flush();

    void close();

}
