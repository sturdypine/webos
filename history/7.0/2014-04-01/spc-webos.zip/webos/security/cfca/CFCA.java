package spc.webos.security.cfca;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import spc.webos.constant.AppRetCode;
import spc.webos.constant.Common;
import spc.webos.exception.AppException;
import spc.webos.security.AbstractEncryptSig;
import spc.webos.security.IEncrypt;
import spc.webos.security.ISignature;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

import com.cfca.toolkit.CastleProperties;

public class CFCA extends AbstractEncryptSig
{
	protected Map castleProperties;
	protected Map castles = new HashMap();
	protected Map defCastleProperties;
	protected CnccCastle defCnccCastle;
	protected boolean verifyCert = false;

	public static final String PKCS_P7 = "P7";

	protected ICFCACNSN cnsn; // �Ƿ����cn-sn

	public CFCA()
	{
		name = "CFCA";
	}

	public CnccCastle getCnccCastle(String nodeCd, Map attribute)
	{
		CnccCastle castle = (CnccCastle) castles.get(nodeCd);
		return castle != null ? castle : defCnccCastle;
	}

	public String sign(String nodeCd, byte[] content, Map attribute) throws Exception
	{
		CnccCastle castle = getCnccCastle(nodeCd, attribute);
		// modified by chenjs 2011-12-08 ǩ����ʽ֧��p1 & p7
		String pkcs = (attribute == null) ? PKCS_P7 : StringX.null2emptystr(attribute.get("PKCS"),
				PKCS_P7);
		String charset = (attribute == null) ? Common.CHARSET_GBK : StringX.null2emptystr(
				attribute.get("CHARSET"), Common.CHARSET_GBK);
		String sign = PKCS_P7.equalsIgnoreCase(pkcs) ? castle.signDataDetached(content) : castle
				.signData(new String(content, charset)); // P7 or P1
		if (log.isDebugEnabled()) log.debug("pkcs:" + pkcs + ", charset:" + charset + ", src:[["
				+ new String(StringX.encodeBase64(content)) + "]], sign:[[" + sign + "]]");
		return sign;
	}

	protected void verifyCertificate(String nodeCd, CnccCastle castle, String sign, Map attribute)
			throws Exception
	{
		if (!verifyCert) return;
		byte[] cert = castle.getCertificate(sign); // ��ǩ����Ϣ�л�ȡ֤��
		int verifyCertificate = 0;
		if ((verifyCertificate = castle.verifyCertificate(cert)) <= 0)
		{ // ��֤ǩ����Ϣ�й�Կ�Ƿ�ΪCFCA����֤��Կ
			log.warn("sign:[" + sign + "], cert:[" + new String(StringX.encodeBase64(cert))
					+ "], verify:[" + verifyCertificate + "] is invalid!!!");
			throw new AppException(AppRetCode.SIG_DECODE, "Not CFCA Cert(" + verifyCertificate
					+ ")!!!");
		}
	}

	public boolean unsign(String nodeCd, String sign, byte[] content, Map attribute)
			throws Exception
	{
		CnccCastle castle = getCnccCastle(nodeCd, attribute);
		if (castle == null) castle = defCnccCastle;
		verifyCertificate(nodeCd, castle, sign, attribute);
		byte[] cert = castle.getCertificate(sign); // ��ǩ����Ϣ�л�ȡ֤��
		boolean check = castle.verifySignedDataDetached(sign, content); // ��֤ǩ��
		if (!check) log.warn("fail to unsign, node: [" + nodeCd + "], sign:[" + sign
				+ "], content:[" + new String(StringX.encodeBase64(content)) + "]");
		// ���Ŀǰû�����ð󶨹�ϵ�ӿڻ����������ǩ�����򲻼����������󶨹�ϵ�ļ��
		if (!check || cnsn == null) return check;

		String dn = castle.getDN(cert);
		// ��ȡdn��CN=֮��Ĳ���
		// ���CN֮���б��ֵ����������֮�����","�ֿ����ݴ˽�ȡCN
		String cn = (dn.substring(dn.indexOf("CN=") + 3));
		if (cn.indexOf(",") > 0) cn = cn.substring(0, cn.indexOf(","));
		String sn = StringX.bigint2str(castle.getSerialNumber(cert).toByteArray());
		// ��ȡ�кţ��޷�ȡ���к�ʱ����cnsn�����Ƿ����ͨ��
		String acctSvcr = getAccSvcr(nodeCd, content, attribute);
		if (log.isInfoEnabled()) log.info("sn:[" + sn + "], cn:[" + cn + "], cert acctSvcr:"
				+ acctSvcr);
		boolean b = cnsn.validate(acctSvcr, sn, cn);
		if (!b) log.warn("fail to unsign, DN:[" + dn + "], CN: [" + cn + "], SN:[" + sn
				+ "], acctSvcr:[" + acctSvcr + "]");
		return b;
	}

	protected String getAccSvcr(String nodeCd, byte[] content, Map attribute)
	{
		return StringX.EMPTY_STRING;
	}

	public void init() throws Exception
	{
		if (ISignature.SIGS.containsKey(name)) log.warn("ISignature(" + name + ") repeated!!!");
		ISignature.SIGS.put(name, this);
		if (IEncrypt.ENCRYPTS.containsKey(name)) log.warn("IEncrypt(" + name + ") repeated!!!");
		IEncrypt.ENCRYPTS.put(name, this);
		if (castleProperties == null) log.info("castleProperties is null!!!");
		else
		{
			Iterator keys = castleProperties.keySet().iterator();
			while (keys.hasNext())
			{
				String key = keys.next().toString();
				Object obj = castleProperties.get(key);
				CnccCastle castle = new CnccCastle(
						(obj instanceof CastleProperties) ? (CastleProperties) obj
								: getCastleProperties((Map) obj));
				castle.initCertAppContext();
				castles.put(key, castle);
			}
		}
		if (defCastleProperties != null) defCnccCastle = new CnccCastle(
				getCastleProperties(defCastleProperties));
	}

	public CastleProperties getCastleProperties(Map p) throws Exception
	{
		CastleProperties castleProperties = new CastleProperties();
		String dirAbsolutePath = SystemUtil.relativePath2AbsolutePath(StringX.null2emptystr(p
				.get("dir")));
		castleProperties.setmCachedCRLDirPath(dirAbsolutePath); // ֤�����ļ�ϵͳ�еľ���·��
		if (p.containsKey("server"))
		{ // LDap��֤֤���Ƿ����������
			castleProperties.setmLdapServerName(StringX.null2emptystr(p.get("server")));
			castleProperties.setmLdapServerPort(new Integer(StringX.null2emptystr(p.get("port")))
					.intValue());
		}
		castleProperties.setmUserCertFilePath(dirAbsolutePath + File.separator
				+ StringX.null2emptystr(p.get("pfx"), "cfca.pfx")); // �û�˽Կ�ļ���
		castleProperties.setmUserCertPassword(StringX.null2emptystr(p.get("pwd"))); // ˽Կ����
		return castleProperties;
	}

	// ���ʹ��֤����Ƽ���ʱ�� ��Ҫ֪���Է���Կ��Ϣ
	public byte[] getPublicCert(String nodeCd, Map attribute)
	{
		return null;
	}

	// ��˽Կ����
	public byte[] decode(String nodeCd, byte[] src, Map attribute) throws Exception
	{
		return getCnccCastle(nodeCd, attribute).decodeEnvelope(new String(src)).getBytes();
	}

	// �ù�Կ����
	public byte[] encode(String nodeCd, byte[] src, Map attribute) throws Exception
	{
		CnccCastle castle = getCnccCastle(nodeCd, attribute);
		if (castle == null) castle = defCnccCastle;
		return castle.generateEnvelope(new String(src), 0, getPublicCert(nodeCd, attribute))
				.getBytes();
	}

	public byte[] translatePinWith2AccNo(String pin, String nodeCd1, String nodeCd2, String acc1,
			String acc2) throws Exception
	{
		return null;
	}

	public void setCnsn(ICFCACNSN cnsn)
	{
		this.cnsn = cnsn;
	}

	public void setCastleProperties(Map castleProperties)
	{
		this.castleProperties = castleProperties;
	}

	public CnccCastle getDefCnccCastle()
	{
		return defCnccCastle;
	}

	public void setDefCnccCastle(CnccCastle defCnccCastle)
	{
		this.defCnccCastle = defCnccCastle;
	}

	public void setCastles(Map castles)
	{
		this.castles = castles;
	}

	public void setDefCastleProperties(Map defCastleProperties)
	{
		this.defCastleProperties = defCastleProperties;
	}

	public boolean isVerifyCert()
	{
		return verifyCert;
	}

	public void setVerifyCert(boolean verifyCert)
	{
		this.verifyCert = verifyCert;
	}
}
