package spc.webos.endpoint;

import java.util.ArrayList;
import java.util.List;

public class ClusterEndpoint extends AbstractClusterEndpoint
{
	public void execute(Executable exe) throws Exception
	{
		int failCount = 0;
		int start = cursor();
		while (true)
		{
			if (start >= endpoints.size()) start = 0;
			if (execute(((Endpoint) endpoints.get(start)), exe, failCount++)) return;
			start++;
		}
	}

	/**
	 * ��ȡ��ǰ��һ��ִ��ʵ��������
	 * 
	 * @return
	 */
	protected int cursor()
	{
		if (algorithm == 1) return ((int) (cursor++)) % endpoints.size();
		if (algorithm == 2) return (int) (Math.random() * 1000000) % endpoints.size();
		return 0;
	}

	public void init() throws Exception
	{
	}

	public void destory()
	{
		log.info("destory " + endpoints.size());
		for (int i = 0; i < endpoints.size(); i++)
			((Endpoint) endpoints.get(i)).destory();
		endpoints.clear();
	}

	public ClusterEndpoint()
	{
	}

	public ClusterEndpoint(List endpoints)
	{
		this.endpoints = endpoints;
	}

	protected int algorithm = 1; // Ⱥ���㷨: 1 ������һ��ʹ�õ���һ���� 2 �����ʼ�� 0 ʼ�մ�0��ʼ
	protected long cursor = 0;
	protected List endpoints = new ArrayList();

	public void setEndpoints(List endpoints)
	{
		this.endpoints = endpoints;
	}

	public void setAlgorithm(int algorithm)
	{
		this.algorithm = algorithm;
	}
}
