package spc.webos.endpoint;

import java.util.Hashtable;

import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.directory.InitialDirContext;

import spc.webos.log.Log;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

import com.ibm.jms.JMSBytesMessage;
import com.ibm.msg.client.jms.JmsConnectionFactory;
import com.ibm.msg.client.jms.JmsDestination;

/**
 * ʹ��JMS�����ļ�ģʽ����MQ������Ϣ
 * 
 * @author chenjs
 * 
 */
public class MQFSJMSEndpoint implements Endpoint
{
	public void init() throws Exception
	{
		createJCF();
	}

	public void execute(Executable exe) throws Exception
	{
		Connection connection = null;
		Session session = null;
		String reqQName = StringX.nullity(exe.reqQName) ? this.reqQName : exe.reqQName;
		String repQName = StringX.nullity(exe.repQName) ? this.repQName : exe.repQName;
		int timeout = (exe.timeout > 0 ? exe.timeout : this.timeout);
		if (log.isInfoEnabled()) log.info("reqQ:" + reqQName + ", repQ:" + repQName + ",corId:"
				+ new String(StringX.encodeBase64(exe.correlationID)) + ", timeout:" + timeout);
		try
		{
			connection = jcf.createConnection();
			session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			MessageProducer producer = session.createProducer((JmsDestination) context
					.lookup(reqQName));
			connection.start();
			BytesMessage reqmsg = session.createBytesMessage();
			reqmsg.writeBytes(exe.request);
			if (exe.correlationID != null) reqmsg.setJMSCorrelationIDAsBytes(exe.correlationID);
			// reqmsg.setJMSReplyTo((JmsDestination) context.lookup(repQName));
			producer.send(reqmsg);
			log.info("success to send jms msg...");

			// read response msg...
			if (exe.withoutReturn)
			{
				log.info("withoutReturn...");
				return;
			}
			String jmsCorId = StringX.byte2hex(exe.correlationID);
			MessageConsumer consumer = session.createConsumer(
					(JmsDestination) context.lookup(repQName), "JMSCorrelationID='ID:" + jmsCorId
							+ "'");
			JMSBytesMessage repmsg = (JMSBytesMessage) consumer.receive(timeout * 1000);
			if (repmsg != null)
			{
				exe.response = new byte[(int) repmsg.getBodyLength()];
				repmsg.readBytes(exe.response);
			}
			else log.info("No message received!!");
		}
		finally
		{
			close(session, connection);
		}
	}

	public void destory()
	{
		close(session, connection);
	}

	public void close(Session session, Connection connection)
	{
		try
		{
			if (session != null) session.close();
		}
		catch (JMSException jmsex)
		{
		}
		try
		{
			if (connection != null) connection.close();
		}
		catch (JMSException jmsex)
		{
		}
	}

	public Endpoint clone() throws CloneNotSupportedException
	{
		return null;
	}

	protected void createJCF() throws Exception
	{
		Hashtable env = new Hashtable();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.fscontext.RefFSContextFactory");
		// file:/d:/workspace.esb/MQJMS/
		env.put(Context.PROVIDER_URL, "file:/"
				+ SystemUtil.getInstance().getResourceLoader().getResource(cxtUrl).getFile()
						.getAbsolutePath());
		context = new InitialDirContext(env);
		jcf = (JmsConnectionFactory) context.lookup(cnnFactoryFromJndi);
	}

	public void setLocation(String location) throws Exception
	{
		throw new RuntimeException("No method!!!");
	}

	protected String cxtUrl;
	protected String cnnFactoryFromJndi = "QCF_GW_IN";
	protected JmsConnectionFactory jcf;
	protected Context context;
	protected Connection connection;
	protected Session session;
	protected boolean longCnn; // �Ƿ�����
	protected int timeout;
	protected String reqQName;
	protected String repQName;
	protected Log log = Log.getLogger(getClass());

	public void setCxtUrl(String cxtUrl)
	{
		this.cxtUrl = cxtUrl;
	}

	public void setCnnFactoryFromJndi(String cnnFactoryFromJndi)
	{
		this.cnnFactoryFromJndi = cnnFactoryFromJndi;
	}

	public void setReqQName(String reqQName)
	{
		this.reqQName = reqQName;
	}

	public void setRepQName(String repQName)
	{
		this.repQName = repQName;
	}

	public void setTimeout(int timeout)
	{
		this.timeout = timeout;
	}
}
