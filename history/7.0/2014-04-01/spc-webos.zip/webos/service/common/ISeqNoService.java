package spc.webos.service.common;

import java.util.Map;

import spc.webos.data.IMessage;

public interface ISeqNoService
{
	public String rndoGenSN(String key, IMessage msg, Map params) throws Exception;
}
