package spc.webos.flownode.impl;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jbpm.graph.def.DelegationException;
import org.jbpm.graph.def.ProcessDefinition;
import org.jbpm.graph.exe.ProcessInstance;
import org.jbpm.graph.exe.Token;
import org.springframework.core.io.Resource;

import spc.webos.constant.BPLVariables;
import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.flownode.IFlowContext;
import spc.webos.flownode.IFlowNode;
import spc.webos.model.JPDLVO;
import spc.webos.util.FileUtil;
import spc.webos.util.StringX;

/**
 * ��JBPM����ִ�е���Ͻڵ�
 * 
 * @author spc
 * 
 */
public class JBPM3SynCFNode extends AbstractCFNode
{
	public JBPM3SynCFNode()
	{
		name = "jbpm3Syn";
	}

	public boolean support(IMessage msg)
	{
		return processDefinitions.containsKey(getProcessName(msg));
	}

	public void flow(IMessage msg, IFlowContext cxt) throws Exception
	{
		try
		{
			jbpm(msg, cxt);
		}
		catch (Exception ex)
		{ // ��������г����쳣������Ҳ�������쳣�и����̴���
			if (ex instanceof DelegationException) ex = (Exception) ((DelegationException) ex)
					.getCause();
			String exTargetFNode = msgExHandler(msg);
			if (exTargetFNode == null) throw ex;
			super.getFlowNode(exTargetFNode);
			IFlowNode fnode = getFlowNode(exTargetFNode);
			// (IFlowNode) SystemUtil.getInstance().getBean(exTargetBean,
			// IFlowNode.class);
			if (log.isInfoEnabled()) log.info("exTargetFNode: " + exTargetFNode);
			if (fnode == null) throw ex;
			fnode.execute(msg, cxt);
		}
	}

	protected void jbpm(IMessage msg, IFlowContext cxt) throws Exception
	{
		if (!msg.getLocal().containsKey(MsgLocalKey.LOCAL_BPL_VARIABLES)) msg.setInLocal(
				MsgLocalKey.LOCAL_BPL_VARIABLES, new HashMap());
		String processName = getProcessName(msg);
		ProcessDefinition pdefinition = (ProcessDefinition) processDefinitions.get(processName);
		if (log.isInfoEnabled()) log.info("JBPM3Syn start to jpdl name: " + pdefinition.getName()
				+ ", by processName: " + processName);
		ProcessInstance instance = new ProcessInstance(pdefinition);

		instance.getContextInstance().setTransientVariable(IFlowContext.JBPM_FLOW_CXT_KEY, cxt);
		instance.getContextInstance().setTransientVariable(IFlowContext.JBPM_MSG_KEY, msg);
		instance.getContextInstance().setVariables(
				(Map) msg.getInLocal(MsgLocalKey.LOCAL_BPL_VARIABLES));
		instance.getContextInstance().setTransientVariable(Common.MODEL_MSG, msg); // ����ǰ������Ϊ���̵���ʱ����
		Token token = instance.getRootToken();
		token.signal();
//		ByteArrayOutputStream baos = new ByteArrayOutputStream();
//		ObjectOutputStream oos = new ObjectOutputStream(baos);
//		oos.writeObject(instance);
//		oos.flush();
//		System.out.println("jbpm:"+new String(StringX.encodeBase64(baos.toByteArray())));
		
		if (!instance.hasEnded()) log.warn("SYN flow has no ended!!!");
		if (log.isInfoEnabled()) log.info("end to jpdl name: " + pdefinition.getName()
				+ ", by processName: " + processName + ", hasEnded:" + instance.hasEnded());
	}

	protected String msgExHandler(IMessage msg)
	{
		List handlers = (List) msg.getBplVariable(BPLVariables.EX_HANDLERS);
		if (handlers == null || handlers.size() == 0) return null;
		if (log.isDebugEnabled()) log.debug("ex handlers chain: " + handlers);
		String handler = (String) handlers.get(handlers.size() - 1);
		handlers.remove(handlers.size() - 1); // ʹ���쳣������ϴ���bean���д�����������Ϻ�ժ��
		return handler;
	}

	protected String getProcessName(IMessage msg)
	{
		String processName = (String) msg.getInLocal(MsgLocalKey.LOCAL_JBPM_PROCESS_NAME);
		return StringX.nullity(processName) ? msg.getMsgCd() : processName;
	}

	public void init() throws Exception
	{
		super.init();
		refresh();
	}

	public void refresh() throws Exception
	{
		super.refresh();
		Map processDefinitions = new HashMap();
		loadFromDisk(processDefinitions);
		loadFromDB(processDefinitions);
		this.processDefinitions = processDefinitions;
	}

	protected void loadFromDB(Map processDefinitions) throws Exception
	{
		if (StringX.nullity(jdplSqlId)) return;
		List jpdls = (List) persistence.execute(jdplSqlId, null);
		if (jpdls == null)
		{
			if (log.isInfoEnabled()) log.info("cannot find jpdls by sql: " + jdplSqlId);
			return;
		}
		for (int i = 0; i < jpdls.size(); i++)
		{
			JPDLVO jpdl = (JPDLVO) jpdls.get(i);
			if (log.isInfoEnabled()) log.info("loading " + jpdl.getName() + ", remark:"
					+ jpdl.getRemark());
			processDefinitions
					.put(jpdl.getName(), ProcessDefinition.parseXmlString(jpdl.getJpdl()));
		}
	}

	protected void loadFromDisk(Map processDefinitions) throws Exception
	{
		if (jpdlDir == null) return;
		File dir = jpdlDir.getFile();
		if (!dir.exists())
		{
			log.error("jpdl dir is no exist:" + dir.getAbsolutePath());
			return;
		}
		readDir(dir, processDefinitions);
	}

	protected void readDir(File dir, Map processDefinitions) throws Exception
	{
		File[] subfile = dir.listFiles();
		for (int i = 0; i < subfile.length; i++)
		{
			if (subfile[i].isDirectory())
			{
				readDir(subfile[i], processDefinitions);
				continue;
			}
			if (subfile[i].getName().equalsIgnoreCase(PROCESS_DEF_FILE_NAME))
			{
				ProcessDefinition definition = ProcessDefinition.parseXmlString(new String(FileUtil
						.file2bytes(subfile[i]), jpdlCharset));
				if (log.isInfoEnabled()) log.info("loading process definition:"
						+ definition.getName());
				processDefinitions.put(definition.getName(), definition);
			}
		}
	}

	protected String jpdlCharset = Common.CHARSET_UTF8;
	protected Resource jpdlDir;
	protected String jdplSqlId;
	protected Map processDefinitions = new HashMap(); // ���̶���
	public final static String PROCESS_DEF_FILE_NAME = "processdefinition.xml";

	public void setJdplSqlId(String jdplSqlId)
	{
		this.jdplSqlId = jdplSqlId;
	}

	public void setJpdlCharset(String jpdlCharset)
	{
		this.jpdlCharset = jpdlCharset;
	}

	public void setJpdlDir(Resource jpdlDir)
	{
		this.jpdlDir = jpdlDir;
	}
}
