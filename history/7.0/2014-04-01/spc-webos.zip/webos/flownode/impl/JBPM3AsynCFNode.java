package spc.webos.flownode.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jbpm.JbpmConfiguration;
import org.jbpm.JbpmContext;
import org.jbpm.db.GraphSession;
import org.jbpm.graph.def.Action;
import org.jbpm.graph.def.DelegationException;
import org.jbpm.graph.def.Event;
import org.jbpm.graph.def.Node;
import org.jbpm.graph.def.ProcessDefinition;
import org.jbpm.graph.exe.ProcessInstance;
import org.jbpm.graph.exe.Token;

import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.Status;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.data.converter.XMLConverter2;
import spc.webos.exception.AppException;
import spc.webos.flownode.IFlowContext;
import spc.webos.flownode.IFlowNode;
import spc.webos.flownode.action.IAfterAsynCall;
import spc.webos.jdbc.blob.ByteArrayBlob;
import spc.webos.model.BPELInstanceVO;
import spc.webos.model.BPELNodeVO;
import spc.webos.persistence.SQLItem;
import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

/**
 * ִ���첽����
 * 
 * @author spc
 * 
 */
public class JBPM3AsynCFNode extends AbstractCFNode
{
	public void flow(IMessage msg, IFlowContext cxt) throws Exception
	{
		JbpmContext jbpmCxt = jbpmCfg.createJbpmContext();
		GraphSession graphSession = jbpmCxt.getGraphSession();
		ProcessDefinition processDefinition = null;
		ProcessInstance instance = null;
		IMessage parent = null;
		Status status = null;
		Map variables = new HashMap();
		BPELNodeVO nodeVO = null;
		BPELInstanceVO instanceVO = null;
		try
		{
			if (msg.isRequestMsg())
			{ // is a request message...
				parent = msg; // first create BPL. parent is current msg.
				long id = createProcessInstance(jbpmCxt, graphSession, msg, cxt);
				processDefinition = graphSession.findLatestProcessDefinition(msg.getMsgCd());
				instance = jbpmCxt.getProcessInstance(id);
			}
			else
			{ // is a response message...
				status = msg.getStatus();
				nodeVO = getNode(msg, cxt);
				instanceVO = getInstance(nodeVO);
				processDefinition = graphSession.findLatestProcessDefinition(instanceVO
						.getProccessName());
				instance = jbpmCxt.getProcessInstance(Long.parseLong(instanceVO.getInstanceId()));

				// handle response msg to parent msg
				parent = converter.deserialize(instanceVO.getParentXml().bytes()); // �ָ�������״̬
				msg.setInLocal(MsgLocalKey.LOCAL_PARENT_MSG, parent);
				parent.setInLocal(MsgLocalKey.LOCAL_SUB_MSG, msg);
				// if (msgMappingService != null)
				// msgMappingService.afterResponse(parent, msg, nodeVO
				// .getNode(), nodeVO.getVer().intValue());
				// else
				// {
				Node lastNode = processDefinition.getNode(nodeVO.getNode()); // ���һ��ִ�еĽڵ�
				if (lastNode == null) log.warn("lastNode(" + nodeVO.getNode() + ") is null!!!");
				else
				{ // �������첽���ã��õ����һ��ִ�еĽڵ㣬Ȼ��������һ�νڵ��Ӧ��ӳ���ϵ
					Event evt = lastNode.getEvent("node-enter");
					List actions = evt == null ? null : evt.getActions();
					if (actions != null && actions.size() > 0)
					{
						Action action = (Action) actions.get(0);
						Object delegation = action.getActionDelegation().instantiate();
						if (delegation instanceof IAfterAsynCall) ((IAfterAsynCall) delegation)
								.after(parent, msg, cxt);
						else log.warn("delegation" + delegation.getClass()
								+ " is not IAfterAsynCall!!!");
					}
				}
				// }
				instanceVO.setParentXml(new ByteArrayBlob(converter.serialize(parent)));
				if (log.isDebugEnabled()) log.debug("after response msg, parent msg is: "
						+ instanceVO.getParentXml());
				// read instance history variables
				if (!StringX.nullity(instanceVO.getVariables())) variables = (Map) JsonUtil
						.json2obj(instanceVO.getVariables());

				// update node
				BPELNodeVO nnodeVO = new BPELNodeVO();
				nnodeVO.setMsgSn(nodeVO.getMsgSn());
				nnodeVO.setStatus(status.isSuccess() ? Status.STATUS_SUCCESS : Status.STATUS_FAIL);
				if (!status.isSuccess())
				{
					nnodeVO.setRetCd(status.getRetCd());
					nnodeVO.setAppCd(status.getAppCd());
					nnodeVO.setLocation(status.getLocation());
					nnodeVO.setRetDesc(status.getDesc());
					nnodeVO.setIp(status.getIp());
				}
				persistence.update(nnodeVO);
				if (Common.YES.equals(nodeVO.getFailAbort()) && status.isFail())
				{ // sub service is fail and bpl node's failabort flag is
					// abort when fail
					throw new AppException(status);
				}
			}

			// to execute next node
			instance.getContextInstance().setTransientVariable(IFlowContext.JBPM_FLOW_CXT_KEY, cxt);
			instance.getContextInstance().setTransientVariable(IFlowContext.JBPM_MSG_KEY, parent);
			if (!parent.getLocal().containsKey(MsgLocalKey.LOCAL_BPL_VARIABLES)) parent.setInLocal(
					MsgLocalKey.LOCAL_BPL_VARIABLES, variables);
			instance.getContextInstance().setVariables(variables);
			instance.getContextInstance().setTransientVariable(Common.MODEL_MSG, parent); // ����ǰ������Ϊ���̵���ʱ����
			Token token = instance.getRootToken();
			token.signal();

			if (parent != msg) msg.addDelayTasks(parent.getDelayTask()); // �������е�δ��ʱ������������뵽��ǰ���Ļ�����
			variables = (Map) parent.getInLocal(MsgLocalKey.LOCAL_BPL_VARIABLES);
			if (instance.hasEnded())
			{ // jpdl has normal end...
				if (log.isInfoEnabled()) log.info("process: " + processDefinition.getName()
						+ ", id: " + instance.getId() + ", parent sn: " + parent.getMsgSn()
						+ " will end...");
				if (log.isDebugEnabled()) log.debug("parent: " + parent.toXml(true));
				instanceVO.setStatus(Status.STATUS_SUCCESS);
				// response to request msg.
				parent.setMsgLocal(null); // 2012-01-25 chenjs ɾ�����ĵ�local��Ϣ
				if (endFNode != null) endFNode.execute(parent, cxt);
				else log.warn("endFNode is null!!!");
				// set success to reponse requester flag
				// msg.setInLocal(REP_SUCCESS_KEY, Boolean.TRUE);
				// delete jbpm instance
				graphSession.deleteProcessInstance(instance.getId());
			}
			else
			{
				BPELNodeVO bnvo = (BPELNodeVO) parent.getInLocal(MsgLocalKey.LOCAL_LAST_NODE);
				if (bnvo != null) persistence.insert(bnvo); // 2012-05-12
															// ��ԭ�ȵ���CreateMsgAsynCallAction����⣬��ʱ����
			}
		}
		catch (Exception e)
		{ // �κ��쳣��ɾ��������Ϣ
			if (e instanceof DelegationException) e = (Exception) ((DelegationException) e)
					.getCause();
			if (instanceVO != null) instanceVO.setStatus(Status.STATUS_FAIL);
			try
			{
				if (instance != null)
				{
					log.warn("force to end process instance: " + instance.getId());
					instance.end();
					graphSession.deleteProcessInstance(instance.getId());
				}
			}
			catch (Exception ex)
			{
				log.warn("handle ex and end instance", ex);
			}
			failAbort(msg, parent, e, cxt);
		}
		finally
		{
			try
			{
				if (instanceVO != null)
				{
					BPELInstanceVO ninstanceVO = new BPELInstanceVO();
					ninstanceVO.setMsgSn(instanceVO.getMsgSn());
					ninstanceVO.setVariables(instanceVO.getVariables());
					if (variables != null && variables.size() > 0) ninstanceVO
							.setVariables(JsonUtil.obj2json(variables));
					ninstanceVO.setParentXml(instanceVO.getParentXml());
					ninstanceVO.setStatus(instanceVO.getStatus());
					persistence.update(ninstanceVO);
				}
			}
			catch (Exception ex)
			{
				log.warn("finally handle instanceVO", ex);
			}
			jbpmCxt.close();
		}
	}

	public JBPM3AsynCFNode()
	{
		name = "jbpm3Asyn";
	}

	public boolean support(IMessage msg)
	{
		if (!msg.isRequestMsg())
		{ // Ӧ����Ϣ
			return Common.APP_CD_BPL.equals(msg.getRefSndApp());
		}
		return true;
	}

	protected void failAbort(IMessage msg, IMessage parent, Exception ex, IFlowContext cxt)
			throws Exception
	{
		if (log.isInfoEnabled()) log.info("failAbort for sn:" + msg.getMsgSn(), ex);
		if (parent == null)
		{
			log.error("failAbort: cannot find parent msg for msg:" + msg.toXml(true), ex);
			return;
		}
		parent.setStatus(SystemUtil.ex2status(parent.getFixedErrDesc(), ex));
		parent.setMsgLocal(null); // 2012-01-25 chenjs ɾ�����ĵ�local��Ϣ
		if (endFNode != null) endFNode.execute(parent, cxt);
	}

	protected BPELNodeVO getNode(IMessage msg, IFlowContext cxt) throws Exception
	{
		BPELNodeVO node = new BPELNodeVO();
		node.setMsgSn(msg.getRefMsgSn());
		// System.out.println("getNode: "+node.getMsgSn()+", "+msg.toXml(true));
		return (BPELNodeVO) persistence.find(node);
	}

	protected BPELInstanceVO getInstance(BPELNodeVO node) throws Exception
	{
		BPELInstanceVO instance = new BPELInstanceVO();
		instance.setMsgSn(node.getRefMsgSn());
		return (BPELInstanceVO) persistence.find(instance);
	}

	/**
	 * ������һ������ı��ġ��������Ϊ
	 * 
	 * @param msg
	 * @param cxt
	 * @throws Exception
	 */
	protected long createProcessInstance(JbpmContext jbpmCxt, GraphSession graphSession,
			IMessage msg, IFlowContext cxt) throws Exception
	{
		String msgCd = msg.getMsgCd();
		ProcessDefinition pdefinition = graphSession.findLatestProcessDefinition(msgCd);
		ProcessInstance instance = new ProcessInstance(pdefinition);

		// insert a row to BPELInstance for a start
		BPELInstanceVO instanceVO = new BPELInstanceVO();
		msg.getMsg().toObject(instanceVO);

		instanceVO.setMsgSn(msg.getMsgSn());
		instanceVO.setMsgCd(msgCd);
		instanceVO.setProccessName(msgCd);
		instanceVO.setVer(String.valueOf(pdefinition.getVersion()));
		instanceVO.setInstanceId(String.valueOf(instance.getId()));
		instanceVO.setStatus(Status.STATUS_UNDERWAY);
		instanceVO.setParentXml(new ByteArrayBlob(converter.serialize(msg)));
		instanceVO.setTmStamp(SystemUtil.getInstance().getCurrentDate(SystemUtil.DF_SALL17));
		persistence.insert(instanceVO);

		jbpmCxt.save(instance);
		return instance.getId();
	}

	public void init() throws Exception
	{
		log.info("JBPM3AsynCFNode init... ");
		super.init();
		jbpmCfg = JbpmConfiguration.parseXmlString(jbpmConfig);
		jbpmCfg.createJbpmContext().close(); // for performance
	}

	protected IFlowNode endFNode; // ��Ϸ����Ӧ������
	protected JbpmConfiguration jbpmCfg;
	protected String jbpmConfig;
	public final static String BPEL_KEY = "BPL";
	protected IMessageConverter converter = new XMLConverter2(false); // bpl�洢ʱ��ɾ��transaction/local��ǩ

	public void setJbpmConfig(String jbpmConfig)
	{
		this.jbpmConfig = jbpmConfig;
	}

	public void setConverter(IMessageConverter converter)
	{
		this.converter = converter;
	}

	public void setEndFNode(IFlowNode endFNode)
	{
		this.endFNode = endFNode;
	}
}
