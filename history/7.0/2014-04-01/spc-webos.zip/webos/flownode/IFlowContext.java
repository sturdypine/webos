package spc.webos.flownode;

import spc.webos.service.IStatus;

public interface IFlowContext extends IStatus
{
	String getName();

	void init() throws Exception;

	public final static String JBPM_FLOW_CXT_KEY = "_JBPM_FLOW_CXT_";
	public final static String JBPM_MSG_KEY = "_JBPM_MSG_";
}
