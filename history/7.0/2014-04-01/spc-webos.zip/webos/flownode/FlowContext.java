package spc.webos.flownode;

import java.util.HashMap;
import java.util.Map;

import spc.webos.log.Log;
import spc.webos.persistence.IPersistence;
import spc.webos.persistence.Persistence;

public class FlowContext implements IFlowContext
{
	protected String name;
	protected IPersistence persistence = Persistence.getInstance();
	protected Log log = Log.getLogger(getClass());

	public IPersistence getPersistence()
	{
		return persistence;
	}

	public String getName()
	{
		return name == null ? getClass().getName() : name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public void init() throws Exception
	{
		if (getName() != null) STATUS.put(getName(), this);
	}

	public void setPersistence(IPersistence persistence)
	{
		this.persistence = persistence;
	}

	public boolean changeStatus(Map param)
	{
		return false;
	}

	public Map checkStatus(Map param)
	{
		Map status = new HashMap();
		status.put("name", name);
		status.put("clazz", getClass());
		return status;
	}

	public void refresh() throws Exception
	{
	}
}
