package spc.webos.web.controller;

/**
 * httpЭ���Message contoller
 */
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.Message;
import spc.webos.data.Status;
import spc.webos.data.converter.IMessageConverter;
import spc.webos.data.converter.XMLConverter2;
import spc.webos.flownode.MessageFlow;
import spc.webos.log.Log;
import spc.webos.util.FileUtil;
import spc.webos.util.NumberX;
import spc.webos.util.StringX;
import spc.webos.util.SystemUtil;

public class MessageCtrller implements Controller
{
	protected Log log = Log.getLogger(getClass());
	protected IMessageConverter converter = XMLConverter2.getInstance();
	protected MessageFlow msgFlow;
	protected String logName; // �����Ҫ�߳���־�����ṩ��־��
	protected String msgKey; // ���������msgKey�����request.getParameter����ñ����ַ���
	protected String reqCharset = Common.CHARSET_UTF8;
	protected String repCharset = Common.CHARSET_UTF8;
	protected String cntType = Common.FILE_XML_CONTENTTYPE;
	protected int hdrLen = 0; // HttpServletRequest �������ֽ�ͷ����
	protected boolean hdrLenBinary;

	public ModelAndView handleRequest(HttpServletRequest req, HttpServletResponse rep)
			throws Exception
	{
		boolean startlog = Log.startWithRequired(logName);
		IMessage msg = null;
		String sn = null;
		try
		{
			if (StringX.nullity(msgKey))
			{
				byte[] xml = null;
				if (hdrLen <= 0)
				{
					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					FileUtil.is2os(req.getInputStream(), baos, true, true);
					xml = baos.toByteArray();
				}
				else
				{ // ���͵�http������������г���ͷ
					InputStream is = req.getInputStream();
					int hdrlen = length(FileUtil.readMsgWithLen(is, hdrLen)); // ��ȡ����
					xml = FileUtil.readMsgWithLen(is, hdrlen); // ��ȡ����
				}

				if (log.isDebugEnabled()) log.debug("req by is: " + new String(xml, reqCharset));
				msg = deserialize(xml, req);
			}
			else
			{
				String strXML = req.getParameter(msgKey);
				if (log.isDebugEnabled()) log.debug("req by MSG: " + strXML);
				msg = deserialize(strXML.getBytes(reqCharset), req);
			}
			sn = msg.getMsgSn();
			sendResponse(rep, execute(msg));
		}
		catch (Throwable t)
		{
			log.info("handleRequest", t);
			if (msg != null)
			{
				Status status = SystemUtil.ex2status(sn, t);
				msg.setStatus(status);
				sendResponse(rep, msg);
			}
			else log.warn("msg is null:", t);
		}
		finally
		{
			if (startlog) Log.print();
		}
		return null;
	}

	protected int length(byte[] lenBytes)
	{
		if (hdrLenBinary) return NumberX.bytes2int(lenBytes);
		return new Integer(new String(lenBytes).trim()).intValue();
	}

	protected byte[] lenBytes(byte[] buf)
	{
		if (hdrLenBinary) return NumberX.int2bytes(buf.length);
		// ���ȹ̶�Ϊ10���Ƶ�8���ֽڣ�����ǰ�油0
		return StringX.int2str(String.valueOf(buf.length), hdrLen).getBytes();
	}

	protected IMessage deserialize(byte[] xml, HttpServletRequest req) throws Exception
	{
		Message reqmsg = new Message();
		String ip = req.getRemoteHost();
		int index = ip.indexOf(':');
		ip = index > 0 ? ip.substring(0, index) : ip;
		reqmsg.setInLocal(MsgLocalKey.ACCEPTOR_REMOTE_HOST, ip);
		reqmsg.setInLocal(MsgLocalKey.ACCEPTOR_LOCAL_PORT, String.valueOf(req.getLocalPort()));
		IMessage msg = converter.deserialize(xml, reqmsg);
		msg.setInLocal(MsgLocalKey.ACCEPTOR_PROTOCOL, Common.ACCEPTOR_PROTOCOL_HTTP);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, xml);
		msg.setInLocal(MsgLocalKey.LOCAL_MSG_CONVERTER, converter);
		msg.setInLocal(MsgLocalKey.ACCEPTOR_REMOTE_HOST, ip);
		msg.setInLocal(MsgLocalKey.ACCEPTOR_LOCAL_PORT, String.valueOf(req.getLocalPort()));
		if (msgFlow != null) msg.setInLocal(MsgLocalKey.LOCAL_MSG_MSGFLOW, msgFlow);
		return msg;
	}

	protected void sendResponse(HttpServletResponse res, IMessage resmsg) throws Exception
	{
		res.setContentType(cntType);
		byte[] buf = converter.serialize(resmsg);
		if (log.isDebugEnabled()) log.debug("repbuf: " + new String(buf, repCharset));
		res.setCharacterEncoding(Common.CHARSET_UTF8);
		if (hdrLen > 0) res.getOutputStream().write(lenBytes(buf));
		res.getOutputStream().write(buf);
		res.getOutputStream().flush();
	}

	protected IMessage execute(IMessage msg) throws Throwable
	{
		msgFlow.execute(msg);
		return msg;
	}

	public void setMsgFlow(MessageFlow msgFlow)
	{
		this.msgFlow = msgFlow;
	}

	public void setConverter(IMessageConverter converter)
	{
		this.converter = converter;
	}

	public void setLogName(String logName)
	{
		this.logName = logName;
	}

	public void setMsgKey(String msgKey)
	{
		this.msgKey = msgKey;
	}

	public void setReqCharset(String reqCharset)
	{
		this.reqCharset = reqCharset;
	}

	public void setRepCharset(String repCharset)
	{
		this.repCharset = repCharset;
	}

	public void setCntType(String cntType)
	{
		this.cntType = cntType;
	}

	public void setHdrLen(int hdrLen)
	{
		this.hdrLen = hdrLen;
	}

	public void setHdrLenBinary(boolean hdrLenBinary)
	{
		this.hdrLenBinary = hdrLenBinary;
	}
}
