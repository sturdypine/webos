package spc.webos.acceptor.fnode;

import spc.webos.acceptor.SocketMessage;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.endpoint.Endpoint;
import spc.webos.endpoint.EndpointFactory;
import spc.webos.endpoint.Executable;

public class ForwardTCPResponseAFNode extends TCPResponseAFNode
{
	protected Object msg2sndobj(IMessage msg) throws Exception
	{
		SocketMessage smsg = (SocketMessage) msg
				.getInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_SOCKETMSG);
		Executable exe = new Executable();
		exe.request = smsg.reqmsg;
		endpoint.execute(exe);
		smsg.repmsg = exe.response;
		return smsg;
	}

	protected Endpoint endpoint;

	public void setEndpoint(Endpoint endpoint)
	{
		this.endpoint = endpoint;
	}

	public void setEndpoint(String endpoint) throws Exception
	{
		this.endpoint = EndpointFactory.getInstance().getEndpoint(endpoint);
	}
}
