package spc.webos.acceptor.tcp;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;

import spc.webos.acceptor.SocketMessage;
import spc.webos.constant.Common;
import spc.webos.constant.MsgLocalKey;
import spc.webos.data.IMessage;
import spc.webos.data.Message;
import spc.webos.log.Log;
import spc.webos.thread.DaemonThread;
import spc.webos.util.FileUtil;

/**
 * �������ĵĻ����߳���
 * 
 * @author spc
 * 
 */
public class HandlerThread extends DaemonThread
{
	public void run()
	{
		startThreadLog();
		if (log.isInfoEnabled()) log.info("HandlerThread(" + Thread.currentThread().getName()
				+ ") start, remote:" + s.getRemoteSocketAddress());
		status = RUNNING;
		acceptor.addHandler(this);
		try
		{ // ֻҪ������û�йرգ���ͻ��˿��Գ����ӵĽ���
			// while (!s.isInputShutdown() && acceptor.getStatus() == RUNNING)
			// {
			// chenjs 2012-12-12 ֻ֧�ֶ�����
			IMessage msg = recieve();
			if (msg != null)
			{
				if (acceptor.getReqbuf() != null) acceptor.getReqbuf().put(msg);
				else log.debug("reqbuf is null!!!");
			}
		}
		catch (Throwable t)
		{
			log.info("HandlerThread.run", t);
			close();
		}
		finally
		{ // һ�����������رգ� ���첽��������߳�Ҳ��ֹͣ����ֹͣǰΪ�˱�֤����������һ���������Ϣ�����˯��1���ֹͣ
			status = STOPPED;
			acceptor.removeHandler(this);
			// close();
		}
		if (log.isInfoEnabled()) log.info("ServerThread(" + Thread.currentThread().getName()
				+ ") stop!!! remote:" + s.getRemoteSocketAddress() + ", local port:" + s.getPort());
		Log.print();
		Log.printNotice();
	}

	public void execute() throws Exception
	{
	}

	/**
	 * �ӽ������л�ȡһ������
	 * 
	 * @return
	 * @throws Exception
	 */
	protected IMessage recieve() throws Exception
	{
		if (bis == null) bis = new BufferedInputStream(s.getInputStream());
		if (os == null) os = s.getOutputStream();

		byte[] buf = null;
		if (acceptor.getHdrLen() > 0)
		{ // chenjs 2012-12-12
			byte[] lenBytes = new byte[acceptor.getHdrLen()];
			bis.read(lenBytes);
			int len = acceptor.length(lenBytes);
			if (acceptor.getMaxbytes() > 0 && len > acceptor.getMaxbytes())
			{
				handleOverSizeMsg(len);
				return null;
			}
			buf = FileUtil.readMsgWithLen(bis, len);
		}
		else
		{ // û���κν�����־��ǰ���Ƕ����ӷ�����
			buf = FileUtil.readMsgWithLen(bis, null); // ���������ж�ȡ������������
		}
		return buf2msg(buf);
	}

	protected IMessage buf2msg(byte[] buf)
	{
		if (buf == null)
		{
			log.debug("buf is null!!!");
			return null; // ˵���������Ѿ��ر�
		}
		Message msg = new Message();
		SocketMessage smsg = new SocketMessage(s, os, buf, acceptor.getHdrLen(), null,
				Common.ACCEPTOR_PROTOCOL_TCPIP);
		String ip = smsg.remoteAddress.getHostAddress();
		int index = ip.indexOf(':');
		msg.setInLocal(MsgLocalKey.ACCEPTOR_REMOTE_HOST, index > 0 ? ip.substring(0, index) : ip);
		msg.setInLocal(MsgLocalKey.ACCEPTOR_LOCAL_PORT, String.valueOf(smsg.localPort));
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_SOCKETMSG, smsg); // ���������Ϣ��ԭʼ��Ϣ
		msg.setInLocal(MsgLocalKey.ACCEPTOR_PROTOCOL, smsg.protocol);
		msg.setInLocal(MsgLocalKey.LOCAL_REP_BUFFER, smsg.repbuf);
		msg.setInLocal(MsgLocalKey.LOCAL_ORIGINAL_REQ_BYTES, smsg.reqmsg);
		msg.setInLocal(MsgLocalKey.LOCAL_MSG_CONVERTER, acceptor.getConverter());
		msg.setInLocal(MsgLocalKey.LOCAL_MSGCVT_DELAY, Boolean.TRUE); // �ӳٽ���
		if (acceptor.getMsgFlow() != null) msg.setInLocal(MsgLocalKey.LOCAL_MSG_MSGFLOW,
				acceptor.getMsgFlow());
		return msg;
	}

	protected boolean handleOverSizeMsg(int len) throws IOException
	{
		log.warn("too long msg, localPort:" + acceptor.getPort() + ",remote: "
				+ s.getRemoteSocketAddress() + ", len:" + len + ", maxbytes:"
				+ acceptor.getMaxbytes() + ", cnn will close!!!");
		s.close();
		return false;
	}

	public void close()
	{
		try
		{
			if (os != null) os.close();
		}
		catch (Throwable t)
		{
		}
		os = null;
		try
		{
			if (bis != null) bis.close();
		}
		catch (Throwable t)
		{
		}
		bis = null;
		try
		{
			s.close();
		}
		catch (Throwable t)
		{
		}
	}

	public boolean startThreadLog()
	{
		if (acceptor.getLogName() == null) return false;
		Log.start(acceptor.getLogName());
		Log.setFTLCondition(acceptor.getLogScript()); // ������־�ű����̻߳�����,���Ա���ҵ���߳��Լ�����,
		return true;
	}

	public HandlerThread()
	{
	}

	public HandlerThread(TCPAcceptor acceptor, Socket s)
	{
		this.acceptor = acceptor;
		this.s = s;
	}

	public void init(TCPAcceptor acceptor, Socket s)
	{
		this.acceptor = acceptor;
		this.s = s;
	}

	protected TCPAcceptor acceptor;
	protected Socket s; // �׽��ֲ�������
	protected OutputStream os; // socket�����
	protected BufferedInputStream bis; // socket������
}
