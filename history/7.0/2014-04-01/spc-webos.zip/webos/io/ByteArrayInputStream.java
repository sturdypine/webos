package spc.webos.io;

import java.io.IOException;
import java.io.InputStream;

public class ByteArrayInputStream extends InputStream
{
	protected ByteArray buf;
	protected int pos = 0;

	public ByteArrayInputStream()
	{
		this.buf = new ByteArray();
	}

	public ByteArrayInputStream(ByteArray buf)
	{
		this.buf = buf;
	}

	public int read() throws IOException
	{
		return buf.read(pos++);
	}

	public int read(byte b[], int off, int len) throws IOException
	{
		int l = buf.read(b, off, len, pos);
		if (l > 0) pos += l;
		return l;
	}

	public void reset()
	{
		pos = 0;
	}

	public ByteArray getBuf()
	{
		return buf;
	}

	public void setBuf(ByteArray buf)
	{
		this.buf = buf;
	}

	public int getPos()
	{
		return pos;
	}

	public void setPos(int pos)
	{
		this.pos = pos;
	}
}
