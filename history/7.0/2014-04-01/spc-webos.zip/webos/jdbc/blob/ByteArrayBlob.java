package spc.webos.jdbc.blob;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import spc.webos.util.StringX;

public class ByteArrayBlob extends AbstractBlob
{
	private static final long serialVersionUID = 1L;
	int len;
	byte[] buf;
	int offset;

	public ByteArrayBlob(byte[] buf)
	{
		this.buf = buf;
		this.offset = 0;
		len = buf.length;
	}

	public ByteArrayBlob(byte[] buf, int offset, int len)
	{
		this.buf = buf;
		this.offset = offset;
		this.len = len;
	}

	public InputStream inputStream() throws IOException
	{
		return (is = new ByteArrayInputStream(buf, offset, len));
	}

	public int length()
	{
		return len;
	}

	public String base64() throws Exception
	{
		if (buf == null) return StringX.EMPTY_STRING;
		return new String(StringX.encodeBase64(bytes()));
	}

	public byte[] bytes()
	{
		if (buf == null) return null;
		if (offset <= 0) return buf;
		byte[] content = new byte[len];
		System.arraycopy(buf, offset, content, 0, len);
		return content;
	}
}
