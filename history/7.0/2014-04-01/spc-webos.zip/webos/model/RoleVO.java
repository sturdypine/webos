package spc.webos.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
* genarated by sturdypine.chen
* Email: sturdypine@gmail.com
* description: 
*/
public class RoleVO implements ValueObject
{
	public static final long serialVersionUID = 20100608L;
	// ����������Ӧ�ֶε�����
	String id; //  ����
	String name; // 
	String orgId;
	String depId;
	String menu; // 
	String remark; // 

	// �ʹ�VO�����������VO����
	
	// �ʹ�VO�������������Sql����
	// Note: ���������Sql����ΪString, Inegter...��Java final classʱ�� ֻ��ʹ��Object���� ����ʱ��ֻ��ͨ��
	// Object��toString()������ʹ�á�
	public static final String TABLE = "sys_role";
	public static final String[] BLOB_FIELD = null;
	public static final String SEQ_NAME = "id";

	
	public RoleVO()
	{
	}
	
	public void setPrimary(String id)
	{
		this.id = id;
	}
	
	public String getPrimary(String delim)
	{
		StringBuffer buf = new StringBuffer();
		buf.append(this.id);
		return buf.toString();
	}
	
	public Map getPrimary()
	{
		Map m = new HashMap();
		m.put("id", id);
		return m;
	}
	
	public String getTable()
	{
		return TABLE;
	}
	
	public String[] getBlobField()
	{
		return BLOB_FIELD;
	}
	
	public String getKeyName()
	{
		return SEQ_NAME;
	}
	
	public Serializable getKey()
	{
		return id;
	}
	
	// set all properties to NULL
	public void setNULL()
	{
    	this.id = null;
    	this.name = null;
    	this.menu = null;
    	this.remark = null;
	}
	
	public boolean equals(Object o)
	{
		if (this == o) return true;
		if (!(o instanceof RoleVO)) return false;
		RoleVO obj = (RoleVO) o;
		if (!id.equals(obj.id)) return false;
		if (!name.equals(obj.name)) return false;
		if (!menu.equals(obj.menu)) return false;
		if (!remark.equals(obj.remark)) return false;
		return true;
	}
	
	// ֻ����������ɢ��
	public int hashCode()
	{
		long hashCode = getClass().hashCode();
		if (id != null) hashCode += id.hashCode();
		return (int)hashCode;
	}
	
	public int compareTo(Object o)
	{
		return -1;
	}

	// set all properties to default value...
	public void init()
	{
	}
	
    public String getId()
    {
        return id;
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public String getName()
    {
        return name;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getMenu()
    {
        return menu;
    }
    
    public void setMenu(String menu)
    {
        this.menu = menu;
    }
    
    public String getRemark()
    {
        return remark;
    }
    
    public void setRemark(String remark)
    {
        this.remark = remark;
    }
    
	
	public void set(RoleVO vo)
	{
    	this.id = vo.id;
    	this.name = vo.name;
    	this.menu = vo.menu;
    	this.remark = vo.remark;
	}
	
	public static long getSerialVersionUID()
	{
		return serialVersionUID;
	}
	
	public StringBuffer toJson()
	{
		StringBuffer buf = new StringBuffer();
		buf.append('{');
		if (id != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("id:'");
			buf.append(id);
			buf.append('\'');
		}
		if (name != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("name:'");
			buf.append(name);
			buf.append('\'');
		}
		if (menu != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("menu:'");
			buf.append(menu);
			buf.append('\'');
		}
		if (remark != null)
		{
			if (buf.length() > 2) buf.append(',');
			buf.append("remark:'");
			buf.append(remark);
			buf.append('\'');
		}
		buf.append('}');
		return buf;
	}
	
	public void afterLoad()
	{
		// TODO Auto-generated method stub

	}

	public void beforeLoad()
	{
		// TODO Auto-generated method stub

	}

	public void setManualSeq(Long seq)
	{
		
	}
	
	public void destory()
	{

	}
	
	public String getOrgId()
	{
		return orgId;
	}

	public void setOrgId(String orgId)
	{
		this.orgId = orgId;
	}

	public String getDepId()
	{
		return depId;
	}

	public void setDepId(String depId)
	{
		this.depId = depId;
	}

	public String toString()
	{
		StringBuffer buf = new StringBuffer(128);
		buf.append(getClass().getName() + "(serialVersionUID=" + serialVersionUID + "):");
		buf.append(toJson());
		return buf.toString();
	}
}
